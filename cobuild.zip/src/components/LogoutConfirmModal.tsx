import React, { useEffect } from 'react';
import { createPortal } from 'react-dom';
import { LogOut, X } from 'lucide-react';

interface LogoutConfirmModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  loading?: boolean;
}

export const LogoutConfirmModal: React.FC<LogoutConfirmModalProps> = ({
  isOpen,
  onClose,
  onConfirm,
  loading = false,
}) => {
  // Prevent background scrolling while confirmation dialog is open
  useEffect(() => {
    if (isOpen && typeof document !== 'undefined') {
      const originalOverflow = document.body.style.overflow;
      document.body.style.overflow = 'hidden';
      return () => {
        document.body.style.overflow = originalOverflow;
      };
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const modalContent = (
    <div
      id="logout-confirm-overlay"
      className="fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-[#1A1A1A]/40 backdrop-blur-xs animate-in fade-in duration-200"
      onClick={onClose}
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        width: '100vw',
        height: '100vh',
      }}
    >
      <div
        id="logout-confirm-dialog"
        className="relative w-full max-w-sm rounded-3xl border border-[#E5E2DA] bg-[#FFFFFF] p-6 shadow-2xl transition-all"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          id="btn-close-logout-modal"
          onClick={onClose}
          className="absolute right-4 top-4 rounded-xl p-1.5 text-[#8A8578] hover:bg-[#F5F1E8] hover:text-[#1A1A1A] transition-colors"
          title="Close"
        >
          <X className="h-4 w-4" />
        </button>

        <div className="flex flex-col items-center text-center">
          <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-[#FDE4D8] border border-[#E8491D]/30 text-[#E8491D] shadow-xs">
            <LogOut className="h-6 w-6" />
          </div>

          <h3 id="logout-confirm-title" className="text-base font-bold text-[#1A1A1A]">
            Are you sure you want to log out?
          </h3>
          <p className="mt-1.5 text-xs text-[#55524A] leading-relaxed">
            You will need to sign in again to access your collaboration tickets and profile.
          </p>

          <div className="mt-6 flex w-full items-center justify-end gap-2.5">
            <button
              id="btn-logout-cancel"
              type="button"
              onClick={onClose}
              className="flex-1 rounded-xl border border-[#E5E2DA] bg-[#FAF8F3] py-2 px-4 text-xs font-semibold text-[#1A1A1A] hover:bg-[#F5F1E8] transition-colors"
            >
              Cancel
            </button>
            <button
              id="btn-logout-confirm"
              type="button"
              disabled={loading}
              onClick={() => {
                onConfirm();
                onClose();
              }}
              className="flex-1 rounded-xl bg-[#E8491D] hover:bg-[#FF5722] py-2 px-4 text-xs font-semibold text-white shadow-xs transition hover:-translate-y-0.5 active:translate-y-0 disabled:opacity-50"
            >
              Log Out
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  return typeof document !== 'undefined' ? createPortal(modalContent, document.body) : modalContent;
};
