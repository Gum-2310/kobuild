import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { UserProfile, UserSection, PreferredTrack, ConversationContext } from '../types';
import { getOrCreateDirectConversation } from '../services/userService';
import {
  MessageSquare,
  MapPin,
  Sparkles,
  X,
  GraduationCap,
  Home as HomeIcon,
  Briefcase,
  Users,
  Send,
  Loader2,
  ExternalLink,
} from 'lucide-react';

interface UserProfilePopoverProps {
  isOpen: boolean;
  onClose: () => void;
  targetUser: {
    uid: string;
    name: string;
    photoURL?: string | null;
    section?: UserSection | null;
    preferredTrack?: PreferredTrack | null;
    location?: string;
    bio?: string;
    skills?: string[];
  };
  context?: ConversationContext;
  onOpenChatWithUser?: (conversationId: string) => void;
  onOpenAuth: () => void;
}

export const UserProfilePopover: React.FC<UserProfilePopoverProps> = ({
  isOpen,
  onClose,
  targetUser,
  context,
  onOpenChatWithUser,
  onOpenAuth,
}) => {
  const { user, userProfile } = useAuth();
  const [messageText, setMessageText] = useState('');
  const [sending, setSending] = useState(false);
  const [sentSuccess, setSentSuccess] = useState(false);

  if (!isOpen) return null;

  const isSelf = Boolean(user && user.uid === targetUser.uid);

  const effectiveTrack =
    targetUser.preferredTrack !== undefined
      ? targetUser.preferredTrack === 'none'
        ? null
        : targetUser.preferredTrack
      : targetUser.section;

  const getSectionIcon = (sec?: UserSection | PreferredTrack | null) => {
    switch (sec) {
      case 'student':
        return <GraduationCap className="h-3.5 w-3.5 text-[#E8491D]" />;
      case 'homemaker':
        return <HomeIcon className="h-3.5 w-3.5 text-emerald-600" />;
      case 'entrepreneur':
        return <Briefcase className="h-3.5 w-3.5 text-purple-600" />;
      case 'community':
        return <Users className="h-3.5 w-3.5 text-[#E8491D]" />;
      default:
        return <Sparkles className="h-3.5 w-3.5 text-[#E8491D]" />;
    }
  };

  const getSectionBadgeClass = (sec?: UserSection | PreferredTrack | null) => {
    switch (sec) {
      case 'student':
        return 'bg-[#FDE4D8] text-[#E8491D] border-[#E8491D]/40';
      case 'homemaker':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case 'entrepreneur':
        return 'bg-purple-50 text-purple-700 border-purple-200';
      case 'community':
        return 'bg-[#FDE4D8] text-[#E8491D] border-[#E8491D]/40';
      default:
        return 'bg-[#FAF8F3] text-[#55524A] border-[#E5E2DA]';
    }
  };

  const getTrackLabel = (sec?: UserSection | PreferredTrack | null) => {
    switch (sec) {
      case 'student':
        return 'Student';
      case 'homemaker':
        return 'Homemaker';
      case 'entrepreneur':
        return 'Entrepreneur';
      case 'community':
        return 'Community';
      default:
        return 'Builder';
    }
  };

  const handleStartChat = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !userProfile) {
      onOpenAuth();
      return;
    }

    if (isSelf) return;

    setSending(true);
    try {
      const convId = await getOrCreateDirectConversation(
        userProfile,
        targetUser.uid,
        context,
        messageText.trim() ? messageText.trim() : undefined
      );

      setSentSuccess(true);
      setTimeout(() => {
        setSending(false);
        onClose();
        if (onOpenChatWithUser) {
          onOpenChatWithUser(convId);
        }
      }, 400);
    } catch (err) {
      console.error('Failed to start chat:', err);
      setSending(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-[#1A1A1A]/40 p-4 backdrop-blur-xs animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md rounded-3xl border border-[#E5E2DA] bg-[#FFFFFF] p-6 shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top bar */}
        <div className="flex items-start justify-between pb-3 border-b border-[#E5E2DA]">
          <div className="flex items-center gap-2">
            <span
              className={`inline-flex items-center gap-1.5 rounded-md px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider border ${getSectionBadgeClass(
                effectiveTrack
              )}`}
            >
              {getSectionIcon(effectiveTrack)}
              {getTrackLabel(effectiveTrack)}
            </span>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1 text-[#8A8578] hover:bg-[#F2EFE6] hover:text-[#1A1A1A] transition"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Profile Card Header */}
        <div className="pt-4 flex items-center gap-3.5">
          {targetUser.photoURL ? (
            <img
              src={targetUser.photoURL}
              alt={targetUser.name}
              className="h-14 w-14 rounded-2xl object-cover border border-[#E5E2DA] shadow-xs"
              referrerPolicy="no-referrer"
            />
          ) : (
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-[#FDE4D8] border border-[#E8491D]/30 text-[#E8491D] text-xl font-bold">
              {(targetUser.name || 'B').charAt(0).toUpperCase()}
            </div>
          )}
          <div className="flex-1 min-w-0">
            <h3 className="text-base font-bold text-[#1A1A1A] truncate">{targetUser.name}</h3>
            {targetUser.location && (
              <p className="flex items-center gap-1 text-xs text-[#55524A] mt-0.5">
                <MapPin className="h-3 w-3 text-[#8A8578]" />
                <span className="truncate">{targetUser.location}</span>
              </p>
            )}
          </div>
        </div>

        {/* Bio */}
        {targetUser.bio && (
          <div className="mt-4 rounded-xl bg-[#FAF8F3] border border-[#E5E2DA] p-3 text-xs text-[#55524A] leading-relaxed">
            {targetUser.bio}
          </div>
        )}

        {/* Skills */}
        {Array.isArray(targetUser.skills) && targetUser.skills.length > 0 && (
          <div className="mt-3">
            <div className="text-[10px] font-bold uppercase tracking-wider text-[#8A8578] mb-1.5">
              Skills &amp; Expertise
            </div>
            <div className="flex flex-wrap gap-1.5">
              {targetUser.skills.slice(0, 6).map((skill, idx) => (
                <span
                  key={idx}
                  className="rounded-md bg-[#F2EFE6] border border-[#E5E2DA] px-2 py-0.5 text-[11px] text-[#1A1A1A]"
                >
                  {skill}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Direct Message Action */}
        {!isSelf ? (
          <form onSubmit={handleStartChat} className="mt-5 pt-4 border-t border-[#E5E2DA] space-y-3">
            <label className="block text-xs font-semibold text-[#1A1A1A]">
              Send a Direct Message
            </label>
            <div className="relative">
              <input
                type="text"
                value={messageText}
                onChange={(e) => setMessageText(e.target.value)}
                placeholder={
                  context?.title
                    ? `Hi ${targetUser.name.split(' ')[0]}, let's discuss "${context.title}"...`
                    : `Hi ${targetUser.name.split(' ')[0]}, I'd love to connect on CoBuild...`
                }
                className="w-full rounded-xl border border-[#E5E2DA] bg-[#FFFFFF] pl-3.5 pr-10 py-2.5 text-xs text-[#1A1A1A] placeholder:text-[#8A8578] focus:border-[#E8491D] focus:outline-none"
              />
              <button
                type="submit"
                disabled={sending}
                className="absolute right-1.5 top-1.5 flex h-7 w-7 items-center justify-center rounded-lg bg-[#E8491D] text-white hover:bg-[#FF5722] disabled:opacity-50 transition"
              >
                {sending ? (
                  <Loader2 className="h-3.5 w-3.5 animate-spin" />
                ) : (
                  <Send className="h-3.5 w-3.5" />
                )}
              </button>
            </div>
            <p className="text-[10px] text-[#8A8578]">
              Opens an encrypted direct conversation channel with {targetUser.name}.
            </p>
          </form>
        ) : (
          <div className="mt-5 pt-4 border-t border-[#E5E2DA] text-center text-xs text-[#8A8578]">
            This is your own profile.
          </div>
        )}
      </div>
    </div>
  );
};
