import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { UserSection } from '../types';
import { formatAuthError } from '../utils/authErrors';
import {
  X,
  Mail,
  Lock,
  User,
  AlertCircle,
  Loader2,
  CheckCircle2,
} from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialMode?: 'signin' | 'signup';
  targetSection?: UserSection | null;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  initialMode = 'signin',
}) => {
  const {
    signInWithEmail,
    signUpWithEmail,
    signInWithGoogle,
    error: authError,
    clearError,
  } = useAuth();

  const [mode, setMode] = useState<'signin' | 'signup'>(initialMode);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const [invalidField, setInvalidField] = useState<'name' | 'email' | 'password' | 'confirmPassword' | null>(null);

  useEffect(() => {
    if (isOpen) {
      setMode(initialMode);
      setFormError(null);
      setInvalidField(null);
      clearError();
    }
  }, [isOpen, initialMode]);

  if (!isOpen) return null;

  const handleModeSwitch = (newMode: 'signin' | 'signup') => {
    setMode(newMode);
    setFormError(null);
    setInvalidField(null);
    clearError();
  };

  const handleClose = () => {
    setFormError(null);
    setInvalidField(null);
    clearError();
    onClose();
  };

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    setInvalidField(null);
    clearError();

    const trimmedEmail = email.trim().toLowerCase();
    const trimmedName = name.trim();

    // 1. Validation for Sign Up
    if (mode === 'signup') {
      if (!trimmedName) {
        setFormError('Please enter your full name.');
        setInvalidField('name');
        return;
      }

      if (trimmedName.length < 2) {
        setFormError('Name must be at least 2 characters.');
        setInvalidField('name');
        return;
      }

      if (!trimmedEmail) {
        setFormError('Please enter your email address.');
        setInvalidField('email');
        return;
      }

      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(trimmedEmail)) {
        setFormError('Invalid email address. Please enter a valid email format (e.g. name@example.com).');
        setInvalidField('email');
        return;
      }

      if (!password) {
        setFormError('Please enter a password.');
        setInvalidField('password');
        return;
      }

      if (password.length < 6) {
        setFormError('Password is too weak. Please use at least 6 characters.');
        setInvalidField('password');
        return;
      }

      if (password !== confirmPassword) {
        setFormError('Passwords do not match. Please verify your confirmation password.');
        setInvalidField('confirmPassword');
        return;
      }
    } else {
      // Sign In validation
      if (!trimmedEmail) {
        setFormError('Please enter your email address.');
        setInvalidField('email');
        return;
      }

      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(trimmedEmail)) {
        setFormError('Invalid email address. Please enter a valid email format (e.g. name@example.com).');
        setInvalidField('email');
        return;
      }

      if (!password) {
        setFormError('Please enter your password.');
        setInvalidField('password');
        return;
      }
    }

    setSubmitting(true);
    try {
      if (mode === 'signin') {
        await signInWithEmail(trimmedEmail, password);
      } else {
        await signUpWithEmail(trimmedEmail, password, trimmedName);
      }
      handleClose();
    } catch (err: unknown) {
      const friendlyMsg = formatAuthError(err);
      setFormError(friendlyMsg);

      // Intelligently highlight the offending field
      const lower = friendlyMsg.toLowerCase();
      if (lower.includes('email')) {
        setInvalidField('email');
      } else if (lower.includes('password') || lower.includes('credential')) {
        setInvalidField('password');
      } else if (lower.includes('name')) {
        setInvalidField('name');
      }
    } finally {
      setSubmitting(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setFormError(null);
    setInvalidField(null);
    clearError();
    setSubmitting(true);
    try {
      await signInWithGoogle();
      handleClose();
    } catch (err: unknown) {
      const friendlyMsg = formatAuthError(err);
      if (!friendlyMsg.includes('cancelled before completion')) {
        setFormError(friendlyMsg);
      }
    } finally {
      setSubmitting(false);
    }
  };

  const displayError = formError || authError;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-[#1A1A1A]/40 p-4 backdrop-blur-xs animate-in fade-in duration-200"
      onClick={handleClose}
      id="auth-modal-backdrop"
    >
      <div
        className="relative w-full max-w-md rounded-3xl border border-[#E5E2DA] bg-[#FFFFFF] p-6 sm:p-8 shadow-2xl transition-all"
        onClick={(e) => e.stopPropagation()}
        id="auth-modal-content"
      >
        {/* Close button */}
        <button
          id="btn-close-auth-modal"
          onClick={handleClose}
          className="absolute right-4 top-4 rounded-xl p-2 text-[#8A8578] hover:bg-[#F5F1E8] hover:text-[#1A1A1A] transition-colors"
          aria-label="Close dialog"
        >
          <X className="h-5 w-5" />
        </button>

        {/* Header */}
        <div className="mb-5 text-center">
          <h2 className="text-xl font-bold tracking-tight text-[#1A1A1A]">
            {mode === 'signin' ? 'Welcome Back' : 'Join kobuildd'}
          </h2>
          <p className="mt-1 text-xs text-[#55524A]">
            {mode === 'signin'
              ? 'Sign in to collaborate, build, and discover opportunities'
              : 'Create your profile to collaborate, build, and grow'}
          </p>
        </div>

        {/* Tab switch */}
        <div className="mb-5 flex rounded-xl bg-[#F2EFE6] p-1 border border-[#E5E2DA]">
          <button
            id="tab-auth-signin"
            type="button"
            onClick={() => handleModeSwitch('signin')}
            className={`w-1/2 rounded-lg py-1.5 text-xs font-semibold transition ${
              mode === 'signin'
                ? 'bg-[#E8491D] text-white shadow-xs'
                : 'text-[#55524A] hover:text-[#1A1A1A]'
            }`}
          >
            Sign In
          </button>
          <button
            id="tab-auth-signup"
            type="button"
            onClick={() => handleModeSwitch('signup')}
            className={`w-1/2 rounded-lg py-1.5 text-xs font-semibold transition ${
              mode === 'signup'
                ? 'bg-[#E8491D] text-white shadow-xs'
                : 'text-[#55524A] hover:text-[#1A1A1A]'
            }`}
          >
            Create Account
          </button>
        </div>

        {/* Error Alert */}
        {displayError && (
          <div
            id="auth-error-message"
            className="mb-4 flex items-start gap-2 rounded-xl bg-rose-50 p-3 text-xs text-rose-700 border border-rose-200 animate-in fade-in duration-150"
          >
            <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
            <span className="leading-tight font-medium">{displayError}</span>
          </div>
        )}

        {/* Google One-Click Sign-In */}
        <button
          id="btn-google-auth"
          type="button"
          disabled={submitting}
          onClick={handleGoogleSignIn}
          className="flex w-full items-center justify-center gap-3 rounded-xl border border-[#E5E2DA] bg-[#FAF8F3] py-2.5 px-4 text-xs font-semibold text-[#1A1A1A] shadow-xs transition hover:bg-[#F5F1E8] hover:border-[#D4D0C5] disabled:opacity-50"
        >
          <svg className="h-4 w-4 shrink-0" viewBox="0 0 24 24">
            <path
              fill="#4285F4"
              d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
            />
            <path
              fill="#34A853"
              d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
            />
            <path
              fill="#FBBC05"
              d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
            />
            <path
              fill="#EA4335"
              d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
            />
          </svg>
          <span>Continue with Google</span>
        </button>

        <div className="my-4 flex items-center gap-3">
          <div className="h-px flex-1 bg-[#E5E2DA]" />
          <span className="text-[10px] uppercase tracking-widest text-[#8A8578] font-bold font-mono">
            or with email
          </span>
          <div className="h-px flex-1 bg-[#E5E2DA]" />
        </div>

        {/* Email Form */}
        <form onSubmit={handleEmailAuth} noValidate className="space-y-3">
          {mode === 'signup' && (
            <div>
              <label className="mb-1 block text-xs font-semibold text-[#1A1A1A]">
                Full Name <span className="text-[#E8491D]">*</span>
              </label>
              <div className="relative">
                <User className="pointer-events-none absolute left-3 top-2.5 h-4 w-4 text-[#8A8578]" />
                <input
                  id="input-auth-name"
                  type="text"
                  value={name}
                  onChange={(e) => {
                    setName(e.target.value);
                    if (invalidField === 'name') setInvalidField(null);
                  }}
                  placeholder="e.g. Alex Morgan"
                  className={`w-full rounded-xl border bg-[#FFFFFF] py-2 pl-9 pr-3 text-xs text-[#1A1A1A] placeholder:text-[#8A8578] focus:outline-none transition ${
                    invalidField === 'name'
                      ? 'border-rose-400 focus:border-rose-500 ring-1 ring-rose-300'
                      : 'border-[#E5E2DA] focus:border-[#E8491D]'
                  }`}
                />
              </div>
            </div>
          )}

          {/* Email */}
          <div>
            <label className="mb-1 block text-xs font-semibold text-[#1A1A1A]">
              Email Address <span className="text-[#E8491D]">*</span>
            </label>
            <div className="relative">
              <Mail className="pointer-events-none absolute left-3 top-2.5 h-4 w-4 text-[#8A8578]" />
              <input
                id="input-auth-email"
                type="email"
                value={email}
                onChange={(e) => {
                  setEmail(e.target.value);
                  if (invalidField === 'email') setInvalidField(null);
                }}
                placeholder="name@example.com"
                className={`w-full rounded-xl border bg-[#FFFFFF] py-2 pl-9 pr-3 text-xs text-[#1A1A1A] placeholder:text-[#8A8578] focus:outline-none transition ${
                  invalidField === 'email'
                    ? 'border-rose-400 focus:border-rose-500 ring-1 ring-rose-300'
                    : 'border-[#E5E2DA] focus:border-[#E8491D]'
                }`}
              />
            </div>
          </div>

          {/* Password */}
          <div>
            <label className="mb-1 block text-xs font-semibold text-[#1A1A1A]">
              Password <span className="text-[#E8491D]">*</span>
            </label>
            <div className="relative">
              <Lock className="pointer-events-none absolute left-3 top-2.5 h-4 w-4 text-[#8A8578]" />
              <input
                id="input-auth-password"
                type="password"
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  if (invalidField === 'password') setInvalidField(null);
                }}
                placeholder="•••••••• (min. 6 characters)"
                className={`w-full rounded-xl border bg-[#FFFFFF] py-2 pl-9 pr-3 text-xs text-[#1A1A1A] placeholder:text-[#8A8578] focus:outline-none transition ${
                  invalidField === 'password'
                    ? 'border-rose-400 focus:border-rose-500 ring-1 ring-rose-300'
                    : 'border-[#E5E2DA] focus:border-[#E8491D]'
                }`}
              />
            </div>
          </div>

          {/* Confirm Password (only in signup mode) */}
          {mode === 'signup' && (
            <div>
              <label className="mb-1 block text-xs font-semibold text-[#1A1A1A]">
                Confirm Password <span className="text-[#E8491D]">*</span>
              </label>
              <div className="relative">
                <Lock className="pointer-events-none absolute left-3 top-2.5 h-4 w-4 text-[#8A8578]" />
                <input
                  id="input-auth-confirm-password"
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => {
                    setConfirmPassword(e.target.value);
                    if (invalidField === 'confirmPassword') setInvalidField(null);
                  }}
                  placeholder="••••••••"
                  className={`w-full rounded-xl border bg-[#FFFFFF] py-2 pl-9 pr-3 text-xs text-[#1A1A1A] placeholder:text-[#8A8578] focus:outline-none transition ${
                    invalidField === 'confirmPassword'
                      ? 'border-rose-400 focus:border-rose-500 ring-1 ring-rose-300'
                      : 'border-[#E5E2DA] focus:border-[#E8491D]'
                  }`}
                />
              </div>
            </div>
          )}

          {/* Submit button */}
          <button
            id="btn-submit-auth"
            type="submit"
            disabled={submitting}
            className="mt-3 flex w-full items-center justify-center gap-2 rounded-xl bg-[#E8491D] hover:bg-[#FF5722] py-2.5 text-xs font-semibold text-white shadow-xs transition disabled:opacity-50 active:scale-[0.99]"
          >
            {submitting ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                <span>Processing...</span>
              </>
            ) : (
              <span>
                {mode === 'signin' ? 'Sign In' : 'Create Account & Profile'}
              </span>
            )}
          </button>
        </form>
      </div>
    </div>
  );
};
