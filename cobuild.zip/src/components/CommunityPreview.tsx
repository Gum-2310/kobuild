import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { UserSection, AppView, CommunityPost, BuildRequest, TeamRequirement, Ticket } from '../types';
import {
  subscribeCommunityPosts,
  subscribeAllTickets,
  createCommunityPost,
  expressInterestInPost,
  seedInitialCommunityPostsIfEmpty,
  deleteCommunityPost,
  deleteSectionTicket,
} from '../services/userService';
import { CommentDrawerModal } from './community/CommentDrawerModal';
import { WantToBuildModal } from './community/WantToBuildModal';
import { ManageBuildersModal } from './community/ManageBuildersModal';
import { UserProfilePopover } from './UserProfilePopover';
import { TicketDetailsModal } from './collab/TicketDetailsModal';
import { ManageTicketModal } from './collab/ManageTicketModal';
import { TicketApplyModal } from './collab/TicketApplyModal';
import {
  Sparkles,
  MessageSquare,
  Lightbulb,
  Plus,
  Compass,
  ArrowRight,
  ThumbsUp,
  CheckCircle2,
  Lock,
  Layers,
  Send,
  Loader2,
  FolderGit2,
  Heart,
  UserPlus,
  Rocket,
  Search,
  Filter,
  Users,
  Check,
  Briefcase,
  GraduationCap,
  Home as HomeIcon,
  HelpCircle,
  ExternalLink,
  Trash2,
  AlertTriangle,
  Info,
} from 'lucide-react';

interface CommunityPreviewProps {
  onOpenAuth: (section?: UserSection | null) => void;
  onNavigate: (view: AppView, section?: UserSection) => void;
}

export const CommunityPreview: React.FC<CommunityPreviewProps> = ({ onOpenAuth, onNavigate }) => {
  const { user, userProfile } = useAuth();

  // Feed State
  const [posts, setPosts] = useState<CommunityPost[]>([]);
  const [ticketsMap, setTicketsMap] = useState<Record<string, Ticket>>({});
  const [loading, setLoading] = useState(true);

  // Search & Filter State
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSection, setSelectedSection] = useState<string>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  // Modals for Raw Ideas
  const [showIdeaModal, setShowIdeaModal] = useState(false);
  const [activeCommentPost, setActiveCommentPost] = useState<CommunityPost | null>(null);
  const [activeWantToBuildPost, setActiveWantToBuildPost] = useState<CommunityPost | null>(null);
  const [activeManagePost, setActiveManagePost] = useState<CommunityPost | null>(null);

  // Modals for Ticket-linked Posts
  const [activeTicketDetails, setActiveTicketDetails] = useState<Ticket | null>(null);
  const [activeTicketManage, setActiveTicketManage] = useState<Ticket | null>(null);
  const [activeTicketApply, setActiveTicketApply] = useState<Ticket | null>(null);

  // User Profile Popover State
  const [popoverUser, setPopoverUser] = useState<{
    uid: string;
    name: string;
    photoURL?: string | null;
    section?: UserSection;
    location?: string;
    bio?: string;
    skills?: string[];
  } | null>(null);
  const [popoverContext, setPopoverContext] = useState<any>(null);

  // Deletion State
  const [deletePostTarget, setDeletePostTarget] = useState<CommunityPost | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);

  // New Idea Form State
  const [ideaTitle, setIdeaTitle] = useState('');
  const [ideaDesc, setIdeaDesc] = useState('');
  const [ideaCategory, setIdeaCategory] = useState('Experimental');
  const [roleInputs, setRoleInputs] = useState<TeamRequirement[]>([
    { role: 'Developer', count: 1 },
    { role: 'UI/UX Designer', count: 1 },
  ]);
  const [newRoleName, setNewRoleName] = useState('');
  const [newRoleCount, setNewRoleCount] = useState(1);

  const [saving, setSaving] = useState(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Local likes tracking
  const [likedPostIds, setLikedPostIds] = useState<Record<string, boolean>>({});

  // 1. Mount & Live Subscription
  useEffect(() => {
    // Seed sample posts if empty so preview is rich
    seedInitialCommunityPostsIfEmpty().catch(() => {});

    const unsubPosts = subscribeCommunityPosts((livePosts) => {
      setPosts(livePosts);
      setLoading(false);
    });

    const unsubTickets = subscribeAllTickets((liveTicketsMap) => {
      setTicketsMap(liveTicketsMap);
    });

    return () => {
      unsubPosts();
      unsubTickets();
    };
  }, []);

  const handlePostIdea = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !ideaTitle.trim()) return;

    setSaving(true);
    try {
      const validRoles = roleInputs.filter((r) => r.role.trim() && r.count > 0);
      const totalTeamSize = validRoles.reduce((acc, curr) => acc + curr.count, 0);

      const creatorName =
        userProfile?.name || user.displayName || user.email?.split('@')[0] || 'Community Builder';
      const creatorSection: UserSection =
        userProfile?.section || (selectedSection !== 'all' ? (selectedSection as UserSection) : 'student');
      const creatorLocation = userProfile?.location || '';
      const creatorPhotoURL = userProfile?.photoURL || user.photoURL || null;

      const docId = await createCommunityPost({
        creatorId: user.uid,
        creatorName,
        creatorPhotoURL,
        creatorSection,
        creatorLocation,
        title: ideaTitle.trim(),
        description: ideaDesc.trim(),
        category: ideaCategory,
        tags: [ideaCategory.toLowerCase(), creatorSection],
        status: 'idea',
        teamRequirements: validRoles,
        targetTeamSize: totalTeamSize > 0 ? totalTeamSize : 2,
      });

      // Optimistic feed update to guarantee instant visibility
      const newPostObj: CommunityPost = {
        id: docId,
        creatorId: user.uid,
        creatorName,
        creatorPhotoURL,
        creatorSection,
        creatorLocation,
        title: ideaTitle.trim(),
        description: ideaDesc.trim(),
        category: ideaCategory,
        tags: [ideaCategory.toLowerCase(), creatorSection],
        status: 'idea',
        teamRequirements: validRoles,
        targetTeamSize: totalTeamSize > 0 ? totalTeamSize : 2,
        upvotesCount: 0,
        commentsCount: 0,
        interestedCount: 0,
        buildRequestsCount: 0,
        shortlistedCount: 0,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      setPosts((prev) => [newPostObj, ...prev.filter((p) => p.id !== docId)]);

      // If user had active search or section filter that would hide their post, reset to 'all' so it is visible
      if (selectedSection !== 'all' && selectedSection !== creatorSection) {
        setSelectedSection('all');
      }
      setSearchQuery('');

      setIdeaTitle('');
      setIdeaDesc('');
      setRoleInputs([
        { role: 'Developer', count: 1 },
        { role: 'UI/UX Designer', count: 1 },
      ]);
      setShowIdeaModal(false);
      setSuccessMsg('Your idea has been published! It is now live in the Community feed.');
      setTimeout(() => setSuccessMsg(null), 5000);
    } catch (err) {
      console.error('Failed to post idea:', err);
    } finally {
      setSaving(false);
    }
  };

  const handleToggleLike = async (postId: string) => {
    if (!user) {
      onOpenAuth(null);
      return;
    }

    const isLiked = !!likedPostIds[postId];
    setLikedPostIds((prev) => ({ ...prev, [postId]: !isLiked }));

    // Optimistically update local posts list
    setPosts((prev) =>
      prev.map((p) => {
        if (p.id === postId) {
          const delta = isLiked ? -1 : 1;
          return {
            ...p,
            upvotesCount: Math.max(0, (p.upvotesCount || 0) + delta),
            interestedCount: Math.max(0, (p.interestedCount || 0) + delta),
          };
        }
        return p;
      })
    );

    const targetPost = posts.find((p) => p.id === postId);
    try {
      await expressInterestInPost(postId, isLiked ? -1 : 1, userProfile, targetPost);
    } catch (err) {
      console.error('Failed to toggle like on Firestore:', err);
    }
  };

  const handleAddRoleInput = () => {
    if (!newRoleName.trim()) return;
    setRoleInputs([...roleInputs, { role: newRoleName.trim(), count: Number(newRoleCount) || 1 }]);
    setNewRoleName('');
    setNewRoleCount(1);
  };

  const handleRemoveRoleInput = (index: number) => {
    setRoleInputs(roleInputs.filter((_, i) => i !== index));
  };

  const handleConfirmDeletePost = async () => {
    if (!deletePostTarget || !user) return;
    setIsDeleting(true);
    setDeleteError(null);
    try {
      if (deletePostTarget.ticketId) {
        await deleteSectionTicket(deletePostTarget.ticketId, deletePostTarget.creatorId);
      } else {
        await deleteCommunityPost(deletePostTarget.id, deletePostTarget.creatorId);
      }
      // Immediately update local feed state
      setPosts((prev) => prev.filter((p) => p.id !== deletePostTarget.id));
      setDeletePostTarget(null);
    } catch (err: any) {
      console.error('Failed to delete collaboration item:', err);
      setDeleteError('Unable to delete this item. Please try again.');
    } finally {
      setIsDeleting(false);
    }
  };

  const getSectionBadgeClass = (sec?: UserSection) => {
    switch (sec) {
      case 'student':
        return 'bg-[#FDE4D8] text-[#E8491D] border-[#E8491D]/40';
      case 'homemaker':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case 'entrepreneur':
        return 'bg-purple-50 text-purple-700 border-purple-200';
      default:
        return 'bg-[#FAF8F3] text-[#55524A] border-[#E5E2DA]';
    }
  };

  const formatRelativeTime = (isoString?: string) => {
    if (!isoString) return 'just now';
    const date = new Date(isoString);
    const diffSec = Math.floor((Date.now() - date.getTime()) / 1000);
    if (diffSec < 60) return 'just now';
    if (diffSec < 3600) return `${Math.floor(diffSec / 60)}m ago`;
    if (diffSec < 86400) return `${Math.floor(diffSec / 3600)}h ago`;
    return `${Math.floor(diffSec / 86400)}d ago`;
  };

  // Filter posts
  const filteredPosts = posts.filter((p) => {
    const matchesSearch =
      searchQuery.trim() === '' ||
      p.title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.description?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.creatorName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.category?.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesSection = selectedSection === 'all' || p.creatorSection === selectedSection;

    const matchesCategory =
      selectedCategory === 'all' ||
      p.category?.toLowerCase().includes(selectedCategory.toLowerCase());

    return matchesSearch && matchesSection && matchesCategory;
  });

  return (
    <div className="space-y-10 pb-20">
      {/* 1. Header Banner */}
      <div className="rounded-3xl border border-[#E5E2DA] bg-[#FFFFFF] p-6 sm:p-10 shadow-xs dark-interactive-card">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-3 max-w-2xl">
            <div className="inline-flex items-center gap-2 rounded-full border border-[#E8491D]/30 bg-[#FDE4D8] px-3 py-1 text-xs font-semibold text-[#E8491D]">
              <Lightbulb className="h-3.5 w-3.5 text-[#E8491D]" />
              <span>Community Ideas &amp; Discovery Hub</span>
            </div>

            <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight text-[#1A1A1A] leading-tight">
              Where unusual, unfinished, &amp; &ldquo;crazy&rdquo; ideas find believers.
            </h1>

            <p className="text-xs sm:text-sm leading-relaxed text-[#55524A]">
              The community is the open ground for raw concepts. Share what you are thinking, discuss viability, validate feedback with peers, and shortlist your squad to launch a dedicated Build Space.
            </p>
          </div>

          <div className="shrink-0 flex flex-col gap-2">
            {user ? (
              <button
                onClick={() => setShowIdeaModal(true)}
                className="flex items-center justify-center gap-2 rounded-xl bg-[#E8491D] hover:bg-[#FF5722] px-5 py-3 text-xs font-semibold text-white shadow-xs transition active:scale-[0.99] dark-interactive-card"
              >
                <Plus className="h-4 w-4" />
                <span>Share a Raw Idea</span>
              </button>
            ) : (
              <button
                onClick={() => onOpenAuth(null)}
                className="flex items-center justify-center gap-2 rounded-xl bg-[#E8491D] hover:bg-[#FF5722] px-5 py-3 text-xs font-semibold text-white shadow-xs transition active:scale-[0.99] dark-interactive-card"
              >
                <Lock className="h-4 w-4" />
                <span>Sign In to Post Ideas</span>
              </button>
            )}
          </div>
        </div>

        {/* Success Alert */}
        {successMsg && (
          <div className="mt-6 flex items-center gap-2 rounded-xl bg-emerald-50 border border-emerald-200 p-3 text-xs text-emerald-800 font-medium animate-in fade-in">
            <CheckCircle2 className="h-4 w-4 text-emerald-600 shrink-0" />
            <span>{successMsg}</span>
          </div>
        )}
      </div>

      {/* 2. The Idea Lifecycle Formula */}
      <div className="rounded-2xl border border-[#E5E2DA] bg-[#FFFFFF] p-6 shadow-xs">
        <h2 className="text-xs font-bold uppercase tracking-widest text-[#8A8578] mb-4">
          The kobuildd Lifecycle Formula
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-5 gap-3 items-center text-center">
          <div className="rounded-xl bg-[#FAF8F3] border border-[#E5E2DA] p-4 dark-interactive-card">
            <div className="text-xs font-bold text-[#1A1A1A] mb-1">1. Community Post</div>
            <p className="text-[11px] text-[#55524A]">Discover raw ideas &amp; discuss viability</p>
          </div>
          <div className="text-[#8A8578] font-mono text-xl hidden sm:block">→</div>
          <div className="rounded-xl bg-[#FDE4D8]/50 border border-[#E8491D]/35 p-4 dark-interactive-card">
            <div className="text-xs font-bold text-[#E8491D] mb-1">2. Want to Build</div>
            <p className="text-[11px] text-[#E8491D]/80">Apply with skills &amp; get shortlisted</p>
          </div>
          <div className="text-[#8A8578] font-mono text-xl hidden sm:block">→</div>
          <div className="rounded-xl bg-[#FAF8F3] border border-[#E5E2DA] text-[#1A1A1A] p-4 dark-interactive-card">
            <div className="text-xs font-bold text-[#1A1A1A] mb-1">3. Launch Build Space</div>
            <p className="text-[11px] text-[#55524A]">Squad workspace to build together</p>
          </div>
        </div>
      </div>

      {/* 3. Search & Filter Bar */}
      <div className="space-y-3">
        <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between">
          {/* Search Bar */}
          <div className="relative flex-1">
            <Search className="absolute left-3.5 top-3 h-4 w-4 text-[#8A8578]" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search community ideas by topic, problem, or creator..."
              className="w-full rounded-xl border border-[#E5E2DA] bg-[#FFFFFF] pl-10 pr-4 py-2.5 text-xs text-[#1A1A1A] placeholder:text-[#8A8578] focus:border-[#E8491D] focus:outline-none shadow-2xs"
            />
          </div>

          {/* Section Selector */}
          <div className="flex items-center gap-1 bg-[#FFFFFF] p-1 rounded-xl border border-[#E5E2DA] overflow-x-auto">
            {[
              { id: 'all', label: 'All Ideas' },
              { id: 'student', label: 'Students' },
              { id: 'homemaker', label: 'Homemakers' },
              { id: 'entrepreneur', label: 'Entrepreneurs' },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setSelectedSection(tab.id)}
                className={`rounded-lg px-3 py-1.5 text-xs font-semibold whitespace-nowrap transition ${
                  selectedSection === tab.id
                    ? 'bg-[#E8491D] text-white shadow-2xs'
                    : 'text-[#55524A] hover:text-[#1A1A1A]'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Category Pill Filters */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1">
          <span className="text-[11px] font-semibold text-[#8A8578] uppercase tracking-wider shrink-0">
            Category:
          </span>
          {[
            { id: 'all', label: 'All Categories' },
            { id: 'hardware', label: 'Hardware & IoT' },
            { id: 'software', label: 'Software & AI' },
            { id: 'local', label: 'Local Business' },
            { id: 'creative', label: 'Creative & Media' },
            { id: 'culinary', label: 'Culinary' },
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`rounded-full px-3 py-1 text-[11px] font-medium whitespace-nowrap border transition ${
                selectedCategory === cat.id
                  ? 'bg-[#E8491D] text-white border-[#E8491D]'
                  : 'bg-[#FFFFFF] text-[#55524A] border-[#E5E2DA] hover:border-[#D4D0C5] hover:text-[#1A1A1A]'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* 4. Community Ideas Stream */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-xs font-bold uppercase tracking-widest text-[#8A8578]">
            Live Community Stream ({filteredPosts.length})
          </h2>
          <span className="text-xs font-mono text-[#8A8578]">Real-time Firestore sync</span>
        </div>

        {loading ? (
          <div className="flex flex-col items-center justify-center py-16 gap-3 text-[#55524A]">
            <Loader2 className="h-8 w-8 animate-spin text-[#E8491D]" />
            <span className="text-xs font-medium">Fetching ideas from community...</span>
          </div>
        ) : filteredPosts.length === 0 ? (
          <div className="rounded-3xl border border-dashed border-[#E5E2DA] bg-[#FFFFFF] p-12 text-center space-y-3">
            <Lightbulb className="mx-auto h-10 w-10 text-[#8A8578]" />
            <h3 className="text-sm font-bold text-[#1A1A1A]">No ideas found</h3>
            <p className="text-xs text-[#55524A] max-w-sm mx-auto">
              Be the first to share an unusual idea or try clearing your search filters.
            </p>
            {user && (
              <button
                onClick={() => setShowIdeaModal(true)}
                className="mt-2 inline-flex items-center gap-1.5 rounded-xl bg-[#E8491D] hover:bg-[#FF5722] px-4 py-2 text-xs font-semibold text-white"
              >
                <Plus className="h-3.5 w-3.5" />
                <span>Post Your Idea</span>
              </button>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredPosts.map((post) => {
              // Retrieve real linked ticket from single source of truth if this post is a ticket representation
              const linkedTicket: Ticket | null = post.ticketId ? ticketsMap[post.ticketId] || null : null;
              const isCreator = Boolean(
                user && (user.uid === post.creatorId || (linkedTicket && user.uid === linkedTicket.creatorId))
              );
              const isLiked = Boolean(likedPostIds[post.id]);
              const isBuilding = post.status === 'building' || post.status === 'build_space_active';

              return (
                <div
                  key={post.id}
                  className="rounded-3xl border border-[#E5E2DA] bg-[#FFFFFF] p-6 shadow-xs space-y-4 flex flex-col justify-between dark-interactive-card"
                >
                  {/* Top Bar: Creator Info & Status Badge */}
                  <div className="space-y-3">
                    <div className="flex items-center justify-between gap-2">
                      <div
                        className="flex items-center gap-2.5 cursor-pointer group"
                        onClick={() => {
                          setPopoverUser({
                            uid: post.creatorId,
                            name: post.creatorName,
                            section: post.creatorSection,
                            location: post.creatorLocation,
                          });
                          setPopoverContext({
                            type: 'post',
                            id: post.id,
                            title: post.title,
                            note: 'Community Idea discussion',
                          });
                        }}
                      >
                        <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-[#FAF8F3] border border-[#E5E2DA] text-[#1A1A1A] text-xs font-bold shrink-0 group-hover:border-[#E8491D] group-hover:text-[#E8491D] transition">
                          {post.creatorName?.charAt(0) || 'C'}
                        </div>
                        <div>
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className="text-xs font-bold text-[#1A1A1A] group-hover:text-[#E8491D] transition">
                              {post.creatorName}
                            </span>
                            <span
                              className={`rounded border px-1.5 py-0.2 text-[9px] font-bold uppercase ${getSectionBadgeClass(
                                post.creatorSection
                              )}`}
                            >
                              {post.creatorSection}
                            </span>
                          </div>
                          <div className="text-[10px] text-[#8A8578] font-mono">
                            {post.creatorLocation ? `${post.creatorLocation} • ` : ''}
                            {formatRelativeTime(post.createdAt)}
                          </div>
                        </div>
                      </div>

                      {/* Real Ticket / Community Status Badge */}
                      {linkedTicket ? (
                        linkedTicket.status === 'open' ? (
                          <span className="inline-flex items-center gap-1.5 rounded-md bg-emerald-50 text-emerald-800 border border-emerald-200 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider font-mono shrink-0">
                            <span className="h-1.5 w-1.5 rounded-full bg-emerald-600 animate-pulse" />
                            OPEN FOR COLLABORATION
                          </span>
                        ) : linkedTicket.status === 'in_progress' ? (
                          <span className="inline-flex items-center gap-1.5 rounded-md bg-amber-50 text-amber-800 border border-amber-200 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider font-mono shrink-0">
                            <span className="h-1.5 w-1.5 rounded-full bg-amber-600" />
                            COLLABORATION IN PROGRESS
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1.5 rounded-md bg-[#F2EFE6] text-[#8A8578] border border-[#E5E2DA] px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider font-mono shrink-0">
                            <span className="h-1.5 w-1.5 rounded-full bg-[#8A8578]" />
                            COLLABORATION CLOSED
                          </span>
                        )
                      ) : isBuilding ? (
                        <span className="rounded-md bg-emerald-50 text-emerald-700 border border-emerald-200 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider font-mono shrink-0">
                          🚀 Building Phase
                        </span>
                      ) : (
                        <span className="rounded-md bg-[#FAF8F3] text-[#55524A] border border-[#E5E2DA] px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider shrink-0">
                          {post.category || 'Raw Idea'}
                        </span>
                      )}
                    </div>

                    {/* Idea Title & Description */}
                    <div>
                      <h3
                        onClick={() => {
                          if (linkedTicket) {
                            setActiveTicketDetails(linkedTicket);
                          } else {
                            setActiveCommentPost(post);
                          }
                        }}
                        className="text-base font-bold text-[#1A1A1A] leading-snug hover:text-[#E8491D] cursor-pointer transition"
                      >
                        &ldquo;{post.title}&rdquo;
                      </h3>
                      <p className="mt-1.5 text-xs leading-relaxed text-[#55524A] line-clamp-3">
                        {post.description}
                      </p>
                    </div>

                    {/* Team Requirements / Skills Checklist */}
                    {((linkedTicket?.skillsRequired && linkedTicket.skillsRequired.length > 0) ||
                      (post.teamRequirements && post.teamRequirements.length > 0)) && (
                      <div className="pt-2 border-t border-[#E5E2DA]">
                        <span className="text-[10px] font-bold text-[#8A8578] uppercase tracking-wider block mb-1">
                          Looking for squad:
                        </span>
                        <div className="flex flex-wrap gap-1.5">
                          {linkedTicket?.skillsRequired ? (
                            linkedTicket.skillsRequired.map((skill, idx) => (
                              <span
                                key={idx}
                                className="rounded-lg bg-[#FAF8F3] border border-[#E5E2DA] px-2 py-0.5 text-[10px] font-medium text-[#55524A]"
                              >
                                {skill}
                              </span>
                            ))
                          ) : (
                            post.teamRequirements?.map((req, idx) => (
                              <span
                                key={idx}
                                className="rounded-lg bg-[#FAF8F3] border border-[#E5E2DA] px-2 py-0.5 text-[10px] font-medium text-[#55524A]"
                              >
                                {req.count}x {req.role}
                              </span>
                            ))
                          )}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Bottom Action Bar */}
                  <div className="pt-3 border-t border-[#E5E2DA] space-y-3">
                    {/* Metrics / Counts */}
                    <div className="flex items-center justify-between text-xs text-[#55524A]">
                      <div className="flex items-center gap-3">
                        {/* Comments / Discuss trigger */}
                        <button
                          onClick={() => {
                            if (linkedTicket) {
                              setActiveTicketDetails(linkedTicket);
                            } else {
                              setActiveCommentPost(post);
                            }
                          }}
                          className="flex items-center gap-1 font-semibold text-[#1A1A1A] hover:text-[#E8491D] transition"
                        >
                          <MessageSquare className="h-3.5 w-3.5 text-[#E8491D]" />
                          <span>{post.commentsCount || 0} comments</span>
                        </button>

                        <span>•</span>

                        <span>
                          {linkedTicket
                            ? `${linkedTicket.interestedCount || 0} interested`
                            : `${post.interestedCount || post.upvotesCount || 0} interested`}
                        </span>
                      </div>

                      {/* Heart (Like / Interested) Toggle */}
                      <button
                        onClick={() => handleToggleLike(post.id)}
                        className={`flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-lg border transition ${
                          isLiked
                            ? 'bg-rose-50 border-rose-200 text-rose-700'
                            : 'border-[#E5E2DA] bg-[#FAF8F3] text-[#55524A] hover:text-[#1A1A1A] hover:border-[#D4D0C5]'
                        }`}
                      >
                        <Heart
                          className={`h-3.5 w-3.5 ${
                            isLiked ? 'fill-rose-500 text-rose-500' : 'text-[#8A8578]'
                          }`}
                        />
                        <span>{isLiked ? 'Interested' : 'Support'}</span>
                      </button>
                    </div>

                    {/* Action Buttons Grid */}
                    <div className="flex flex-wrap items-center gap-2">
                      {/* Ticket Details or Comments Modal Trigger */}
                      {linkedTicket ? (
                        <button
                          onClick={() => setActiveTicketDetails(linkedTicket)}
                          className="flex-1 min-w-[90px] flex items-center justify-center gap-1.5 rounded-xl border border-[#E5E2DA] bg-[#FAF8F3] px-3 py-2 text-xs font-semibold text-[#1A1A1A] hover:bg-[#F5F1E8] transition cursor-pointer"
                        >
                          <Info className="h-3.5 w-3.5 text-[#8A8578]" />
                          <span>Details</span>
                        </button>
                      ) : (
                        <button
                          onClick={() => setActiveCommentPost(post)}
                          className="flex-1 min-w-[90px] flex items-center justify-center gap-1.5 rounded-xl border border-[#E5E2DA] bg-[#FAF8F3] px-3 py-2 text-xs font-semibold text-[#1A1A1A] hover:bg-[#F5F1E8] transition cursor-pointer"
                        >
                          <MessageSquare className="h-3.5 w-3.5 text-[#8A8578]" />
                          <span>Discuss</span>
                        </button>
                      )}

                      {/* Dynamic Action Buttons Mirroring Collab State */}
                      {linkedTicket ? (
                        /* TICKET-LINKED POST */
                        isCreator ? (
                          /* Creator of Ticket */
                          <>
                            <button
                              onClick={() => setActiveTicketManage(linkedTicket)}
                              className="flex-1 min-w-[120px] flex items-center justify-center gap-1.5 rounded-xl border border-[#E8491D]/50 bg-[#FDE4D8] px-3 py-2 text-xs font-bold text-[#E8491D] hover:bg-[#FDE4D8]/80 transition cursor-pointer"
                            >
                              <Users className="h-3.5 w-3.5" />
                              <span>
                                Manage Squad{' '}
                                {linkedTicket.applicationsCount ? `(${linkedTicket.applicationsCount})` : ''}
                              </span>
                            </button>

                            <button
                              id={`btn-delete-ticket-${post.id}`}
                              title="Delete Ticket"
                              onClick={() => {
                                setDeleteError(null);
                                setDeletePostTarget(post);
                              }}
                              className="flex items-center justify-center gap-1.5 rounded-xl border border-rose-200 bg-rose-50 hover:bg-rose-100 px-3 py-2 text-xs font-semibold text-rose-700 transition active:scale-[0.99] cursor-pointer"
                            >
                              <Trash2 className="h-3.5 w-3.5 text-rose-600" />
                              <span>Delete</span>
                            </button>
                          </>
                        ) : linkedTicket.status === 'closed' ? (
                          /* Non-Creator on Closed Ticket: Applications Closed (Disabled) */
                          <div
                            className="flex-1 min-w-[120px] flex items-center justify-center gap-1.5 rounded-xl border border-[#E5E2DA] bg-[#F2EFE6] px-3 py-2 text-xs font-medium text-[#8A8578] cursor-not-allowed select-none"
                            title="This collaboration opportunity is closed and no longer accepting applications."
                          >
                            <Lock className="h-3.5 w-3.5 text-[#8A8578]" />
                            <span>Applications Closed</span>
                          </div>
                        ) : (
                          /* Non-Creator on Open or In-Progress Ticket: Want to Build */
                          <button
                            onClick={() => {
                              if (!user) {
                                onOpenAuth(linkedTicket.section);
                                return;
                              }
                              setActiveTicketApply(linkedTicket);
                            }}
                            className="flex-1 flex items-center justify-center gap-1.5 rounded-xl border border-[#E8491D]/50 bg-[#FDE4D8] px-3 py-2 text-xs font-bold text-[#E8491D] hover:bg-[#FDE4D8]/80 transition cursor-pointer"
                          >
                            <UserPlus className="h-3.5 w-3.5" />
                            <span>Want to Build</span>
                          </button>
                        )
                      ) : (
                        /* RAW COMMUNITY IDEA */
                        isCreator ? (
                          <>
                            <button
                              onClick={() => setActiveManagePost(post)}
                              className="flex-1 min-w-[120px] flex items-center justify-center gap-1.5 rounded-xl border border-[#E8491D]/50 bg-[#FDE4D8] px-3 py-2 text-xs font-bold text-[#E8491D] hover:bg-[#FDE4D8]/80 transition cursor-pointer"
                            >
                              <Users className="h-3.5 w-3.5" />
                              <span>
                                Manage Squad {post.buildRequestsCount ? `(${post.buildRequestsCount})` : ''}
                              </span>
                            </button>

                            <button
                              id={`btn-delete-ticket-${post.id}`}
                              title="Delete Post"
                              onClick={() => {
                                setDeleteError(null);
                                setDeletePostTarget(post);
                              }}
                              className="flex items-center justify-center gap-1.5 rounded-xl border border-rose-200 bg-rose-50 hover:bg-rose-100 px-3 py-2 text-xs font-semibold text-rose-700 transition active:scale-[0.99] cursor-pointer"
                            >
                              <Trash2 className="h-3.5 w-3.5 text-rose-600" />
                              <span>Delete</span>
                            </button>
                          </>
                        ) : (
                          <button
                            onClick={() => {
                              if (!user) {
                                onOpenAuth(null);
                                return;
                              }
                              setActiveWantToBuildPost(post);
                            }}
                            className="flex-1 flex items-center justify-center gap-1.5 rounded-xl border border-[#E8491D]/50 bg-[#FDE4D8] px-3 py-2 text-xs font-bold text-[#E8491D] hover:bg-[#FDE4D8]/80 transition cursor-pointer"
                          >
                            <UserPlus className="h-3.5 w-3.5" />
                            <span>Want to Build</span>
                          </button>
                        )
                      )}

                      {/* If status is already building -> View Build Space button */}
                      {isBuilding && (
                        <button
                          onClick={() => onNavigate('buildspace')}
                          className="flex items-center gap-1.5 rounded-xl bg-[#FAF8F3] border border-[#E5E2DA] px-3 py-2 text-xs font-bold text-[#1A1A1A] hover:bg-[#F5F1E8] transition cursor-pointer"
                        >
                          <Rocket className="h-3.5 w-3.5 text-[#E8491D]" />
                          <span>View Space</span>
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* 5. Modals */}

      {/* Idea Creation Modal */}
      {showIdeaModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-[#1A1A1A]/40 p-3 sm:p-4 backdrop-blur-xs animate-in fade-in"
          onClick={() => setShowIdeaModal(false)}
        >
          <div
            className="w-full max-w-lg max-h-[90vh] overflow-y-auto rounded-3xl border border-[#E5E2DA] bg-[#FFFFFF] p-6 shadow-2xl space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div>
              <h3 className="text-lg font-bold text-[#1A1A1A]">Post a Community Idea</h3>
              <p className="text-xs text-[#55524A]">
                Share a raw or experimental concept for validation, feedback, and co-builder interest.
              </p>
            </div>

            <form onSubmit={handlePostIdea} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-[#1A1A1A] mb-1">
                  Idea Title or Problem Statement <span className="text-[#E8491D]">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={ideaTitle}
                  onChange={(e) => setIdeaTitle(e.target.value)}
                  placeholder="e.g. Acoustic soil-sensor probe that plays audio sweeps when plants need water"
                  className="w-full rounded-xl border border-[#E5E2DA] bg-[#FAF8F3] px-3.5 py-2 text-xs text-[#1A1A1A] placeholder:text-[#8A8578] focus:border-[#E8491D] focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#1A1A1A] mb-1">Category</label>
                <select
                  value={ideaCategory}
                  onChange={(e) => setIdeaCategory(e.target.value)}
                  className="w-full rounded-xl border border-[#E5E2DA] bg-[#FAF8F3] px-3.5 py-2 text-xs text-[#1A1A1A] focus:border-[#E8491D] focus:outline-none"
                >
                  <option value="Hardware / IoT" className="bg-[#FFFFFF] text-[#1A1A1A]">Hardware / IoT</option>
                  <option value="Software & AI" className="bg-[#FFFFFF] text-[#1A1A1A]">Software &amp; AI</option>
                  <option value="Local Business & Services" className="bg-[#FFFFFF] text-[#1A1A1A]">Local Business &amp; Services</option>
                  <option value="Creative & Media" className="bg-[#FFFFFF] text-[#1A1A1A]">Creative &amp; Media</option>
                  <option value="Culinary" className="bg-[#FFFFFF] text-[#1A1A1A]">Culinary &amp; Food</option>
                  <option value="Experimental" className="bg-[#FFFFFF] text-[#1A1A1A]">Experimental / Crazy Concept</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#1A1A1A] mb-1">
                  Description &amp; Problem Detail <span className="text-[#E8491D]">*</span>
                </label>
                <textarea
                  rows={4}
                  required
                  value={ideaDesc}
                  onChange={(e) => setIdeaDesc(e.target.value)}
                  placeholder="Describe your thinking, what makes it exciting, and what kind of feedback you are looking for..."
                  className="w-full rounded-xl border border-[#E5E2DA] bg-[#FAF8F3] p-3 text-xs text-[#1A1A1A] placeholder:text-[#8A8578] focus:border-[#E8491D] focus:outline-none"
                />
              </div>

              {/* Team Requirements Definition */}
              <div className="rounded-2xl border border-[#E5E2DA] bg-[#FAF8F3] p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-bold text-[#1A1A1A]">
                    Who do you need on your squad?
                  </label>
                  <span className="text-[11px] text-[#8A8578]">Specify roles &amp; counts</span>
                </div>

                <div className="flex flex-wrap gap-2">
                  {roleInputs.map((r, idx) => (
                    <div
                      key={idx}
                      className="flex items-center gap-1.5 rounded-lg bg-[#FFFFFF] border border-[#E5E2DA] px-2.5 py-1 text-xs text-[#1A1A1A] shadow-2xs"
                    >
                      <span>
                        {r.count}x {r.role}
                      </span>
                      <button
                        type="button"
                        onClick={() => handleRemoveRoleInput(idx)}
                        className="text-[#8A8578] hover:text-[#E8491D] p-0.5"
                      >
                        ×
                      </button>
                    </div>
                  ))}
                </div>

                <div className="flex items-center gap-2 pt-1">
                  <input
                    type="text"
                    placeholder="Role (e.g. Firmware Engineer)"
                    value={newRoleName}
                    onChange={(e) => setNewRoleName(e.target.value)}
                    className="flex-1 rounded-lg border border-[#E5E2DA] bg-[#FFFFFF] px-3 py-1.5 text-xs text-[#1A1A1A] placeholder:text-[#8A8578] focus:outline-none"
                  />
                  <input
                    type="number"
                    min={1}
                    max={5}
                    value={newRoleCount}
                    onChange={(e) => setNewRoleCount(parseInt(e.target.value) || 1)}
                    className="w-14 rounded-lg border border-[#E5E2DA] bg-[#FFFFFF] px-2 py-1.5 text-xs text-[#1A1A1A] text-center focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={handleAddRoleInput}
                    className="rounded-lg bg-[#FFFFFF] border border-[#E5E2DA] px-3 py-1.5 text-xs font-semibold text-[#1A1A1A] hover:bg-[#F5F1E8]"
                  >
                    + Add
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-[#E5E2DA]">
                <button
                  type="button"
                  onClick={() => setShowIdeaModal(false)}
                  className="rounded-xl border border-[#E5E2DA] px-4 py-2 text-xs font-semibold text-[#55524A] hover:bg-[#FAF8F3] hover:text-[#1A1A1A]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={saving || !ideaTitle.trim()}
                  className="flex items-center gap-1.5 rounded-xl bg-[#E8491D] hover:bg-[#FF5722] px-5 py-2 text-xs font-semibold text-white disabled:opacity-50"
                >
                  {saving ? (
                    <Loader2 className="h-3.5 w-3.5 animate-spin" />
                  ) : (
                    <Send className="h-3.5 w-3.5" />
                  )}
                  <span>Publish Idea</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Comments Drawer / Modal */}
      {activeCommentPost && (
        <CommentDrawerModal
          post={activeCommentPost}
          onClose={() => setActiveCommentPost(null)}
          onOpenAuth={onOpenAuth}
        />
      )}

      {/* Want To Build Application Modal */}
      {activeWantToBuildPost && (
        <WantToBuildModal
          post={activeWantToBuildPost}
          onClose={() => setActiveWantToBuildPost(null)}
          onOpenAuth={onOpenAuth}
        />
      )}

      {/* Creator Squad / Builder Management Modal for Raw Ideas */}
      {activeManagePost && (
        <ManageBuildersModal
          post={activeManagePost}
          onClose={() => setActiveManagePost(null)}
          onNavigate={onNavigate}
        />
      )}

      {/* Collaboration Ticket Details Modal */}
      {activeTicketDetails && (
        <TicketDetailsModal
          ticket={activeTicketDetails}
          isOpen={Boolean(activeTicketDetails)}
          onClose={() => setActiveTicketDetails(null)}
          onOpenApply={(t) => {
            setActiveTicketDetails(null);
            setActiveTicketApply(t);
          }}
          onOpenManage={(t) => {
            setActiveTicketDetails(null);
            setActiveTicketManage(t);
          }}
          onTicketUpdated={(updatedTicket) => {
            setActiveTicketDetails(updatedTicket);
            setTicketsMap((prev) => ({ ...prev, [updatedTicket.id]: updatedTicket }));
          }}
          onTicketDeleted={(ticketId) => {
            setActiveTicketDetails(null);
            setTicketsMap((prev) => {
              const next = { ...prev };
              delete next[ticketId];
              return next;
            });
            setPosts((prev) => prev.filter((p) => p.ticketId !== ticketId));
          }}
          onOpenAuth={onOpenAuth}
          onNavigateToChat={() => onNavigate('chats')}
        />
      )}

      {/* Collaboration Ticket Squad Management Modal */}
      {activeTicketManage && (
        <ManageTicketModal
          ticket={activeTicketManage}
          isOpen={Boolean(activeTicketManage)}
          onClose={() => setActiveTicketManage(null)}
          onTicketUpdated={(updatedTicket) => {
            setActiveTicketManage(updatedTicket);
            setTicketsMap((prev) => ({ ...prev, [updatedTicket.id]: updatedTicket }));
          }}
          onTicketDeleted={(ticketId) => {
            setActiveTicketManage(null);
            setTicketsMap((prev) => {
              const next = { ...prev };
              delete next[ticketId];
              return next;
            });
            setPosts((prev) => prev.filter((p) => p.ticketId !== ticketId));
          }}
        />
      )}

      {/* Collaboration Ticket Apply Modal */}
      {activeTicketApply && (
        <TicketApplyModal
          ticket={activeTicketApply}
          isOpen={Boolean(activeTicketApply)}
          onClose={() => setActiveTicketApply(null)}
          onApplicationSent={(ticketId) => {
            setActiveTicketApply(null);
            setTicketsMap((prev) => {
              const existing = prev[ticketId];
              if (!existing) return prev;
              return {
                ...prev,
                [ticketId]: {
                  ...existing,
                  applicationsCount: (existing.applicationsCount || 0) + 1,
                },
              };
            });
          }}
        />
      )}

      {/* Delete Ticket Confirmation Dialog Modal */}
      {deletePostTarget && (
        <div
          className="fixed inset-0 z-60 flex items-center justify-center bg-[#1A1A1A]/60 p-4 backdrop-blur-xs animate-in fade-in"
          onClick={() => {
            if (!isDeleting) {
              setDeletePostTarget(null);
              setDeleteError(null);
            }
          }}
        >
          <div
            className="w-full max-w-md rounded-2xl border border-[#E5E2DA] bg-[#FFFFFF] p-6 shadow-2xl space-y-4 animate-in zoom-in-95"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start gap-3.5">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-rose-100 text-rose-600 border border-rose-200 shrink-0">
                <Trash2 className="h-5 w-5" />
              </div>
              <div className="space-y-1">
                <h3 className="text-base font-bold text-[#1A1A1A]">
                  Delete this collaboration item?
                </h3>
                <p className="text-xs text-[#55524A] leading-relaxed">
                  This action will permanently remove this item from the community and collaboration tracks. This action cannot be undone.
                </p>
                <div className="mt-2 rounded-xl bg-[#FAF8F3] border border-[#E5E2DA] p-2.5 text-xs font-semibold text-[#1A1A1A] line-clamp-2">
                  &ldquo;{deletePostTarget.title}&rdquo;
                </div>
              </div>
            </div>

            {deleteError && (
              <div className="flex items-center gap-2 rounded-xl bg-rose-50 border border-rose-200 p-3 text-xs text-rose-700">
                <AlertTriangle className="h-4 w-4 shrink-0 text-rose-600" />
                <span>{deleteError}</span>
              </div>
            )}

            <div className="flex items-center justify-end gap-2.5 pt-2 border-t border-[#E5E2DA]">
              <button
                type="button"
                id="btn-cancel-delete-post"
                disabled={isDeleting}
                onClick={() => {
                  setDeletePostTarget(null);
                  setDeleteError(null);
                }}
                className="rounded-xl border border-[#E5E2DA] bg-[#FFFFFF] hover:bg-[#FAF8F3] px-4 py-2 text-xs font-semibold text-[#55524A] transition disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                type="button"
                id="btn-confirm-delete-post"
                disabled={isDeleting}
                onClick={handleConfirmDeletePost}
                className="flex items-center gap-1.5 rounded-xl bg-rose-600 hover:bg-rose-700 px-4 py-2 text-xs font-bold text-white shadow-sm transition disabled:opacity-50"
              >
                {isDeleting ? (
                  <>
                    <Loader2 className="h-3.5 w-3.5 animate-spin" />
                    <span>Deleting...</span>
                  </>
                ) : (
                  <>
                    <Trash2 className="h-3.5 w-3.5" />
                    <span>Delete</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* User Profile & Direct Message Popover */}
      {popoverUser && (
        <UserProfilePopover
          isOpen={Boolean(popoverUser)}
          onClose={() => setPopoverUser(null)}
          targetUser={popoverUser}
          context={popoverContext}
          onOpenChatWithUser={() => {
            setPopoverUser(null);
            onNavigate('chats');
          }}
          onOpenAuth={() => onOpenAuth(null)}
        />
      )}
    </div>
  );
};
