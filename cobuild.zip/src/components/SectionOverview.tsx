import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { Ticket, UserSection, AppView } from '../types';
import {
  subscribeSectionTickets,
  seedInitialTicketsIfEmpty,
  expressInterestInTicket,
  deleteSectionTicket,
  decodeTicketShareParam,
  getSectionTicketById,
} from '../services/userService';
import { RaiseTicketModal } from './collab/RaiseTicketModal';
import { TicketDetailsModal } from './collab/TicketDetailsModal';
import { TicketApplyModal } from './collab/TicketApplyModal';
import { ManageTicketModal } from './collab/ManageTicketModal';
import { SectionCollaborationActivityCard } from './collab/UserCommunityActivityCard';
import {
  GraduationCap,
  Home,
  Briefcase,
  Users,
  Database,
  ShieldCheck,
  CheckCircle,
  Sparkles,
  ArrowRight,
  Plus,
  Search,
  Filter,
  Calendar,
  MapPin,
  Heart,
  Hammer,
  Clock,
  Settings,
  Eye,
  Loader2,
  AlertCircle,
  Tag,
  Trash2,
  AlertTriangle,
} from 'lucide-react';

interface SectionOverviewProps {
  onOpenAuth: (section?: UserSection | null) => void;
  onOpenProfile: () => void;
  onNavigate?: (view: AppView, section?: UserSection) => void;
}

const SECTION_DETAILS: Record<
  UserSection,
  {
    title: string;
    subtitle: string;
    description: string;
    icon: React.FC<{ className?: string }>;
    accentColor: string;
    badgeBg: string;
    badgeText: string;
    ticketCategoryDesc: string;
    useCases: { title: string; desc: string }[];
    popularTags: string[];
  }
> = {
  student: {
    title: 'Students Collaboration Hub',
    subtitle: 'Find project teammates based on skills, interests, and course requirements',
    description:
      'Connect with fellow students for hackathons, engineering capstones, research projects, design critiques, and technical builds.',
    icon: GraduationCap,
    accentColor: '#E8491D',
    badgeBg: 'bg-[#FDE4D8] border-[#E8491D]/40 text-[#E8491D]',
    badgeText: 'Student Network',
    ticketCategoryDesc: 'Post projects, capstone topics, or hackathon squad requirements to find student co-builders.',
    useCases: [
      {
        title: 'Hackathon Squads',
        desc: 'Team up with backend developers, UI/UX designers, and ML researchers.',
      },
      {
        title: 'Capstone & Term Projects',
        desc: 'Match with classmates whose technical competencies complement yours.',
      },
      {
        title: 'Skill Exchanges & Mentorship',
        desc: 'Learn new tech stacks through peer-to-peer coding and project collaboration.',
      },
    ],
    popularTags: ['React', 'Python', 'Machine Learning', 'UI/UX', 'Mobile App', 'Cloud', 'Data Science'],
  },
  homemaker: {
    title: 'Homemakers & Local Creators Hub',
    subtitle: 'Find nearby people to collaborate on small businesses, services, and craft boutiques',
    description:
      'Partner with peers to launch or expand home bakeries, catering, custom tailoring, event decor, boutique crafts, or neighborhood services.',
    icon: Home,
    accentColor: '#10B981',
    badgeBg: 'bg-[#ECFDF5] border-emerald-300 text-emerald-800',
    badgeText: 'Homemaker Network',
    ticketCategoryDesc: 'Post your homemade craft, bakery, catering, or local service idea to find trusted partners.',
    useCases: [
      {
        title: 'Home Bakeries & Catering',
        desc: 'Partner with someone who loves baking while you handle order dispatch or packaging.',
      },
      {
        title: 'Boutiques & Handmade Crafts',
        desc: 'Team up to produce artisanal goods, crochet, jewelry, or handmade gifts.',
      },
      {
        title: 'Neighborhood Services',
        desc: 'Co-organize after-school workshops, hobby classes, or local event planning.',
      },
    ],
    popularTags: ['Artisan Baking', 'Tailoring', 'Event Styling', 'Catering', 'Handmade Crafts', 'Culinary'],
  },
  entrepreneur: {
    title: 'Entrepreneurs & Builders Hub',
    subtitle: 'Find co-founders, early partners, and collaborators with complementary skill sets',
    description:
      'Discover business partners, technical co-founders, growth marketers, or product specialists to build your next venture.',
    icon: Briefcase,
    accentColor: '#8B5CF6',
    badgeBg: 'bg-[#F5F3FF] border-purple-300 text-purple-800',
    badgeText: 'Entrepreneur Network',
    ticketCategoryDesc: 'Post your startup MVP, commercial project, or co-founder requirement to find dedicated builders.',
    useCases: [
      {
        title: 'Co-Founder Matching',
        desc: 'Find a technical counterpart for your business domain or vice-versa.',
      },
      {
        title: 'Early Stage Project Teaming',
        desc: 'Build minimum viable products (MVPs) with dedicated partner builders.',
      },
      {
        title: 'Growth & Go-To-Market',
        desc: 'Collaborate with sales experts, content creators, and community leads.',
      },
    ],
    popularTags: ['B2B SaaS', 'Marketing', 'Product Strategy', 'Full-Stack', 'E-Commerce', 'Fintech'],
  },
};

export const SectionOverview: React.FC<SectionOverviewProps> = ({
  onOpenAuth,
  onOpenProfile,
  onNavigate,
}) => {
  const { user, userProfile, activeSection } = useAuth();
  const current = SECTION_DETAILS[activeSection] || SECTION_DETAILS.student;
  const IconComponent = current.icon;

  // Tickets state
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [loadingTickets, setLoadingTickets] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'open' | 'in_progress' | 'closed'>('all');
  const [selectedTag, setSelectedTag] = useState<string | null>(null);

  // Modals state
  const [raiseModalOpen, setRaiseModalOpen] = useState(false);
  const [detailsModalTicket, setDetailsModalTicket] = useState<Ticket | null>(null);
  const [applyModalTicket, setApplyModalTicket] = useState<Ticket | null>(null);
  const [manageModalTicket, setManageModalTicket] = useState<Ticket | null>(null);

  // Deletion state
  const [deleteTicketTarget, setDeleteTicketTarget] = useState<Ticket | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);
  const [ticketNotice, setTicketNotice] = useState<string | null>(null);

  // Seed initial tickets on mount & subscribe to section tickets in real-time
  useEffect(() => {
    let isSubscribed = true;
    setLoadingTickets(true);

    seedInitialTicketsIfEmpty().catch((e) =>
      console.error('Failed to seed initial tickets:', e)
    );

    const unsubscribe = subscribeSectionTickets(activeSection, (fetchedTickets) => {
      if (isSubscribed) {
        setTickets(fetchedTickets);
        setLoadingTickets(false);
      }
    });

    return () => {
      isSubscribed = false;
      unsubscribe();
    };
  }, [activeSection]);

  // Check URL query parameters for deep-linked shared tickets (e.g. ?ticket=... or ?ticketId=...)
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const params = new URLSearchParams(window.location.search);
    const ticketParam = params.get('ticket') || params.get('ticketId') || params.get('t');
    if (!ticketParam) return;

    const decodedId = decodeTicketShareParam(ticketParam);
    if (!decodedId) return;

    let isMounted = true;
    getSectionTicketById(decodedId)
      .then((fetchedTicket) => {
        if (!isMounted) return;
        if (fetchedTicket) {
          setDetailsModalTicket(fetchedTicket);
        } else {
          setTicketNotice('The requested collaboration ticket could not be found or has been removed.');
          setTimeout(() => {
            if (isMounted) setTicketNotice(null);
          }, 6000);
        }
      })
      .catch((err) => {
        console.error('Error fetching deep-linked ticket:', err);
      });

    return () => {
      isMounted = false;
    };
  }, []);

  const handleCloseDetailsModal = () => {
    setDetailsModalTicket(null);
    if (typeof window !== 'undefined' && window.location.search) {
      const params = new URLSearchParams(window.location.search);
      if (params.has('ticket') || params.has('ticketId') || params.has('t')) {
        params.delete('ticket');
        params.delete('ticketId');
        params.delete('t');
        const newQuery = params.toString() ? `?${params.toString()}` : '';
        window.history.replaceState({}, '', `${window.location.pathname}${newQuery}`);
      }
    }
  };

  const handleOpenRaiseTicket = () => {
    if (!user) {
      onOpenAuth(activeSection);
      return;
    }
    setRaiseModalOpen(true);
  };

  const handleTicketCreated = (newTicket: Ticket) => {
    if (newTicket.section === activeSection) {
      setTickets((prev) => [newTicket, ...prev.filter((t) => t.id !== newTicket.id)]);
    }
    // Open details of the created ticket
    setDetailsModalTicket(newTicket);
  };

  const handleTicketUpdated = (updatedTicket: Ticket) => {
    setTickets((prev) =>
      prev.map((t) => (t.id === updatedTicket.id ? updatedTicket : t))
    );
    if (detailsModalTicket?.id === updatedTicket.id) {
      setDetailsModalTicket(updatedTicket);
    }
  };

  const handleTicketDeleted = (ticketId: string) => {
    setTickets((prev) => prev.filter((t) => t.id !== ticketId));
    if (detailsModalTicket?.id === ticketId) {
      setDetailsModalTicket(null);
    }
    if (manageModalTicket?.id === ticketId) {
      setManageModalTicket(null);
    }
  };

  const handleConfirmDeleteSectionTicket = async () => {
    if (!deleteTicketTarget || !user) return;
    setIsDeleting(true);
    setDeleteError(null);
    try {
      await deleteSectionTicket(deleteTicketTarget.id, deleteTicketTarget.creatorId);
      handleTicketDeleted(deleteTicketTarget.id);
      setDeleteTicketTarget(null);
    } catch (err: any) {
      console.error('Failed to delete collaboration ticket:', err);
      setDeleteError('Unable to delete this ticket. Please try again.');
    } finally {
      setIsDeleting(false);
    }
  };

  const handleToggleInterest = async (ticket: Ticket, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!user) {
      onOpenAuth(activeSection);
      return;
    }

    const currentCount = ticket.interestedCount || 0;
    const newCount = currentCount + 1;
    handleTicketUpdated({ ...ticket, interestedCount: newCount });

    try {
      await expressInterestInTicket(ticket.id, 1);
    } catch (err) {
      console.error('Failed to express interest:', err);
    }
  };

  // Filtered tickets
  const filteredTickets = tickets.filter((ticket) => {
    // 1. Strict Section Isolation: Ensure tickets strictly match activeSection
    if (ticket.section !== activeSection) return false;

    // 2. Status filter
    if (statusFilter !== 'all' && ticket.status !== statusFilter) return false;

    // 3. Tag filter
    if (selectedTag) {
      const hasTag = ticket.skillsRequired?.some(
        (s) => s.toLowerCase() === selectedTag.toLowerCase()
      );
      if (!hasTag) return false;
    }

    // 4. Search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchTitle = ticket.title.toLowerCase().includes(q);
      const matchDesc = ticket.description.toLowerCase().includes(q);
      const matchSkills = ticket.skillsRequired?.some((s) => s.toLowerCase().includes(q));
      const matchCreator = ticket.creatorName?.toLowerCase().includes(q);
      const matchLoc = ticket.location?.toLowerCase().includes(q);
      if (!matchTitle && !matchDesc && !matchSkills && !matchCreator && !matchLoc) {
        return false;
      }
    }

    return true;
  });

  const formatDate = (dateStr?: string) => {
    if (!dateStr) return 'Recently';
    try {
      const d = new Date(dateStr);
      const now = new Date();
      const diffHours = Math.floor((now.getTime() - d.getTime()) / (1000 * 60 * 60));
      if (diffHours < 1) return 'Just now';
      if (diffHours < 24) return `${diffHours}h ago`;
      if (diffHours < 48) return 'Yesterday';
      return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    } catch {
      return dateStr;
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Section Hero Banner */}
      <div className="w-full rounded-3xl border border-[#E5E2DA] bg-[#FFFFFF] p-5 sm:p-6 shadow-xs">
        {/* Top Bar of Hero: Network Badge on Left, Single Raise Ticket Button on Right */}
        <div className="flex items-center justify-between gap-4 pb-3.5 border-b border-[#F2EFE6] mb-5">
          <div className="inline-flex items-center gap-2 rounded-lg border px-3 py-1 text-[11px] font-bold uppercase tracking-widest bg-[#F2EFE6] border-[#E5E2DA]">
            <span className={`inline-flex items-center gap-1.5 ${current.badgeBg}`}>
              <IconComponent className="h-3.5 w-3.5" />
              {current.badgeText}
            </span>
          </div>

          <button
            id="btn-single-raise-ticket"
            onClick={handleOpenRaiseTicket}
            className="inline-flex items-center gap-1.5 rounded-xl bg-[#E8491D] hover:bg-[#FF5722] px-3.5 py-1.5 text-xs font-bold text-white shadow-2xs transition hover:-translate-y-0.5 active:translate-y-0 shrink-0"
          >
            <Plus className="h-3.5 w-3.5" />
            <span>Raise Ticket</span>
          </button>
        </div>

        {/* Two-Column Balanced Hero Content */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-center">
          {/* LEFT COLUMN — approx 55–60% width */}
          <div className="lg:col-span-7 flex flex-col justify-center space-y-3">
            <div className="space-y-1.5">
              <h1 className="text-2xl font-bold tracking-tight text-[#1A1A1A] sm:text-3xl">
                {current.title}
              </h1>

              <p className="text-xs sm:text-sm leading-relaxed text-[#55524A] max-w-xl">
                {current.description}
              </p>
            </div>

            {/* Focus area tags */}
            <div className="flex flex-wrap items-center gap-1.5 pt-1">
              <span className="text-xs font-semibold text-[#8A8578] uppercase tracking-wider">
                Focus Areas:
              </span>
              {current.popularTags.map((tag) => (
                <button
                  key={tag}
                  onClick={() => setSelectedTag(selectedTag === tag ? null : tag)}
                  className={`rounded-md px-2.5 py-0.5 text-[11px] font-medium border transition hover:-translate-y-0.5 ${
                    selectedTag === tag
                      ? 'bg-[#E8491D] text-white border-[#E8491D]'
                      : 'bg-[#FAF8F3] text-[#55524A] border-[#E5E2DA] hover:border-[#D4D0C5] hover:text-[#1A1A1A]'
                  }`}
                >
                  {tag}
                </button>
              ))}
              {selectedTag && (
                <button
                  onClick={() => setSelectedTag(null)}
                  className="text-[10px] font-bold text-[#E8491D] underline ml-1"
                >
                  Clear filter
                </button>
              )}
            </div>
          </div>

          {/* RIGHT COLUMN — approx 40–45% width (compact public collaboration activity indicator) */}
          <div className="lg:col-span-5 w-full flex justify-end">
            <div className="w-full">
              <SectionCollaborationActivityCard
                activeSection={activeSection}
              />
            </div>
          </div>
        </div>
      </div>

      {/* =========================================================================
          COLLAB TICKETS FEED SECTION
          ========================================================================= */}
      <div className="space-y-5">
        {/* Ticket Notice Alert (e.g., deep-linked ticket not found or archived) */}
        {ticketNotice && (
          <div className="flex items-center justify-between gap-3 rounded-2xl bg-amber-50 border border-amber-200 p-4 text-xs font-semibold text-amber-900 shadow-xs animate-in fade-in">
            <div className="flex items-center gap-2.5">
              <AlertCircle className="h-4 w-4 text-amber-600 shrink-0" />
              <span>{ticketNotice}</span>
            </div>
            <button
              onClick={() => setTicketNotice(null)}
              className="text-amber-700 hover:text-amber-900 text-xs font-bold underline"
            >
              Dismiss
            </button>
          </div>
        )}

        {/* Feed Header and Controls */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#E5E2DA] pb-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <h2 className="text-lg sm:text-xl font-bold tracking-tight text-[#1A1A1A]">
                Collaboration Tickets ({filteredTickets.length})
              </h2>
              <span className="rounded-md bg-[#FAF8F3] border border-[#E5E2DA] px-2 py-0.5 text-[10px] font-bold text-[#8A8578] uppercase">
                {activeSection} only
              </span>
            </div>
            <p className="text-xs text-[#55524A]">
              Active requests for co-builders, technical teammates, and collaborators in this track.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            {/* Status Filter buttons */}
            <div className="flex items-center rounded-xl bg-[#FFFFFF] border border-[#E5E2DA] p-0.5 text-xs shadow-2xs">
              {(['all', 'open', 'in_progress', 'closed'] as const).map((st) => (
                <button
                  key={st}
                  onClick={() => setStatusFilter(st)}
                  className={`rounded-lg px-2.5 py-1 font-semibold capitalize transition ${
                    statusFilter === st
                      ? 'bg-[#1A1A1A] text-white shadow-2xs'
                      : 'text-[#55524A] hover:text-[#1A1A1A]'
                  }`}
                >
                  {st.replace('_', ' ')}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Search Bar */}
        <div className="relative">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-[#8A8578]" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={`Search ${activeSection} tickets by title, skills, location, or keywords...`}
            className="w-full rounded-2xl border border-[#E5E2DA] bg-[#FFFFFF] pl-10 pr-4 py-2.5 text-xs text-[#1A1A1A] placeholder:text-[#8A8578] focus:border-[#E8491D] focus:outline-none shadow-2xs"
          />
        </div>

        {/* Tickets Grid */}
        {loadingTickets ? (
          <div className="py-16 flex flex-col items-center justify-center gap-3">
            <Loader2 className="h-7 w-7 animate-spin text-[#E8491D]" />
            <p className="text-xs font-semibold text-[#8A8578] uppercase tracking-wider">
              Loading {activeSection} tickets...
            </p>
          </div>
        ) : filteredTickets.length === 0 ? (
          <div className="rounded-3xl border border-dashed border-[#D4D0C5] bg-[#FFFFFF] p-8 text-center space-y-3">
            <div className="mx-auto flex h-10 w-10 items-center justify-center rounded-2xl bg-[#FAF8F3] border border-[#E5E2DA] text-[#8A8578]">
              <Sparkles className="h-5 w-5 text-[#E8491D]" />
            </div>
            <div className="space-y-1">
              <h3 className="text-sm font-bold text-[#1A1A1A]">No tickets found in this view</h3>
              <p className="text-xs text-[#55524A] max-w-md mx-auto leading-relaxed">
                {searchQuery || selectedTag || statusFilter !== 'all'
                  ? 'Try clearing your search filters or status selector.'
                  : `Active collaboration tickets raised in ${current.title} will appear here.`}
              </p>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {filteredTickets.map((ticket) => {
              const isCreator = Boolean(user && user.uid === ticket.creatorId);

              return (
                <div
                  key={ticket.id}
                  onClick={() => setDetailsModalTicket(ticket)}
                  className="group relative flex flex-col justify-between rounded-3xl border border-[#E5E2DA] bg-[#FFFFFF] p-5 shadow-sm transition hover:shadow-md hover:border-[#D4D0C5] cursor-pointer"
                >
                  {/* Card Top: Status & Track & Actions */}
                  <div className="space-y-3">
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span
                          className={`inline-flex items-center gap-1 rounded-md px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider ${
                            ticket.status === 'open'
                              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                              : ticket.status === 'in_progress'
                              ? 'bg-amber-50 text-amber-800 border border-amber-200'
                              : 'bg-[#F2EFE6] text-[#8A8578] border border-[#E5E2DA]'
                          }`}
                        >
                          <span
                            className={`h-1.5 w-1.5 rounded-full ${
                              ticket.status === 'open'
                                ? 'bg-emerald-600 animate-pulse'
                                : ticket.status === 'in_progress'
                                ? 'bg-amber-600'
                                : 'bg-[#8A8578]'
                            }`}
                          />
                          {ticket.status === 'open' ? 'Open' : ticket.status === 'in_progress' ? 'In Progress' : 'Closed'}
                        </span>

                        {isCreator && (
                          <span className="rounded-md bg-[#FAF8F3] border border-[#E8491D]/30 px-2 py-0.5 text-[10px] font-bold text-[#E8491D]">
                            Your Ticket
                          </span>
                        )}
                      </div>

                      <span className="text-[11px] text-[#8A8578] flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {formatDate(ticket.createdAt)}
                      </span>
                    </div>

                    {/* Title */}
                    <h3 className="text-sm sm:text-base font-bold text-[#1A1A1A] group-hover:text-[#E8491D] transition line-clamp-2 leading-snug">
                      {ticket.title}
                    </h3>

                    {/* Short Description */}
                    <p className="text-xs text-[#55524A] line-clamp-3 leading-relaxed">
                      {ticket.description}
                    </p>

                    {/* Skills Required Badges */}
                    <div className="flex flex-wrap gap-1 pt-1">
                      {ticket.skillsRequired && ticket.skillsRequired.slice(0, 3).map((skill, idx) => (
                        <span
                          key={idx}
                          className="rounded-md bg-[#FAF8F3] border border-[#E5E2DA] px-2 py-0.5 text-[10px] font-medium text-[#1A1A1A]"
                        >
                          {skill}
                        </span>
                      ))}
                      {ticket.skillsRequired && ticket.skillsRequired.length > 3 && (
                        <span className="rounded-md bg-[#FAF8F3] border border-[#E5E2DA] px-1.5 py-0.5 text-[10px] font-semibold text-[#8A8578]">
                          +{ticket.skillsRequired.length - 3}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Card Bottom: Creator + Meta + Actions */}
                  <div className="pt-4 mt-4 border-t border-[#E5E2DA] space-y-3">
                    {/* Creator line */}
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2 overflow-hidden">
                        {ticket.creatorPhotoURL ? (
                          <img
                            src={ticket.creatorPhotoURL}
                            alt={ticket.creatorName}
                            className="h-6 w-6 rounded-full object-cover border border-[#E5E2DA]"
                            referrerPolicy="no-referrer"
                          />
                        ) : (
                          <div className="flex h-6 w-6 items-center justify-center rounded-full bg-[#FAF8F3] border border-[#E5E2DA] text-[#E8491D] font-bold text-[10px]">
                            {(ticket.creatorName || 'U').charAt(0).toUpperCase()}
                          </div>
                        )}
                        <span className="text-xs font-semibold text-[#1A1A1A] truncate">
                          {ticket.creatorName}
                        </span>
                      </div>

                      <div className="flex items-center gap-2 text-[11px] text-[#8A8578] shrink-0 font-medium">
                        <span className="flex items-center gap-1">
                          <Users className="h-3 w-3 text-[#E8491D]" />
                          {ticket.peopleNeeded || 1} needed
                        </span>
                      </div>
                    </div>

                    {/* Location & Deadline info */}
                    <div className="flex items-center justify-between text-[11px] text-[#8A8578]">
                      <span className="flex items-center gap-1 truncate max-w-[150px]">
                        <MapPin className="h-3 w-3 text-[#8A8578]" />
                        {ticket.location || 'Remote'}
                      </span>
                      {ticket.deadline && (
                        <span className="flex items-center gap-1">
                          <Calendar className="h-3 w-3 text-[#8A8578]" />
                          {ticket.deadline}
                        </span>
                      )}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-between gap-2 pt-1">
                      <button
                        onClick={(e) => handleToggleInterest(ticket, e)}
                        className="flex items-center gap-1 rounded-lg border border-[#E5E2DA] bg-[#FAF8F3] px-2.5 py-1.5 text-[11px] font-semibold text-[#55524A] hover:bg-white hover:text-rose-600 transition"
                      >
                        <Heart className="h-3.5 w-3.5" />
                        <span>{ticket.interestedCount || 0}</span>
                      </button>

                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setDetailsModalTicket(ticket);
                          }}
                          className="rounded-lg border border-[#E5E2DA] bg-white px-3 py-1.5 text-xs font-semibold text-[#55524A] hover:bg-[#FAF8F3] hover:text-[#1A1A1A] transition"
                        >
                          View Details
                        </button>

                        {!isCreator ? (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              if (!user) {
                                onOpenAuth(activeSection);
                              } else {
                                setApplyModalTicket(ticket);
                              }
                            }}
                            disabled={ticket.status === 'closed'}
                            className="flex items-center gap-1 rounded-lg bg-[#E8491D] hover:bg-[#FF5722] px-3 py-1.5 text-xs font-bold text-white shadow-2xs transition disabled:opacity-50"
                          >
                            <Hammer className="h-3 w-3" />
                            <span>Want to Build</span>
                          </button>
                        ) : (
                          <div className="flex items-center gap-1.5">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setManageModalTicket(ticket);
                              }}
                              className="flex items-center gap-1 rounded-lg bg-[#1A1A1A] hover:bg-[#333333] px-3 py-1.5 text-xs font-bold text-white shadow-2xs transition"
                            >
                              <Settings className="h-3 w-3" />
                              <span>Manage</span>
                            </button>
                            <button
                              id={`btn-delete-section-ticket-${ticket.id}`}
                              title="Delete Ticket"
                              onClick={(e) => {
                                e.stopPropagation();
                                setDeleteError(null);
                                setDeleteTicketTarget(ticket);
                              }}
                              className="flex items-center justify-center p-1.5 rounded-lg border border-rose-200 bg-rose-50 hover:bg-rose-100 text-rose-700 transition"
                            >
                              <Trash2 className="h-3.5 w-3.5 text-rose-600" />
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Collaboration Use Cases Section */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xs font-bold uppercase tracking-widest text-[#8A8578]">
            Collaboration Tracks in this Section
          </h2>
          <span className="text-[11px] font-mono text-[#8A8578]">3 Modular Tracks</span>
        </div>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          {current.useCases.map((useCase, index) => (
            <div
              key={index}
              className="dark-interactive-card rounded-2xl border border-[#E5E2DA] bg-[#FFFFFF] p-5 shadow-sm"
            >
              <div className="flex h-7 w-7 items-center justify-center rounded-md bg-[#FDE4D8] border border-[#E8491D]/30 text-[#E8491D] mb-3 font-mono font-bold text-xs">
                0{index + 1}
              </div>
              <h3 className="text-sm font-bold text-[#1A1A1A] mb-1.5">{useCase.title}</h3>
              <p className="text-xs leading-relaxed text-[#55524A]">{useCase.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Modals */}
      <RaiseTicketModal
        section={activeSection}
        isOpen={raiseModalOpen}
        onClose={() => setRaiseModalOpen(false)}
        onTicketCreated={handleTicketCreated}
      />

      <TicketDetailsModal
        ticket={detailsModalTicket}
        isOpen={Boolean(detailsModalTicket)}
        onClose={handleCloseDetailsModal}
        onOpenApply={(t) => {
          setDetailsModalTicket(null);
          setApplyModalTicket(t);
        }}
        onOpenManage={(t) => {
          setDetailsModalTicket(null);
          setManageModalTicket(t);
        }}
        onTicketUpdated={handleTicketUpdated}
        onTicketDeleted={handleTicketDeleted}
        onOpenAuth={onOpenAuth}
        onNavigateToChat={() => onNavigate && onNavigate('chats')}
      />

      <TicketApplyModal
        ticket={applyModalTicket}
        isOpen={Boolean(applyModalTicket)}
        onClose={() => setApplyModalTicket(null)}
        onApplicationSent={(ticketId) => {
          setTickets((prev) =>
            prev.map((t) =>
              t.id === ticketId
                ? {
                    ...t,
                    applicationsCount: (t.applicationsCount || 0) + 1,
                    interestedCount: (t.interestedCount || 0) + 1,
                  }
                : t
            )
          );
        }}
      />

      <ManageTicketModal
        ticket={manageModalTicket}
        isOpen={Boolean(manageModalTicket)}
        onClose={() => setManageModalTicket(null)}
        onTicketUpdated={handleTicketUpdated}
        onTicketDeleted={handleTicketDeleted}
      />

      {/* Delete Ticket Confirmation Dialog Modal */}
      {deleteTicketTarget && (
        <div
          className="fixed inset-0 z-60 flex items-center justify-center bg-[#1A1A1A]/60 p-4 backdrop-blur-xs animate-in fade-in"
          onClick={() => {
            if (!isDeleting) {
              setDeleteTicketTarget(null);
              setDeleteError(null);
            }
          }}
        >
          <div
            className="w-full max-w-md rounded-2xl border border-[#E5E2DA] bg-[#FFFFFF] p-6 shadow-2xl space-y-4 animate-in zoom-in-95"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start gap-3.5">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-rose-100 text-rose-600 border border-rose-200 shrink-0">
                <Trash2 className="h-5 w-5" />
              </div>
              <div className="space-y-1">
                <h3 className="text-base font-bold text-[#1A1A1A]">
                  Delete this collaboration ticket?
                </h3>
                <p className="text-xs text-[#55524A] leading-relaxed">
                  This action will permanently remove this ticket from the community. Any collaboration activity associated with this ticket may also be removed. This action cannot be undone.
                </p>
                <div className="mt-2 rounded-xl bg-[#FAF8F3] border border-[#E5E2DA] p-2.5 text-xs font-semibold text-[#1A1A1A] line-clamp-2">
                  &ldquo;{deleteTicketTarget.title}&rdquo;
                </div>
              </div>
            </div>

            {deleteError && (
              <div className="flex items-center gap-2 rounded-xl bg-rose-50 border border-rose-200 p-3 text-xs text-rose-700">
                <AlertTriangle className="h-4 w-4 shrink-0 text-rose-600" />
                <span>{deleteError}</span>
              </div>
            )}

            <div className="flex items-center justify-end gap-2.5 pt-2 border-t border-[#E5E2DA]">
              <button
                type="button"
                id="btn-cancel-delete-section-ticket"
                disabled={isDeleting}
                onClick={() => {
                  setDeleteTicketTarget(null);
                  setDeleteError(null);
                }}
                className="rounded-xl border border-[#E5E2DA] bg-[#FFFFFF] hover:bg-[#FAF8F3] px-4 py-2 text-xs font-semibold text-[#55524A] transition disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                type="button"
                id="btn-confirm-delete-section-ticket"
                disabled={isDeleting}
                onClick={handleConfirmDeleteSectionTicket}
                className="flex items-center gap-1.5 rounded-xl bg-rose-600 hover:bg-rose-700 px-4 py-2 text-xs font-bold text-white shadow-sm transition disabled:opacity-50"
              >
                {isDeleting ? (
                  <>
                    <Loader2 className="h-3.5 w-3.5 animate-spin" />
                    <span>Deleting...</span>
                  </>
                ) : (
                  <>
                    <Trash2 className="h-3.5 w-3.5" />
                    <span>Delete Ticket</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
