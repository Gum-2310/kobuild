import React, { useState, useRef, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { UserSection, AppView, AppNotification, Conversation } from '../types';
import {
  subscribeUserNotifications,
  subscribeUserConversations,
  markNotificationAsRead,
  markAllNotificationsAsRead,
} from '../services/userService';
import { LogoutConfirmModal } from './LogoutConfirmModal';
import {
  GraduationCap,
  Home as HomeIcon,
  Briefcase,
  LogIn,
  LogOut,
  ShieldCheck,
  Sparkles,
  MessageSquare,
  ChevronDown,
  Users2,
  ArrowUpRight,
  Check,
  Bell,
  CheckCheck,
  Clock,
  Heart,
  Hammer,
  Rocket,
} from 'lucide-react';

interface NavbarProps {
  currentView: AppView;
  onNavigate: (view: AppView, section?: UserSection) => void;
  onOpenAuth: (section?: UserSection | null) => void;
  onOpenProfile: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  onNavigate,
  onOpenAuth,
  onOpenProfile,
}) => {
  const { user, userProfile, logout, activeSection, setActiveSection, loading } = useAuth();

  // Logout confirmation modal state
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);

  // Notifications State & Dropdown
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const notifDropdownRef = useRef<HTMLDivElement>(null);

  // Chats unread counts
  const [unreadChatCount, setUnreadChatCount] = useState<number>(0);

  // Desktop Collab Dropdown State
  const [collabDropdownOpen, setCollabDropdownOpen] = useState(false);
  const collabDropdownRef = useRef<HTMLDivElement>(null);

  // Mobile Collab Popover State
  const [mobileCollabOpen, setMobileCollabOpen] = useState(false);
  const mobileCollabRef = useRef<HTMLDivElement>(null);

  const isCollabActive =
    currentView === 'student' || currentView === 'homemaker' || currentView === 'entrepreneur';

  // Find which specific subsection is currently active, if any
  const activeCollabSection = isCollabActive ? (currentView as UserSection) : null;

  // Real-time notifications and chats subscriptions
  useEffect(() => {
    if (!user) {
      setNotifications([]);
      setUnreadChatCount(0);
      return;
    }

    const unsubNotifs = subscribeUserNotifications(user.uid, (notifs) => {
      setNotifications(notifs);
    });

    const unsubConvs = subscribeUserConversations(user.uid, (convs) => {
      let totalUnread = 0;
      convs.forEach((c) => {
        totalUnread += c.unreadCounts?.[user.uid] || 0;
      });
      setUnreadChatCount(totalUnread);
    });

    return () => {
      unsubNotifs();
      unsubConvs();
    };
  }, [user]);

  // Click outside to close notifications and collab dropdowns
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        notifDropdownRef.current &&
        !notifDropdownRef.current.contains(event.target as Node)
      ) {
        setNotificationsOpen(false);
      }
      if (
        collabDropdownRef.current &&
        !collabDropdownRef.current.contains(event.target as Node)
      ) {
        setCollabDropdownOpen(false);
      }
      if (
        mobileCollabRef.current &&
        !mobileCollabRef.current.contains(event.target as Node)
      ) {
        setMobileCollabOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const unreadNotifsCount = notifications.filter((n) => !n.read).length;

  const handleNotificationClick = async (notif: AppNotification) => {
    if (!notif.read) {
      await markNotificationAsRead(notif.id);
    }
    setNotificationsOpen(false);

    if (notif.type === 'message' || notif.relatedConversationId) {
      onNavigate('chats');
    } else if (notif.type === 'comment' || notif.type === 'reply' || notif.relatedPostId) {
      onNavigate('community');
    } else if (notif.relatedTicketId) {
      onNavigate('chats');
    } else {
      onNavigate('chats');
    }
  };

  const handleMarkAllRead = async () => {
    if (!user) return;
    await markAllNotificationsAsRead(user.uid);
  };

  // Handle clicking a specific Collab sub-track
  const handleSectionSelect = (section: UserSection) => {
    setActiveSection(section);
    onNavigate(section, section);
    setCollabDropdownOpen(false);
    setMobileCollabOpen(false);
  };

  return (
    <header className="sticky top-0 z-30 border-b border-[#E5E2DA] bg-[#FFFFFF]/95 backdrop-blur-md">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6 lg:px-8">
        {/* Brand Logo & Name -> Navigates to HOME page */}
        <div className="flex items-center gap-5">
          <button
            id="nav-brand-kobuildd"
            onClick={() => {
              onNavigate('home');
              setCollabDropdownOpen(false);
              setMobileCollabOpen(false);
            }}
            className="flex items-center gap-2.5 text-left transition hover:opacity-90 group"
            title="Go to Home"
          >
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#FDE4D8] border border-[#E8491D]/30 text-[#E8491D] shadow-xs group-hover:border-[#E8491D]/60 group-hover:bg-[#FDE4D8] transition">
              <Sparkles className="h-4.5 w-4.5 text-[#E8491D]" />
            </div>
            <div>
              <span className="text-base font-bold tracking-tight text-[#1A1A1A] group-hover:text-[#E8491D] transition-colors">kobuildd</span>
              <span className="ml-2 hidden text-[10px] font-bold uppercase tracking-wider text-[#E8491D] bg-[#FDE4D8] px-1.5 py-0.5 rounded border border-[#E8491D]/35 sm:inline-block">
                Network
              </span>
            </div>
          </button>

          {/* Desktop Main Navigation Tabs: Home | Communities | Collab | Chats | Build Spaces */}
          <nav
            className="hidden lg:flex items-center space-x-1 rounded-xl bg-[#F2EFE6] p-1 border border-[#E5E2DA]"
            aria-label="Main Navigation"
          >
            {/* 1. Home Tab */}
            <button
              id="nav-tab-home"
              onClick={() => {
                onNavigate('home');
                setCollabDropdownOpen(false);
              }}
              className={`flex items-center gap-1.5 rounded-lg px-3.5 py-1.5 text-xs font-semibold transition-all duration-200 ease-out ${
                currentView === 'home'
                  ? 'bg-white text-[#1A1A1A] shadow-xs'
                  : 'text-[#55524A] hover:text-[#1A1A1A] hover:bg-white/60'
              }`}
            >
              <HomeIcon className="h-3.5 w-3.5" />
              <span>Home</span>
            </button>

            {/* 2. Communities Tab */}
            <button
              id="nav-tab-communities"
              onClick={() => {
                onNavigate('communities');
                setCollabDropdownOpen(false);
              }}
              className={`flex items-center gap-1.5 rounded-lg px-3.5 py-1.5 text-xs font-semibold transition-all duration-200 ease-out ${
                currentView === 'communities' || currentView === 'community'
                  ? 'bg-white text-[#1A1A1A] shadow-xs'
                  : 'text-[#55524A] hover:text-[#1A1A1A] hover:bg-white/60'
              }`}
            >
              <Users2 className="h-3.5 w-3.5 text-[#E8491D]" />
              <span>Communities</span>
            </button>

            {/* 3. Collab Tab with Small Clean Popover */}
            <div className="relative" ref={collabDropdownRef}>
              <button
                id="nav-tab-collab"
                onClick={() => setCollabDropdownOpen((prev) => !prev)}
                className={`flex items-center gap-1.5 rounded-lg px-3.5 py-1.5 text-xs font-semibold transition-all duration-200 ease-out ${
                  isCollabActive || currentView === 'collab'
                    ? 'bg-white text-[#1A1A1A] shadow-xs'
                    : 'text-[#55524A] hover:text-[#1A1A1A] hover:bg-white/60'
                }`}
                aria-expanded={collabDropdownOpen}
                aria-haspopup="true"
              >
                <Briefcase className="h-3.5 w-3.5 text-[#E8491D]" />
                <span>Collab</span>
              </button>

              {/* Small Clean Dropdown Popover */}
              {collabDropdownOpen && (
                <div
                  className="absolute left-0 mt-1.5 w-48 rounded-2xl border border-[#E5E2DA] bg-[#FFFFFF] p-1.5 shadow-xl z-50 animate-in fade-in zoom-in-95 duration-100"
                >
                  <div className="space-y-0.5">
                    <button
                      id="nav-collab-opt-student"
                      onClick={() => handleSectionSelect('student')}
                      className={`w-full flex items-center gap-2.5 rounded-xl px-3 py-2 text-xs font-semibold transition text-left ${
                        activeCollabSection === 'student'
                          ? 'bg-[#FDE4D8] text-[#E8491D]'
                          : 'text-[#1A1A1A] hover:bg-[#FAF8F3]'
                      }`}
                    >
                      <span className="text-base leading-none">🎓</span>
                      <span>Students</span>
                    </button>

                    <button
                      id="nav-collab-opt-homemaker"
                      onClick={() => handleSectionSelect('homemaker')}
                      className={`w-full flex items-center gap-2.5 rounded-xl px-3 py-2 text-xs font-semibold transition text-left ${
                        activeCollabSection === 'homemaker'
                          ? 'bg-[#ECFDF5] text-emerald-800'
                          : 'text-[#1A1A1A] hover:bg-[#FAF8F3]'
                      }`}
                    >
                      <span className="text-base leading-none">🏠</span>
                      <span>Homemakers</span>
                    </button>

                    <button
                      id="nav-collab-opt-entrepreneur"
                      onClick={() => handleSectionSelect('entrepreneur')}
                      className={`w-full flex items-center gap-2.5 rounded-xl px-3 py-2 text-xs font-semibold transition text-left ${
                        activeCollabSection === 'entrepreneur'
                          ? 'bg-[#F5F3FF] text-purple-800'
                          : 'text-[#1A1A1A] hover:bg-[#FAF8F3]'
                      }`}
                    >
                      <span className="text-base leading-none">💼</span>
                      <span>Entrepreneurs</span>
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* 4. Chats Tab */}
            <button
              id="nav-tab-chats"
              onClick={() => {
                onNavigate('chats');
                setCollabDropdownOpen(false);
              }}
              className={`relative flex items-center gap-1.5 rounded-lg px-3.5 py-1.5 text-xs font-semibold transition-all duration-200 ease-out ${
                currentView === 'chats'
                  ? 'bg-white text-[#1A1A1A] shadow-xs'
                  : 'text-[#55524A] hover:text-[#1A1A1A] hover:bg-white/60'
              }`}
            >
              <MessageSquare className="h-3.5 w-3.5 text-[#55524A]" />
              <span>Chats</span>
              {unreadChatCount > 0 && (
                <span className="flex h-4 min-w-4 items-center justify-center rounded-full bg-[#E8491D] px-1 text-[9px] font-bold text-white shadow-xs animate-in zoom-in">
                  {unreadChatCount > 99 ? '99+' : unreadChatCount}
                </span>
              )}
            </button>

            {/* 5. Build Spaces Tab */}
            <button
              id="nav-tab-buildspace"
              onClick={() => {
                onNavigate('build_spaces');
                setCollabDropdownOpen(false);
              }}
              className={`flex items-center gap-1.5 rounded-lg px-3.5 py-1.5 text-xs font-semibold transition-all duration-200 ease-out ${
                currentView === 'build_spaces' || currentView === 'build_space' || currentView === 'buildspace'
                  ? 'bg-white text-[#1A1A1A] shadow-xs'
                  : 'text-[#55524A] hover:text-[#1A1A1A] hover:bg-white/60'
              }`}
            >
              <Hammer className="h-3.5 w-3.5 text-[#E8491D]" />
              <span>Build Spaces</span>
            </button>
          </nav>
        </div>

        {/* Status and User Action */}
        <div className="flex items-center gap-3">
          {/* Backend Status indicator */}
          <div className="hidden xl:flex items-center gap-1.5 rounded-full bg-[#F2EFE6] px-2.5 py-1 text-xs font-medium text-[#55524A] border border-[#E5E2DA]">
            <ShieldCheck className="h-3.5 w-3.5 text-[#E8491D]" />
            <span className="font-mono text-[11px]">Firestore Connected</span>
          </div>

          {/* Real-time Notifications Bell */}
          {user && (
            <div className="relative" ref={notifDropdownRef}>
              <button
                id="btn-notifications-bell"
                onClick={() => setNotificationsOpen((prev) => !prev)}
                className={`relative flex h-8 w-8 items-center justify-center rounded-xl border transition ${
                  notificationsOpen
                    ? 'border-[#E8491D] bg-[#FDE4D8]/60 text-[#E8491D]'
                    : 'border-[#E5E2DA] bg-[#FFFFFF] text-[#55524A] hover:border-[#D4D0C5] hover:bg-[#FAF8F3] hover:text-[#1A1A1A]'
                }`}
                title="Notifications"
              >
                <Bell className="h-4 w-4" />
                {unreadNotifsCount > 0 && (
                  <span className="absolute -top-1 -right-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-[#E8491D] px-1 text-[9px] font-bold text-white shadow-xs">
                    {unreadNotifsCount > 99 ? '99+' : unreadNotifsCount}
                  </span>
                )}
              </button>

              {/* Notifications Dropdown Panel */}
              {notificationsOpen && (
                <div className="absolute right-0 mt-2 w-80 sm:w-96 rounded-2xl border border-[#E5E2DA] bg-[#FFFFFF] shadow-2xl overflow-hidden z-50 animate-in fade-in zoom-in-95 duration-150">
                  <div className="flex items-center justify-between border-b border-[#E5E2DA] bg-[#FAF8F3] px-4 py-3">
                    <div className="flex items-center gap-2">
                      <Bell className="h-4 w-4 text-[#E8491D]" />
                      <h4 className="text-xs font-bold text-[#1A1A1A]">Notifications</h4>
                      {unreadNotifsCount > 0 && (
                        <span className="rounded-full bg-[#FDE4D8] px-1.5 py-0.2 text-[10px] font-bold text-[#E8491D] border border-[#E8491D]/30">
                          {unreadNotifsCount} new
                        </span>
                      )}
                    </div>
                    {unreadNotifsCount > 0 && (
                      <button
                        onClick={handleMarkAllRead}
                        className="text-[11px] text-[#8A8578] hover:text-[#E8491D] font-medium flex items-center gap-1 transition"
                      >
                        <CheckCheck className="h-3 w-3" />
                        <span>Mark all read</span>
                      </button>
                    )}
                  </div>

                  <div className="max-h-80 overflow-y-auto divide-y divide-[#E5E2DA]">
                    {notifications.length === 0 ? (
                      <div className="py-10 text-center text-[#8A8578]">
                        <Bell className="h-8 w-8 mx-auto mb-2 opacity-30 text-[#8A8578]" />
                        <p className="text-xs font-medium text-[#1A1A1A]">No notifications yet</p>
                        <p className="text-[11px] text-[#55524A] mt-0.5">
                          Updates on ticket applications and comments will appear here.
                        </p>
                      </div>
                    ) : (
                      notifications.slice(0, 20).map((notif) => {
                        return (
                          <div
                            key={notif.id}
                            onClick={() => handleNotificationClick(notif)}
                            className={`p-3.5 transition cursor-pointer hover:bg-[#FAF8F3] ${
                              !notif.read ? 'bg-[#FDE4D8]/15 font-medium' : 'bg-[#FFFFFF]'
                            }`}
                          >
                            <div className="flex items-start gap-2.5">
                              {notif.senderPhotoURL ? (
                                <img
                                  src={notif.senderPhotoURL}
                                  alt={notif.senderName || 'Sender'}
                                  className="h-7 w-7 rounded-lg object-cover border border-[#E5E2DA] shrink-0 mt-0.5"
                                  referrerPolicy="no-referrer"
                                />
                              ) : (
                                <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-[#FAF8F3] border border-[#E5E2DA] text-[#E8491D] shrink-0 mt-0.5">
                                  {notif.type === 'want_to_build' ? (
                                    <Rocket className="h-3.5 w-3.5" />
                                  ) : notif.type === 'interest' ? (
                                    <Heart className="h-3.5 w-3.5" />
                                  ) : notif.type === 'comment' || notif.type === 'reply' ? (
                                    <MessageSquare className="h-3.5 w-3.5" />
                                  ) : (
                                    <Sparkles className="h-3.5 w-3.5" />
                                  )}
                                </div>
                              )}
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center justify-between gap-1">
                                  <p className="text-xs font-bold text-[#1A1A1A] truncate">
                                    {notif.title}
                                  </p>
                                  {!notif.read && (
                                    <span className="h-1.5 w-1.5 rounded-full bg-[#E8491D] shrink-0" />
                                  )}
                                </div>
                                <p className="text-[11px] text-[#55524A] line-clamp-2 mt-0.5">
                                  {notif.message}
                                </p>
                                <span className="text-[10px] text-[#8A8578] font-mono mt-1 block">
                                  {new Date(notif.createdAt).toLocaleTimeString([], {
                                    hour: '2-digit',
                                    minute: '2-digit',
                                  })}
                                </span>
                              </div>
                            </div>
                          </div>
                        );
                      })
                    )}
                  </div>
                </div>
              )}
            </div>
          )}

          {loading ? (
            <div className="h-8 w-24 animate-pulse rounded-lg bg-[#F2EFE6]" />
          ) : user ? (
            <div className="flex items-center gap-2">
              {/* Profile button */}
              <button
                id="btn-nav-profile"
                onClick={() => {
                  onOpenProfile();
                  setCollabDropdownOpen(false);
                  setMobileCollabOpen(false);
                }}
                className={`flex items-center gap-2 rounded-xl border px-3 py-1.5 text-xs font-medium transition duration-150 hover:-translate-y-0.5 ${
                  currentView === 'profile'
                    ? 'border-[#E8491D]/50 bg-[#FDE4D8]/50 text-[#1A1A1A] shadow-xs'
                    : 'border-[#E5E2DA] bg-[#FFFFFF] text-[#1A1A1A] hover:bg-[#F5F1E8] hover:border-[#D4D0C5]'
                }`}
              >
                {user.photoURL ? (
                  <img
                    src={user.photoURL}
                    alt={userProfile?.name || 'User'}
                    className="h-5 w-5 rounded-full object-cover border border-[#E5E2DA]"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <div className="flex h-5 w-5 items-center justify-center rounded-full bg-[#F2EFE6] border border-[#D4D0C5] text-[10px] font-bold text-[#1A1A1A]">
                    {(userProfile?.name || user.email || 'U').charAt(0).toUpperCase()}
                  </div>
                )}
                <span className="max-w-[100px] truncate font-semibold text-[#1A1A1A]">
                  {userProfile?.name || user.displayName || user.email?.split('@')[0]}
                </span>
                <span className="text-[11px] text-[#8A8578] hidden sm:inline">• Profile</span>
              </button>

              {/* Sign out */}
              <button
                id="btn-logout"
                onClick={() => setShowLogoutConfirm(true)}
                title="Sign Out"
                className="flex h-8 w-8 items-center justify-center rounded-lg border border-[#E5E2DA] bg-[#FFFFFF] text-[#55524A] transition hover:bg-[#F5F1E8] hover:text-[#1A1A1A] hover:border-[#D4D0C5]"
              >
                <LogOut className="h-4 w-4" />
              </button>
            </div>
          ) : (
            <button
              id="btn-open-auth"
              onClick={() => onOpenAuth(null)}
              className="flex items-center gap-2 rounded-xl bg-[#E8491D] hover:bg-[#FF5722] px-4 py-2 text-xs font-semibold text-white shadow-sm transition hover:-translate-y-0.5 active:translate-y-0 active:scale-[0.99]"
            >
              <LogIn className="h-3.5 w-3.5" />
              <span>Sign In / Join</span>
            </button>
          )}
        </div>
      </div>

      {/* Mobile Main Navigation Bar: Home | Communities | Collab | Chats | Build Spaces */}
      <div className="flex lg:hidden items-center justify-between border-t border-[#E5E2DA] px-2 py-1.5 bg-[#FFFFFF] gap-1">
        <button
          id="mobile-nav-home"
          onClick={() => {
            onNavigate('home');
            setMobileCollabOpen(false);
          }}
          className={`flex-1 text-center text-xs font-semibold py-2 rounded-lg transition-all duration-200 ease-out ${
            currentView === 'home'
              ? 'bg-[#F2EFE6] text-[#1A1A1A]'
              : 'text-[#55524A] hover:text-[#1A1A1A]'
          }`}
        >
          Home
        </button>

        <button
          id="mobile-nav-communities"
          onClick={() => {
            onNavigate('communities');
            setMobileCollabOpen(false);
          }}
          className={`flex-1 text-center text-xs font-semibold py-2 rounded-lg transition-all duration-200 ease-out ${
            currentView === 'communities' || currentView === 'community'
              ? 'bg-[#F2EFE6] text-[#1A1A1A]'
              : 'text-[#55524A] hover:text-[#1A1A1A]'
          }`}
        >
          Communities
        </button>

        <div className="relative flex-1" ref={mobileCollabRef}>
          <button
            id="mobile-nav-collab"
            onClick={() => setMobileCollabOpen((prev) => !prev)}
            className={`w-full flex items-center justify-center gap-1 text-xs font-semibold py-2 rounded-lg transition-all duration-200 ease-out ${
              isCollabActive || currentView === 'collab'
                ? 'bg-[#F2EFE6] text-[#1A1A1A]'
                : 'text-[#55524A] hover:text-[#1A1A1A]'
            }`}
          >
            <span>Collab</span>
          </button>

          {/* Mobile Clean Compact Popover */}
          {mobileCollabOpen && (
            <div className="absolute left-1/2 -translate-x-1/2 top-full mt-1.5 w-48 rounded-2xl border border-[#E5E2DA] bg-[#FFFFFF] p-1.5 shadow-xl z-50 animate-in fade-in zoom-in-95 duration-100">
              <div className="space-y-0.5">
                <button
                  id="mobile-collab-opt-student"
                  onClick={() => handleSectionSelect('student')}
                  className={`w-full flex items-center gap-2.5 rounded-xl px-3 py-2 text-xs font-semibold transition text-left ${
                    activeCollabSection === 'student'
                      ? 'bg-[#FDE4D8] text-[#E8491D]'
                      : 'text-[#1A1A1A] hover:bg-[#FAF8F3]'
                  }`}
                >
                  <span className="text-base leading-none">🎓</span>
                  <span>Students</span>
                </button>

                <button
                  id="mobile-collab-opt-homemaker"
                  onClick={() => handleSectionSelect('homemaker')}
                  className={`w-full flex items-center gap-2.5 rounded-xl px-3 py-2 text-xs font-semibold transition text-left ${
                    activeCollabSection === 'homemaker'
                      ? 'bg-[#ECFDF5] text-emerald-800'
                      : 'text-[#1A1A1A] hover:bg-[#FAF8F3]'
                  }`}
                >
                  <span className="text-base leading-none">🏠</span>
                  <span>Homemakers</span>
                </button>

                <button
                  id="mobile-collab-opt-entrepreneur"
                  onClick={() => handleSectionSelect('entrepreneur')}
                  className={`w-full flex items-center gap-2.5 rounded-xl px-3 py-2 text-xs font-semibold transition text-left ${
                    activeCollabSection === 'entrepreneur'
                      ? 'bg-[#F5F3FF] text-purple-800'
                      : 'text-[#1A1A1A] hover:bg-[#FAF8F3]'
                  }`}
                >
                  <span className="text-base leading-none">💼</span>
                  <span>Entrepreneurs</span>
                </button>
              </div>
            </div>
          )}
        </div>

        <button
          id="mobile-nav-chats"
          onClick={() => {
            onNavigate('chats');
            setMobileCollabOpen(false);
          }}
          className={`flex-1 flex items-center justify-center gap-1 text-xs font-semibold py-2 rounded-lg transition-all duration-200 ease-out ${
            currentView === 'chats'
              ? 'bg-[#F2EFE6] text-[#1A1A1A]'
              : 'text-[#55524A] hover:text-[#1A1A1A]'
          }`}
        >
          <span>Chats</span>
          {unreadChatCount > 0 && (
            <span className="flex h-3.5 min-w-3.5 items-center justify-center rounded-full bg-[#E8491D] px-1 text-[8px] font-bold text-white">
              {unreadChatCount > 99 ? '99+' : unreadChatCount}
            </span>
          )}
        </button>

        <button
          id="mobile-nav-buildspace"
          onClick={() => {
            onNavigate('build_spaces');
            setMobileCollabOpen(false);
          }}
          className={`flex-1 text-center text-xs font-semibold py-2 rounded-lg transition-all duration-200 ease-out ${
            currentView === 'build_spaces' || currentView === 'build_space' || currentView === 'buildspace'
              ? 'bg-[#F2EFE6] text-[#1A1A1A]'
              : 'text-[#55524A] hover:text-[#1A1A1A]'
          }`}
        >
          Build Spaces
        </button>
      </div>

      {/* Logout Confirmation Dialog */}
      <LogoutConfirmModal
        isOpen={showLogoutConfirm}
        onClose={() => setShowLogoutConfirm(false)}
        onConfirm={() => logout()}
      />
    </header>
  );
};


