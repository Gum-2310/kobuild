import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import { UserSection, AppView, Conversation, ChatMessage } from '../types';
import {
  subscribeUserConversations,
  subscribeConversationMessages,
  sendChatMessage,
  markConversationAsRead,
} from '../services/userService';
import {
  MessageSquare,
  Send,
  Lock,
  Search,
  Sparkles,
  Loader2,
  GraduationCap,
  Home as HomeIcon,
  Briefcase,
} from 'lucide-react';
import { UserProfilePopover } from './UserProfilePopover';

interface ChatsViewProps {
  onOpenAuth: (section?: UserSection | null) => void;
  onNavigate: (view: AppView, section?: UserSection) => void;
  initialConversationId?: string | null;
}

export const ChatsView: React.FC<ChatsViewProps> = ({
  onOpenAuth,
  onNavigate,
  initialConversationId,
}) => {
  const { user, userProfile } = useAuth();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [loadingConvs, setLoadingConvs] = useState(true);
  const [activeChatId, setActiveChatId] = useState<string | null>(initialConversationId || null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [loadingMessages, setLoadingMessages] = useState(false);
  const [messageInput, setMessageInput] = useState('');
  const [sending, setSending] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Target user profile popover state
  const [popoverUser, setPopoverUser] = useState<{
    uid: string;
    name: string;
    photoURL?: string | null;
    section?: UserSection;
    location?: string;
    bio?: string;
    skills?: string[];
  } | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Subscribe to real-time conversations for current authenticated user
  useEffect(() => {
    if (!user) {
      setConversations([]);
      setLoadingConvs(false);
      return;
    }

    setLoadingConvs(true);
    const unsub = subscribeUserConversations(user.uid, (convs) => {
      setConversations(convs);
      setLoadingConvs(false);

      // If activeChatId not set yet or initial was provided, set first or initial
      setActiveChatId((current) => {
        if (current && convs.some((c) => c.id === current)) {
          return current;
        }
        if (initialConversationId && convs.some((c) => c.id === initialConversationId)) {
          return initialConversationId;
        }
        return convs.length > 0 ? convs[0].id : null;
      });
    });

    return () => unsub();
  }, [user, initialConversationId]);

  // Subscribe to real-time messages for active conversation
  useEffect(() => {
    if (!activeChatId || !user) {
      setMessages([]);
      return;
    }

    setLoadingMessages(true);
    // Mark as read in Firestore
    markConversationAsRead(activeChatId, user.uid);

    const unsub = subscribeConversationMessages(activeChatId, (msgs) => {
      setMessages(msgs);
      setLoadingMessages(false);
      setTimeout(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    });

    return () => unsub();
  }, [activeChatId, user]);

  const activeConversation = conversations.find((c) => c.id === activeChatId) || null;

  // Resolve other participant details for direct chat
  const otherParticipant = React.useMemo(() => {
    if (!activeConversation || !user) return null;
    const otherId = (activeConversation.participants || []).find((p) => p !== user.uid);
    if (!otherId) return null;

    const details = activeConversation.participantDetails?.[otherId];
    const name = details?.name || activeConversation.participantNames?.[otherId] || 'Builder';

    return {
      uid: otherId,
      name,
      photoURL: details?.photoURL || null,
      section: details?.section || 'student',
      location: details?.location || '',
      bio: details?.bio || '',
      skills: details?.skills || [],
    };
  }, [activeConversation, user]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageInput.trim() || !activeChatId || !user || !userProfile || sending) return;

    const textToSend = messageInput.trim();
    setMessageInput('');
    setSending(true);

    try {
      await sendChatMessage(activeChatId, textToSend, userProfile);
    } catch (err) {
      console.error('Failed to send message:', err);
      // Restore input on failure
      setMessageInput(textToSend);
    } finally {
      setSending(false);
    }
  };

  const filteredConversations = conversations.filter((c) => {
    if (!searchQuery.trim()) return true;
    const queryLower = searchQuery.toLowerCase();
    const otherId = (c.participants || []).find((p) => p !== user?.uid);
    const otherName = (otherId && c.participantNames?.[otherId]) || '';
    const title = c.title || '';
    const contextTitle = c.context?.title || '';
    return (
      otherName.toLowerCase().includes(queryLower) ||
      title.toLowerCase().includes(queryLower) ||
      contextTitle.toLowerCase().includes(queryLower)
    );
  });

  const getSectionIcon = (sec?: UserSection) => {
    switch (sec) {
      case 'student':
        return <GraduationCap className="h-3 w-3 text-[#E8491D]" />;
      case 'homemaker':
        return <HomeIcon className="h-3 w-3 text-emerald-600" />;
      case 'entrepreneur':
        return <Briefcase className="h-3 w-3 text-purple-600" />;
      default:
        return <Sparkles className="h-3 w-3 text-[#E8491D]" />;
    }
  };

  const getSectionBadgeClass = (sec?: UserSection) => {
    switch (sec) {
      case 'student':
        return 'bg-[#FDE4D8] text-[#E8491D] border-[#E8491D]/40';
      case 'homemaker':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case 'entrepreneur':
        return 'bg-purple-50 text-purple-700 border-purple-200';
      default:
        return 'bg-[#FAF8F3] text-[#55524A] border-[#E5E2DA]';
    }
  };

  if (!user) {
    return (
      <div className="mx-auto max-w-3xl py-12 text-center">
        <div className="rounded-3xl border border-[#E5E2DA] bg-[#FFFFFF] p-10 sm:p-14 shadow-xs">
          <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-[#FDE4D8] border border-[#E8491D]/40 text-[#E8491D] mb-4 shadow-xs">
            <MessageSquare className="h-6 w-6" />
          </div>
          <h2 className="text-xl font-bold tracking-tight text-[#1A1A1A]">
            KOBUILD Direct Messaging
          </h2>
          <p className="mx-auto mt-2 max-w-md text-xs sm:text-sm text-[#55524A] leading-relaxed">
            Real-time conversations with people and teams you connect with across KOBUILD. Sign in to access your messages.
          </p>
          <div className="mt-6 flex justify-center">
            <button
              onClick={() => onOpenAuth(null)}
              className="flex items-center gap-2 rounded-xl bg-[#E8491D] hover:bg-[#D03E15] px-6 py-3 text-xs sm:text-sm font-semibold text-white shadow-xs transition active:scale-[0.99]"
            >
              <Lock className="h-4 w-4" />
              <span>Sign In to Open Chats</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-16">
      {/* Header Info */}
      <div className="rounded-2xl border border-[#E5E2DA] bg-[#FFFFFF] p-6 shadow-xs">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-[#1A1A1A]">
            Chats &amp; Direct Messaging
          </h1>
          <p className="text-xs sm:text-sm text-[#55524A] mt-1">
            Real-time conversations with people and teams you connect with across KOBUILD.
          </p>
        </div>
      </div>

      {/* Main Chat Interface */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-0 rounded-3xl border border-[#E5E2DA] bg-[#FFFFFF] shadow-xs overflow-hidden min-h-[620px]">
        {/* Left Sidebar: Conversations list */}
        <div className="md:col-span-4 border-r border-[#E5E2DA] p-4 flex flex-col bg-[#FAF8F3]">
          <div className="relative mb-3">
            <Search className="absolute left-3 top-2.5 h-3.5 w-3.5 text-[#8A8578]" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search conversations..."
              className="w-full rounded-xl border border-[#E5E2DA] bg-[#FFFFFF] pl-8 pr-3 py-2 text-xs text-[#1A1A1A] placeholder:text-[#8A8578] focus:border-[#E8491D] focus:outline-none"
            />
          </div>

          <div className="flex items-center justify-between text-[11px] font-bold uppercase tracking-wider text-[#8A8578] px-2 mb-2">
            <span>Conversations</span>
            <span>{filteredConversations.length}</span>
          </div>

          {loadingConvs ? (
            <div className="flex flex-1 items-center justify-center py-12">
              <Loader2 className="h-5 w-5 animate-spin text-[#E8491D]" />
            </div>
          ) : filteredConversations.length === 0 ? (
            <div className="flex-1 flex flex-col items-center justify-center p-6 text-center text-[#8A8578]">
              <MessageSquare className="h-8 w-8 mb-2 opacity-40 text-[#E8491D]" />
              <p className="text-xs font-medium text-[#1A1A1A]">No conversations yet</p>
              <p className="text-[11px] text-[#55524A] mt-1 max-w-[200px]">
                Start a direct conversation with teammates and collaborators across KOBUILD.
              </p>
            </div>
          ) : (
            <div className="space-y-1.5 overflow-y-auto flex-1 max-h-[520px]">
              {filteredConversations.map((conv) => {
                const otherId = (conv.participants || []).find((p) => p !== user.uid);
                const details = otherId ? conv.participantDetails?.[otherId] : null;
                const otherName =
                  details?.name ||
                  (otherId ? conv.participantNames?.[otherId] : null) ||
                  conv.title ||
                  'Builder Discussion';
                const unread = (conv.unreadCounts?.[user.uid] || 0) > 0;
                const isActive = conv.id === activeChatId;

                return (
                  <div
                    key={conv.id}
                    onClick={() => setActiveChatId(conv.id)}
                    className={`rounded-2xl border p-3 cursor-pointer transition ${
                      isActive
                        ? 'border-[#E8491D] bg-[#FFFFFF] shadow-xs ring-1 ring-[#E8491D]/30'
                        : unread
                        ? 'border-[#E8491D]/40 bg-[#FFFFFF] hover:border-[#E8491D]'
                        : 'border-transparent hover:border-[#E5E2DA] bg-transparent hover:bg-[#FFFFFF]'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2.5 min-w-0">
                        {details?.photoURL ? (
                          <img
                            src={details.photoURL}
                            alt={otherName}
                            className="h-8 w-8 rounded-xl object-cover border border-[#E5E2DA] shrink-0"
                            referrerPolicy="no-referrer"
                          />
                        ) : (
                          <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-[#FDE4D8] border border-[#E8491D]/30 text-[#E8491D] text-xs font-bold shrink-0">
                            {otherName.charAt(0).toUpperCase()}
                          </div>
                        )}
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-1.5">
                            <h4 className="text-xs font-bold text-[#1A1A1A] truncate">{otherName}</h4>
                            {unread && (
                              <span className="h-2 w-2 rounded-full bg-[#E8491D] shrink-0" />
                            )}
                          </div>
                          {details?.section && (
                            <span className="text-[10px] text-[#8A8578] capitalize font-medium">
                              {details.section} track
                            </span>
                          )}
                        </div>
                      </div>

                      {conv.lastMessageAt && (
                        <span className="text-[10px] text-[#8A8578] font-mono shrink-0">
                          {new Date(conv.lastMessageAt).toLocaleTimeString([], {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </span>
                      )}
                    </div>

                    {conv.context?.title && (
                      <div className="mt-1.5 flex items-center gap-1 text-[10px] text-[#E8491D] font-medium truncate bg-[#FDE4D8]/40 rounded-md px-1.5 py-0.5">
                        <span className="truncate">Context: {conv.context.title}</span>
                      </div>
                    )}

                    <p
                      className={`mt-1.5 text-[11px] line-clamp-1 ${
                        unread ? 'font-semibold text-[#1A1A1A]' : 'text-[#55524A]'
                      }`}
                    >
                      {conv.lastMessage || 'Conversation started'}
                    </p>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Right Area: Message Stream */}
        <div className="md:col-span-8 flex flex-col justify-between p-6 bg-[#FFFFFF] min-h-[600px]">
          {activeConversation ? (
            <>
              {/* Top Bar of Active Chat */}
              <div className="flex items-center justify-between border-b border-[#E5E2DA] pb-4">
                <div
                  className="flex items-center gap-3 cursor-pointer group"
                  onClick={() => otherParticipant && setPopoverUser(otherParticipant)}
                >
                  {otherParticipant?.photoURL ? (
                    <img
                      src={otherParticipant.photoURL}
                      alt={otherParticipant.name}
                      className="h-10 w-10 rounded-xl object-cover border border-[#E5E2DA] shadow-xs group-hover:scale-105 transition"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#FDE4D8] border border-[#E8491D]/30 text-[#E8491D] font-bold text-sm group-hover:scale-105 transition">
                      {(otherParticipant?.name || 'B').charAt(0).toUpperCase()}
                    </div>
                  )}
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-sm font-bold text-[#1A1A1A] group-hover:text-[#E8491D] transition">
                        {otherParticipant?.name || activeConversation.title || 'Discussion Channel'}
                      </h3>
                      {otherParticipant?.section && (
                        <span
                          className={`inline-flex items-center gap-1 rounded-md px-1.5 py-0.2 text-[9px] font-bold uppercase border ${getSectionBadgeClass(
                            otherParticipant.section
                          )}`}
                        >
                          {getSectionIcon(otherParticipant.section)}
                          {otherParticipant.section}
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-[#55524A]">
                      {activeConversation.context?.title ? (
                        <span>Re: <span className="font-semibold text-[#1A1A1A]">{activeConversation.context.title}</span></span>
                      ) : (
                        'Verified Collaborator • Click to view profile'
                      )}
                    </p>
                  </div>
                </div>
              </div>

              {/* Messages Feed */}
              <div className="my-6 space-y-4 overflow-y-auto flex-1 max-h-[400px] pr-2">
                {loadingMessages ? (
                  <div className="flex h-40 items-center justify-center">
                    <Loader2 className="h-6 w-6 animate-spin text-[#E8491D]" />
                  </div>
                ) : messages.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-16 text-center text-[#8A8578]">
                    <div className="h-10 w-10 rounded-2xl bg-[#FAF8F3] border border-[#E5E2DA] flex items-center justify-center text-[#E8491D] mb-2">
                      <Sparkles className="h-5 w-5" />
                    </div>
                    <p className="text-xs font-semibold text-[#1A1A1A]">Conversation started</p>
                    <p className="text-[11px] text-[#55524A] mt-0.5">
                      Say hi to start the conversation!
                    </p>
                  </div>
                ) : (
                  messages.map((m) => {
                    const isSelf = m.senderId === user.uid;
                    return (
                      <div
                        key={m.id}
                        className={`flex flex-col ${isSelf ? 'items-end' : 'items-start'}`}
                      >
                        <div className="flex items-center gap-1.5 mb-1 px-1">
                          <span className="text-[10px] font-bold text-[#8A8578]">
                            {isSelf ? 'You' : m.senderName}
                          </span>
                          <span className="text-[9px] text-[#8A8578] font-mono">
                            {m.createdAt
                              ? new Date(m.createdAt).toLocaleTimeString([], {
                                  hour: '2-digit',
                                  minute: '2-digit',
                                })
                              : ''}
                          </span>
                        </div>

                        {m.contextNote && (
                          <div className="text-[9px] text-[#8A8578] italic mb-1 px-1">
                            Context: {m.contextNote}
                          </div>
                        )}

                        <div
                          className={`max-w-md rounded-2xl px-4 py-2.5 text-xs leading-relaxed break-words ${
                            isSelf
                              ? 'bg-[#E8491D] text-white shadow-xs rounded-tr-xs'
                              : 'bg-[#FAF8F3] text-[#1A1A1A] border border-[#E5E2DA] rounded-tl-xs'
                          }`}
                        >
                          {m.text}
                        </div>
                      </div>
                    );
                  })
                )}
                <div ref={messagesEndRef} />
              </div>

              {/* Message Input Box */}
              <form onSubmit={handleSendMessage} className="flex items-center gap-2 border-t border-[#E5E2DA] pt-4">
                <input
                  type="text"
                  value={messageInput}
                  onChange={(e) => setMessageInput(e.target.value)}
                  placeholder={`Type a message to ${otherParticipant?.name || 'collaborator'}...`}
                  className="flex-1 rounded-xl border border-[#E5E2DA] bg-[#FAF8F3] px-4 py-2.5 text-xs text-[#1A1A1A] placeholder:text-[#8A8578] focus:border-[#E8491D] focus:outline-none"
                />
                <button
                  type="submit"
                  disabled={!messageInput.trim() || sending}
                  className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#E8491D] text-white transition hover:bg-[#D03E15] disabled:opacity-40 shadow-xs"
                >
                  {sending ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Send className="h-4 w-4" />
                  )}
                </button>
              </form>
            </>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-center p-8">
              <div className="h-12 w-12 rounded-2xl bg-[#FDE4D8] border border-[#E8491D]/30 flex items-center justify-center text-[#E8491D] mb-3">
                <MessageSquare className="h-6 w-6" />
              </div>
              <h3 className="text-sm font-bold text-[#1A1A1A]">Select a Conversation</h3>
              <p className="text-xs text-[#55524A] mt-1 max-w-sm">
                Select a conversation from the sidebar to view messages and reply.
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Target User Popover */}
      {popoverUser && (
        <UserProfilePopover
          isOpen={Boolean(popoverUser)}
          onClose={() => setPopoverUser(null)}
          targetUser={popoverUser}
          onOpenChatWithUser={(convId) => {
            setActiveChatId(convId);
            setPopoverUser(null);
          }}
          onOpenAuth={() => onOpenAuth(null)}
        />
      )}
    </div>
  );
};
