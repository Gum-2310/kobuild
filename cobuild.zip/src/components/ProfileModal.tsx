import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { PreferredTrack, UserSection } from '../types';
import {
  X,
  User,
  GraduationCap,
  Home,
  Briefcase,
  Users,
  CircleSlash,
  MapPin,
  Tag,
  Calendar,
  Check,
  Loader2,
  AlertCircle,
} from 'lucide-react';

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ProfileModal: React.FC<ProfileModalProps> = ({ isOpen, onClose }) => {
  const { userProfile, updateProfileData, user } = useAuth();

  const [name, setName] = useState('');
  const [track, setTrack] = useState<PreferredTrack | null>(null);
  const [location, setLocation] = useState('');
  const [skillsInput, setSkillsInput] = useState('');
  const [bio, setBio] = useState('');
  const [saving, setSaving] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (userProfile) {
      setName(userProfile.name || '');
      // Initialize preferred track from profile; fallback to existing section if preferredTrack is not yet set
      if (userProfile.preferredTrack !== undefined) {
        setTrack(userProfile.preferredTrack);
      } else if (userProfile.section) {
        setTrack(userProfile.section as PreferredTrack);
      } else {
        setTrack(null);
      }
      setLocation(userProfile.location || '');
      setSkillsInput(userProfile.skills?.join(', ') || '');
      setBio(userProfile.bio || '');
    }
  }, [userProfile, isOpen]);

  if (!isOpen || !userProfile) return null;

  const handleSelectTrack = (selectedOption: PreferredTrack) => {
    setTrack((current) => (current === selectedOption ? null : selectedOption));
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSavedSuccess(false);

    if (!name.trim()) {
      setError('Name cannot be empty.');
      return;
    }

    setSaving(true);
    try {
      const skillsArray = skillsInput
        .split(',')
        .map((s) => s.trim())
        .filter(Boolean);

      const sectionValue: UserSection | null =
        track === 'student' || track === 'homemaker' || track === 'entrepreneur'
          ? track
          : null;

      await updateProfileData({
        name: name.trim(),
        preferredTrack: track ?? null,
        section: sectionValue,
        location: location.trim(),
        skills: skillsArray,
        bio: bio.trim(),
      });

      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 2500);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to update profile';
      setError(msg);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-[#1A1A1A]/40 p-4 backdrop-blur-xs animate-in fade-in duration-200"
      onClick={onClose}
      id="profile-modal-backdrop"
    >
      <div
        className="relative w-full max-w-lg rounded-3xl border border-[#E5E2DA] bg-[#FFFFFF] p-6 sm:p-8 shadow-2xl transition-all"
        onClick={(e) => e.stopPropagation()}
        id="profile-modal-content"
      >
        <button
          id="btn-close-profile-modal"
          onClick={onClose}
          className="absolute right-4 top-4 rounded-xl p-2 text-[#8A8578] hover:bg-[#F5F1E8] hover:text-[#1A1A1A] transition-colors"
        >
          <X className="h-5 w-5" />
        </button>

        {/* Profile Header */}
        <div className="flex items-center gap-4 mb-6 border-b border-[#E5E2DA] pb-4">
          {user?.photoURL ? (
            <img
              src={user.photoURL}
              alt={userProfile.name}
              className="h-14 w-14 rounded-2xl object-cover border border-[#E5E2DA]"
              referrerPolicy="no-referrer"
            />
          ) : (
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-[#E8491D] text-lg font-bold text-white shadow-xs">
              {userProfile.name.charAt(0).toUpperCase()}
            </div>
          )}
          <div>
            <h2 className="text-lg font-bold text-[#1A1A1A]">{userProfile.name}</h2>
            <p className="text-xs font-mono text-[#8A8578]">{userProfile.email}</p>
          </div>
        </div>

        {error && (
          <div className="mb-4 flex items-start gap-2 rounded-xl bg-rose-50 p-2.5 text-xs text-rose-700 border border-rose-200">
            <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        {savedSuccess && (
          <div className="mb-4 flex items-center gap-2 rounded-xl bg-emerald-50 p-2.5 text-xs text-emerald-700 border border-emerald-200 font-mono">
            <Check className="h-4 w-4 shrink-0" />
            <span>Profile successfully synced to Firestore!</span>
          </div>
        )}

        <form onSubmit={handleSave} className="space-y-4">
          {/* Section Selection (Optional Preferred Track) */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-semibold text-[#1A1A1A]">Preferred Track</label>
              <span className="text-[11px] text-[#8A8578]">Optional</span>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {/* Student */}
              <button
                type="button"
                id="profile-edit-sec-student"
                onClick={() => handleSelectTrack('student')}
                className={`flex items-center justify-center gap-1.5 rounded-xl border py-2 px-2 text-xs transition ${
                  track === 'student'
                    ? 'border-[#E8491D] bg-[#FDE4D8] font-semibold text-[#E8491D]'
                    : 'border-[#E5E2DA] bg-[#FAF8F3] text-[#55524A] hover:bg-[#F5F1E8] hover:text-[#1A1A1A]'
                }`}
              >
                <GraduationCap className="h-3.5 w-3.5 text-[#E8491D]" />
                <span>Student</span>
              </button>

              {/* Homemaker */}
              <button
                type="button"
                id="profile-edit-sec-homemaker"
                onClick={() => handleSelectTrack('homemaker')}
                className={`flex items-center justify-center gap-1.5 rounded-xl border py-2 px-2 text-xs transition ${
                  track === 'homemaker'
                    ? 'border-[#E8491D] bg-[#FDE4D8] font-semibold text-[#E8491D]'
                    : 'border-[#E5E2DA] bg-[#FAF8F3] text-[#55524A] hover:bg-[#F5F1E8] hover:text-[#1A1A1A]'
                }`}
              >
                <Home className="h-3.5 w-3.5 text-[#E8491D]" />
                <span>Homemaker</span>
              </button>

              {/* Entrepreneur */}
              <button
                type="button"
                id="profile-edit-sec-entrepreneur"
                onClick={() => handleSelectTrack('entrepreneur')}
                className={`flex items-center justify-center gap-1.5 rounded-xl border py-2 px-2 text-xs transition ${
                  track === 'entrepreneur'
                    ? 'border-[#E8491D] bg-[#FDE4D8] font-semibold text-[#E8491D]'
                    : 'border-[#E5E2DA] bg-[#FAF8F3] text-[#55524A] hover:bg-[#F5F1E8] hover:text-[#1A1A1A]'
                }`}
              >
                <Briefcase className="h-3.5 w-3.5 text-[#E8491D]" />
                <span>Entrepreneur</span>
              </button>

              {/* Community */}
              <button
                type="button"
                id="profile-edit-sec-community"
                onClick={() => handleSelectTrack('community')}
                className={`flex items-center justify-center gap-1.5 rounded-xl border py-2 px-2 text-xs transition ${
                  track === 'community'
                    ? 'border-[#E8491D] bg-[#FDE4D8] font-semibold text-[#E8491D]'
                    : 'border-[#E5E2DA] bg-[#FAF8F3] text-[#55524A] hover:bg-[#F5F1E8] hover:text-[#1A1A1A]'
                }`}
              >
                <Users className="h-3.5 w-3.5 text-[#E8491D]" />
                <span>Community</span>
              </button>

              {/* None */}
              <button
                type="button"
                id="profile-edit-sec-none"
                onClick={() => handleSelectTrack('none')}
                className={`flex items-center justify-center gap-1.5 rounded-xl border py-2 px-2 text-xs transition ${
                  track === 'none'
                    ? 'border-[#E8491D] bg-[#FDE4D8] font-semibold text-[#E8491D]'
                    : 'border-[#E5E2DA] bg-[#FAF8F3] text-[#55524A] hover:bg-[#F5F1E8] hover:text-[#1A1A1A]'
                }`}
              >
                <CircleSlash className="h-3.5 w-3.5 text-[#E8491D]" />
                <span>None</span>
              </button>
            </div>
          </div>

          {/* Full Name */}
          <div>
            <label className="mb-1 block text-xs font-semibold text-[#1A1A1A]">Full Name</label>
            <div className="relative">
              <User className="pointer-events-none absolute left-3 top-2.5 h-4 w-4 text-[#8A8578]" />
              <input
                id="profile-input-name"
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full rounded-xl border border-[#E5E2DA] bg-[#FFFFFF] py-2 pl-9 pr-3 text-xs text-[#1A1A1A] placeholder:text-[#8A8578] focus:border-[#E8491D] focus:outline-none"
              />
            </div>
          </div>

          {/* Location */}
          <div>
            <label className="mb-1 block text-xs font-semibold text-[#1A1A1A]">Location</label>
            <div className="relative">
              <MapPin className="pointer-events-none absolute left-3 top-2.5 h-4 w-4 text-[#8A8578]" />
              <input
                id="profile-input-location"
                type="text"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="e.g. Austin, TX or North Campus"
                className="w-full rounded-xl border border-[#E5E2DA] bg-[#FFFFFF] py-2 pl-9 pr-3 text-xs text-[#1A1A1A] placeholder:text-[#8A8578] focus:border-[#E8491D] focus:outline-none"
              />
            </div>
          </div>

          {/* Skills */}
          <div>
            <label className="mb-1 block text-xs font-semibold text-[#1A1A1A]">
              Skills &amp; Talents (comma separated)
            </label>
            <div className="relative">
              <Tag className="pointer-events-none absolute left-3 top-2.5 h-4 w-4 text-[#8A8578]" />
              <input
                id="profile-input-skills"
                type="text"
                value={skillsInput}
                onChange={(e) => setSkillsInput(e.target.value)}
                placeholder="e.g. React, Node.js, Culinary Arts, Graphic Design"
                className="w-full rounded-xl border border-[#E5E2DA] bg-[#FFFFFF] py-2 pl-9 pr-3 text-xs text-[#1A1A1A] placeholder:text-[#8A8578] focus:border-[#E8491D] focus:outline-none"
              />
            </div>
          </div>

          {/* Bio */}
          <div>
            <label className="mb-1 block text-xs font-semibold text-[#1A1A1A]">Bio</label>
            <textarea
              id="profile-input-bio"
              rows={3}
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              placeholder="Tell others what you are building or looking to collaborate on..."
              className="w-full rounded-xl border border-[#E5E2DA] bg-[#FFFFFF] p-2.5 text-xs text-[#1A1A1A] placeholder:text-[#8A8578] focus:border-[#E8491D] focus:outline-none"
            />
          </div>

          {/* Metadata info */}
          <div className="flex items-center justify-between text-[11px] text-[#8A8578] pt-2 border-t border-[#E5E2DA]">
            <div className="flex items-center gap-1 font-mono">
              <Calendar className="h-3 w-3 text-[#8A8578]" />
              <span>Joined: {new Date(userProfile.createdAt).toLocaleDateString()}</span>
            </div>
            <span className="font-mono text-[10px] text-emerald-600 font-semibold">Firestore Synced</span>
          </div>

          {/* Action button */}
          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              id="btn-cancel-profile"
              onClick={onClose}
              className="rounded-xl border border-[#E5E2DA] bg-[#FAF8F3] px-3.5 py-2 text-xs font-semibold text-[#1A1A1A] hover:bg-[#F5F1E8] transition-colors"
            >
              Close
            </button>
            <button
              type="submit"
              id="btn-save-profile"
              disabled={saving}
              className="flex items-center gap-1.5 rounded-xl bg-[#E8491D] hover:bg-[#FF5722] px-4 py-2 text-xs font-semibold text-white shadow-xs disabled:opacity-50 active:scale-[0.99]"
            >
              {saving ? (
                <>
                  <Loader2 className="h-3.5 w-3.5 animate-spin" />
                  <span>Saving...</span>
                </>
              ) : (
                <span>Save Changes</span>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
