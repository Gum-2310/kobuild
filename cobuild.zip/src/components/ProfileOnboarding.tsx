import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { UserSection } from '../types';
import { LogoutConfirmModal } from './LogoutConfirmModal';
import {
  GraduationCap,
  Home,
  Briefcase,
  User,
  MapPin,
  Sparkles,
  Loader2,
  AlertCircle,
  CheckCircle2,
} from 'lucide-react';

interface ProfileOnboardingProps {
  lockedSection?: UserSection | null;
}

export const ProfileOnboarding: React.FC<ProfileOnboardingProps> = ({ lockedSection = null }) => {
  const { user, completeProfile, activeSection, error: authError, logout } = useAuth();

  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);
  const [section, setSection] = useState<UserSection>(lockedSection || activeSection || 'student');
  const [name, setName] = useState(user?.displayName || '');
  const [location, setLocation] = useState('');
  const [skillsInput, setSkillsInput] = useState('');
  const [interestsInput, setInterestsInput] = useState('');
  const [bio, setBio] = useState('');
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (!name.trim()) {
      setFormError('Please enter your name.');
      return;
    }

    setSaving(true);
    try {
      const skillsArray = skillsInput
        .split(',')
        .map((s) => s.trim())
        .filter(Boolean);

      const interestsArray = interestsInput
        .split(',')
        .map((s) => s.trim())
        .filter(Boolean);

      await completeProfile({
        name: name.trim(),
        section: lockedSection || section,
        location: location.trim(),
        skills: skillsArray,
        interests: interestsArray,
        bio: bio.trim(),
      });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to save profile';
      setFormError(msg);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="mx-auto max-w-2xl px-4 py-10 sm:px-6">
      <div className="rounded-3xl border border-[#E5E2DA] bg-[#FFFFFF] p-6 sm:p-8 shadow-2xl">
        {/* Header */}
        <div className="mb-6 text-center">
          <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-2xl bg-[#FDE4D8] text-[#E8491D] border border-[#E8491D]/40 shadow-xs">
            <Sparkles className="h-6 w-6" />
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-[#1A1A1A]">Complete Your Profile</h1>
          <p className="mt-1.5 text-xs text-[#55524A]">
            Welcome to kobuildd. Choose your section and configure your collaboration presence.
          </p>
        </div>

        {/* Error Alert */}
        {(formError || authError) && (
          <div className="mb-5 flex items-start gap-2 rounded-xl bg-rose-50 p-3 text-xs text-rose-700 border border-rose-200">
            <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
            <span>{formError || authError}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Section Selection */}
          <div>
            <label className="mb-2 block text-xs font-bold uppercase tracking-wider text-[#8A8578]">
              1. Collaboration Category <span className="text-[#E8491D]">*</span>
            </label>
            {lockedSection ? (
              <div className="rounded-2xl border border-[#E5E2DA] bg-[#FAF8F3] p-3.5 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-[#FFFFFF] text-[#E8491D] border border-[#E5E2DA]">
                    {lockedSection === 'student' ? (
                      <GraduationCap className="h-4.5 w-4.5 text-[#E8491D]" />
                    ) : lockedSection === 'homemaker' ? (
                      <Home className="h-4.5 w-4.5 text-[#E8491D]" />
                    ) : (
                      <Briefcase className="h-4.5 w-4.5 text-[#E8491D]" />
                    )}
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-[#1A1A1A] capitalize">{lockedSection} Track</h4>
                    <p className="text-[11px] text-[#55524A]">Locked to your signup category</p>
                  </div>
                </div>
                <span className="rounded bg-[#FFFFFF] border border-[#E5E2DA] px-2 py-0.5 text-[10px] font-mono font-bold uppercase text-[#55524A]">
                  Pre-selected
                </span>
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
                {/* Student */}
                <button
                  type="button"
                  id="onboarding-select-student"
                  onClick={() => setSection('student')}
                  className={`flex flex-col items-start rounded-2xl border p-3.5 text-left transition ${
                    section === 'student'
                      ? 'border-[#E8491D] bg-[#FDE4D8] ring-1 ring-[#E8491D]/50 shadow-xs'
                      : 'border-[#E5E2DA] bg-[#FFFFFF] hover:bg-[#FAF8F3] hover:border-[#D4D0C5]'
                  }`}
                >
                  <div className="flex items-center gap-2 mb-1.5">
                    <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-[#FDE4D8] text-[#E8491D] border border-[#E8491D]/40">
                      <GraduationCap className="h-4 w-4" />
                    </div>
                    <span className="font-bold text-xs text-[#1A1A1A]">Students</span>
                  </div>
                  <p className="text-[11px] leading-relaxed text-[#55524A]">
                    Find hackathon & course teammates with matching technical or creative skills.
                  </p>
                </button>

                {/* Homemaker */}
                <button
                  type="button"
                  id="onboarding-select-homemaker"
                  onClick={() => setSection('homemaker')}
                  className={`flex flex-col items-start rounded-2xl border p-3.5 text-left transition ${
                    section === 'homemaker'
                      ? 'border-[#E8491D] bg-[#FDE4D8] ring-1 ring-[#E8491D]/50 shadow-xs'
                      : 'border-[#E5E2DA] bg-[#FFFFFF] hover:bg-[#FAF8F3] hover:border-[#D4D0C5]'
                  }`}
                >
                  <div className="flex items-center gap-2 mb-1.5">
                    <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-[#FDE4D8] text-[#E8491D] border border-[#E8491D]/40">
                      <Home className="h-4 w-4" />
                    </div>
                    <span className="font-bold text-xs text-[#1A1A1A]">Homemakers</span>
                  </div>
                  <p className="text-[11px] leading-relaxed text-[#55524A]">
                    Collaborate on local small businesses, home bakeries, boutique crafts & services.
                  </p>
                </button>

                {/* Entrepreneur */}
                <button
                  type="button"
                  id="onboarding-select-entrepreneur"
                  onClick={() => setSection('entrepreneur')}
                  className={`flex flex-col items-start rounded-2xl border p-3.5 text-left transition ${
                    section === 'entrepreneur'
                      ? 'border-[#E8491D] bg-[#FDE4D8] ring-1 ring-[#E8491D]/50 shadow-xs'
                      : 'border-[#E5E2DA] bg-[#FFFFFF] hover:bg-[#FAF8F3] hover:border-[#D4D0C5]'
                  }`}
                >
                  <div className="flex items-center gap-2 mb-1.5">
                    <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-[#FDE4D8] text-[#E8491D] border border-[#E8491D]/40">
                      <Briefcase className="h-4 w-4" />
                    </div>
                    <span className="font-bold text-xs text-[#1A1A1A]">Entrepreneurs</span>
                  </div>
                  <p className="text-[11px] leading-relaxed text-[#55524A]">
                    Find co-founders, early partners, advisors, and cross-functional builders.
                  </p>
                </button>
              </div>
            )}
          </div>

          {/* Basic Info */}
          <div className="space-y-4">
            <label className="block text-xs font-bold uppercase tracking-wider text-[#8A8578]">
              2. Basic Information
            </label>

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div>
                <label className="mb-1 block text-xs font-semibold text-[#1A1A1A]">
                  Full Name <span className="text-[#E8491D]">*</span>
                </label>
                <div className="relative">
                  <User className="pointer-events-none absolute left-3 top-2.5 h-4 w-4 text-[#8A8578]" />
                  <input
                    id="onboarding-name"
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Your name"
                    className="w-full rounded-xl border border-[#E5E2DA] bg-[#FFFFFF] py-2 pl-9 pr-3 text-xs text-[#1A1A1A] placeholder:text-[#8A8578] focus:border-[#E8491D] focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="mb-1 block text-xs font-semibold text-[#1A1A1A]">
                  Location (City or Region)
                </label>
                <div className="relative">
                  <MapPin className="pointer-events-none absolute left-3 top-2.5 h-4 w-4 text-[#8A8578]" />
                  <input
                    id="onboarding-location"
                    type="text"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    placeholder="e.g. Seattle, WA or Cambridge"
                    className="w-full rounded-xl border border-[#E5E2DA] bg-[#FFFFFF] py-2 pl-9 pr-3 text-xs text-[#1A1A1A] placeholder:text-[#8A8578] focus:border-[#E8491D] focus:outline-none"
                  />
                </div>
              </div>
            </div>

            {/* Skills & Interests */}
            <div>
              <label className="mb-1 block text-xs font-semibold text-[#1A1A1A]">
                Skills & Talents (comma separated)
              </label>
              <input
                id="onboarding-skills"
                type="text"
                value={skillsInput}
                onChange={(e) => setSkillsInput(e.target.value)}
                placeholder="e.g. Python, UI Design, Catering, Social Media, Sales"
                className="w-full rounded-xl border border-[#E5E2DA] bg-[#FFFFFF] py-2 px-3 text-xs text-[#1A1A1A] placeholder:text-[#8A8578] focus:border-[#E8491D] focus:outline-none"
              />
            </div>

            <div>
              <label className="mb-1 block text-xs font-semibold text-[#1A1A1A]">
                Interests / Goals (comma separated)
              </label>
              <input
                id="onboarding-interests"
                type="text"
                value={interestsInput}
                onChange={(e) => setInterestsInput(e.target.value)}
                placeholder="e.g. AI Projects, Eco-friendly Crafts, Artisan Bakery, SaaS"
                className="w-full rounded-xl border border-[#E5E2DA] bg-[#FFFFFF] py-2 px-3 text-xs text-[#1A1A1A] placeholder:text-[#8A8578] focus:border-[#E8491D] focus:outline-none"
              />
            </div>

            {/* Bio */}
            <div>
              <label className="mb-1 block text-xs font-semibold text-[#1A1A1A]">Short Bio</label>
              <textarea
                id="onboarding-bio"
                rows={3}
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                placeholder="Briefly introduce yourself and what kind of collaboration you're seeking..."
                className="w-full rounded-xl border border-[#E5E2DA] bg-[#FFFFFF] p-2.5 text-xs text-[#1A1A1A] placeholder:text-[#8A8578] focus:border-[#E8491D] focus:outline-none"
              />
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center justify-between pt-2 border-t border-[#E5E2DA]">
            <button
              type="button"
              id="onboarding-btn-signout"
              onClick={() => setShowLogoutConfirm(true)}
              className="text-xs font-semibold text-[#8A8578] hover:text-[#1A1A1A] transition-colors"
            >
              Sign Out
            </button>

            <button
              type="submit"
              id="onboarding-btn-save"
              disabled={saving}
              className="flex items-center gap-2 rounded-xl bg-[#E8491D] hover:bg-[#FF5722] px-5 py-2.5 text-xs font-semibold text-white shadow-xs transition disabled:opacity-50 active:scale-[0.99]"
            >
              {saving ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  <span>Saving Profile to Firestore...</span>
                </>
              ) : (
                <>
                  <CheckCircle2 className="h-4 w-4" />
                  <span>Complete Setup & Enter</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>

      {/* Logout Confirmation Dialog */}
      <LogoutConfirmModal
        isOpen={showLogoutConfirm}
        onClose={() => setShowLogoutConfirm(false)}
        onConfirm={() => logout()}
      />
    </div>
  );
};
