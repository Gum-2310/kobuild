import React, { useState, useEffect, useMemo } from 'react';
import { useAuth } from '../context/AuthContext';
import { Ticket, UserSection, TicketStatus, AppView } from '../types';
import { subscribeUserTickets } from '../services/userService';
import { RaiseTicketModal } from './collab/RaiseTicketModal';
import { ManageTicketModal } from './collab/ManageTicketModal';
import { TicketDetailsModal } from './collab/TicketDetailsModal';
import {
  Ticket as TicketIcon,
  Plus,
  ArrowLeft,
  Search,
  Filter,
  Heart,
  Users,
  Calendar,
  Clock,
  CheckCircle2,
  AlertCircle,
  GraduationCap,
  Home,
  Briefcase,
  Layers,
  Sparkles,
  Loader2,
  ChevronRight,
  Settings2,
  Tag,
} from 'lucide-react';

interface MyTicketsViewProps {
  onNavigate: (view: AppView, section?: UserSection) => void;
  onOpenAuth: (section?: UserSection | null) => void;
}

export const MyTicketsView: React.FC<MyTicketsViewProps> = ({
  onNavigate,
  onOpenAuth,
}) => {
  const { user, activeSection } = useAuth();
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [loading, setLoading] = useState(true);

  // Filters state
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSection, setSelectedSection] = useState<'all' | UserSection>('all');
  const [selectedStatus, setSelectedStatus] = useState<'all' | TicketStatus>('all');

  // Modals state
  const [raiseModalOpen, setRaiseModalOpen] = useState(false);
  const [manageModalTicket, setManageModalTicket] = useState<Ticket | null>(null);
  const [detailsModalTicket, setDetailsModalTicket] = useState<Ticket | null>(null);

  // Subscribe to user tickets
  useEffect(() => {
    if (!user) {
      setLoading(false);
      return;
    }

    setLoading(true);
    const unsubscribe = subscribeUserTickets(user.uid, (userTickets) => {
      setTickets(userTickets);
      setLoading(false);
    });

    return () => {
      unsubscribe();
    };
  }, [user]);

  // Compute summary stats
  const stats = useMemo(() => {
    const total = tickets.length;
    const open = tickets.filter((t) => t.status === 'open').length;
    const inProgress = tickets.filter((t) => t.status === 'in_progress').length;
    const completed = tickets.filter((t) => t.status === 'closed').length;
    const totalLikes = tickets.reduce((acc, t) => acc + (t.interestedCount || 0), 0);
    return { total, open, inProgress, completed, totalLikes };
  }, [tickets]);

  // Filtered tickets list
  const filteredTickets = useMemo(() => {
    return tickets.filter((ticket) => {
      // Section filter
      if (selectedSection !== 'all' && ticket.section !== selectedSection) {
        return false;
      }
      // Status filter
      if (selectedStatus !== 'all' && ticket.status !== selectedStatus) {
        return false;
      }
      // Search query
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchesTitle = ticket.title.toLowerCase().includes(query);
        const matchesDesc = ticket.description.toLowerCase().includes(query);
        const matchesCategory = ticket.category?.toLowerCase().includes(query) || false;
        const matchesSkills = ticket.skillsRequired?.some((s) => s.toLowerCase().includes(query)) || false;
        if (!matchesTitle && !matchesDesc && !matchesCategory && !matchesSkills) {
          return false;
        }
      }
      return true;
    });
  }, [tickets, selectedSection, selectedStatus, searchQuery]);

  const getSectionBadge = (section: UserSection) => {
    switch (section) {
      case 'student':
        return {
          label: 'Students',
          icon: GraduationCap,
          color: 'bg-orange-50 text-orange-800 border-orange-200',
        };
      case 'homemaker':
        return {
          label: 'Homemakers',
          icon: Home,
          color: 'bg-emerald-50 text-emerald-800 border-emerald-200',
        };
      case 'entrepreneur':
        return {
          label: 'Entrepreneurs',
          icon: Briefcase,
          color: 'bg-purple-50 text-purple-800 border-purple-200',
        };
      default:
        return {
          label: 'Community',
          icon: TicketIcon,
          color: 'bg-gray-50 text-gray-800 border-gray-200',
        };
    }
  };

  const getStatusBadge = (status: TicketStatus) => {
    switch (status) {
      case 'open':
        return {
          label: 'Open',
          classes: 'bg-emerald-50 text-emerald-700 border-emerald-200',
          dot: 'bg-emerald-500',
        };
      case 'in_progress':
        return {
          label: 'In Progress',
          classes: 'bg-blue-50 text-blue-700 border-blue-200',
          dot: 'bg-blue-500',
        };
      case 'closed':
        return {
          label: 'Completed',
          classes: 'bg-gray-100 text-gray-600 border-gray-200',
          dot: 'bg-gray-400',
        };
    }
  };

  const formatDate = (isoString: string) => {
    try {
      const d = new Date(isoString);
      return d.toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
      });
    } catch {
      return 'Recently';
    }
  };

  if (!user) {
    return (
      <div className="mx-auto max-w-xl py-16 text-center">
        <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-[#FFFFFF] border border-[#E5E2DA] text-[#E8491D] shadow-xs mb-4">
          <TicketIcon className="h-6 w-6" />
        </div>
        <h2 className="text-xl font-bold text-[#1A1A1A]">Sign In to View Your Tickets</h2>
        <p className="mt-2 text-xs text-[#55524A] leading-relaxed">
          You need to be signed in to manage, track applicants, and monitor collaboration tickets you have created.
        </p>
        <button
          onClick={() => onOpenAuth(activeSection)}
          className="mt-6 rounded-xl bg-[#E8491D] hover:bg-[#FF5722] px-6 py-2.5 text-xs font-bold text-white shadow-md transition hover:-translate-y-0.5"
        >
          Sign In / Register
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-16">
      {/* 1. Header & Navigation */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#E5E2DA] pb-5">
        <div className="space-y-1">
          <button
            id="btn-back-to-hub"
            onClick={() => onNavigate(activeSection, activeSection)}
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#8A8578] hover:text-[#1A1A1A] transition mb-1"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            <span>Back to {activeSection.charAt(0).toUpperCase() + activeSection.slice(1)} Hub</span>
          </button>
          <div className="flex items-center gap-3">
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-[#1A1A1A]">
              My Tickets
            </h1>
            <span className="rounded-full bg-[#FAF8F3] border border-[#E5E2DA] px-2.5 py-0.5 text-xs font-mono font-semibold text-[#55524A]">
              {tickets.length} total
            </span>
          </div>
          <p className="text-xs text-[#55524A]">
            Manage and monitor all collaboration tickets you've created across kobuildd.
          </p>
        </div>

        <button
          id="btn-my-tickets-raise"
          onClick={() => setRaiseModalOpen(true)}
          className="flex items-center justify-center gap-2 rounded-xl bg-[#E8491D] hover:bg-[#FF5722] px-4 py-2.5 text-xs font-bold text-white shadow-md transition hover:-translate-y-0.5 active:translate-y-0 shrink-0"
        >
          <Plus className="h-4 w-4" />
          <span>Raise a Ticket</span>
        </button>
      </div>

      {/* 2. Top Summary Stat Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="rounded-2xl border border-[#E5E2DA] bg-[#FFFFFF] p-3.5 shadow-2xs">
          <span className="text-[10px] font-bold uppercase tracking-wider text-[#8A8578]">
            Total Raised
          </span>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-xl font-bold font-mono text-[#1A1A1A]">{stats.total}</span>
            <span className="text-[10px] text-[#8A8578]">tickets</span>
          </div>
        </div>

        <div className="rounded-2xl border border-[#E5E2DA] bg-[#FFFFFF] p-3.5 shadow-2xs">
          <span className="text-[10px] font-bold uppercase tracking-wider text-[#8A8578]">
            Active & Open
          </span>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-xl font-bold font-mono text-emerald-700">{stats.open}</span>
            <span className="text-[10px] text-emerald-600 font-medium">seeking team</span>
          </div>
        </div>

        <div className="rounded-2xl border border-[#E5E2DA] bg-[#FFFFFF] p-3.5 shadow-2xs">
          <span className="text-[10px] font-bold uppercase tracking-wider text-[#8A8578]">
            In Progress
          </span>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-xl font-bold font-mono text-blue-700">{stats.inProgress}</span>
            <span className="text-[10px] text-blue-600 font-medium">squad active</span>
          </div>
        </div>

        <div className="rounded-2xl border border-[#E5E2DA] bg-[#FFFFFF] p-3.5 shadow-2xs">
          <span className="text-[10px] font-bold uppercase tracking-wider text-[#8A8578]">
            Completed
          </span>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-xl font-bold font-mono text-gray-700">{stats.completed}</span>
            <span className="text-[10px] text-gray-500 font-medium">finished</span>
          </div>
        </div>
      </div>

      {/* 3. Search and Filters Bar */}
      <div className="rounded-2xl border border-[#E5E2DA] bg-[#FFFFFF] p-3.5 shadow-xs space-y-3">
        <div className="flex flex-col md:flex-row md:items-center gap-3">
          {/* Search Input */}
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-[#8A8578]" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search your tickets by title, category, or skills..."
              className="w-full rounded-xl border border-[#E5E2DA] bg-[#FAF8F3] pl-9 pr-4 py-2 text-xs text-[#1A1A1A] placeholder-[#8A8578] focus:border-[#E8491D] focus:bg-[#FFFFFF] focus:outline-none transition"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-bold text-[#8A8578] hover:text-[#1A1A1A]"
              >
                ✕
              </button>
            )}
          </div>

          {/* Section Filter */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 md:pb-0">
            <span className="text-[11px] font-semibold text-[#8A8578] shrink-0 mr-1 hidden lg:inline">
              Track:
            </span>
            {(['all', 'student', 'homemaker', 'entrepreneur'] as const).map((sec) => (
              <button
                key={sec}
                onClick={() => setSelectedSection(sec)}
                className={`rounded-lg px-2.5 py-1 text-xs font-semibold whitespace-nowrap transition border ${
                  selectedSection === sec
                    ? 'bg-[#1A1A1A] text-white border-[#1A1A1A]'
                    : 'bg-[#FAF8F3] text-[#55524A] border-[#E5E2DA] hover:bg-[#F2EFE6]'
                }`}
              >
                {sec === 'all'
                  ? 'All Tracks'
                  : sec === 'student'
                  ? 'Students'
                  : sec === 'homemaker'
                  ? 'Homemakers'
                  : 'Entrepreneurs'}
              </button>
            ))}
          </div>

          {/* Status Filter */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 md:pb-0">
            <span className="text-[11px] font-semibold text-[#8A8578] shrink-0 mr-1 hidden lg:inline">
              Status:
            </span>
            {(['all', 'open', 'in_progress', 'closed'] as const).map((st) => (
              <button
                key={st}
                onClick={() => setSelectedStatus(st)}
                className={`rounded-lg px-2.5 py-1 text-xs font-semibold whitespace-nowrap transition border ${
                  selectedStatus === st
                    ? 'bg-[#E8491D] text-white border-[#E8491D]'
                    : 'bg-[#FAF8F3] text-[#55524A] border-[#E5E2DA] hover:bg-[#F2EFE6]'
                }`}
              >
                {st === 'all'
                  ? 'All Statuses'
                  : st === 'open'
                  ? 'Open'
                  : st === 'in_progress'
                  ? 'In Progress'
                  : 'Completed'}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* 4. Tickets List / Table Presentation */}
      {loading ? (
        <div className="rounded-2xl border border-[#E5E2DA] bg-[#FFFFFF] p-12 text-center">
          <Loader2 className="mx-auto h-7 w-7 animate-spin text-[#E8491D] mb-3" />
          <p className="text-xs font-semibold text-[#8A8578]">Loading your tickets from Firestore...</p>
        </div>
      ) : filteredTickets.length === 0 ? (
        /* Empty State */
        <div className="rounded-2xl border border-dashed border-[#D4D0C5] bg-[#FFFFFF] p-12 text-center">
          <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-[#FAF8F3] border border-[#E5E2DA] text-[#8A8578] mb-3">
            <TicketIcon className="h-6 w-6 text-[#E8491D]" />
          </div>
          {tickets.length === 0 ? (
            <>
              <h3 className="text-sm font-bold text-[#1A1A1A]">No tickets raised yet</h3>
              <p className="mt-1 text-xs text-[#55524A] max-w-sm mx-auto">
                Create a collaboration ticket in Students, Homemakers, or Entrepreneurs to find partners and start building.
              </p>
              <button
                onClick={() => setRaiseModalOpen(true)}
                className="mt-4 rounded-xl bg-[#E8491D] hover:bg-[#FF5722] px-4 py-2 text-xs font-bold text-white shadow-xs transition"
              >
                + Raise Your First Ticket
              </button>
            </>
          ) : (
            <>
              <h3 className="text-sm font-bold text-[#1A1A1A]">No tickets match your filters</h3>
              <p className="mt-1 text-xs text-[#55524A]">
                Try adjusting your search query, track filter, or status filter.
              </p>
              <button
                onClick={() => {
                  setSearchQuery('');
                  setSelectedSection('all');
                  setSelectedStatus('all');
                }}
                className="mt-4 rounded-xl border border-[#E5E2DA] bg-[#FAF8F3] hover:bg-[#F2EFE6] px-4 py-2 text-xs font-semibold text-[#1A1A1A] transition"
              >
                Reset Filters
              </button>
            </>
          )}
        </div>
      ) : (
        <div className="space-y-4">
          {/* DESKTOP TABLE (Hidden on small mobile screens) */}
          <div className="hidden md:block overflow-hidden rounded-2xl border border-[#E5E2DA] bg-[#FFFFFF] shadow-sm">
            <table className="w-full text-left text-xs text-[#55524A] divide-y divide-[#E5E2DA]">
              <thead className="bg-[#FAF8F3] text-[10px] font-bold uppercase tracking-wider text-[#8A8578]">
                <tr>
                  <th scope="col" className="px-5 py-3.5">
                    Ticket Details
                  </th>
                  <th scope="col" className="px-4 py-3.5">
                    Track
                  </th>
                  <th scope="col" className="px-4 py-3.5">
                    Status
                  </th>
                  <th scope="col" className="px-4 py-3.5 text-center">
                    Likes / Interest
                  </th>
                  <th scope="col" className="px-4 py-3.5 text-center">
                    Squad / Applicants
                  </th>
                  <th scope="col" className="px-4 py-3.5">
                    Created
                  </th>
                  <th scope="col" className="px-5 py-3.5 text-right">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E5E2DA] bg-[#FFFFFF]">
                {filteredTickets.map((ticket) => {
                  const sectionBadge = getSectionBadge(ticket.section);
                  const SectionIcon = sectionBadge.icon;
                  const statusBadge = getStatusBadge(ticket.status);

                  return (
                    <tr
                      key={ticket.id}
                      className="hover:bg-[#FAF8F3] transition duration-150 cursor-pointer"
                      onClick={() => setManageModalTicket(ticket)}
                    >
                      {/* Ticket Details */}
                      <td className="px-5 py-4 max-w-xs">
                        <div className="space-y-1">
                          <h4 className="font-bold text-[#1A1A1A] text-xs hover:text-[#E8491D] transition-colors line-clamp-1">
                            {ticket.title}
                          </h4>
                          <p className="text-[11px] text-[#55524A] line-clamp-1">
                            {ticket.description}
                          </p>
                          {ticket.category && (
                            <span className="inline-block rounded-md bg-[#F2EFE6] px-2 py-0.5 text-[9px] font-semibold text-[#55524A] border border-[#E5E2DA]">
                              {ticket.category}
                            </span>
                          )}
                        </div>
                      </td>

                      {/* Track */}
                      <td className="px-4 py-4 whitespace-nowrap">
                        <span
                          className={`inline-flex items-center gap-1.5 rounded-lg border px-2.5 py-1 text-[11px] font-semibold ${sectionBadge.color}`}
                        >
                          <SectionIcon className="h-3 w-3" />
                          {sectionBadge.label}
                        </span>
                      </td>

                      {/* Status */}
                      <td className="px-4 py-4 whitespace-nowrap">
                        <span
                          className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wider ${statusBadge.classes}`}
                        >
                          <span className={`h-1.5 w-1.5 rounded-full ${statusBadge.dot}`} />
                          {statusBadge.label}
                        </span>
                      </td>

                      {/* Likes / Interest */}
                      <td className="px-4 py-4 whitespace-nowrap text-center">
                        <span className="inline-flex items-center gap-1 rounded-md bg-rose-50 border border-rose-200/80 px-2 py-1 text-xs font-mono font-bold text-rose-700">
                          <Heart className="h-3 w-3 text-rose-600 fill-rose-600" />
                          {ticket.interestedCount || 0}
                        </span>
                      </td>

                      {/* Squad / Applicants */}
                      <td className="px-4 py-4 whitespace-nowrap text-center">
                        <div className="inline-flex items-center gap-1.5 font-mono text-xs font-semibold text-[#1A1A1A]">
                          <Users className="h-3.5 w-3.5 text-[#8A8578]" />
                          <span>
                            {ticket.applicationsCount || 0} applied
                          </span>
                          <span className="text-[10px] text-[#8A8578] font-sans">
                            ({ticket.peopleNeeded} needed)
                          </span>
                        </div>
                      </td>

                      {/* Created Date */}
                      <td className="px-4 py-4 whitespace-nowrap text-[11px] text-[#8A8578] font-mono">
                        {formatDate(ticket.createdAt)}
                      </td>

                      {/* Actions */}
                      <td className="px-5 py-4 whitespace-nowrap text-right">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setManageModalTicket(ticket);
                          }}
                          className="inline-flex items-center gap-1 rounded-xl bg-[#FAF8F3] hover:bg-[#F2EFE6] border border-[#E5E2DA] px-3 py-1.5 text-xs font-semibold text-[#1A1A1A] transition shadow-2xs"
                        >
                          <Settings2 className="h-3.5 w-3.5 text-[#E8491D]" />
                          <span>Manage</span>
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* MOBILE RESPONSIVE CARD LIST (Shown on mobile screens) */}
          <div className="md:hidden space-y-3">
            {filteredTickets.map((ticket) => {
              const sectionBadge = getSectionBadge(ticket.section);
              const SectionIcon = sectionBadge.icon;
              const statusBadge = getStatusBadge(ticket.status);

              return (
                <div
                  key={ticket.id}
                  onClick={() => setManageModalTicket(ticket)}
                  className="rounded-2xl border border-[#E5E2DA] bg-[#FFFFFF] p-4 shadow-sm space-y-3 active:scale-[0.99] transition"
                >
                  {/* Top Badges */}
                  <div className="flex items-center justify-between">
                    <span
                      className={`inline-flex items-center gap-1.5 rounded-lg border px-2.5 py-0.5 text-[10px] font-semibold ${sectionBadge.color}`}
                    >
                      <SectionIcon className="h-3 w-3" />
                      {sectionBadge.label}
                    </span>

                    <span
                      className={`inline-flex items-center gap-1.5 rounded-full border px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider ${statusBadge.classes}`}
                    >
                      <span className={`h-1.5 w-1.5 rounded-full ${statusBadge.dot}`} />
                      {statusBadge.label}
                    </span>
                  </div>

                  {/* Title & Description */}
                  <div>
                    <h4 className="font-bold text-[#1A1A1A] text-sm">{ticket.title}</h4>
                    <p className="text-xs text-[#55524A] mt-1 line-clamp-2 leading-relaxed">
                      {ticket.description}
                    </p>
                  </div>

                  {/* Meta Information Bar */}
                  <div className="flex flex-wrap items-center justify-between gap-2 border-t border-[#E5E2DA] pt-2.5 text-xs text-[#8A8578]">
                    <div className="flex items-center gap-3">
                      <span className="inline-flex items-center gap-1 text-rose-700 font-mono font-semibold">
                        <Heart className="h-3 w-3 fill-rose-600 text-rose-600" />
                        {ticket.interestedCount || 0} likes
                      </span>
                      <span className="inline-flex items-center gap-1 font-mono font-semibold text-[#1A1A1A]">
                        <Users className="h-3 w-3 text-[#8A8578]" />
                        {ticket.applicationsCount || 0} applicants
                      </span>
                    </div>

                    <span className="text-[10px] font-mono text-[#8A8578]">
                      {formatDate(ticket.createdAt)}
                    </span>
                  </div>

                  {/* Manage Button CTA */}
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setManageModalTicket(ticket);
                    }}
                    className="w-full flex items-center justify-center gap-1.5 rounded-xl bg-[#FAF8F3] hover:bg-[#F2EFE6] border border-[#E5E2DA] py-2 text-xs font-bold text-[#1A1A1A] shadow-2xs transition"
                  >
                    <Settings2 className="h-3.5 w-3.5 text-[#E8491D]" />
                    <span>Manage Ticket & Applicants</span>
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* MODALS */}
      <RaiseTicketModal
        isOpen={raiseModalOpen}
        onClose={() => setRaiseModalOpen(false)}
        section={selectedSection !== 'all' ? selectedSection : activeSection}
        onTicketCreated={(newTicket) => {
          setTickets((prev) => [newTicket, ...prev.filter((t) => t.id !== newTicket.id)]);
          setRaiseModalOpen(false);
          setManageModalTicket(newTicket);
        }}
      />

      {manageModalTicket && (
        <ManageTicketModal
          ticket={manageModalTicket}
          isOpen={Boolean(manageModalTicket)}
          onClose={() => setManageModalTicket(null)}
          onTicketUpdated={(updatedTicket) => {
            setTickets((prev) =>
              prev.map((t) => (t.id === updatedTicket.id ? updatedTicket : t))
            );
            setManageModalTicket(updatedTicket);
          }}
          onTicketDeleted={(deletedTicketId) => {
            setTickets((prev) => prev.filter((t) => t.id !== deletedTicketId));
            setManageModalTicket(null);
          }}
        />
      )}

      {detailsModalTicket && (
        <TicketDetailsModal
          ticket={detailsModalTicket}
          isOpen={Boolean(detailsModalTicket)}
          onClose={() => setDetailsModalTicket(null)}
          onOpenApply={() => {}}
          onOpenManage={(t) => {
            setDetailsModalTicket(null);
            setManageModalTicket(t);
          }}
          onTicketUpdated={(updatedTicket) => {
            setTickets((prev) =>
              prev.map((t) => (t.id === updatedTicket.id ? updatedTicket : t))
            );
            setDetailsModalTicket(updatedTicket);
          }}
          onTicketDeleted={(deletedTicketId) => {
            setTickets((prev) => prev.filter((t) => t.id !== deletedTicketId));
            setDetailsModalTicket(null);
          }}
          onOpenAuth={() => {}}
        />
      )}
    </div>
  );
};
