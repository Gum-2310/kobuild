export { UserCommunityActivityCard, UserCommunityActivityCard as UserActivityCard, SectionCollaborationActivityCard } from './UserCommunityActivityCard';
