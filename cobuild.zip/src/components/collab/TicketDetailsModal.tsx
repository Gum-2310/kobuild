import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Ticket, UserSection } from '../../types';
import {
  expressInterestInTicket,
  updateSectionTicket,
  deleteSectionTicket,
  generateTicketShareUrl,
} from '../../services/userService';
import { UserProfilePopover } from '../UserProfilePopover';
import {
  X,
  GraduationCap,
  Home,
  Briefcase,
  Calendar,
  MapPin,
  Users,
  Heart,
  Hammer,
  ShieldCheck,
  Clock,
  CheckCircle,
  Settings,
  Trash2,
  Share2,
  Check,
  Copy,
  Mail,
  MessageCircle,
  AlertCircle,
  AlertTriangle,
  Loader2,
  MessageSquare,
  Sparkles,
} from 'lucide-react';

interface TicketDetailsModalProps {
  ticket: Ticket | null;
  isOpen: boolean;
  onClose: () => void;
  onOpenApply: (ticket: Ticket) => void;
  onOpenManage: (ticket: Ticket) => void;
  onTicketUpdated: (updatedTicket: Ticket) => void;
  onTicketDeleted: (ticketId: string) => void;
  onOpenAuth: (section?: UserSection) => void;
  onNavigateToChat?: () => void;
}

const SECTION_META: Record<
  UserSection,
  { label: string; icon: React.FC<{ className?: string }>; color: string }
> = {
  student: { label: 'Student Track', icon: GraduationCap, color: '#E8491D' },
  homemaker: { label: 'Homemaker Track', icon: Home, color: '#10B981' },
  entrepreneur: { label: 'Entrepreneur Track', icon: Briefcase, color: '#8B5CF6' },
};

export const TicketDetailsModal: React.FC<TicketDetailsModalProps> = ({
  ticket,
  isOpen,
  onClose,
  onOpenApply,
  onOpenManage,
  onTicketUpdated,
  onTicketDeleted,
  onOpenAuth,
  onNavigateToChat,
}) => {
  const { user, userProfile } = useAuth();
  const [hasInterited, setHasInterested] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [copiedFeedback, setCopiedFeedback] = useState<string | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);
  const [showProfilePopover, setShowProfilePopover] = useState(false);

  if (!isOpen || !ticket) return null;

  const isCreator = Boolean(user && user.uid === ticket.creatorId);
  const meta = SECTION_META[ticket.section] || SECTION_META.student;
  const SectionIcon = meta.icon;

  const shareUrl = generateTicketShareUrl(ticket);

  const copyShareUrlToClipboard = async () => {
    let success = false;
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(shareUrl);
        success = true;
      }
    } catch (e) {
      console.warn('navigator.clipboard failed, attempting fallback', e);
    }

    if (!success) {
      try {
        const textarea = document.createElement('textarea');
        textarea.value = shareUrl;
        textarea.style.position = 'fixed';
        textarea.style.left = '-9999px';
        textarea.style.top = '-9999px';
        document.body.appendChild(textarea);
        textarea.focus();
        textarea.select();
        success = document.execCommand('copy');
        document.body.removeChild(textarea);
      } catch (err) {
        console.error('Fallback copy command failed:', err);
      }
    }

    setCopiedLink(true);
    setCopiedFeedback('Link copied to clipboard');
    setTimeout(() => {
      setCopiedLink(false);
      setCopiedFeedback(null);
    }, 2500);
  };

  const handleShare = async () => {
    const shareData = {
      title: `${ticket.title} | kobuildd Collaboration`,
      text: `Join the collaboration on this ${meta.label} ticket: "${ticket.title}"`,
      url: shareUrl,
    };

    if (
      typeof navigator !== 'undefined' &&
      typeof navigator.share === 'function'
    ) {
      try {
        await navigator.share(shareData);
        return;
      } catch (err: any) {
        if (err && err.name === 'AbortError') {
          return; // User closed the native share dialog
        }
        // If native share is not permitted in iframe or throws, fall through to modal
      }
    }

    // Open custom share modal if Web Share is not supported or failed
    setShowShareModal(true);
  };

  const handleToggleInterest = async () => {
    if (!user) {
      onOpenAuth(ticket.section);
      return;
    }

    const delta = hasInterited ? -1 : 1;
    setHasInterested(!hasInterited);
    const newCount = Math.max(0, (ticket.interestedCount || 0) + delta);

    try {
      await expressInterestInTicket(ticket.id, delta, userProfile, ticket);
      onTicketUpdated({
        ...ticket,
        interestedCount: newCount,
      });
    } catch (err) {
      console.error('Failed to update interest:', err);
    }
  };

  const handleStatusChange = async (newStatus: 'open' | 'in_progress' | 'closed') => {
    try {
      await updateSectionTicket(ticket.id, { status: newStatus });
      onTicketUpdated({
        ...ticket,
        status: newStatus,
        updatedAt: new Date().toISOString(),
      });
    } catch (err) {
      console.error('Failed to update ticket status:', err);
    }
  };

  const handleConfirmDelete = async () => {
    setIsDeleting(true);
    setDeleteError(null);
    try {
      await deleteSectionTicket(ticket.id, ticket.creatorId);
      if (onTicketDeleted) {
        onTicketDeleted(ticket.id);
      }
      setShowDeleteConfirm(false);
      onClose();
    } catch (err: any) {
      console.error('Failed to delete ticket:', err);
      setDeleteError('Unable to delete this ticket. Please try again.');
    } finally {
      setIsDeleting(false);
    }
  };

  const handleCopyShare = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const formatDate = (dateStr?: string) => {
    if (!dateStr) return 'Recently';
    try {
      return new Date(dateStr).toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
      });
    } catch {
      return dateStr;
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-[#1A1A1A]/40 p-3 sm:p-4 backdrop-blur-xs overflow-y-auto animate-in fade-in"
      onClick={onClose}
    >
      <div
        className="w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-3xl border border-[#E5E2DA] bg-[#FFFFFF] p-6 sm:p-8 shadow-2xl space-y-6"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top bar with track badge and close */}
        <div className="flex items-start justify-between gap-4 border-b border-[#E5E2DA] pb-4">
          <div className="flex flex-wrap items-center gap-2">
            <span className="inline-flex items-center gap-1.5 rounded-lg border border-[#E5E2DA] bg-[#FAF8F3] px-2.5 py-1 text-xs font-bold uppercase tracking-wider text-[#1A1A1A]">
              <SectionIcon className="h-3.5 w-3.5 text-[#E8491D]" />
              {meta.label}
            </span>
            <span
              className={`inline-flex items-center gap-1 rounded-lg px-2.5 py-1 text-xs font-semibold uppercase tracking-wider ${
                ticket.status === 'open'
                  ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                  : ticket.status === 'in_progress'
                  ? 'bg-amber-50 text-amber-800 border border-amber-200'
                  : 'bg-[#F2EFE6] text-[#8A8578] border border-[#E5E2DA]'
              }`}
            >
              <span
                className={`h-1.5 w-1.5 rounded-full ${
                  ticket.status === 'open'
                    ? 'bg-emerald-600 animate-pulse'
                    : ticket.status === 'in_progress'
                    ? 'bg-amber-600'
                    : 'bg-[#8A8578]'
                }`}
              />
              {ticket.status === 'open' ? 'Active / Open' : ticket.status === 'in_progress' ? 'In Progress' : 'Closed'}
            </span>
            {isCreator && (
              <span className="inline-flex items-center gap-1 rounded-lg bg-[#FAF8F3] border border-[#E8491D]/30 px-2 py-0.5 text-[11px] font-bold text-[#E8491D]">
                <ShieldCheck className="h-3 w-3" />
                Your Ticket
              </span>
            )}
          </div>

          <div className="flex items-center gap-1">
            <button
              onClick={handleShare}
              title="Share Ticket"
              className="flex items-center gap-1.5 rounded-full px-2.5 py-1.5 text-xs font-semibold text-[#8A8578] hover:bg-[#FAF8F3] hover:text-[#1A1A1A] transition border border-transparent hover:border-[#E5E2DA]"
            >
              {copiedLink ? (
                <>
                  <Check className="h-4 w-4 text-emerald-600" />
                  <span className="text-emerald-600 font-bold hidden sm:inline">Copied!</span>
                </>
              ) : (
                <>
                  <Share2 className="h-4 w-4" />
                  <span className="hidden sm:inline">Share</span>
                </>
              )}
            </button>
            <button
              onClick={onClose}
              className="rounded-full p-2 text-[#8A8578] hover:bg-[#FAF8F3] hover:text-[#1A1A1A] transition"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Title */}
        <div className="space-y-2">
          <h2 className="text-xl sm:text-2xl font-extrabold text-[#1A1A1A] tracking-tight leading-snug">
            {ticket.title}
          </h2>
          <div className="flex flex-wrap items-center gap-4 text-xs text-[#8A8578]">
            <span className="flex items-center gap-1.5">
              <Clock className="h-3.5 w-3.5" />
              Posted {formatDate(ticket.createdAt)}
            </span>
            <span className="flex items-center gap-1.5">
              <MapPin className="h-3.5 w-3.5 text-[#E8491D]" />
              {ticket.location || 'Remote'}
            </span>
            {ticket.deadline && (
              <span className="flex items-center gap-1.5 font-medium text-[#1A1A1A]">
                <Calendar className="h-3.5 w-3.5 text-[#8A8578]" />
                Deadline: {ticket.deadline}
              </span>
            )}
          </div>
        </div>

        {/* Creator Info Box */}
        <div
          onClick={() => !isCreator && setShowProfilePopover(true)}
          className={`flex items-center justify-between gap-4 rounded-2xl border border-[#E5E2DA] bg-[#FAF8F3] p-4 transition ${
            !isCreator ? 'cursor-pointer hover:border-[#E8491D] hover:bg-[#FFFFFF]' : ''
          }`}
        >
          <div className="flex items-center gap-3">
            {ticket.creatorPhotoURL ? (
              <img
                src={ticket.creatorPhotoURL}
                alt={ticket.creatorName}
                className="h-11 w-11 rounded-full object-cover border border-[#E5E2DA]"
                referrerPolicy="no-referrer"
              />
            ) : (
              <div className="flex h-11 w-11 items-center justify-center rounded-full bg-[#FFFFFF] border border-[#E5E2DA] text-[#E8491D] font-bold text-sm">
                {(ticket.creatorName || 'U').slice(0, 2).toUpperCase()}
              </div>
            )}
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-xs text-[#1A1A1A]">{ticket.creatorName}</span>
                <span className="rounded-md bg-[#FFFFFF] border border-[#E5E2DA] px-2 py-0.5 text-[10px] font-semibold text-[#8A8578] capitalize">
                  {ticket.creatorSection || ticket.section}
                </span>
                {!isCreator && (
                  <span className="text-[10px] text-[#E8491D] font-medium hidden sm:inline flex items-center gap-0.5">
                    • Message Creator &rarr;
                  </span>
                )}
              </div>
              <p className="text-[11px] text-[#55524A] line-clamp-1 mt-0.5">
                {ticket.creatorBio || ticket.creatorLocation || 'Builder on kobuildd'}
              </p>
            </div>
          </div>

          <div className="text-right flex-shrink-0">
            <span className="text-[10px] font-bold text-[#8A8578] uppercase tracking-wider block">Requirement</span>
            <span className="text-xs font-bold text-[#1A1A1A] flex items-center gap-1 justify-end">
              <Users className="h-3.5 w-3.5 text-[#E8491D]" />
              {ticket.peopleNeeded || 1} {Number(ticket.peopleNeeded) === 1 ? 'Person' : 'People'} Needed
            </span>
          </div>
        </div>

        {/* Full Description */}
        <div className="space-y-2">
          <h3 className="text-xs font-bold uppercase tracking-wider text-[#8A8578]">Project &amp; Collaboration Details</h3>
          <p className="text-xs sm:text-sm text-[#55524A] leading-relaxed whitespace-pre-line bg-[#FAF8F3]/50 p-4 rounded-2xl border border-[#E5E2DA]">
            {ticket.description}
          </p>
        </div>

        {/* Skills Required */}
        <div className="space-y-2">
          <h3 className="text-xs font-bold uppercase tracking-wider text-[#8A8578]">Skills &amp; Roles Needed</h3>
          <div className="flex flex-wrap gap-1.5">
            {ticket.skillsRequired && ticket.skillsRequired.length > 0 ? (
              ticket.skillsRequired.map((skill, i) => (
                <span
                  key={i}
                  className="rounded-xl bg-[#FAF8F3] border border-[#E5E2DA] px-3 py-1 text-xs font-semibold text-[#1A1A1A]"
                >
                  {skill}
                </span>
              ))
            ) : (
              <span className="text-xs text-[#8A8578] italic">Open to all motivated contributors</span>
            )}
          </div>
        </div>

        {/* Creator Management Actions (If creator) */}
        {isCreator && (
          <div className="rounded-2xl border border-[#E5E2DA] bg-[#FAF8F3] p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-[#1A1A1A] flex items-center gap-1.5">
                <Settings className="h-4 w-4 text-[#8A8578]" />
                Creator Management Controls
              </span>
              <button
                onClick={() => onOpenManage(ticket)}
                className="text-xs font-bold text-[#E8491D] hover:underline"
              >
                View Applications ({ticket.applicationsCount || 0})
              </button>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-[#E5E2DA]">
              <div className="flex items-center gap-2">
                <span className="text-xs text-[#8A8578]">Status:</span>
                <button
                  onClick={() => handleStatusChange('open')}
                  className={`rounded-lg px-2.5 py-1 text-xs font-semibold border transition ${
                    ticket.status === 'open'
                      ? 'bg-emerald-600 text-white border-emerald-600'
                      : 'bg-white text-[#55524A] border-[#E5E2DA] hover:bg-[#FAF8F3]'
                  }`}
                >
                  Open
                </button>
                <button
                  onClick={() => handleStatusChange('in_progress')}
                  className={`rounded-lg px-2.5 py-1 text-xs font-semibold border transition ${
                    ticket.status === 'in_progress'
                      ? 'bg-amber-600 text-white border-amber-600'
                      : 'bg-white text-[#55524A] border-[#E5E2DA] hover:bg-[#FAF8F3]'
                  }`}
                >
                  In Progress
                </button>
                <button
                  onClick={() => handleStatusChange('closed')}
                  className={`rounded-lg px-2.5 py-1 text-xs font-semibold border transition ${
                    ticket.status === 'closed'
                      ? 'bg-[#8A8578] text-white border-[#8A8578]'
                      : 'bg-white text-[#55524A] border-[#E5E2DA] hover:bg-[#FAF8F3]'
                  }`}
                >
                  Closed
                </button>
              </div>

              <button
                onClick={() => {
                  setDeleteError(null);
                  setShowDeleteConfirm(true);
                }}
                disabled={isDeleting}
                className="flex items-center gap-1 rounded-lg border border-rose-200 bg-rose-50 px-3 py-1 text-xs font-semibold text-rose-700 hover:bg-rose-100 transition"
              >
                <Trash2 className="h-3.5 w-3.5" />
                Delete Ticket
              </button>
            </div>
          </div>
        )}

        {/* Footer Actions */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-[#E5E2DA]">
          <div className="flex items-center gap-2">
            <button
              onClick={handleToggleInterest}
              className={`flex items-center gap-1.5 rounded-xl border px-3.5 py-2 text-xs font-semibold transition ${
                hasInterited
                  ? 'bg-rose-50 border-rose-200 text-rose-600'
                  : 'bg-[#FAF8F3] border-[#E5E2DA] text-[#55524A] hover:text-[#1A1A1A] hover:bg-white'
              }`}
            >
              <Heart className={`h-4 w-4 ${hasInterited ? 'fill-rose-600 text-rose-600' : ''}`} />
              <span>{ticket.interestedCount || 0} Interested</span>
            </button>
            <span className="text-xs text-[#8A8578] font-medium">
              {ticket.applicationsCount || 0} applications received
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="rounded-xl border border-[#E5E2DA] bg-[#FFFFFF] px-4 py-2 text-xs font-semibold text-[#55524A] hover:bg-[#FAF8F3] transition"
            >
              Close
            </button>

            {!isCreator ? (
              <>
                <button
                  type="button"
                  onClick={() => setShowProfilePopover(true)}
                  className="flex items-center gap-1.5 rounded-xl border border-[#E5E2DA] bg-[#FAF8F3] hover:bg-[#FFFFFF] hover:border-[#D4D0C5] px-4 py-2 text-xs font-semibold text-[#1A1A1A] transition"
                >
                  <MessageSquare className="h-3.5 w-3.5 text-[#E8491D]" />
                  <span>Message</span>
                </button>

                <button
                  onClick={() => {
                    if (!user) {
                      onOpenAuth(ticket.section);
                    } else {
                      onOpenApply(ticket);
                    }
                  }}
                  disabled={ticket.status === 'closed'}
                  className="flex items-center gap-2 rounded-xl bg-[#E8491D] hover:bg-[#FF5722] px-6 py-2 text-xs font-bold text-white shadow-md transition hover:-translate-y-0.5 active:translate-y-0 disabled:opacity-50"
                >
                  <Hammer className="h-4 w-4" />
                  <span>Want to Build</span>
                </button>
              </>
            ) : (
              <button
                onClick={() => onOpenManage(ticket)}
                className="flex items-center gap-2 rounded-xl bg-[#1A1A1A] hover:bg-[#333333] px-5 py-2 text-xs font-bold text-white shadow-md transition"
              >
                <Users className="h-4 w-4" />
                <span>Manage Collaborators</span>
              </button>
            )}
          </div>
        </div>

        {/* Delete Confirmation Modal Overlay */}
        {showDeleteConfirm && (
          <div className="fixed inset-0 z-60 flex items-center justify-center bg-[#1A1A1A]/60 p-4 backdrop-blur-xs animate-in fade-in">
            <div
              className="w-full max-w-md rounded-2xl border border-[#E5E2DA] bg-[#FFFFFF] p-6 shadow-2xl space-y-4 animate-in zoom-in-95"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-start gap-3.5">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-rose-100 text-rose-600 border border-rose-200 shrink-0">
                  <Trash2 className="h-5 w-5" />
                </div>
                <div className="space-y-1">
                  <h3 className="text-base font-bold text-[#1A1A1A]">
                    Delete this collaboration ticket?
                  </h3>
                  <p className="text-xs text-[#55524A] leading-relaxed">
                    This action will permanently remove this ticket from the community. Any collaboration activity associated with this ticket may also be removed. This action cannot be undone.
                  </p>
                  <div className="mt-2 rounded-xl bg-[#FAF8F3] border border-[#E5E2DA] p-2.5 text-xs font-semibold text-[#1A1A1A] line-clamp-2">
                    &ldquo;{ticket.title}&rdquo;
                  </div>
                </div>
              </div>

              {deleteError && (
                <div className="flex items-center gap-2 rounded-xl bg-rose-50 border border-rose-200 p-3 text-xs text-rose-700">
                  <AlertTriangle className="h-4 w-4 shrink-0 text-rose-600" />
                  <span>{deleteError}</span>
                </div>
              )}

              <div className="flex items-center justify-end gap-2.5 pt-2 border-t border-[#E5E2DA]">
                <button
                  type="button"
                  disabled={isDeleting}
                  onClick={() => {
                    setShowDeleteConfirm(false);
                    setDeleteError(null);
                  }}
                  className="rounded-xl border border-[#E5E2DA] bg-[#FFFFFF] hover:bg-[#FAF8F3] px-4 py-2 text-xs font-semibold text-[#55524A] transition disabled:opacity-50"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  disabled={isDeleting}
                  onClick={handleConfirmDelete}
                  className="flex items-center gap-1.5 rounded-xl bg-rose-600 hover:bg-rose-700 px-4 py-2 text-xs font-bold text-white shadow-sm transition disabled:opacity-50"
                >
                  {isDeleting ? (
                    <>
                      <Loader2 className="h-3.5 w-3.5 animate-spin" />
                      <span>Deleting...</span>
                    </>
                  ) : (
                    <>
                      <Trash2 className="h-3.5 w-3.5" />
                      <span>Delete Ticket</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* User Profile & Direct Message Popover */}
        {showProfilePopover && (
          <UserProfilePopover
            isOpen={showProfilePopover}
            onClose={() => setShowProfilePopover(false)}
            targetUser={{
              uid: ticket.creatorId,
              name: ticket.creatorName,
              photoURL: ticket.creatorPhotoURL,
              section: ticket.creatorSection || ticket.section,
              location: ticket.creatorLocation || ticket.location,
              bio: ticket.creatorBio,
            }}
            context={{
              type: 'ticket',
              id: ticket.id,
              title: ticket.title,
              note: 'Collaboration ticket inquiry',
            }}
            onOpenChatWithUser={() => {
              setShowProfilePopover(false);
              onClose();
              if (onNavigateToChat) {
                onNavigateToChat();
              }
            }}
            onOpenAuth={() => onOpenAuth(ticket.section)}
          />
        )}

        {/* Share Ticket Dialog Modal */}
        {showShareModal && (
          <div
            className="fixed inset-0 z-60 flex items-center justify-center bg-[#1A1A1A]/50 p-4 backdrop-blur-xs animate-in fade-in"
            onClick={() => setShowShareModal(false)}
          >
            <div
              className="w-full max-w-lg rounded-3xl border border-[#E5E2DA] bg-[#FFFFFF] p-6 sm:p-7 shadow-2xl space-y-5"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between border-b border-[#E5E2DA] pb-3.5">
                <div className="flex items-center gap-2">
                  <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#FAF8F3] border border-[#E5E2DA] text-[#E8491D]">
                    <Share2 className="h-4 w-4" />
                  </div>
                  <div>
                    <h3 className="text-base font-extrabold text-[#1A1A1A]">Share Ticket</h3>
                    <p className="text-xs text-[#8A8578]">Invite peers to collaborate on this ticket</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setShowShareModal(false)}
                  className="rounded-full p-1.5 text-[#8A8578] hover:bg-[#FAF8F3] hover:text-[#1A1A1A] transition"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              {/* Ticket Mini Card Preview */}
              <div className="rounded-2xl border border-[#E5E2DA] bg-[#FAF8F3] p-4 space-y-2">
                <div className="flex items-center gap-2">
                  <span className="inline-flex items-center gap-1 rounded-md border border-[#E5E2DA] bg-[#FFFFFF] px-2 py-0.5 text-[11px] font-bold text-[#1A1A1A] uppercase tracking-wider">
                    <SectionIcon className="h-3 w-3 text-[#E8491D]" />
                    {meta.label}
                  </span>
                  <span className="text-xs text-[#8A8578] flex items-center gap-1">
                    <MapPin className="h-3 w-3 text-[#E8491D]" />
                    {ticket.location || 'Remote'}
                  </span>
                </div>
                <p className="text-sm font-bold text-[#1A1A1A] line-clamp-2 leading-snug">
                  {ticket.title}
                </p>
                {ticket.skillsRequired && ticket.skillsRequired.length > 0 && (
                  <div className="flex flex-wrap gap-1 pt-1">
                    {ticket.skillsRequired.slice(0, 3).map((skill, idx) => (
                      <span
                        key={idx}
                        className="rounded-md bg-[#FFFFFF] border border-[#E5E2DA] px-2 py-0.5 text-[10px] font-medium text-[#55524A]"
                      >
                        {skill}
                      </span>
                    ))}
                    {ticket.skillsRequired.length > 3 && (
                      <span className="text-[10px] text-[#8A8578] self-center">
                        +{ticket.skillsRequired.length - 3} more
                      </span>
                    )}
                  </div>
                )}
              </div>

              {/* Quick Share Actions */}
              <div className="grid grid-cols-3 gap-2.5">
                {/* 1. Copy Link */}
                <button
                  type="button"
                  onClick={copyShareUrlToClipboard}
                  className={`flex flex-col items-center justify-center gap-2 rounded-2xl border p-3.5 transition text-center ${
                    copiedLink
                      ? 'border-emerald-500 bg-emerald-50 text-emerald-800'
                      : 'border-[#E5E2DA] bg-[#FFFFFF] text-[#1A1A1A] hover:border-[#E8491D] hover:bg-[#FAF8F3]'
                  }`}
                >
                  <div
                    className={`flex h-10 w-10 items-center justify-center rounded-xl transition ${
                      copiedLink
                        ? 'bg-emerald-600 text-white'
                        : 'bg-[#FAF8F3] border border-[#E5E2DA] text-[#1A1A1A]'
                    }`}
                  >
                    {copiedLink ? <Check className="h-5 w-5" /> : <Copy className="h-5 w-5" />}
                  </div>
                  <span className="text-xs font-bold leading-tight">
                    {copiedLink ? 'Copied!' : 'Copy Link'}
                  </span>
                </button>

                {/* 2. WhatsApp */}
                <a
                  href={`https://api.whatsapp.com/send?text=${encodeURIComponent(
                    `Check out this collaboration ticket on kobuildd: "${ticket.title}" (${meta.label})\n\nOpen Ticket:\n${shareUrl}`
                  )}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex flex-col items-center justify-center gap-2 rounded-2xl border border-[#E5E2DA] bg-[#FFFFFF] p-3.5 text-[#1A1A1A] transition text-center hover:border-emerald-500 hover:bg-emerald-50/40"
                >
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-100 text-emerald-700">
                    <MessageCircle className="h-5 w-5" />
                  </div>
                  <span className="text-xs font-bold leading-tight">WhatsApp</span>
                </a>

                {/* 3. Email */}
                <a
                  href={`mailto:?subject=${encodeURIComponent(
                    `Collaborate on: ${ticket.title}`
                  )}&body=${encodeURIComponent(
                    `Hi,\n\nI wanted to share this collaboration ticket on kobuildd with you:\n\n"${ticket.title}"\nTrack: ${meta.label}\nLocation: ${ticket.location || 'Remote'}\nSkills: ${(ticket.skillsRequired || []).join(', ') || 'Any'}\n\nJoin the collaboration here:\n${shareUrl}\n\nBest regards`
                  )}`}
                  className="flex flex-col items-center justify-center gap-2 rounded-2xl border border-[#E5E2DA] bg-[#FFFFFF] p-3.5 text-[#1A1A1A] transition text-center hover:border-blue-500 hover:bg-blue-50/40"
                >
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-100 text-blue-700">
                    <Mail className="h-5 w-5" />
                  </div>
                  <span className="text-xs font-bold leading-tight">Email</span>
                </a>
              </div>

              {/* Direct Link Input Box with 1-click Copy */}
              <div className="space-y-1.5">
                <label className="block text-[11px] font-bold uppercase tracking-wider text-[#8A8578]">
                  Direct Ticket Link
                </label>
                <div className="flex items-center gap-2 rounded-2xl border border-[#E5E2DA] bg-[#FAF8F3] p-1.5 focus-within:border-[#E8491D] focus-within:bg-[#FFFFFF] transition">
                  <input
                    type="text"
                    readOnly
                    value={shareUrl}
                    onFocus={(e) => e.target.select()}
                    className="w-full bg-transparent px-3 py-1 text-xs text-[#1A1A1A] font-mono outline-hidden select-all"
                  />
                  <button
                    type="button"
                    onClick={copyShareUrlToClipboard}
                    className={`shrink-0 flex items-center gap-1.5 rounded-xl px-3.5 py-1.5 text-xs font-bold transition shadow-xs ${
                      copiedLink
                        ? 'bg-emerald-600 text-white'
                        : 'bg-[#1A1A1A] text-white hover:bg-[#E8491D]'
                    }`}
                  >
                    {copiedLink ? (
                      <>
                        <Check className="h-3.5 w-3.5" />
                        <span>Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="h-3.5 w-3.5" />
                        <span>Copy</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* Notification Banner when Copied */}
              {copiedFeedback && (
                <div className="flex items-center gap-2 rounded-xl bg-emerald-50 border border-emerald-200 p-2.5 text-xs font-semibold text-emerald-800 animate-in fade-in">
                  <CheckCircle className="h-4 w-4 text-emerald-600 shrink-0" />
                  <span>{copiedFeedback}</span>
                </div>
              )}

              {/* Privacy and Security Notice */}
              <div className="rounded-xl bg-[#FAF8F3] border border-[#E5E2DA] p-3 text-[11px] text-[#8A8578] flex items-start gap-2">
                <ShieldCheck className="h-4 w-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>
                  This link opens the ticket directly. No personal account credentials or private contact details are shared.
                </span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
