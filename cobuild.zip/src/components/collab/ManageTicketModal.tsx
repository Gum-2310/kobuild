import React, { useState, useEffect } from 'react';
import { Ticket, Application } from '../../types';
import {
  subscribeTicketApplications,
  updateTicketApplicationStatus,
  updateSectionTicket,
  deleteSectionTicket,
} from '../../services/userService';
import {
  X,
  Users,
  CheckCircle2,
  XCircle,
  Clock,
  Trash2,
  MapPin,
  Check,
  Loader2,
  ShieldCheck,
  AlertTriangle,
} from 'lucide-react';

interface ManageTicketModalProps {
  ticket: Ticket | null;
  isOpen: boolean;
  onClose: () => void;
  onTicketUpdated: (updatedTicket: Ticket) => void;
  onTicketDeleted?: (ticketId: string) => void;
}

export const ManageTicketModal: React.FC<ManageTicketModalProps> = ({
  ticket,
  isOpen,
  onClose,
  onTicketUpdated,
  onTicketDeleted,
}) => {
  const [applications, setApplications] = useState<Application[]>([]);
  const [loading, setLoading] = useState(true);
  const [updatingId, setUpdatingId] = useState<string | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);

  useEffect(() => {
    if (!isOpen || !ticket) {
      setShowDeleteConfirm(false);
      setDeleteError(null);
      return;
    }

    setLoading(true);
    setShowDeleteConfirm(false);
    setDeleteError(null);

    const unsubscribe = subscribeTicketApplications(ticket.id, (apps) => {
      setApplications(apps);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [isOpen, ticket?.id]);

  if (!isOpen || !ticket) return null;

  const handleUpdateStatus = async (appId: string, status: 'accepted' | 'rejected') => {
    setUpdatingId(appId);
    try {
      await updateTicketApplicationStatus(appId, status);
      setApplications((prev) =>
        prev.map((a) => (a.id === appId ? { ...a, status } : a))
      );
    } catch (err) {
      console.error('Failed to update application status:', err);
    } finally {
      setUpdatingId(null);
    }
  };

  const handleToggleTicketStatus = async (newStatus: 'open' | 'in_progress' | 'closed') => {
    try {
      await updateSectionTicket(ticket.id, { status: newStatus });
      onTicketUpdated({ ...ticket, status: newStatus });
    } catch (err) {
      console.error('Failed to update ticket status:', err);
    }
  };

  const handleConfirmDelete = async () => {
    setIsDeleting(true);
    setDeleteError(null);
    try {
      await deleteSectionTicket(ticket.id, ticket.creatorId);
      if (onTicketDeleted) {
        onTicketDeleted(ticket.id);
      }
      setShowDeleteConfirm(false);
      onClose();
    } catch (err: any) {
      console.error('Failed to delete ticket:', err);
      setDeleteError('Unable to delete this ticket. Please try again.');
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-[#1A1A1A]/40 p-3 sm:p-4 backdrop-blur-xs overflow-y-auto animate-in fade-in"
      onClick={onClose}
    >
      <div
        className="w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-3xl border border-[#E5E2DA] bg-[#FFFFFF] p-6 sm:p-8 shadow-2xl space-y-6 relative"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-start justify-between gap-4 border-b border-[#E5E2DA] pb-4">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-1.5 rounded-md border border-[#E5E2DA] bg-[#FAF8F3] px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wider text-[#1A1A1A]">
              <ShieldCheck className="h-3 w-3 text-[#E8491D]" />
              Manage Ticket
            </div>
            <h2 className="text-xl font-bold text-[#1A1A1A] tracking-tight">
              {ticket.title}
            </h2>
            <p className="text-xs text-[#55524A]">
              Review collaborators who clicked "Want to Build" and manage your collaboration slot.
            </p>
          </div>
          <button
            onClick={onClose}
            className="rounded-full p-1.5 text-[#8A8578] hover:bg-[#FAF8F3] hover:text-[#1A1A1A] transition"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Quick Ticket Settings */}
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-[#E5E2DA] bg-[#FAF8F3] p-4">
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-[#8A8578]">Status:</span>
            {(['open', 'in_progress', 'closed'] as const).map((s) => (
              <button
                key={s}
                onClick={() => handleToggleTicketStatus(s)}
                className={`rounded-lg px-2.5 py-1 text-xs font-semibold capitalize border transition ${
                  ticket.status === s
                    ? 'bg-[#1A1A1A] text-white border-[#1A1A1A]'
                    : 'bg-white text-[#55524A] border-[#E5E2DA] hover:bg-[#FAF8F3]'
                }`}
              >
                {s.replace('_', ' ')}
              </button>
            ))}
          </div>

          <button
            id="btn-manage-ticket-delete"
            onClick={() => {
              setDeleteError(null);
              setShowDeleteConfirm(true);
            }}
            className="flex items-center gap-1.5 rounded-lg border border-rose-200 bg-rose-50 px-3 py-1 text-xs font-semibold text-rose-700 hover:bg-rose-100 transition"
          >
            <Trash2 className="h-3.5 w-3.5" />
            Delete Ticket
          </button>
        </div>

        {/* Inline Error Message if Delete Failed while confirm was open or closed */}
        {deleteError && !showDeleteConfirm && (
          <div className="flex items-center justify-between rounded-xl bg-rose-50 border border-rose-200 p-3 text-xs text-rose-700">
            <div className="flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 shrink-0 text-rose-600" />
              <span>{deleteError}</span>
            </div>
            <button
              onClick={() => setDeleteError(null)}
              className="text-rose-600 hover:text-rose-800"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        )}

        {/* Applicants List */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold uppercase tracking-wider text-[#8A8578]">
              Collaborator Applications ({applications.length})
            </h3>
            <span className="text-[11px] text-[#8A8578]">
              Goal: {ticket.peopleNeeded || 1} teammate{(ticket.peopleNeeded || 1) > 1 ? 's' : ''}
            </span>
          </div>

          {loading ? (
            <div className="py-8 text-center text-xs text-[#8A8578] flex items-center justify-center gap-2">
              <Loader2 className="h-4 w-4 animate-spin text-[#E8491D]" />
              Loading applications...
            </div>
          ) : applications.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-[#E5E2DA] bg-[#FAF8F3] p-8 text-center space-y-2">
              <Users className="mx-auto h-8 w-8 text-[#8A8578]/50" />
              <p className="text-xs font-bold text-[#1A1A1A]">No applications yet</p>
              <p className="text-[11px] text-[#8A8578] max-w-sm mx-auto">
                Peers who view this ticket in the {ticket.section} section can click "Want to Build" to send an introduction.
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {applications.map((app) => (
                <div
                  key={app.id}
                  className="rounded-2xl border border-[#E5E2DA] bg-[#FFFFFF] p-4 shadow-2xs space-y-3"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      {app.applicantPhotoURL ? (
                        <img
                          src={app.applicantPhotoURL}
                          alt={app.applicantName}
                          className="h-10 w-10 rounded-full object-cover border border-[#E5E2DA]"
                          referrerPolicy="no-referrer"
                        />
                      ) : (
                        <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[#FAF8F3] border border-[#E5E2DA] text-[#E8491D] font-bold text-xs">
                          {(app.applicantName || 'U').slice(0, 2).toUpperCase()}
                        </div>
                      )}
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-[#1A1A1A]">{app.applicantName}</span>
                          <span className="rounded bg-[#FAF8F3] border border-[#E5E2DA] px-1.5 py-0.5 text-[9px] font-semibold text-[#8A8578] capitalize">
                            {app.applicantSection || ticket.section}
                          </span>
                        </div>
                        {app.applicantLocation && (
                          <span className="text-[10px] text-[#8A8578] flex items-center gap-1">
                            <MapPin className="h-3 w-3" />
                            {app.applicantLocation}
                          </span>
                        )}
                      </div>
                    </div>

                    <span
                      className={`rounded-full px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wider ${
                        app.status === 'accepted'
                          ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                          : app.status === 'rejected'
                          ? 'bg-rose-50 text-rose-800 border border-rose-200'
                          : 'bg-amber-50 text-amber-800 border border-amber-200'
                      }`}
                    >
                      {app.status}
                    </span>
                  </div>

                  {/* Application Note */}
                  <p className="text-xs text-[#55524A] bg-[#FAF8F3] p-3 rounded-xl border border-[#E5E2DA] leading-relaxed">
                    "{app.message}"
                  </p>

                  {/* Applicant Skills */}
                  {app.skills && app.skills.length > 0 && (
                    <div className="flex flex-wrap gap-1">
                      {app.skills.map((s, idx) => (
                        <span
                          key={idx}
                          className="rounded-md bg-[#FAF8F3] border border-[#E5E2DA] px-2 py-0.5 text-[10px] font-medium text-[#1A1A1A]"
                        >
                          {s}
                        </span>
                      ))}
                    </div>
                  )}

                  {/* Review Actions */}
                  <div className="flex items-center justify-between pt-2 border-t border-[#E5E2DA]">
                    <span className="text-[10px] text-[#8A8578] flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      Applied on {new Date(app.createdAt).toLocaleDateString()}
                    </span>

                    <div className="flex items-center gap-2">
                      {app.status !== 'rejected' && (
                        <button
                          onClick={() => handleUpdateStatus(app.id, 'rejected')}
                          disabled={updatingId === app.id}
                          className="rounded-lg border border-[#E5E2DA] bg-[#FFFFFF] px-2.5 py-1 text-xs font-semibold text-[#8A8578] hover:text-rose-600 hover:border-rose-200 transition"
                        >
                          Decline
                        </button>
                      )}
                      {app.status !== 'accepted' && (
                        <button
                          onClick={() => handleUpdateStatus(app.id, 'accepted')}
                          disabled={updatingId === app.id}
                          className="flex items-center gap-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 px-3 py-1 text-xs font-bold text-white transition shadow-2xs"
                        >
                          <Check className="h-3.5 w-3.5" />
                          Accept &amp; Connect
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex justify-end pt-4 border-t border-[#E5E2DA]">
          <button
            onClick={onClose}
            className="rounded-xl bg-[#1A1A1A] hover:bg-[#333333] px-6 py-2 text-xs font-bold text-white shadow-md transition"
          >
            Done
          </button>
        </div>

        {/* Confirmation Dialog Overlay */}
        {showDeleteConfirm && (
          <div className="fixed inset-0 z-60 flex items-center justify-center bg-[#1A1A1A]/60 p-4 backdrop-blur-xs animate-in fade-in">
            <div
              className="w-full max-w-md rounded-2xl border border-[#E5E2DA] bg-[#FFFFFF] p-6 shadow-2xl space-y-4 animate-in zoom-in-95"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-start gap-3.5">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-rose-100 text-rose-600 border border-rose-200 shrink-0">
                  <Trash2 className="h-5 w-5" />
                </div>
                <div className="space-y-1">
                  <h3 className="text-base font-bold text-[#1A1A1A]">
                    Delete this collaboration ticket?
                  </h3>
                  <p className="text-xs text-[#55524A] leading-relaxed">
                    This action will permanently remove this ticket from the community. Any collaboration activity associated with this ticket may also be removed. This action cannot be undone.
                  </p>
                  <div className="mt-2 rounded-xl bg-[#FAF8F3] border border-[#E5E2DA] p-2.5 text-xs font-semibold text-[#1A1A1A] line-clamp-2">
                    &ldquo;{ticket.title}&rdquo;
                  </div>
                </div>
              </div>

              {deleteError && (
                <div className="flex items-center gap-2 rounded-xl bg-rose-50 border border-rose-200 p-3 text-xs text-rose-700">
                  <AlertTriangle className="h-4 w-4 shrink-0 text-rose-600" />
                  <span>{deleteError}</span>
                </div>
              )}

              <div className="flex items-center justify-end gap-2.5 pt-2 border-t border-[#E5E2DA]">
                <button
                  type="button"
                  id="btn-cancel-delete-ticket"
                  disabled={isDeleting}
                  onClick={() => {
                    setShowDeleteConfirm(false);
                    setDeleteError(null);
                  }}
                  className="rounded-xl border border-[#E5E2DA] bg-[#FFFFFF] hover:bg-[#FAF8F3] px-4 py-2 text-xs font-semibold text-[#55524A] transition disabled:opacity-50"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  id="btn-confirm-delete-ticket"
                  disabled={isDeleting}
                  onClick={handleConfirmDelete}
                  className="flex items-center gap-1.5 rounded-xl bg-rose-600 hover:bg-rose-700 px-4 py-2 text-xs font-bold text-white shadow-sm transition disabled:opacity-50"
                >
                  {isDeleting ? (
                    <>
                      <Loader2 className="h-3.5 w-3.5 animate-spin" />
                      <span>Deleting...</span>
                    </>
                  ) : (
                    <>
                      <Trash2 className="h-3.5 w-3.5" />
                      <span>Delete Ticket</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

