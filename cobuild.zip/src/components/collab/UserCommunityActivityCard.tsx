import React, { useState, useEffect } from 'react';
import { UserSection } from '../../types';
import { subscribeSectionActiveStats } from '../../services/userService';
import {
  Ticket,
  GraduationCap,
  Home,
  Briefcase,
  Loader2,
  Sparkles,
} from 'lucide-react';

interface UserCommunityActivityCardProps {
  onNavigateToMyTickets?: () => void;
  onOpenAuth?: (section?: UserSection | null) => void;
  activeSection: UserSection;
}

const SECTION_CONFIG: Record<
  UserSection,
  {
    name: string;
    icon: React.FC<{ className?: string }>;
    accentColor: string;
    badgeBg: string;
    badgeText: string;
    description: string;
  }
> = {
  student: {
    name: 'Students',
    icon: GraduationCap,
    accentColor: '#E8491D',
    badgeBg: 'bg-[#FDE4D8] text-[#E8491D] border-[#E8491D]/30',
    badgeText: 'Students Collaboration Activity',
    description: 'Open collaboration opportunities in this section',
  },
  homemaker: {
    name: 'Homemakers & Local Creators',
    icon: Home,
    accentColor: '#10B981',
    badgeBg: 'bg-emerald-50 text-emerald-800 border-emerald-200',
    badgeText: 'Homemakers Collaboration Activity',
    description: 'Open collaboration opportunities in this section',
  },
  entrepreneur: {
    name: 'Entrepreneurs & Builders',
    icon: Briefcase,
    accentColor: '#8B5CF6',
    badgeBg: 'bg-purple-50 text-purple-800 border-purple-200',
    badgeText: 'Entrepreneurs Collaboration Activity',
    description: 'Open collaboration opportunities in this section',
  },
};

export const UserCommunityActivityCard: React.FC<UserCommunityActivityCardProps> = ({
  activeSection,
}) => {
  const [stats, setStats] = useState<{ activeCount: number; openRequestsCount: number; loading: boolean }>({
    activeCount: 0,
    openRequestsCount: 0,
    loading: true,
  });

  const config = SECTION_CONFIG[activeSection] || SECTION_CONFIG.student;
  const Icon = config.icon;

  useEffect(() => {
    setStats((prev) => ({ ...prev, loading: true }));
    const unsubscribe = subscribeSectionActiveStats(activeSection, (data) => {
      setStats({
        activeCount: data.activeCount,
        openRequestsCount: data.openRequestsCount,
        loading: false,
      });
    });

    return () => {
      unsubscribe();
    };
  }, [activeSection]);

  return (
    <div
      id="section-collaboration-activity-card"
      className="w-full rounded-2xl border border-[#E5E2DA] bg-[#FAF8F3] p-4 sm:p-5 shadow-xs flex flex-col justify-between transition hover:border-[#D4D0C5]"
    >
      {/* Top Header Row with Badge and Real-time Pulse */}
      <div className="flex items-center justify-between border-b border-[#E5E2DA] pb-2.5 mb-3">
        <div className="flex items-center gap-1.5 min-w-0">
          <div className="flex h-5 w-5 items-center justify-center rounded-md bg-[#FFFFFF] border border-[#E5E2DA] text-[#1A1A1A] shrink-0">
            <Icon className="h-3.5 w-3.5" />
          </div>
          <span className="text-[10px] font-bold uppercase tracking-wider text-[#1A1A1A] truncate">
            {config.badgeText}
          </span>
        </div>

        <div className="flex items-center gap-1.5 rounded-full bg-[#FFFFFF] border border-[#E5E2DA] px-2 py-0.5 shrink-0 shadow-2xs">
          <span className="relative flex h-1.5 w-1.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
            <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-emerald-600" />
          </span>
          <span className="text-[9px] font-mono font-semibold tracking-tight text-[#55524A] uppercase">
            Live
          </span>
        </div>
      </div>

      {/* Main Single Public Stat Area */}
      {stats.loading ? (
        <div className="py-4 flex items-center justify-center gap-2 text-xs text-[#8A8578]">
          <Loader2 className="h-4 w-4 animate-spin text-[#E8491D]" />
          <span>Syncing section activity...</span>
        </div>
      ) : (
        <div className="space-y-1.5 py-0.5">
          <div className="flex items-baseline gap-2.5">
            <span className="text-3xl sm:text-4xl font-extrabold tracking-tight text-[#1A1A1A] font-mono leading-none">
              {stats.activeCount}
            </span>
            <div className="flex flex-col">
              <span className="text-xs sm:text-sm font-bold text-[#1A1A1A] leading-tight">
                {stats.activeCount === 1 ? 'Active Collaboration Ticket' : 'Active Collaboration Tickets'}
              </span>
              <span className="text-[10px] font-mono text-[#8A8578] uppercase tracking-wider">
                {activeSection} section
              </span>
            </div>
          </div>

          <p className="text-xs text-[#55524A] leading-relaxed">
            Open collaboration opportunities in this section
          </p>
        </div>
      )}

      {/* Bottom context bar */}
      <div className="border-t border-[#E5E2DA] pt-2 mt-3 flex items-center justify-between text-[10px] text-[#8A8578]">
        <span className="flex items-center gap-1">
          <Ticket className="h-3 w-3 text-[#E8491D]" />
          <span>Calculated from active requests</span>
        </span>
        <span className="font-mono font-medium text-[#55524A]">Strict section count</span>
      </div>
    </div>
  );
};

export { UserCommunityActivityCard as SectionCollaborationActivityCard };
