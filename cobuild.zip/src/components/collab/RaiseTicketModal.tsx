import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { UserSection, Ticket } from '../../types';
import { createSectionTicket } from '../../services/userService';
import {
  GraduationCap,
  Home,
  Briefcase,
  X,
  Plus,
  Send,
  Loader2,
  Calendar,
  MapPin,
  Users,
  Sparkles,
  CheckCircle2,
} from 'lucide-react';

interface RaiseTicketModalProps {
  section: UserSection;
  isOpen: boolean;
  onClose: () => void;
  onTicketCreated: (newTicket: Ticket) => void;
}

const SECTION_CONFIG: Record<
  UserSection,
  {
    name: string;
    icon: React.FC<{ className?: string }>;
    accentColor: string;
    badgeText: string;
    titlePlaceholder: string;
    descPlaceholder: string;
    suggestedSkills: string[];
    roleExamples: string[];
    guideText: string;
  }
> = {
  student: {
    name: 'Students Collaboration',
    icon: GraduationCap,
    accentColor: '#E8491D',
    badgeText: 'Student Ticket',
    titlePlaceholder: 'e.g. Autonomous Solar Lawn Rover Capstone or AI Flashcard Generator',
    descPlaceholder:
      'Describe your course project, capstone, hackathon idea, or research scope. Explain what has already been built and what specific teammates you need to finish it...',
    suggestedSkills: ['React', 'Python', 'C++', 'Computer Vision', 'UI/UX Design', 'FastAPI', 'ROS', 'Mobile App', 'Machine Learning'],
    roleExamples: ['Frontend Dev', 'ML Researcher', 'Firmware Engineer', 'UI/UX Designer'],
    guideText: 'Student tickets help you find peers with complementary technical skills for capstones, hackathons, and term projects.',
  },
  homemaker: {
    name: 'Homemakers & Local Creators',
    icon: Home,
    accentColor: '#10B981',
    badgeText: 'Homemaker Ticket',
    titlePlaceholder: 'e.g. Artisanal Sourdough Micro-Bakery or Festive Macramé Decor Studio',
    descPlaceholder:
      'Describe your culinary, boutique, handmade craft, tutoring, or neighborhood business idea. Detail what part you handle and what support/collaborators you need...',
    suggestedSkills: ['Order Management', 'Baking / Culinary', 'Social Media Marketing', 'Packaging & Dispatch', 'Handmade Crafts', 'Photography', 'Local Delivery'],
    roleExamples: ['Order Coordinator', 'Marketing Partner', 'Packaging Assistant', 'Co-Instructor'],
    guideText: 'Homemaker tickets connect you with local peers to turn home skills and artisanal crafts into thriving collaborative businesses.',
  },
  entrepreneur: {
    name: 'Entrepreneurs & Builders',
    icon: Briefcase,
    accentColor: '#8B5CF6',
    badgeText: 'Entrepreneur Ticket',
    titlePlaceholder: 'e.g. Commercial Fleet Telematics SaaS MVP or AI Diagnostics Screener',
    descPlaceholder:
      'Describe your startup, business venture, or MVP development goals. Specify current traction (LOIs, prototype) and the key partners or co-founders you are looking for...',
    suggestedSkills: ['Full-Stack TypeScript', 'B2B Sales', 'Go-To-Market', 'React / Next.js', 'PostgreSQL', 'Product Strategy', 'UI/UX', 'Cloud Architecture'],
    roleExamples: ['Technical Co-Founder', 'Full-Stack Lead', 'Growth Marketer', 'Product Specialist'],
    guideText: 'Entrepreneur tickets help founders find dedicated technical counterparts, growth leads, and early MVP co-builders.',
  },
};

export const RaiseTicketModal: React.FC<RaiseTicketModalProps> = ({
  section,
  isOpen,
  onClose,
  onTicketCreated,
}) => {
  const { user, userProfile } = useAuth();
  const config = SECTION_CONFIG[section];
  const IconComponent = config.icon;

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('');
  const [peopleNeeded, setPeopleNeeded] = useState<number | string>(2);
  const [deadline, setDeadline] = useState('');
  const [locationType, setLocationType] = useState('Remote');
  const [customLocation, setCustomLocation] = useState('');
  const [skills, setSkills] = useState<string[]>([]);
  const [skillInput, setSkillInput] = useState('');
  const [saving, setSaving] = useState(false);
  const [errors, setErrors] = useState<{
    title?: string;
    description?: string;
    skills?: string;
    peopleNeeded?: string;
    location?: string;
  }>({});
  const [firestoreError, setFirestoreError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleAddSkill = (skillToAdd: string) => {
    const trimmed = skillToAdd.trim();
    if (!trimmed) return;
    if (!skills.includes(trimmed)) {
      const updated = [...skills, trimmed];
      setSkills(updated);
      if (updated.length > 0) {
        setErrors((prev) => ({ ...prev, skills: undefined }));
      }
    }
    setSkillInput('');
  };

  const handleRemoveSkill = (index: number) => {
    const updated = skills.filter((_, i) => i !== index);
    setSkills(updated);
  };

  const handleKeyDownSkill = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' || e.key === ',') {
      e.preventDefault();
      handleAddSkill(skillInput);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFirestoreError(null);

    // STEP 1: Validate every required field locally
    const validationErrors: {
      title?: string;
      description?: string;
      skills?: string;
      peopleNeeded?: string;
      location?: string;
    } = {};

    if (!title.trim()) {
      validationErrors.title = 'Please enter a ticket title or project name.';
    }

    if (!description.trim()) {
      validationErrors.description = 'Please describe your project and collaboration requirements.';
    }

    if (skills.length === 0) {
      validationErrors.skills = 'Please add at least one skill or role.';
    }

    const numCollaborators = Number(peopleNeeded);
    if (
      peopleNeeded === '' ||
      peopleNeeded === null ||
      peopleNeeded === undefined ||
      isNaN(numCollaborators) ||
      numCollaborators <= 0
    ) {
      validationErrors.peopleNeeded = 'Please enter the number of collaborators needed.';
    }

    if (!locationType || (locationType === 'Custom' && !customLocation.trim())) {
      validationErrors.location = 'Please select a work location preference.';
    }

    // STEP 2: Stop immediately if any field is invalid
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }

    // Auth & Section check
    if (!user) {
      setFirestoreError('You must be signed in to raise a collaboration ticket.');
      return;
    }

    if (!section || !['student', 'homemaker', 'entrepreneur'].includes(section)) {
      setFirestoreError('Invalid collaboration section. Please select a valid track.');
      return;
    }

    setSaving(true);
    setFirestoreError(null);

    const finalLocation =
      locationType === 'Custom'
        ? customLocation.trim()
        : locationType;

    const creatorName =
      userProfile?.name || user.displayName || user.email?.split('@')[0] || 'Community Builder';
    const creatorPhotoURL = userProfile?.photoURL || user.photoURL || null;
    const creatorLocation = userProfile?.location || finalLocation || 'Remote';
    const creatorBio = userProfile?.bio || '';

    try {
      // Build safe payload with NO undefined values anywhere
      const ticketPayload: any = {
        creatorId: user.uid,
        creatorName,
        creatorPhotoURL,
        creatorSection: userProfile?.section || section,
        creatorLocation,
        creatorBio,
        section, // Automatically locked to the current section
        title: title.trim(),
        description: description.trim(),
        category: category.trim() || config.name,
        skillsRequired: [...skills],
        peopleNeeded: numCollaborators,
        location: finalLocation,
        status: 'open' as const,
      };

      const trimmedDeadline = deadline.trim();
      if (trimmedDeadline) {
        ticketPayload.deadline = trimmedDeadline;
      }

      const docId = await createSectionTicket(ticketPayload);

      const createdTicketObj: Ticket = {
        id: docId,
        ...ticketPayload,
        interestedCount: 0,
        applicationsCount: 0,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      onTicketCreated(createdTicketObj);
      onClose();
    } catch (err: any) {
      console.error('Failed to raise ticket in Firestore:', err);
      // Generic friendly error - never expose technical Firebase error
      setFirestoreError('Unable to create the ticket right now. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-[#1A1A1A]/40 p-3 sm:p-4 backdrop-blur-xs overflow-y-auto animate-in fade-in"
      onClick={onClose}
    >
      <div
        className="w-full max-w-xl max-h-[92vh] overflow-y-auto rounded-3xl border border-[#E5E2DA] bg-[#FFFFFF] p-6 sm:p-8 shadow-2xl space-y-6"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-start justify-between gap-4 border-b border-[#E5E2DA] pb-4">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-1.5 rounded-md border px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wider bg-[#FAF8F3] border-[#E5E2DA]">
              <IconComponent className="h-3.5 w-3.5 text-[#E8491D]" />
              <span className="text-[#1A1A1A]">{config.badgeText}</span>
              <span className="text-[#8A8578] font-mono">• Auto-Assigned</span>
            </div>
            <h2 className="text-xl font-bold text-[#1A1A1A] tracking-tight">
              Raise a Collaboration Ticket
            </h2>
            <p className="text-xs text-[#55524A]">{config.guideText}</p>
          </div>
          <button
            onClick={onClose}
            className="rounded-full p-1.5 text-[#8A8578] hover:bg-[#FAF8F3] hover:text-[#1A1A1A] transition"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {firestoreError && (
          <div className="rounded-xl bg-rose-50 border border-rose-200 p-3 text-xs text-rose-800 font-medium">
            {firestoreError}
          </div>
        )}

        {/* Ticket Form */}
        <form onSubmit={handleSubmit} noValidate className="space-y-5">
          {/* Section Indicator (Read-only banner confirming section) */}
          <div className="flex flex-wrap items-center gap-x-9 gap-y-1 rounded-xl bg-[#FAF8F3] border border-[#E5E2DA] px-3.5 py-2 text-xs">
            <span className="text-[#8A8578] font-medium shrink-0">Target Section:</span>
            <span className="font-bold text-[#1A1A1A] capitalize flex items-center gap-1.5 shrink-0">
              <IconComponent className="h-3.5 w-3.5 text-[#E8491D]" />
              {section} Collaboration Track
            </span>
          </div>

          {/* 1. Title */}
          <div>
            <label className="block text-xs font-bold text-[#1A1A1A] mb-1.5">
              Ticket Title / Project Name <span className="text-[#E8491D]">*</span>
            </label>
            <input
              type="text"
              id="input-ticket-title"
              value={title}
              onChange={(e) => {
                const val = e.target.value;
                setTitle(val);
                if (val.trim()) {
                  setErrors((prev) => ({ ...prev, title: undefined }));
                }
              }}
              placeholder={config.titlePlaceholder}
              className={`w-full rounded-xl border ${
                errors.title
                  ? 'border-rose-500 bg-rose-50/40 focus:border-rose-500'
                  : 'border-[#E5E2DA] bg-[#FAF8F3] focus:border-[#E8491D]'
              } px-3.5 py-2.5 text-xs text-[#1A1A1A] placeholder:text-[#8A8578] focus:bg-white focus:outline-none transition shadow-2xs`}
            />
            {errors.title && (
              <p className="mt-1.5 text-[11px] font-medium text-rose-600">
                {errors.title}
              </p>
            )}
          </div>

          {/* 2. Description */}
          <div>
            <label className="block text-xs font-bold text-[#1A1A1A] mb-1.5">
              Description &amp; Collaboration Details <span className="text-[#E8491D]">*</span>
            </label>
            <textarea
              rows={4}
              id="input-ticket-desc"
              value={description}
              onChange={(e) => {
                const val = e.target.value;
                setDescription(val);
                if (val.trim()) {
                  setErrors((prev) => ({ ...prev, description: undefined }));
                }
              }}
              placeholder={config.descPlaceholder}
              className={`w-full rounded-xl border ${
                errors.description
                  ? 'border-rose-500 bg-rose-50/40 focus:border-rose-500'
                  : 'border-[#E5E2DA] bg-[#FAF8F3] focus:border-[#E8491D]'
              } p-3 text-xs text-[#1A1A1A] placeholder:text-[#8A8578] focus:bg-white focus:outline-none transition shadow-2xs leading-relaxed`}
            />
            {errors.description && (
              <p className="mt-1.5 text-[11px] font-medium text-rose-600">
                {errors.description}
              </p>
            )}
          </div>

          {/* 3. Skills / People Needed Tag Adder */}
          <div className="space-y-2">
            <label className="block text-xs font-bold text-[#1A1A1A]">
              Skills &amp; Roles Needed <span className="text-[#E8491D]">*</span>
            </label>
            <div
              className={`rounded-2xl border ${
                errors.skills
                  ? 'border-rose-500 bg-rose-50/30'
                  : 'border-[#E5E2DA] bg-[#FAF8F3]'
              } p-3.5 space-y-3 transition`}
            >
              {/* Selected skills badges */}
              <div className="flex flex-wrap gap-1.5 min-h-[30px] items-center">
                {skills.length === 0 && (
                  <span className="text-[11px] text-[#8A8578] italic">
                    Type a skill and press Enter, or click suggested chips below
                  </span>
                )}
                {skills.map((skill, index) => (
                  <span
                    key={index}
                    className="inline-flex items-center gap-1 rounded-lg bg-[#FFFFFF] border border-[#E5E2DA] px-2.5 py-1 text-xs font-medium text-[#1A1A1A] shadow-2xs"
                  >
                    <span>{skill}</span>
                    <button
                      type="button"
                      onClick={() => handleRemoveSkill(index)}
                      className="text-[#8A8578] hover:text-[#E8491D] transition"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </span>
                ))}
              </div>

              {/* Input box */}
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={skillInput}
                  onChange={(e) => setSkillInput(e.target.value)}
                  onKeyDown={handleKeyDownSkill}
                  placeholder="Type skill &amp; press Enter (e.g. React Native, Sourdough, Sales)..."
                  className="flex-1 rounded-xl border border-[#E5E2DA] bg-[#FFFFFF] px-3 py-1.5 text-xs text-[#1A1A1A] placeholder:text-[#8A8578] focus:border-[#E8491D] focus:outline-none"
                />
                <button
                  type="button"
                  id="btn-add-skill"
                  onClick={() => handleAddSkill(skillInput)}
                  className="rounded-xl border border-[#E5E2DA] bg-[#FFFFFF] px-3 py-1.5 text-xs font-semibold text-[#1A1A1A] hover:bg-[#FAF8F3]"
                >
                  Add
                </button>
              </div>

              {/* Suggested quick pills */}
              <div className="pt-1">
                <span className="text-[10px] font-bold text-[#8A8578] uppercase tracking-wider block mb-1">
                  Suggested for {config.name}:
                </span>
                <div className="flex flex-wrap gap-1">
                  {config.suggestedSkills.map((s) => (
                    <button
                      key={s}
                      type="button"
                      onClick={() => handleAddSkill(s)}
                      disabled={skills.includes(s)}
                      className={`rounded-md px-2 py-0.5 text-[11px] font-medium border transition ${
                        skills.includes(s)
                          ? 'bg-[#E5E2DA] text-[#8A8578] border-transparent cursor-default'
                          : 'bg-[#FFFFFF] text-[#55524A] border-[#E5E2DA] hover:border-[#D4D0C5] hover:text-[#1A1A1A]'
                      }`}
                    >
                      + {s}
                    </button>
                  ))}
                </div>
              </div>
            </div>
            {errors.skills && (
              <p className="mt-1 text-[11px] font-medium text-rose-600">
                {errors.skills}
              </p>
            )}
          </div>

          {/* 4. Number of People Needed & Deadline */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-[#1A1A1A] mb-1.5">
                Number of Collaborators Needed <span className="text-[#E8491D]">*</span>
              </label>
              <div className="flex items-center gap-2">
                <Users className="h-4 w-4 text-[#8A8578] shrink-0" />
                <input
                  type="number"
                  min={1}
                  max={50}
                  value={peopleNeeded}
                  onChange={(e) => {
                    const val = e.target.value;
                    setPeopleNeeded(val);
                    const num = Number(val);
                    if (val !== '' && !isNaN(num) && num > 0) {
                      setErrors((prev) => ({ ...prev, peopleNeeded: undefined }));
                    }
                  }}
                  className={`w-full rounded-xl border ${
                    errors.peopleNeeded
                      ? 'border-rose-500 bg-rose-50/40 focus:border-rose-500'
                      : 'border-[#E5E2DA] bg-[#FAF8F3] focus:border-[#E8491D]'
                  } px-3.5 py-2 text-xs font-semibold text-[#1A1A1A] focus:bg-white focus:outline-none transition`}
                />
              </div>
              {errors.peopleNeeded && (
                <p className="mt-1.5 text-[11px] font-medium text-rose-600">
                  {errors.peopleNeeded}
                </p>
              )}
            </div>

            <div>
              <label className="block text-xs font-bold text-[#1A1A1A] mb-1.5">
                Optional Target Deadline
              </label>
              <div className="flex items-center gap-2">
                <Calendar className="h-4 w-4 text-[#8A8578] shrink-0" />
                <input
                  type="text"
                  value={deadline}
                  onChange={(e) => setDeadline(e.target.value)}
                  placeholder="e.g. Nov 15, 2026 or 4 Weeks"
                  className="w-full rounded-xl border border-[#E5E2DA] bg-[#FAF8F3] px-3.5 py-2 text-xs text-[#1A1A1A] placeholder:text-[#8A8578] focus:border-[#E8491D] focus:bg-white focus:outline-none transition"
                />
              </div>
            </div>
          </div>

          {/* 5. Location / Remote Option */}
          <div>
            <label className="block text-xs font-bold text-[#1A1A1A] mb-1.5">
              Work Location Preference <span className="text-[#E8491D]">*</span>
            </label>
            <div
              className={`rounded-2xl border ${
                errors.location
                  ? 'border-rose-500 bg-rose-50/30 p-2.5'
                  : 'border-transparent'
              } transition`}
            >
              <div className="flex flex-wrap items-center gap-2">
                {['Remote', 'Hybrid', 'On-site / Campus', 'Local Neighborhood', 'Custom'].map((loc) => (
                  <button
                    key={loc}
                    type="button"
                    onClick={() => {
                      setLocationType(loc);
                      if (loc !== 'Custom' || customLocation.trim()) {
                        setErrors((prev) => ({ ...prev, location: undefined }));
                      }
                    }}
                    className={`rounded-xl px-3 py-1.5 text-xs font-semibold border transition ${
                      locationType === loc
                        ? 'bg-[#E8491D] text-white border-[#E8491D]'
                        : 'bg-[#FAF8F3] text-[#55524A] border-[#E5E2DA] hover:border-[#D4D0C5] hover:text-[#1A1A1A]'
                    }`}
                  >
                    {loc}
                  </button>
                ))}
              </div>

              {locationType === 'Custom' && (
                <div className="mt-2.5">
                  <input
                    type="text"
                    value={customLocation}
                    onChange={(e) => {
                      const val = e.target.value;
                      setCustomLocation(val);
                      if (val.trim()) {
                        setErrors((prev) => ({ ...prev, location: undefined }));
                      }
                    }}
                    placeholder="Specify city, college campus, or neighborhood..."
                    className={`w-full rounded-xl border ${
                      errors.location
                        ? 'border-rose-500 bg-rose-50/40 focus:border-rose-500'
                        : 'border-[#E5E2DA] bg-[#FAF8F3] focus:border-[#E8491D]'
                    } px-3.5 py-2 text-xs text-[#1A1A1A] placeholder:text-[#8A8578] focus:bg-white focus:outline-none transition`}
                  />
                </div>
              )}
            </div>
            {errors.location && (
              <p className="mt-1.5 text-[11px] font-medium text-rose-600">
                {errors.location}
              </p>
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-[#E5E2DA]">
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl border border-[#E5E2DA] bg-[#FFFFFF] px-4 py-2.5 text-xs font-semibold text-[#55524A] hover:bg-[#FAF8F3] hover:text-[#1A1A1A] transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              id="btn-create-ticket"
              disabled={saving}
              className="flex items-center gap-2 rounded-xl bg-[#E8491D] hover:bg-[#FF5722] px-6 py-2.5 text-xs font-bold text-white shadow-md transition hover:-translate-y-0.5 active:translate-y-0 active:scale-[0.99] disabled:opacity-50"
            >
              {saving ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  <span>Publishing Ticket...</span>
                </>
              ) : (
                <>
                  <Send className="h-4 w-4" />
                  <span>Create Ticket</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
