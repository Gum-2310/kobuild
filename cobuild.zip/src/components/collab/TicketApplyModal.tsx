import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Ticket, Application } from '../../types';
import { createTicketApplication } from '../../services/userService';
import {
  X,
  Hammer,
  Send,
  Loader2,
  CheckCircle2,
  Users,
  Sparkles,
} from 'lucide-react';

interface TicketApplyModalProps {
  ticket: Ticket | null;
  isOpen: boolean;
  onClose: () => void;
  onApplicationSent: (ticketId: string) => void;
}

export const TicketApplyModal: React.FC<TicketApplyModalProps> = ({
  ticket,
  isOpen,
  onClose,
  onApplicationSent,
}) => {
  const { user, userProfile } = useAuth();
  const [message, setMessage] = useState('');
  const [skillsText, setSkillsText] = useState(
    userProfile?.skills?.join(', ') || ''
  );
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  if (!isOpen || !ticket) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      setErrorMsg('You must be signed in to submit a collaboration request.');
      return;
    }

    if (!message.trim()) {
      setErrorMsg('Please write a short note about why you want to build this.');
      return;
    }

    setSubmitting(true);
    setErrorMsg(null);

    try {
      const applicantSkills = skillsText
        .split(',')
        .map((s) => s.trim())
        .filter(Boolean);

      const payload = {
        ticketId: ticket.id,
        ticketTitle: ticket.title,
        ticketSection: ticket.section,
        applicantId: user.uid,
        applicantName:
          userProfile?.name || user.displayName || user.email?.split('@')[0] || 'Peer Builder',
        applicantPhotoURL: userProfile?.photoURL || user.photoURL || null,
        applicantSection: userProfile?.section || ticket.section,
        applicantLocation: userProfile?.location || '',
        applicantBio: userProfile?.bio || '',
        skills: applicantSkills,
        message: message.trim(),
      };

      await createTicketApplication(payload, ticket.creatorId);
      setSuccess(true);
      onApplicationSent(ticket.id);
      setTimeout(() => {
        setSuccess(false);
        onClose();
      }, 1500);
    } catch (err: any) {
      console.error('Failed to submit application:', err);
      setErrorMsg(err.message || 'Failed to submit application. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-[#1A1A1A]/40 p-3 sm:p-4 backdrop-blur-xs overflow-y-auto animate-in fade-in"
      onClick={onClose}
    >
      <div
        className="w-full max-w-lg rounded-3xl border border-[#E5E2DA] bg-[#FFFFFF] p-6 sm:p-8 shadow-2xl space-y-6"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-4 border-b border-[#E5E2DA] pb-4">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-1.5 rounded-md border border-[#E5E2DA] bg-[#FAF8F3] px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wider text-[#1A1A1A]">
              <Hammer className="h-3 w-3 text-[#E8491D]" />
              Want to Build
            </div>
            <h2 className="text-lg font-bold text-[#1A1A1A] tracking-tight">
              Apply to Collaborate
            </h2>
            <p className="text-xs text-[#55524A] line-clamp-1">
              Project: <span className="font-semibold text-[#1A1A1A]">{ticket.title}</span>
            </p>
          </div>
          <button
            onClick={onClose}
            className="rounded-full p-1.5 text-[#8A8578] hover:bg-[#FAF8F3] hover:text-[#1A1A1A] transition"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {errorMsg && (
          <div className="rounded-xl bg-rose-50 border border-rose-200 p-3 text-xs text-rose-800 font-medium">
            {errorMsg}
          </div>
        )}

        {success ? (
          <div className="py-8 flex flex-col items-center justify-center text-center space-y-3">
            <CheckCircle2 className="h-12 w-12 text-emerald-600 animate-in zoom-in" />
            <h3 className="text-base font-bold text-[#1A1A1A]">Collaboration Request Sent!</h3>
            <p className="text-xs text-[#55524A] max-w-xs">
              {ticket.creatorName} has been notified and can review your profile in their ticket dashboard.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="rounded-2xl border border-[#E5E2DA] bg-[#FAF8F3] p-3 text-xs space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-[#8A8578]">Project Lead:</span>
                <span className="font-semibold text-[#1A1A1A]">{ticket.creatorName}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[#8A8578]">Required Skills:</span>
                <span className="font-medium text-[#1A1A1A] line-clamp-1">
                  {ticket.skillsRequired?.join(', ') || 'General Collaboration'}
                </span>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#1A1A1A] mb-1.5">
                Your Skills &amp; Relevant Experience
              </label>
              <input
                type="text"
                value={skillsText}
                onChange={(e) => setSkillsText(e.target.value)}
                placeholder="e.g. React Native, CAD Design, Product Strategy..."
                className="w-full rounded-xl border border-[#E5E2DA] bg-[#FAF8F3] px-3.5 py-2 text-xs text-[#1A1A1A] placeholder:text-[#8A8578] focus:border-[#E8491D] focus:bg-white focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#1A1A1A] mb-1.5">
                Why do you want to collaborate on this? <span className="text-[#E8491D]">*</span>
              </label>
              <textarea
                rows={4}
                required
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Introduce yourself, your weekly availability, and how you plan to contribute to this ticket..."
                className="w-full rounded-xl border border-[#E5E2DA] bg-[#FAF8F3] p-3 text-xs text-[#1A1A1A] placeholder:text-[#8A8578] focus:border-[#E8491D] focus:bg-white focus:outline-none leading-relaxed"
              />
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-[#E5E2DA]">
              <button
                type="button"
                onClick={onClose}
                className="rounded-xl border border-[#E5E2DA] bg-[#FFFFFF] px-4 py-2 text-xs font-semibold text-[#55524A] hover:bg-[#FAF8F3] transition"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={submitting || !message.trim()}
                className="flex items-center gap-2 rounded-xl bg-[#E8491D] hover:bg-[#FF5722] px-6 py-2 text-xs font-bold text-white shadow-md transition disabled:opacity-50"
              >
                {submitting ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    <span>Submitting...</span>
                  </>
                ) : (
                  <>
                    <Send className="h-4 w-4" />
                    <span>Submit Application</span>
                  </>
                )}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
