import React from 'react';
import { useAuth } from '../context/AuthContext';
import { UserSection, AppView } from '../types';
import {
  Sparkles,
  ArrowRight,
  Flame,
  Users,
  MessageSquare,
  Hammer,
  Lightbulb,
  CheckCircle2,
  Rocket,
  Shield,
  Trophy,
  Briefcase,
  GraduationCap,
  Home as HomeIcon,
} from 'lucide-react';

interface HomePageProps {
  onNavigate: (view: AppView, section?: UserSection) => void;
  onOpenAuth: (section?: UserSection | null) => void;
}

export const HomePage: React.FC<HomePageProps> = ({ onNavigate, onOpenAuth }) => {
  const { user } = useAuth();

  const handleGetStarted = () => {
    if (user) {
      onNavigate('communities');
    } else {
      onOpenAuth(null);
    }
  };

  return (
    <div className="space-y-16 pb-20">
      {/* 1. Hero Section */}
      <section className="relative overflow-hidden rounded-3xl border border-[#E5E2DA] bg-[#FFFFFF] p-8 sm:p-12 lg:p-16 shadow-xl">
        {/* Subtle geometric grid backdrop accent */}
        <div className="absolute inset-0 bg-[radial-gradient(#E5E2DA_1px,transparent_1px)] [background-size:24px_24px] opacity-60 pointer-events-none" />

        <div className="relative z-10 max-w-3xl space-y-6">
          <div className="inline-flex items-center gap-2 rounded-full border border-[#E8491D]/30 bg-[#FDE4D8] px-3.5 py-1 text-xs font-semibold text-[#E8491D]">
            <Sparkles className="h-3.5 w-3.5 text-[#E8491D]" />
            <span>KOBUILD Collaborative Ecosystem</span>
          </div>

          <h1 className="text-3xl font-extrabold tracking-tight text-[#1A1A1A] sm:text-5xl lg:text-6xl leading-[1.12]">
            From the boldest ideas to real-world impact.
          </h1>

          <p className="text-base sm:text-lg leading-relaxed text-[#55524A] max-w-2xl font-normal">
            Join official flagship challenges like the 90-Day Winter Arc, discover open community squads, talk in real-time chats, and work with teammates in dedicated Build Spaces.
          </p>

          {/* CTAs */}
          <div className="flex flex-wrap items-center gap-3 pt-2">
            <button
              id="home-cta-explore-communities"
              onClick={() => onNavigate('communities')}
              className="flex items-center gap-2 rounded-xl bg-[#E8491D] hover:bg-[#D03E15] px-6 py-3.5 text-xs sm:text-sm font-semibold text-white shadow-lg transition duration-200 hover:-translate-y-0.5 active:translate-y-0 active:scale-[0.99]"
            >
              <Flame className="h-4 w-4 fill-current text-white" />
              <span>Explore Communities &amp; Challenges</span>
              <ArrowRight className="h-4 w-4" />
            </button>

            <button
              id="home-cta-buildspaces"
              onClick={() => onNavigate('build_spaces')}
              className="flex items-center gap-2 rounded-xl border border-[#E5E2DA] bg-[#F2EFE6] px-6 py-3.5 text-xs sm:text-sm font-semibold text-[#1A1A1A] shadow-sm transition duration-200 hover:bg-[#E5E2DA] hover:-translate-y-0.5 active:translate-y-0 active:scale-[0.99]"
            >
              <Hammer className="h-4 w-4 text-[#E8491D]" />
              <span>Open Build Spaces</span>
            </button>
          </div>
        </div>
      </section>

      {/* 2. Platform Architecture: 4 Core Pillars */}
      <section className="space-y-6">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <h2 className="text-xs font-bold uppercase tracking-widest text-[#8A8578]">
            Core Architecture
          </h2>
          <p className="text-2xl font-bold tracking-tight text-[#1A1A1A]">
            The 5 Pillars of KOBUILD
          </p>
          <p className="text-xs sm:text-sm text-[#55524A]">
            A complete collaborative ecosystem designed for real action, accountability, and project delivery.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {/* 1. Home */}
          <div className="rounded-2xl border border-[#E5E2DA] bg-[#FFFFFF] p-6 flex flex-col justify-between shadow-sm hover:border-[#D4D0C5] transition-all">
            <div>
              <div className="flex items-center justify-between mb-4">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#F2EFE6] text-[#1A1A1A] shadow-xs">
                  <Sparkles className="h-5 w-5 text-[#E8491D]" />
                </div>
                <span className="rounded-md bg-[#F2EFE6] border border-[#E5E2DA] px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-[#55524A]">
                  Overview
                </span>
              </div>
              <h3 className="text-base font-bold text-[#1A1A1A] mb-1.5">1. Home</h3>
              <p className="text-xs leading-relaxed text-[#55524A] mb-4">
                Your mission control dashboard. Discover trending challenges, track active projects, and see platform highlights.
              </p>
            </div>
            <button
              onClick={() => onNavigate('home')}
              className="flex items-center justify-between rounded-lg border border-[#E5E2DA] bg-[#FAF8F3] px-3 py-2 text-xs font-semibold text-[#1A1A1A] transition hover:bg-[#F2EFE6]"
            >
              <span>Explore Home</span>
              <ArrowRight className="h-3.5 w-3.5 text-[#8A8578]" />
            </button>
          </div>

          {/* 2. Communities */}
          <div className="rounded-2xl border border-[#E8491D]/40 bg-[#FFFFFF] p-6 flex flex-col justify-between shadow-md hover:border-[#E8491D] transition-all">
            <div>
              <div className="flex items-center justify-between mb-4">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#E8491D] text-white shadow-xs">
                  <Flame className="h-5 w-5 fill-current" />
                </div>
                <span className="rounded-md bg-[#FDE4D8] border border-[#E8491D]/30 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-[#E8491D]">
                  Challenges &amp; Squads
                </span>
              </div>
              <h3 className="text-base font-bold text-[#1A1A1A] mb-1.5">2. Communities</h3>
              <p className="text-xs leading-relaxed text-[#55524A] mb-4">
                Join KOBUILD official challenges with daily proof verifications &amp; leaderboards, or launch open community squads with live sessions.
              </p>
            </div>
            <button
              onClick={() => onNavigate('communities')}
              className="flex items-center justify-between rounded-lg border border-[#E8491D]/30 bg-[#FDE4D8] px-3 py-2 text-xs font-semibold text-[#E8491D] transition hover:bg-[#E8491D] hover:text-white"
            >
              <span>Join Communities</span>
              <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </div>

          {/* 3. Collab */}
          <div className="rounded-2xl border border-[#8B5CF6]/30 bg-[#FFFFFF] p-6 flex flex-col justify-between shadow-sm hover:border-[#8B5CF6] transition-all">
            <div>
              <div className="flex items-center justify-between mb-4">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#F5F3FF] text-[#8B5CF6] shadow-xs">
                  <Briefcase className="h-5 w-5 text-[#8B5CF6]" />
                </div>
                <span className="rounded-md bg-[#F5F3FF] border border-[#8B5CF6]/30 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-[#8B5CF6]">
                  3 Isolated Tracks
                </span>
              </div>
              <h3 className="text-base font-bold text-[#1A1A1A] mb-1.5">3. Collab Tracks</h3>
              <p className="text-xs leading-relaxed text-[#55524A] mb-3">
                Raise and discover dedicated collaboration tickets isolated across Students, Homemakers, and Entrepreneurs.
              </p>
              <div className="flex flex-wrap gap-1.5 mb-4">
                <button
                  onClick={() => onNavigate('student', 'student')}
                  className="inline-flex items-center gap-1 rounded-md bg-[#FAF8F3] px-2 py-1 text-[11px] font-semibold text-[#55524A] hover:bg-[#E8491D] hover:text-white transition"
                >
                  <GraduationCap className="h-3 w-3" />
                  <span>Students</span>
                </button>
                <button
                  onClick={() => onNavigate('homemaker', 'homemaker')}
                  className="inline-flex items-center gap-1 rounded-md bg-[#FAF8F3] px-2 py-1 text-[11px] font-semibold text-[#55524A] hover:bg-[#10B981] hover:text-white transition"
                >
                  <HomeIcon className="h-3 w-3" />
                  <span>Homemakers</span>
                </button>
                <button
                  onClick={() => onNavigate('entrepreneur', 'entrepreneur')}
                  className="inline-flex items-center gap-1 rounded-md bg-[#FAF8F3] px-2 py-1 text-[11px] font-semibold text-[#55524A] hover:bg-[#8B5CF6] hover:text-white transition"
                >
                  <Briefcase className="h-3 w-3" />
                  <span>Entrepreneurs</span>
                </button>
              </div>
            </div>
            <button
              onClick={() => onNavigate('student', 'student')}
              className="flex items-center justify-between rounded-lg border border-[#8B5CF6]/30 bg-[#F5F3FF] px-3 py-2 text-xs font-semibold text-[#8B5CF6] transition hover:bg-[#8B5CF6] hover:text-white"
            >
              <span>Explore Collab Tracks</span>
              <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </div>

          {/* 4. Chats */}
          <div className="rounded-2xl border border-[#E5E2DA] bg-[#FFFFFF] p-6 flex flex-col justify-between shadow-sm hover:border-[#D4D0C5] transition-all">
            <div>
              <div className="flex items-center justify-between mb-4">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#F2EFE6] text-[#55524A] shadow-xs">
                  <MessageSquare className="h-5 w-5 text-[#E8491D]" />
                </div>
                <span className="rounded-md bg-[#F2EFE6] border border-[#E5E2DA] px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-[#55524A]">
                  Real-Time
                </span>
              </div>
              <h3 className="text-base font-bold text-[#1A1A1A] mb-1.5">4. Chats</h3>
              <p className="text-xs leading-relaxed text-[#55524A] mb-4">
                Direct 1-on-1 messaging and project discussion threads with instant synchronization, image uploads, and presence indicators.
              </p>
            </div>
            <button
              onClick={() => onNavigate('chats')}
              className="flex items-center justify-between rounded-lg border border-[#E5E2DA] bg-[#FAF8F3] px-3 py-2 text-xs font-semibold text-[#1A1A1A] transition hover:bg-[#F2EFE6]"
            >
              <span>Open Chats</span>
              <ArrowRight className="h-3.5 w-3.5 text-[#8A8578]" />
            </button>
          </div>

          {/* 5. Build Spaces */}
          <div className="rounded-2xl border border-[#E5E2DA] bg-[#FFFFFF] p-6 flex flex-col justify-between shadow-sm hover:border-[#D4D0C5] transition-all">
            <div>
              <div className="flex items-center justify-between mb-4">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#F2EFE6] text-[#55524A] shadow-xs">
                  <Hammer className="h-5 w-5 text-[#E8491D]" />
                </div>
                <span className="rounded-md bg-[#F2EFE6] border border-[#E5E2DA] px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-[#55524A]">
                  Execution
                </span>
              </div>
              <h3 className="text-base font-bold text-[#1A1A1A] mb-1.5">5. Build Spaces</h3>
              <p className="text-xs leading-relaxed text-[#55524A] mb-4">
                Dedicated private execution workspaces for your raised tickets. Kanbans, milestones, shared files, and deliverable tracking.
              </p>
            </div>
            <button
              onClick={() => onNavigate('build_spaces')}
              className="flex items-center justify-between rounded-lg border border-[#E5E2DA] bg-[#FAF8F3] px-3 py-2 text-xs font-semibold text-[#1A1A1A] transition hover:bg-[#F2EFE6]"
            >
              <span>Enter Build Spaces</span>
              <ArrowRight className="h-3.5 w-3.5 text-[#8A8578]" />
            </button>
          </div>
        </div>
      </section>

      {/* 3. Official Challenges Featurette */}
      <section className="rounded-3xl border border-[#E5E2DA] bg-[#FFFFFF] p-8 sm:p-12 shadow-md">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 pb-8 border-b border-[#E5E2DA]">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#E8491D] text-white text-[10px] font-black uppercase tracking-wider">
              <Trophy className="h-3 w-3" />
              <span>Official Programs</span>
            </div>
            <h2 className="text-2xl font-black text-[#1A1A1A] tracking-tight">
              Flagship Challenges &amp; Verification System
            </h2>
            <p className="text-xs sm:text-sm text-[#55524A] max-w-xl">
              KOBUILD challenges combine strict daily discipline, photo/link proof submissions, AI validation assistance, and live ranking tables.
            </p>
          </div>
          <button
            onClick={() => onNavigate('communities')}
            className="self-start md:self-auto px-5 py-2.5 rounded-xl bg-[#1A1A1A] text-white text-xs font-bold hover:bg-[#333] transition-colors"
          >
            View Active Leaderboards
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-8">
          <div className="p-5 rounded-2xl bg-[#FAF8F3] border border-[#E5E2DA] space-y-2.5">
            <div className="h-8 w-8 rounded-lg bg-[#FDE4D8] border border-[#E8491D]/30 flex items-center justify-center text-[#E8491D] font-bold text-xs">
              01
            </div>
            <h3 className="text-sm font-bold text-[#1A1A1A]">Daily Proof Submissions</h3>
            <p className="text-xs text-[#55524A] leading-relaxed">
              Post verified daily evidence: nutrition logs, GitHub commits, study milestones, or fitness track records.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-[#FAF8F3] border border-[#E5E2DA] space-y-2.5">
            <div className="h-8 w-8 rounded-lg bg-[#FDE4D8] border border-[#E8491D]/30 flex items-center justify-center text-[#E8491D] font-bold text-xs">
              02
            </div>
            <h3 className="text-sm font-bold text-[#1A1A1A]">Live Streaks &amp; Points</h3>
            <p className="text-xs text-[#55524A] leading-relaxed">
              Maintain unbroken streaks, earn multiplier bonus points, and unlock verified tier badges in your builder profile.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-[#FAF8F3] border border-[#E5E2DA] space-y-2.5">
            <div className="h-8 w-8 rounded-lg bg-[#FDE4D8] border border-[#E8491D]/30 flex items-center justify-center text-[#E8491D] font-bold text-xs">
              03
            </div>
            <h3 className="text-sm font-bold text-[#1A1A1A]">Live Squad Rooms</h3>
            <p className="text-xs text-[#55524A] leading-relaxed">
              Host and join live video or audio check-ins, sprint sessions, and group standups directly inside any community.
            </p>
          </div>
        </div>
      </section>

      {/* 4. Bottom Call To Action */}
      <section className="rounded-3xl border border-[#E8491D]/20 bg-gradient-to-r from-[#FDE4D8] via-[#FAF8F3] to-[#F2EFE6] p-8 sm:p-12 text-[#1A1A1A] shadow-lg flex flex-col sm:flex-row sm:items-center justify-between gap-6">
        <div className="space-y-2 max-w-xl">
          <h3 className="text-xl sm:text-2xl font-black tracking-tight text-[#1A1A1A]">
            Ready to build, compete, and deliver?
          </h3>
          <p className="text-xs sm:text-sm text-[#55524A]">
            Join official challenges, find your squad, or launch your own open community on KOBUILD.
          </p>
        </div>
        <button
          id="home-cta-get-started"
          onClick={handleGetStarted}
          className="shrink-0 flex items-center justify-center gap-2 rounded-xl bg-[#E8491D] hover:bg-[#D03E15] px-6 py-3.5 text-xs sm:text-sm font-semibold text-white shadow-lg transition duration-200 hover:-translate-y-0.5 active:translate-y-0 active:scale-[0.99]"
        >
          <Rocket className="h-4 w-4 text-white" />
          <span>Get Started Now</span>
        </button>
      </section>
    </div>
  );
};
