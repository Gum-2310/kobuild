import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { UserStats, UserContribution, UserSection, AppView } from '../types';
import { getUserStatistics, getUserContributions } from '../services/userService';
import {
  User as UserIcon,
  Mail,
  MapPin,
  Calendar,
  Sparkles,
  Edit3,
  Lightbulb,
  Briefcase,
  Users,
  MessageSquare,
  PlusCircle,
  Clock,
  Layers,
  GraduationCap,
  Home,
  CheckCircle2,
  AlertCircle,
  Loader2,
  FolderPlus,
  ArrowUpRight,
} from 'lucide-react';

interface ProfilePageProps {
  onOpenEditProfile: () => void;
  onNavigate: (view: AppView, section?: UserSection) => void;
}

const SECTION_META: Record<
  string,
  { label: string; icon: React.FC<{ className?: string }>; badge: string; color: string }
> = {
  student: {
    label: 'Student Track',
    icon: GraduationCap,
    badge: 'bg-[#FDE4D8] text-[#E8491D] border-[#E8491D]/40',
    color: 'text-[#E8491D]',
  },
  homemaker: {
    label: 'Homemaker Track',
    icon: Home,
    badge: 'bg-[#F2EFE6] text-[#55524A] border-[#D4D0C5]',
    color: 'text-[#55524A]',
  },
  entrepreneur: {
    label: 'Entrepreneur Track',
    icon: Briefcase,
    badge: 'bg-[#F2EFE6] text-[#55524A] border-[#D4D0C5]',
    color: 'text-[#55524A]',
  },
  community: {
    label: 'Community Track',
    icon: Users,
    badge: 'bg-[#FDE4D8] text-[#E8491D] border-[#E8491D]/40',
    color: 'text-[#E8491D]',
  },
};

export const ProfilePage: React.FC<ProfilePageProps> = ({ onOpenEditProfile, onNavigate }) => {
  const { user, userProfile } = useAuth();

  const [stats, setStats] = useState<UserStats>({
    ideasCreated: 0,
    projectsCreated: 0,
    collaborations: 0,
    communityPosts: 0,
    peopleConnected: 0,
  });
  const [contributions, setContributions] = useState<UserContribution[]>([]);
  const [loadingData, setLoadingData] = useState(true);

  useEffect(() => {
    let isMounted = true;

    async function loadProfileData() {
      if (!user) return;
      setLoadingData(true);
      try {
        const [statsData, contributionsData] = await Promise.all([
          getUserStatistics(user.uid),
          getUserContributions(user.uid),
        ]);

        if (isMounted) {
          setStats(statsData);
          setContributions(contributionsData);
        }
      } catch (err) {
        console.error('Failed to load profile data:', err);
      } finally {
        if (isMounted) {
          setLoadingData(false);
        }
      }
    }

    loadProfileData();

    return () => {
      isMounted = false;
    };
  }, [user]);

  if (!user || !userProfile) {
    return (
      <div className="mx-auto max-w-4xl px-4 py-12 text-center">
        <div className="rounded-2xl border border-[#E5E2DA] bg-[#FFFFFF] p-8 shadow-xs">
          <UserIcon className="mx-auto h-10 w-10 text-[#8A8578] mb-3" />
          <h2 className="text-base font-bold text-[#1A1A1A]">Profile Not Found</h2>
          <p className="mt-1 text-xs text-[#55524A]">
            Please sign in and complete your onboarding to view your profile.
          </p>
        </div>
      </div>
    );
  }

  const effectiveTrack =
    userProfile.preferredTrack !== undefined
      ? userProfile.preferredTrack === 'none'
        ? null
        : userProfile.preferredTrack
      : userProfile.section;

  const sectionMeta = effectiveTrack && SECTION_META[effectiveTrack] ? SECTION_META[effectiveTrack] : null;
  const SectionIcon = sectionMeta ? sectionMeta.icon : Sparkles;

  const formattedDate = userProfile.createdAt
    ? new Date(userProfile.createdAt).toLocaleDateString('en-US', {
        month: 'long',
        year: 'numeric',
      })
    : 'Recently';

  return (
    <div className="mx-auto max-w-5xl space-y-8 pb-20">
      {/* 1. Profile Header Card */}
      <div className="rounded-3xl border border-[#E5E2DA] bg-[#FFFFFF] p-6 sm:p-8 lg:p-10 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-start justify-between gap-6">
          {/* Avatar & Main Info */}
          <div className="flex flex-col sm:flex-row items-start gap-5">
            {user.photoURL ? (
              <img
                src={user.photoURL}
                alt={userProfile.name}
                className="h-20 w-20 sm:h-24 sm:w-24 rounded-2xl object-cover border border-[#E5E2DA] shadow-xs shrink-0"
                referrerPolicy="no-referrer"
              />
            ) : (
              <div className="flex h-20 w-20 sm:h-24 sm:w-24 items-center justify-center rounded-2xl bg-[#E8491D] text-2xl font-bold text-white shadow-xs shrink-0">
                {userProfile.name.charAt(0).toUpperCase()}
              </div>
            )}

            <div className="space-y-2">
              <div className="flex flex-wrap items-center gap-2.5">
                <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-[#1A1A1A]">
                  {userProfile.name}
                </h1>
                {sectionMeta ? (
                  <span
                    className={`inline-flex items-center gap-1.5 rounded-md px-2.5 py-1 text-xs font-bold uppercase tracking-wider border ${sectionMeta.badge}`}
                  >
                    <SectionIcon className="h-3.5 w-3.5" />
                    {sectionMeta.label}
                  </span>
                ) : (
                  <span
                    className="inline-flex items-center gap-1.5 rounded-md px-2.5 py-1 text-xs font-bold uppercase tracking-wider border bg-[#FDE4D8] text-[#E8491D] border-[#E8491D]/40"
                  >
                    <Sparkles className="h-3.5 w-3.5 text-[#E8491D]" />
                    Open Collaborator
                  </span>
                )}
              </div>

              <div className="flex flex-wrap items-center gap-y-1 gap-x-4 text-xs text-[#8A8578] font-medium">
                <div className="flex items-center gap-1.5">
                  <Mail className="h-3.5 w-3.5 text-[#8A8578]" />
                  <span>{userProfile.email}</span>
                </div>
                {userProfile.location && (
                  <div className="flex items-center gap-1.5">
                    <MapPin className="h-3.5 w-3.5 text-[#8A8578]" />
                    <span>{userProfile.location}</span>
                  </div>
                )}
                <div className="flex items-center gap-1.5">
                  <Calendar className="h-3.5 w-3.5 text-[#8A8578]" />
                  <span>Joined {formattedDate}</span>
                </div>
              </div>

              {/* Bio */}
              <p className="pt-1 text-xs sm:text-sm text-[#55524A] leading-relaxed max-w-2xl">
                {userProfile.bio || (
                  <span className="italic text-[#8A8578]">
                    No bio provided yet. Click &ldquo;Edit Profile&rdquo; to describe your background and collaboration goals.
                  </span>
                )}
              </p>
            </div>
          </div>

          {/* Edit Action */}
          <div className="shrink-0">
            <button
              id="btn-edit-profile-page"
              onClick={onOpenEditProfile}
              className="flex items-center gap-2 rounded-xl border border-[#E5E2DA] bg-[#FAF8F3] px-4 py-2 text-xs font-semibold text-[#1A1A1A] shadow-xs transition hover:bg-[#F5F1E8]"
            >
              <Edit3 className="h-3.5 w-3.5" />
              <span>Edit Profile</span>
            </button>
          </div>
        </div>

        {/* Skills & Interests Tags */}
        <div className="mt-6 pt-6 border-t border-[#E5E2DA] grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <span className="text-[11px] font-bold uppercase tracking-wider text-[#8A8578] block mb-2">
              Skills &amp; Capabilities
            </span>
            {userProfile.skills && userProfile.skills.length > 0 ? (
              <div className="flex flex-wrap gap-1.5">
                {userProfile.skills.map((skill, i) => (
                  <span
                    key={i}
                    className="rounded-md bg-[#FAF8F3] px-2.5 py-1 text-xs font-medium text-[#55524A] border border-[#E5E2DA]"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            ) : (
              <p className="text-xs text-[#8A8578] italic">No skills listed yet.</p>
            )}
          </div>

          <div>
            <span className="text-[11px] font-bold uppercase tracking-wider text-[#8A8578] block mb-2">
              Interests &amp; Focus Areas
            </span>
            {userProfile.interests && userProfile.interests.length > 0 ? (
              <div className="flex flex-wrap gap-1.5">
                {userProfile.interests.map((interest, i) => (
                  <span
                    key={i}
                    className="rounded-md bg-[#FAF8F3] px-2.5 py-1 text-xs font-medium text-[#55524A] border border-[#E5E2DA]"
                  >
                    {interest}
                  </span>
                ))}
              </div>
            ) : (
              <p className="text-xs text-[#8A8578] italic">No interests listed yet.</p>
            )}
          </div>
        </div>
      </div>

      {/* 2. Real Statistics Section (Firestore Calculated) */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-xs font-bold uppercase tracking-widest text-[#8A8578]">
            Real Contribution Statistics
          </h2>
          <span className="text-[11px] font-mono text-[#8A8578]">Calculated from Firestore</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
          {/* Ideas Created */}
          <div className="rounded-2xl border border-[#E5E2DA] bg-[#FFFFFF] p-4 text-center shadow-xs dark-interactive-card">
            <div className="flex h-7 w-7 mx-auto items-center justify-center rounded-lg bg-[#FDE4D8] border border-[#E8491D]/30 text-[#E8491D] mb-2">
              <Lightbulb className="h-3.5 w-3.5" />
            </div>
            <div className="text-xl font-bold text-[#1A1A1A] font-mono">{stats.ideasCreated}</div>
            <div className="text-[11px] text-[#8A8578] font-medium">Ideas Created</div>
          </div>

          {/* Projects Created */}
          <div className="rounded-2xl border border-[#E5E2DA] bg-[#FFFFFF] p-4 text-center shadow-xs dark-interactive-card">
            <div className="flex h-7 w-7 mx-auto items-center justify-center rounded-lg bg-[#FDE4D8] border border-[#E8491D]/30 text-[#E8491D] mb-2">
              <FolderPlus className="h-3.5 w-3.5" />
            </div>
            <div className="text-xl font-bold text-[#1A1A1A] font-mono">{stats.projectsCreated}</div>
            <div className="text-[11px] text-[#8A8578] font-medium">Projects Created</div>
          </div>

          {/* Collaborations */}
          <div className="rounded-2xl border border-[#E5E2DA] bg-[#FFFFFF] p-4 text-center shadow-xs dark-interactive-card">
            <div className="flex h-7 w-7 mx-auto items-center justify-center rounded-lg bg-[#FDE4D8] border border-[#E8491D]/30 text-[#E8491D] mb-2">
              <Briefcase className="h-3.5 w-3.5" />
            </div>
            <div className="text-xl font-bold text-[#1A1A1A] font-mono">{stats.collaborations}</div>
            <div className="text-[11px] text-[#8A8578] font-medium">Collaborations</div>
          </div>

          {/* Community Posts */}
          <div className="rounded-2xl border border-[#E5E2DA] bg-[#FFFFFF] p-4 text-center shadow-xs dark-interactive-card">
            <div className="flex h-7 w-7 mx-auto items-center justify-center rounded-lg bg-[#FDE4D8] border border-[#E8491D]/30 text-[#E8491D] mb-2">
              <MessageSquare className="h-3.5 w-3.5" />
            </div>
            <div className="text-xl font-bold text-[#1A1A1A] font-mono">{stats.communityPosts}</div>
            <div className="text-[11px] text-[#8A8578] font-medium">Community Posts</div>
          </div>

          {/* People Connected */}
          <div className="col-span-2 sm:col-span-1 rounded-2xl border border-[#E5E2DA] bg-[#FFFFFF] p-4 text-center shadow-xs dark-interactive-card">
            <div className="flex h-7 w-7 mx-auto items-center justify-center rounded-lg bg-[#FDE4D8] border border-[#E8491D]/30 text-[#E8491D] mb-2">
              <Users className="h-3.5 w-3.5" />
            </div>
            <div className="text-xl font-bold text-[#1A1A1A] font-mono">{stats.peopleConnected}</div>
            <div className="text-[11px] text-[#8A8578] font-medium">People Connected</div>
          </div>
        </div>
      </div>

      {/* 3. Your Contributions List */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-xs font-bold uppercase tracking-widest text-[#8A8578]">
            Your Contributions
          </h2>
          <span className="text-xs font-mono text-[#8A8578]">
            {contributions.length} Item{contributions.length !== 1 ? 's' : ''}
          </span>
        </div>

        {loadingData ? (
          <div className="rounded-2xl border border-[#E5E2DA] bg-[#FFFFFF] p-10 text-center">
            <Loader2 className="mx-auto h-6 w-6 animate-spin text-[#E8491D]" />
            <p className="mt-2 text-xs text-[#55524A]">Loading contribution records from Firestore...</p>
          </div>
        ) : contributions.length > 0 ? (
          <div className="space-y-3">
            {contributions.map((item) => (
              <div
                key={item.id}
                className="rounded-2xl border border-[#E5E2DA] bg-[#FFFFFF] p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4 transition hover:border-[#D4D0C5] dark-interactive-card"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="rounded bg-[#FAF8F3] border border-[#E5E2DA] px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-[#55524A] font-mono">
                      {item.typeLabel}
                    </span>
                    <span className="rounded bg-emerald-50 text-emerald-700 border border-emerald-200 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider font-mono">
                      {item.status}
                    </span>
                  </div>
                  <h3 className="text-sm font-bold text-[#1A1A1A]">{item.title}</h3>
                  <div className="flex items-center gap-3 text-[11px] text-[#8A8578] font-medium">
                    <span className="flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {new Date(item.createdAt).toLocaleDateString('en-US', {
                        month: 'short',
                        day: 'numeric',
                        year: 'numeric',
                      })}
                    </span>
                    {item.engagement && <span>• {item.engagement}</span>}
                  </div>
                </div>

                <div className="shrink-0">
                  <button
                    onClick={() => onNavigate('community')}
                    className="flex items-center gap-1 rounded-lg border border-[#E5E2DA] bg-[#FAF8F3] px-3 py-1.5 text-xs font-semibold text-[#1A1A1A] hover:bg-[#F5F1E8]"
                  >
                    <span>View Activity</span>
                    <ArrowUpRight className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          /* Empty state as explicitly requested */
          <div className="rounded-3xl border border-dashed border-[#D4D0C5] bg-[#FAF8F3] p-10 sm:p-14 text-center shadow-xs">
            <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-[#FFFFFF] border border-[#E5E2DA] text-[#8A8578] mb-3 shadow-xs">
              <Lightbulb className="h-6 w-6 text-[#8A8578]" />
            </div>
            <h3 className="text-base font-bold text-[#1A1A1A]">
              You haven&apos;t created anything yet.
            </h3>
            <p className="mx-auto mt-1.5 max-w-md text-xs text-[#55524A] leading-relaxed">
              Start by posting an unusual idea in the community for discussion, or publishing a collaboration ticket in your specialized track.
            </p>
            <div className="mt-5 flex justify-center">
              <button
                id="btn-profile-create-first-idea"
                onClick={() => onNavigate('community')}
                className="flex items-center gap-2 rounded-xl bg-[#E8491D] hover:bg-[#FF5722] px-5 py-2.5 text-xs font-semibold text-white shadow-xs transition active:scale-[0.99]"
              >
                <PlusCircle className="h-4 w-4" />
                <span>Create Your First Idea</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
