import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import * as SkeletonUtils from 'three/examples/jsm/utils/SkeletonUtils.js';
import { loadAvatarGlb, AvatarDefinition } from '../../services/avatarRegistry';
import { Loader2, Box, RotateCw } from 'lucide-react';

interface AvatarCard3DPreviewProps {
  avatar: AvatarDefinition;
  isSelected: boolean;
  className?: string;
}

export const AvatarCard3DPreview: React.FC<AvatarCard3DPreviewProps> = ({
  avatar,
  isSelected,
  className = '',
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [progress, setProgress] = useState(0);
  const [hasError, setHasError] = useState(false);

  useEffect(() => {
    if (!mountRef.current) return;

    const container = mountRef.current;
    let isMounted = true;
    let animationFrameId: number;

    const width = container.clientWidth || 280;
    const height = container.clientHeight || 220;

    // Scene
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x18181b); // Sleek dark stage for high contrast with athletic models

    // Camera
    const camera = new THREE.PerspectiveCamera(38, width / height, 0.1, 50);
    camera.position.set(0, 1.25, 3.4);

    // Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.1;
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // Controls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.enableZoom = false; // Keep card layout stable
    controls.enablePan = false;
    controls.autoRotate = true;
    controls.autoRotateSpeed = 2.2;
    controls.maxPolarAngle = Math.PI / 2;
    controls.minPolarAngle = Math.PI / 3.5;
    controls.target.set(0, 0.95, 0);

    // Stage Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 1.3);
    scene.add(ambientLight);

    const keyLight = new THREE.DirectionalLight(0xfffaed, 2.0);
    keyLight.position.set(2.5, 4.0, 3.0);
    keyLight.castShadow = true;
    scene.add(keyLight);

    const fillLight = new THREE.DirectionalLight(0xa5c4f2, 1.0);
    fillLight.position.set(-2.5, 3.0, -2.0);
    scene.add(fillLight);

    // Subtle colored rim light matching avatar's accent color
    const rimColor = new THREE.Color(avatar.previewColor || '#E8491D');
    const rimLight = new THREE.PointLight(rimColor, 1.8, 6.0);
    rimLight.position.set(0, 1.8, -1.8);
    scene.add(rimLight);

    // Circular Pedestal Stage
    const pedestalGeo = new THREE.CylinderGeometry(0.85, 0.95, 0.1, 32);
    const pedestalMat = new THREE.MeshStandardMaterial({
      color: 0x27272a,
      roughness: 0.6,
      metalness: 0.2,
    });
    const pedestal = new THREE.Mesh(pedestalGeo, pedestalMat);
    pedestal.position.y = -0.05;
    pedestal.receiveShadow = true;
    scene.add(pedestal);

    // Glowing stage ring
    const ringGeo = new THREE.RingGeometry(0.82, 0.86, 48);
    const ringMat = new THREE.MeshBasicMaterial({
      color: rimColor,
      side: THREE.DoubleSide,
    });
    const ring = new THREE.Mesh(ringGeo, ringMat);
    ring.rotation.x = -Math.PI / 2;
    ring.position.y = 0.005;
    scene.add(ring);

    let avatarGroup: THREE.Group | null = null;

    // Load actual GLB asset
    loadAvatarGlb(avatar.id, (pct) => {
      if (isMounted) setProgress(pct);
    })
      .then(({ gltf }) => {
        if (!isMounted) return;

        // Clone model safely using SkeletonUtils if available
        const rawModel = gltf.scene;
        const clonedModel = SkeletonUtils.clone(rawModel);

        clonedModel.traverse((child: any) => {
          if (child.isMesh) {
            child.castShadow = true;
            child.receiveShadow = true;
            if (child.material) {
              child.material.needsUpdate = true;
            }
          }
        });

        // Compute bounds and normalize height
        const box = new THREE.Box3().setFromObject(clonedModel);
        const size = new THREE.Vector3();
        box.getSize(size);

        const naturalHeight = size.y || 1.88;
        const targetHeight = 1.88;
        const scale = targetHeight / naturalHeight;
        clonedModel.scale.set(scale, scale, scale);

        // Ground feet at Y = 0
        const scaledBox = new THREE.Box3().setFromObject(clonedModel);
        const bottomY = scaledBox.min.y;
        const centerX = (scaledBox.max.x + scaledBox.min.x) / 2;
        const centerZ = (scaledBox.max.z + scaledBox.min.z) / 2;

        clonedModel.position.set(-centerX, -bottomY, -centerZ);

        avatarGroup = new THREE.Group();
        avatarGroup.add(clonedModel);
        scene.add(avatarGroup);

        setIsLoading(false);
      })
      .catch((err) => {
        console.error(`Failed to load 3D preview for ${avatar.id}:`, err);
        if (isMounted) {
          setHasError(true);
          setIsLoading(false);
        }
      });

    // Render loop
    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      controls.update();
      renderer.render(scene, camera);
    };
    animate();

    const handleResize = () => {
      if (!container) return;
      const newW = container.clientWidth;
      const newH = container.clientHeight;
      if (newW && newH) {
        camera.aspect = newW / newH;
        camera.updateProjectionMatrix();
        renderer.setSize(newW, newH);
      }
    };

    window.addEventListener('resize', handleResize);

    return () => {
      isMounted = false;
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationFrameId);

      if (avatarGroup) {
        scene.remove(avatarGroup);
      }

      controls.dispose();
      renderer.dispose();
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [avatar.id, avatar.previewColor]);

  return (
    <div
      className={`relative w-full h-[220px] rounded-2xl overflow-hidden bg-[#18181b] border transition-all ${
        isSelected
          ? 'border-[#E8491D] shadow-inner shadow-[#E8491D]/20'
          : 'border-white/10 group-hover:border-white/20'
      } ${className}`}
    >
      {/* 3D Canvas Mounting Node */}
      <div ref={mountRef} className="w-full h-full cursor-grab active:cursor-grabbing" />

      {/* Loading Overlay */}
      {isLoading && (
        <div className="absolute inset-0 z-20 flex flex-col items-center justify-center bg-[#18181b]/90 backdrop-blur-xs space-y-2.5 text-white">
          <Loader2 className="h-6 w-6 text-[#E8491D] animate-spin" />
          <div className="text-center">
            <span className="text-[11px] font-bold tracking-wider uppercase block">
              Loading 3D GLB Model
            </span>
            <span className="text-[10px] text-white/50">{progress}%</span>
          </div>
        </div>
      )}

      {/* Error Fallback */}
      {hasError && (
        <div className="absolute inset-0 z-20 flex flex-col items-center justify-center bg-[#18181b] p-4 text-center space-y-2 text-white">
          <Box className="h-8 w-8 text-amber-500" />
          <span className="text-xs font-bold">3D Asset Preview</span>
          <span className="text-[10px] text-white/60">{avatar.name}</span>
        </div>
      )}

      {/* Overlay Badges */}
      <div className="absolute top-2.5 left-2.5 z-10 pointer-events-none flex items-center gap-1.5">
        <span
          className="px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider text-white backdrop-blur-md shadow-xs"
          style={{ backgroundColor: avatar.previewColor }}
        >
          {avatar.id}
        </span>
        <span className="px-2 py-0.5 rounded-full bg-black/60 text-white/80 text-[9px] font-bold backdrop-blur-md border border-white/10">
          Real GLB
        </span>
      </div>

      <div className="absolute bottom-2 right-2.5 z-10 pointer-events-none flex items-center gap-1 text-[10px] font-semibold text-white/40">
        <RotateCw className="h-3 w-3 animate-spin" style={{ animationDuration: '6s' }} />
        <span>360° Turntable</span>
      </div>
    </div>
  );
};
