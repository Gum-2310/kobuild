import React from 'react';
import {
  ArrowLeft,
  Share2,
  Flame,
  CheckCircle2,
  Shield,
  Clock,
  XCircle,
  Loader2,
  Lock,
  Sparkles,
  Calendar,
  Award,
  Users,
  Compass,
  FileCheck,
} from 'lucide-react';
import { Community } from '../../types';

interface PublicCommunityJoinViewProps {
  community: Community;
  isPending: boolean;
  isRejected: boolean;
  actionLoading: boolean;
  isAuthenticated: boolean;
  onJoinClick: () => void;
  onBack: () => void;
  onShare: () => void;
}

export const PublicCommunityJoinView: React.FC<PublicCommunityJoinViewProps> = ({
  community,
  isPending,
  isRejected,
  actionLoading,
  isAuthenticated,
  onJoinClick,
  onBack,
  onShare,
}) => {
  const isWinterArc =
    community.id === 'kobuild-winter-arc-90' ||
    community.title.toLowerCase().includes('winter arc');

  return (
    <div className="w-full max-w-6xl mx-auto space-y-8 animate-fade-in pb-16">
      {/* Top Bar: Back & Share */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl border border-[#E5E2DA] bg-white text-xs font-bold text-[#1A1A1A] hover:bg-[#FAF8F3] hover:border-[#D4D0C5] transition-all cursor-pointer shadow-2xs"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Back to Communities</span>
        </button>

        <button
          onClick={onShare}
          className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl border border-[#E5E2DA] bg-white text-xs font-bold text-[#55524A] hover:text-[#1A1A1A] hover:bg-[#FAF8F3] transition-all cursor-pointer shadow-2xs"
        >
          <Share2 className="h-4 w-4" />
          <span>Share Community</span>
        </button>
      </div>

      {/* Hero Header Card */}
      <div className="relative rounded-3xl overflow-hidden border border-[#E5E2DA] bg-[#141414] text-white shadow-sm">
        {community.coverImage && (
          <div className="absolute inset-0 z-0">
            <img
              src={community.coverImage}
              alt={community.title}
              className="w-full h-full object-cover opacity-35 filter brightness-90"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#141414] via-[#141414]/75 to-transparent" />
          </div>
        )}

        <div className="relative z-10 p-6 sm:p-10 space-y-6">
          <div className="flex flex-wrap items-center gap-2">
            <span
              className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider ${
                community.type === 'kobuild_official'
                  ? 'bg-[#E8491D] text-white'
                  : 'bg-white/20 backdrop-blur-md text-white'
              }`}
            >
              {community.type === 'kobuild_official' ? 'Official Challenge' : 'Open Community'}
            </span>

            {community.category && (
              <span className="px-3 py-1 rounded-full bg-white/10 backdrop-blur-md text-white/90 text-[10px] font-bold uppercase tracking-wide border border-white/10">
                {community.category}
              </span>
            )}

            {isWinterArc && (
              <span className="px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 text-[10px] font-bold tracking-wide border border-amber-400/30 flex items-center gap-1">
                <Flame className="h-3 w-3 fill-current" />
                90-Day Discipline Protocol
              </span>
            )}
          </div>

          <div className="space-y-3 max-w-3xl">
            <h1 className="text-3xl sm:text-5xl font-black tracking-tight text-white">
              {community.title}
            </h1>
            <p className="text-sm sm:text-base text-white/80 leading-relaxed font-normal">
              {community.description}
            </p>
          </div>

          {/* Creator Byline (No participant counts) */}
          <div className="flex items-center gap-3 pt-2 text-xs text-white/70">
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-white/20 border border-white/20 overflow-hidden shrink-0">
              {community.creatorPhotoURL ? (
                <img
                  src={community.creatorPhotoURL}
                  alt={community.creatorName}
                  className="h-full w-full object-cover"
                />
              ) : (
                <Shield className="h-4 w-4 text-[#E8491D]" />
              )}
            </div>
            <div>
              <span className="text-white/50 block text-[10px] uppercase font-bold tracking-wider">
                Hosted by
              </span>
              <span className="font-bold text-white">{community.creatorName}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Public Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
        {/* Left 2 Columns: Purpose, Rules, Requirements */}
        <div className="lg:col-span-2 space-y-6">
          {/* Section 1: Community / Challenge Purpose */}
          <div className="rounded-3xl border border-[#E5E2DA] bg-white p-6 sm:p-8 space-y-4 shadow-xs">
            <div className="flex items-center gap-2.5 text-xs font-black uppercase tracking-wider text-[#E8491D]">
              <Compass className="h-4 w-4" />
              <span>Community Purpose & Mission</span>
            </div>

            <h2 className="text-xl sm:text-2xl font-black text-[#1A1A1A] tracking-tight">
              {isWinterArc ? 'The 90-Day Transformation Protocol' : 'About This Community'}
            </h2>

            <div className="text-xs sm:text-sm text-[#55524A] leading-relaxed space-y-3">
              {isWinterArc ? (
                <>
                  <p>
                    The <strong>90 Day Winter Arc</strong> is KOBUILD’s premier discipline, focus,
                    and physical conditioning challenge. Built around relentless daily execution,
                    participants commit to structured habits, clean nutrition, and daily physical
                    training through the coldest, darkest stretch of the year.
                  </p>
                  <p>
                    Each day, participants log verified photo checkpoints: Breakfast, Lunch, Dinner,
                    and Daily Progress workout verification. Daily consistency builds an unbreakable
                    streak, earning points that dictate your placement in the real-time coliseum and
                    amphitheater ranking.
                  </p>
                </>
              ) : (
                <p>
                  This space brings together dedicated builders, innovators, and creators to share
                  progress, review architecture, participate in challenges, and build real-world
                  projects in public.
                </p>
              )}
            </div>

            {/* Purpose Highlights */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-3">
              <div className="p-4 rounded-2xl bg-[#FAF8F3] border border-[#E5E2DA] space-y-1">
                <span className="text-xs font-black text-[#1A1A1A] block">Daily Accountability</span>
                <span className="text-[11px] text-[#8A8578] leading-tight block">
                  Verify habits and meal checkpoints before midnight daily.
                </span>
              </div>
              <div className="p-4 rounded-2xl bg-[#FAF8F3] border border-[#E5E2DA] space-y-1">
                <span className="text-xs font-black text-[#1A1A1A] block">Virtual 3D Arena</span>
                <span className="text-[11px] text-[#8A8578] leading-tight block">
                  Represent your journey on the interactive 3D coliseum podium.
                </span>
              </div>
              <div className="p-4 rounded-2xl bg-[#FAF8F3] border border-[#E5E2DA] space-y-1">
                <span className="text-xs font-black text-[#1A1A1A] block">Elite Rewards</span>
                <span className="text-[11px] text-[#8A8578] leading-tight block">
                  Earn championship apparel, verified badges, and builder grants.
                </span>
              </div>
            </div>
          </div>

          {/* Section 2: Community Rules & Code of Conduct */}
          <div className="rounded-3xl border border-[#E5E2DA] bg-white p-6 sm:p-8 space-y-4 shadow-xs">
            <div className="flex items-center gap-2.5 text-xs font-black uppercase tracking-wider text-[#1A1A1A]">
              <Shield className="h-4 w-4 text-[#E8491D]" />
              <span>Community Rules & Standards</span>
            </div>

            <h2 className="text-xl font-black text-[#1A1A1A] tracking-tight">Code of Conduct</h2>

            <div className="space-y-3 pt-1">
              {(community.rules && community.rules.length > 0
                ? community.rules
                : [
                    'Maintain authentic submissions and daily progress logs.',
                    'Respect all community members and provide constructive feedback.',
                    'Keep discussions focused on building, fitness, and discipline.',
                    'Zero tolerance for spam, harassment, or fraudulent submissions.',
                  ]
              ).map((rule, idx) => (
                <div key={idx} className="flex items-start gap-3 text-xs sm:text-sm text-[#55524A]">
                  <div className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-[#FDE4D8] text-[#E8491D] mt-0.5">
                    <CheckCircle2 className="h-3.5 w-3.5" />
                  </div>
                  <span className="leading-normal">{rule}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Section 3: Important Participation Requirements */}
          <div className="rounded-3xl border border-[#E5E2DA] bg-white p-6 sm:p-8 space-y-4 shadow-xs">
            <div className="flex items-center gap-2.5 text-xs font-black uppercase tracking-wider text-[#1A1A1A]">
              <FileCheck className="h-4 w-4 text-[#E8491D]" />
              <span>Important Participation Requirements</span>
            </div>

            <h2 className="text-xl font-black text-[#1A1A1A] tracking-tight">
              What Is Required of Participants
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
              <div className="p-4 rounded-2xl border border-[#E5E2DA] bg-[#FAF8F3] space-y-1.5">
                <span className="text-xs font-black text-[#1A1A1A] flex items-center gap-1.5">
                  <Clock className="h-4 w-4 text-[#E8491D]" />
                  Timely Daily Submissions
                </span>
                <p className="text-xs text-[#55524A] leading-relaxed">
                  All daily verification checkpoints must be submitted before 11:59 PM in your
                  local timezone to maintain your active streak.
                </p>
              </div>

              <div className="p-4 rounded-2xl border border-[#E5E2DA] bg-[#FAF8F3] space-y-1.5">
                <span className="text-xs font-black text-[#1A1A1A] flex items-center gap-1.5">
                  <Shield className="h-4 w-4 text-[#E8491D]" />
                  Authentic Verification
                </span>
                <p className="text-xs text-[#55524A] leading-relaxed">
                  Photos must be authentic, original, and taken on the day of submission. Stock or
                  duplicate images are disqualified.
                </p>
              </div>

              <div className="p-4 rounded-2xl border border-[#E5E2DA] bg-[#FAF8F3] space-y-1.5">
                <span className="text-xs font-black text-[#1A1A1A] flex items-center gap-1.5">
                  <Sparkles className="h-4 w-4 text-[#E8491D]" />
                  Arena Avatar Selection
                </span>
                <p className="text-xs text-[#55524A] leading-relaxed">
                  Upon joining, choose your official 3D arena avatar to represent your progress on
                  the coliseum podium.
                </p>
              </div>

              <div className="p-4 rounded-2xl border border-[#E5E2DA] bg-[#FAF8F3] space-y-1.5">
                <span className="text-xs font-black text-[#1A1A1A] flex items-center gap-1.5">
                  <Award className="h-4 w-4 text-[#E8491D]" />
                  Commitment to Completion
                </span>
                <p className="text-xs text-[#55524A] leading-relaxed">
                  This challenge demands mental resilience. Missing a day breaks your streak, but
                  persistent competitors remain eligible for awards.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Prominent Join Card */}
        <div className="space-y-6 lg:sticky lg:top-6">
          <div className="rounded-3xl border-2 border-[#E8491D]/30 bg-white p-6 sm:p-8 space-y-6 shadow-md">
            <div className="space-y-2 text-center sm:text-left">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#FDE4D8] text-[#E8491D] text-[10px] font-black uppercase tracking-wider">
                <Flame className="h-3.5 w-3.5 fill-current" />
                <span>Private Community Gate</span>
              </div>
              <h3 className="text-2xl font-black text-[#1A1A1A] tracking-tight">
                Ready to Join the Arc?
              </h3>
              <p className="text-xs text-[#55524A] leading-relaxed">
                Join this community to access the 3D Virtual Arena, submit daily checkpoints, track
                streaks, and compete on the live coliseum leaderboard.
              </p>
            </div>

            {/* Feature Perks List */}
            <div className="space-y-2.5 pt-2 border-t border-[#E5E2DA]">
              <div className="flex items-center gap-2.5 text-xs text-[#1A1A1A] font-semibold">
                <div className="flex h-5 w-5 items-center justify-center rounded-full bg-emerald-50 text-emerald-600 shrink-0">
                  <CheckCircle2 className="h-3.5 w-3.5" />
                </div>
                <span>Full Access to 3D Virtual Arena</span>
              </div>
              <div className="flex items-center gap-2.5 text-xs text-[#1A1A1A] font-semibold">
                <div className="flex h-5 w-5 items-center justify-center rounded-full bg-emerald-50 text-emerald-600 shrink-0">
                  <CheckCircle2 className="h-3.5 w-3.5" />
                </div>
                <span>Daily Checkpoint Submissions</span>
              </div>
              <div className="flex items-center gap-2.5 text-xs text-[#1A1A1A] font-semibold">
                <div className="flex h-5 w-5 items-center justify-center rounded-full bg-emerald-50 text-emerald-600 shrink-0">
                  <CheckCircle2 className="h-3.5 w-3.5" />
                </div>
                <span>Live Coliseum Leaderboard</span>
              </div>
              <div className="flex items-center gap-2.5 text-xs text-[#1A1A1A] font-semibold">
                <div className="flex h-5 w-5 items-center justify-center rounded-full bg-emerald-50 text-emerald-600 shrink-0">
                  <CheckCircle2 className="h-3.5 w-3.5" />
                </div>
                <span>Championship Rewards & Badges</span>
              </div>
            </div>

            {/* Status alerts if pending / rejected */}
            {isPending ? (
              <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 space-y-2 text-center">
                <div className="flex items-center justify-center gap-2 text-amber-700 text-xs font-bold">
                  <Clock className="h-4 w-4" />
                  <span>Join Request Submitted</span>
                </div>
                <p className="text-[11px] text-amber-800 leading-relaxed">
                  Your request to join has been delivered to the community creator for approval.
                  You will gain full access once approved.
                </p>
              </div>
            ) : isRejected ? (
              <div className="p-4 rounded-2xl bg-red-50 border border-red-200 space-y-2 text-center">
                <div className="flex items-center justify-center gap-2 text-red-700 text-xs font-bold">
                  <XCircle className="h-4 w-4" />
                  <span>Request Declined</span>
                </div>
                <p className="text-[11px] text-red-800 leading-relaxed">
                  The creator did not approve your previous join request. You may contact the
                  creator directly.
                </p>
              </div>
            ) : (
              /* Main Join Community CTA */
              <div className="space-y-3 pt-2">
                <button
                  id="btn-join-community-main"
                  onClick={onJoinClick}
                  disabled={actionLoading}
                  className="w-full inline-flex items-center justify-center gap-2 py-4 px-6 rounded-2xl bg-[#E8491D] hover:bg-[#D03E15] text-white text-sm font-black uppercase tracking-wider shadow-md hover:shadow-lg transition-all disabled:opacity-50 cursor-pointer"
                >
                  {actionLoading ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" />
                      <span>Confirming Membership...</span>
                    </>
                  ) : community.requireApproval ? (
                    <>
                      <Lock className="h-4 w-4" />
                      <span>Request to Join Community</span>
                    </>
                  ) : (
                    <>
                      <Flame className="h-4 w-4" />
                      <span>Join Community</span>
                    </>
                  )}
                </button>

                <p className="text-[11px] text-center text-[#8A8578]">
                  {isAuthenticated
                    ? 'Instant membership confirmation • Free access'
                    : 'Sign in required to record your streak and avatar'}
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
