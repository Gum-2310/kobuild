import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Community, CommunityType, CommunityCategory, AppView, UserSection } from '../../types';
import {
  subscribeAllCommunities,
  seedInitialPlatformCommunities,
  joinPublicCommunity,
  requestToJoinCommunity,
} from '../../services/communityService';
import { CreateCommunityModal } from './CreateCommunityModal';
import { CommunitySpaceView } from './CommunitySpaceView';
import {
  Search,
  Plus,
  Flame,
  Users,
  Award,
  Sparkles,
  MapPin,
  Calendar,
  Lock,
  CheckCircle2,
  Clock,
  ArrowRight,
  TrendingUp,
  Filter,
  Shield,
  Layers,
  ChevronRight,
} from 'lucide-react';

interface CommunitiesHubProps {
  initialCommunityId?: string | null;
  onOpenAuth: (section?: UserSection | null) => void;
  onNavigate: (view: AppView, section?: UserSection) => void;
}

export const CommunitiesHub: React.FC<CommunitiesHubProps> = ({
  initialCommunityId,
  onOpenAuth,
  onNavigate,
}) => {
  const { user, userProfile, isAdmin } = useAuth();

  const [communities, setCommunities] = useState<Community[]>([]);
  const [selectedCommunity, setSelectedCommunity] = useState<Community | null>(null);

  // Main Category Tab: 'all' | 'kobuild_official' | 'open' | 'my_communities'
  const [categoryType, setCategoryType] = useState<'all' | 'kobuild_official' | 'open' | 'my_communities'>('all');

  // Topic filter
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortOption, setSortOption] = useState<'trending' | 'members' | 'newest'>('trending');

  // Modal State
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [createModalType, setCreateModalType] = useState<CommunityType>('open');

  // Subscribe to all communities and seed initial data if admin
  useEffect(() => {
    if (isAdmin) {
      seedInitialPlatformCommunities(true);
    }
    const unsubscribe = subscribeAllCommunities((data) => {
      setCommunities(data);
      if (initialCommunityId) {
        const found = data.find((c) => c.id === initialCommunityId);
        if (found) setSelectedCommunity(found);
      }
    });

    return () => unsubscribe();
  }, [initialCommunityId, isAdmin]);

  // Keep selectedCommunity synced with updated data
  useEffect(() => {
    if (selectedCommunity) {
      const updated = communities.find((c) => c.id === selectedCommunity.id);
      if (updated) setSelectedCommunity(updated);
    }
  }, [communities, selectedCommunity]);

  // Filter & Search Logic
  const filteredCommunities = communities.filter((c) => {
    // Top type filter
    if (categoryType === 'kobuild_official' && c.type !== 'kobuild_official') return false;
    if (categoryType === 'open' && c.type !== 'open') return false;
    if (categoryType === 'my_communities') {
      if (!user) return false;
      const isCreator = c.creatorId === user.uid;
      // Also match if user is in members list
      return isCreator;
    }

    // Category filter
    if (selectedCategory !== 'all') {
      if (selectedCategory === 'challenge' && !c.hasChallenge && c.category !== 'challenge') return false;
      if (selectedCategory === 'coding_ai' && c.category !== 'coding' && c.category !== 'ai') return false;
      if (selectedCategory === 'fitness' && c.category !== 'fitness') return false;
      if (selectedCategory === 'local' && c.category !== 'local') return false;
    }

    // Search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchTitle = c.title.toLowerCase().includes(q);
      const matchDesc = c.description.toLowerCase().includes(q);
      const matchTags = c.tags.some((t) => t.toLowerCase().includes(q));
      const matchLocation = c.location?.toLowerCase().includes(q);
      if (!matchTitle && !matchDesc && !matchTags && !matchLocation) return false;
    }

    return true;
  });

  // Sorting
  const sortedCommunities = [...filteredCommunities].sort((a, b) => {
    if (sortOption === 'members') return (b.memberCount || 0) - (a.memberCount || 0);
    if (sortOption === 'newest') return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    // Default 'trending': prioritizes featured/active
    if (a.featured && !b.featured) return -1;
    if (!a.featured && b.featured) return 1;
    return (b.activeCount || 0) - (a.activeCount || 0);
  });

  // If a community is selected, show the rich CommunitySpaceView!
  if (selectedCommunity) {
    return (
      <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-4">
        <CommunitySpaceView
          community={selectedCommunity}
          onBack={() => setSelectedCommunity(null)}
          onOpenAuth={onOpenAuth}
          onNavigate={onNavigate}
        />
      </div>
    );
  }

  const kobuildOfficialCount = communities.filter((c) => c.type === 'kobuild_official').length;
  const openCommunitiesCount = communities.filter((c) => c.type === 'open').length;

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-8">
      {/* Header & Hero */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 border-b border-[#E5E2DA] pb-6">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#E8491D]">
            <Flame className="h-4 w-4 fill-current" />
            <span>KOBUILD Collaborative Ecosystem</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-[#1A1A1A] mt-1">
            Communities & Challenges
          </h1>
          <p className="text-xs sm:text-sm text-[#8A8578] mt-1 max-w-2xl">
            Join official KOBUILD challenges and daily discipline tracks, or discover and build in open community squads with fellow builders.
          </p>
        </div>

        {/* Action CTAs */}
        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={() => {
              if (!user) {
                onOpenAuth();
                return;
              }
              setCreateModalType('open');
              setIsCreateModalOpen(true);
            }}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl border border-[#E5E2DA] bg-white text-xs font-bold text-[#1A1A1A] hover:bg-[#F2EFE6] hover:border-[#D4D0C5] transition-all shadow-sm"
          >
            <Plus className="h-4 w-4 text-[#E8491D]" />
            <span>Create Open Community</span>
          </button>

          {/* Launch Challenge: ONLY rendered and accessible for platform owner/admin */}
          {user && isAdmin && (
            <button
              onClick={() => {
                setCreateModalType('kobuild_official');
                setIsCreateModalOpen(true);
              }}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#E8491D] hover:bg-[#D03E15] text-xs font-bold text-white shadow-sm transition-all animate-fade-in"
            >
              <Flame className="h-4 w-4" />
              <span>Launch Challenge</span>
            </button>
          )}
        </div>
      </div>

      {/* PRIMARY CATEGORY SELECTION TABS */}
      <div className="flex items-center gap-2 p-1.5 rounded-2xl bg-[#F2EFE6] border border-[#E5E2DA] overflow-x-auto no-scrollbar">
        <button
          onClick={() => setCategoryType('all')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
            categoryType === 'all'
              ? 'bg-white text-[#1A1A1A] shadow-sm'
              : 'text-[#55524A] hover:text-[#1A1A1A]'
          }`}
        >
          <Layers className="h-4 w-4 text-[#8A8578]" />
          <span>All Communities ({communities.length})</span>
        </button>

        <button
          onClick={() => setCategoryType('kobuild_official')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
            categoryType === 'kobuild_official'
              ? 'bg-[#E8491D] text-white shadow-sm'
              : 'text-[#55524A] hover:text-[#1A1A1A]'
          }`}
        >
          <Flame className="h-4 w-4 fill-current" />
          <span>KOBUILD Communities & Challenges ({kobuildOfficialCount})</span>
        </button>

        <button
          onClick={() => setCategoryType('open')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
            categoryType === 'open'
              ? 'bg-white text-[#1A1A1A] shadow-sm'
              : 'text-[#55524A] hover:text-[#1A1A1A]'
          }`}
        >
          <Users className="h-4 w-4 text-[#E8491D]" />
          <span>Open Communities ({openCommunitiesCount})</span>
        </button>

        {user && (
          <button
            onClick={() => setCategoryType('my_communities')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
              categoryType === 'my_communities'
                ? 'bg-white text-[#1A1A1A] shadow-sm'
                : 'text-[#55524A] hover:text-[#1A1A1A]'
            }`}
          >
            <Shield className="h-4 w-4 text-[#8A8578]" />
            <span>My Created Spaces</span>
          </button>
        )}
      </div>

      {/* SEARCH, TOPIC FILTERS & SORT BAR */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        {/* Search Bar */}
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-[#8A8578]" />
          <input
            type="text"
            placeholder="Search by name, tag, city, or topic..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-[#E5E2DA] bg-white text-xs text-[#1A1A1A] placeholder-[#8A8578] focus:border-[#E8491D] focus:ring-1 focus:ring-[#E8491D] outline-none shadow-sm transition-all"
          />
        </div>

        {/* Topic Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
          {[
            { id: 'all', label: 'All Topics' },
            { id: 'challenge', label: '🏆 Challenges & Arcs' },
            { id: 'coding_ai', label: '🤖 Coding & AI' },
            { id: 'fitness', label: '🔥 Fitness' },
            { id: 'local', label: '📍 Local Squads' },
          ].map((pill) => (
            <button
              key={pill.id}
              onClick={() => setSelectedCategory(pill.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                selectedCategory === pill.id
                  ? 'bg-[#1A1A1A] text-white shadow-sm'
                  : 'bg-white border border-[#E5E2DA] text-[#55524A] hover:bg-[#F2EFE6]'
              }`}
            >
              {pill.label}
            </button>
          ))}
        </div>

        {/* Sort Select */}
        <div className="flex items-center gap-2">
          <span className="text-xs text-[#8A8578]">Sort:</span>
          <select
            value={sortOption}
            onChange={(e) => setSortOption(e.target.value as any)}
            className="px-3 py-1.5 rounded-xl border border-[#E5E2DA] bg-white text-xs font-bold text-[#1A1A1A] outline-none"
          >
            <option value="trending">🔥 Trending</option>
            <option value="members">👥 Most Members</option>
            <option value="newest">✨ Newest</option>
          </select>
        </div>
      </div>

      {/* FEATURED BANNER IF VIEWING OFFICIAL CHALLENGES */}
      {categoryType === 'kobuild_official' && (
        <div className="relative rounded-3xl border border-[#E8491D]/30 bg-gradient-to-r from-[#FDE4D8] via-[#FAF8F3] to-[#F2EFE6] p-6 sm:p-8 overflow-hidden shadow-sm">
          <div className="relative z-10 max-w-2xl space-y-3">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#E8491D] text-white text-[11px] font-black uppercase tracking-wider">
              <Flame className="h-3.5 w-3.5 fill-current" />
              <span>Flagship Season 2026</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-[#1A1A1A] tracking-tight">
              90 DAY WINTER ARC & BUILD SPRINT
            </h2>
            <p className="text-xs sm:text-sm text-[#55524A] leading-relaxed">
              Verify daily nutrition, code milestones, and discipline checkpoints. Climb the live leaderboard, maintain streaks, and win exclusive KOBUILD championship rewards.
            </p>
          </div>
        </div>
      )}

      {/* COMMUNITIES GRID */}
      {sortedCommunities.length === 0 ? (
        <div className="p-16 rounded-3xl border border-[#E5E2DA] bg-white text-center space-y-4 shadow-sm">
          <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-[#F2EFE6] text-[#8A8578] mx-auto">
            <Users className="h-7 w-7" />
          </div>
          <div className="space-y-1">
            <h3 className="text-base font-bold text-[#1A1A1A]">No communities found</h3>
            <p className="text-xs text-[#8A8578] max-w-sm mx-auto">
              No communities matched your current filter. Try adjusting your search query or create a new community.
            </p>
          </div>
          <button
            onClick={() => {
              setCategoryType('all');
              setSelectedCategory('all');
              setSearchQuery('');
            }}
            className="px-4 py-2 rounded-xl bg-[#F2EFE6] text-xs font-bold text-[#1A1A1A] hover:bg-[#E5E2DA]"
          >
            Clear Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {sortedCommunities.map((comm) => (
            <div
              key={comm.id}
              onClick={() => setSelectedCommunity(comm)}
              className="group rounded-3xl border border-[#E5E2DA] bg-white overflow-hidden shadow-sm hover:shadow-md hover:border-[#D4D0C5] transition-all cursor-pointer flex flex-col justify-between"
            >
              {/* Cover Card Image */}
              <div>
                <div className="relative h-44 w-full bg-[#1A1A1A] overflow-hidden">
                  <img
                    src={comm.coverImage || 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=1200&auto=format&fit=crop&q=80'}
                    alt={comm.title}
                    className="w-full h-full object-cover opacity-85 group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/20 to-transparent" />

                  {/* Badges on Top of Cover */}
                  <div className="absolute top-3 left-3 flex flex-wrap items-center gap-1.5">
                    {comm.type === 'kobuild_official' ? (
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-[#E8491D] text-white text-[10px] font-black uppercase tracking-wider shadow">
                        <Flame className="h-3 w-3 fill-current" />
                        KOBUILD Official
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-white/95 text-[#1A1A1A] text-[10px] font-bold uppercase tracking-wider shadow">
                        <Users className="h-3 w-3 text-[#E8491D]" />
                        Open Community
                      </span>
                    )}

                    {comm.requireApproval && (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-black/60 backdrop-blur-sm text-white text-[10px] font-semibold">
                        <Lock className="h-2.5 w-2.5" />
                        Approval
                      </span>
                    )}
                  </div>

                  {/* Duration / Location on Bottom of Cover */}
                  <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between text-white text-xs">
                    <span className="font-semibold capitalize px-2 py-0.5 rounded-md bg-black/50 backdrop-blur-sm text-[10px]">
                      {comm.category}
                    </span>
                    {comm.location && (
                      <span className="inline-flex items-center gap-1 text-[10px] text-white/90">
                        <MapPin className="h-3 w-3" />
                        <span>{comm.location}</span>
                      </span>
                    )}
                  </div>
                </div>

                {/* Content Body */}
                <div className="p-5 space-y-3">
                  <h3 className="text-base font-bold text-[#1A1A1A] line-clamp-1 group-hover:text-[#E8491D] transition-colors">
                    {comm.title}
                  </h3>

                  <p className="text-xs text-[#55524A] line-clamp-2 leading-relaxed">{comm.description}</p>

                  {/* Tags */}
                  <div className="flex flex-wrap gap-1 pt-1">
                    {comm.tags.slice(0, 3).map((tag) => (
                      <span
                        key={tag}
                        className="px-2 py-0.5 rounded-md bg-[#FAF8F3] border border-[#E5E2DA] text-[10px] text-[#55524A] font-medium"
                      >
                        #{tag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Card Footer Bar */}
              <div className="p-4 px-5 bg-[#FAF8F3] border-t border-[#E5E2DA] flex items-center justify-between text-xs">
                <div className="flex items-center gap-1.5 text-[#55524A]">
                  <Users className="h-3.5 w-3.5 text-[#E8491D]" />
                  <span className="font-bold text-[#1A1A1A]">{comm.memberCount}</span>
                  <span>members</span>
                </div>

                <div className="inline-flex items-center gap-1 font-bold text-[#E8491D] text-xs group-hover:translate-x-0.5 transition-transform">
                  <span>Explore Space</span>
                  <ChevronRight className="h-3.5 w-3.5" />
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Create Community Modal */}
      {isCreateModalOpen && (
        <CreateCommunityModal
          isOpen={isCreateModalOpen}
          initialType={createModalType}
          onClose={() => setIsCreateModalOpen(false)}
          onCommunityCreated={(id) => {
            const found = communities.find((c) => c.id === id);
            if (found) setSelectedCommunity(found);
          }}
        />
      )}
    </div>
  );
};
