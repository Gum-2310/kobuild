import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { CommunityCategory, CommunityType, ChallengeRequirement } from '../../types';
import { createCommunity } from '../../services/communityService';
import {
  X,
  Sparkles,
  Shield,
  Upload,
  Plus,
  Trash2,
  Lock,
  Globe,
  Users,
  CheckCircle2,
  Flame,
  Award,
  Loader2,
  Image as ImageIcon,
} from 'lucide-react';

interface CreateCommunityModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCommunityCreated: (communityId: string) => void;
  initialType?: CommunityType;
}

const CATEGORIES: { id: CommunityCategory; label: string; icon: string }[] = [
  { id: 'challenge', label: 'Challenge & Arc', icon: '🏆' },
  { id: 'coding', label: 'Coding & Dev', icon: '💻' },
  { id: 'ai', label: 'AI & Machine Learning', icon: '🤖' },
  { id: 'fitness', label: 'Fitness & Health', icon: '🔥' },
  { id: 'learning', label: 'Learning & Skills', icon: '📚' },
  { id: 'hackathon', label: 'Hackathons & Sprints', icon: '⚡' },
  { id: 'local', label: 'Local City Squad', icon: '📍' },
  { id: 'hobbies', label: 'Hobbies & Creative', icon: '🎨' },
  { id: 'networking', label: 'Networking & Venture', icon: '🚀' },
  { id: 'general', label: 'General Interest', icon: '🌐' },
];

const PRESET_COVERS = [
  'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=1200&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=1200&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1570168007204-dfb528c6958f?w=1200&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=1200&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=1200&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=1200&auto=format&fit=crop&q=80',
];

export const CreateCommunityModal: React.FC<CreateCommunityModalProps> = ({
  isOpen,
  onClose,
  onCommunityCreated,
  initialType = 'open',
}) => {
  const { user, userProfile, isAdmin } = useAuth();

  // If user is not admin, force type to 'open'
  const effectiveInitialType: CommunityType = (isAdmin ? initialType : 'open') as CommunityType;
  const [type, setType] = useState<CommunityType>(effectiveInitialType);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<CommunityCategory>('learning');
  const [coverImage, setCoverImage] = useState(PRESET_COVERS[0]);
  const [customCoverInput, setCustomCoverInput] = useState('');
  const [location, setLocation] = useState('');
  const [isPrivate, setIsPrivate] = useState(false);
  const [requireApproval, setRequireApproval] = useState(false);

  // Rules list
  const [rules, setRules] = useState<string[]>([
    'Be respectful and support all fellow builders.',
    'Share genuine learnings and constructive feedback.',
    'No spam or unauthorized marketing.',
  ]);
  const [newRuleInput, setNewRuleInput] = useState('');

  // Tags list
  const [tagInput, setTagInput] = useState('');
  const [tags, setTags] = useState<string[]>(['Builders', 'Collaboration']);

  // Challenge Config State (if type === 'kobuild_official' or challenge community)
  const [hasChallenge, setHasChallenge] = useState(effectiveInitialType === 'kobuild_official' && isAdmin);
  const [durationDays, setDurationDays] = useState(90);
  const [challengeRules, setChallengeRules] = useState<string[]>([
    'Submit 4 daily photo verifications every single day.',
    'Submissions must be posted before 11:59 PM local time.',
  ]);
  const [dailyRequirements, setDailyRequirements] = useState<ChallengeRequirement[]>([
    { id: 'req_1', title: 'Breakfast Photo', description: 'Healthy meal verification', type: 'photo', points: 25 },
    { id: 'req_2', title: 'Lunch Photo', description: 'Healthy lunch verification', type: 'photo', points: 25 },
    { id: 'req_3', title: 'Dinner Photo', description: 'Healthy dinner verification', type: 'photo', points: 25 },
    { id: 'req_4', title: 'Daily Progress Photo', description: 'Training or workout snapshot', type: 'photo', points: 25 },
  ]);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleAddRule = () => {
    if (newRuleInput.trim()) {
      setRules((prev) => [...prev, newRuleInput.trim()]);
      setNewRuleInput('');
    }
  };

  const handleRemoveRule = (index: number) => {
    setRules((prev) => prev.filter((_, i) => i !== index));
  };

  const handleAddTag = (e: React.KeyboardEvent | React.MouseEvent) => {
    if ('key' in e && e.key !== 'Enter') return;
    if (tagInput.trim() && !tags.includes(tagInput.trim())) {
      setTags((prev) => [...prev, tagInput.trim()]);
      setTagInput('');
    }
  };

  const handleRemoveTag = (tagToRemove: string) => {
    setTags((prev) => prev.filter((t) => t !== tagToRemove));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !userProfile) {
      setError('Please log in to create a community.');
      return;
    }

    if (!title.trim() || !description.trim()) {
      setError('Please provide a community name and description.');
      return;
    }

    // Strict Authorization check for official challenges
    if (type === 'kobuild_official' && !isAdmin) {
      setError('Unauthorized: Only platform owners and administrators can create or launch official KOBUILD Challenges.');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const now = new Date();
      const startDate = now.toISOString();
      const endDate = new Date(now.getTime() + durationDays * 24 * 60 * 60 * 1000).toISOString();

      const created = await createCommunity(
        {
          type,
          title: title.trim(),
          description: description.trim(),
          category,
          coverImage: customCoverInput.trim() || coverImage,
          creatorBio: userProfile.bio || '',
          rules: rules.filter((r) => r.trim().length > 0),
          tags: tags.length > 0 ? tags : [category],
          location: location.trim() || undefined,
          isPrivate,
          requireApproval,
          featured: false,
          trending: true,
          hasChallenge: type === 'kobuild_official' || hasChallenge,
          challengeConfig:
            type === 'kobuild_official' || hasChallenge
              ? {
                  startDate,
                  endDate,
                  durationDays,
                  rules: challengeRules,
                  dailyRequirements,
                  scoringSystem: `${dailyRequirements.reduce((acc, r) => acc + r.points, 0)} points per full day + streak bonus`,
                  rewards: [
                    { title: 'KOBUILD Winner Goodies Kit', description: 'Official merchandise and certificates' },
                    { title: 'Verified Gold Champion Badge', description: 'Permanent status badge on profile' },
                  ],
                }
              : undefined,
        },
        userProfile
      );

      onCommunityCreated(created.id);
      onClose();
    } catch (err: any) {
      console.error('Error creating community:', err);
      setError(err.message || 'Failed to create community. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-[#FAF8F3] border border-[#E5E2DA] rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#E5E2DA] bg-[#F2EFE6]">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#E8491D]/10 text-[#E8491D] border border-[#E8491D]/20">
              <Users className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-[#1A1A1A]">
                {type === 'kobuild_official' ? 'Create Platform Challenge / Community' : 'Create an Open Community'}
              </h2>
              <p className="text-xs text-[#8A8578]">
                {type === 'kobuild_official'
                  ? 'Launch an official KOBUILD challenge, hackathon, or competition'
                  : 'Start a collaborative space for your squad, city, or interest group'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-[#8A8578] hover:bg-[#E5E2DA] hover:text-[#1A1A1A] transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6 max-h-[78vh] overflow-y-auto">
          {error && (
            <div className="p-3.5 rounded-xl bg-red-50 border border-red-200 text-xs text-red-700 font-medium">
              {error}
            </div>
          )}

          {/* Type Selector (Open Community vs Platform Challenge) */}
          {isAdmin ? (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold uppercase tracking-wider text-[#55524A]">Community Type</label>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#E8491D]/10 text-[#E8491D] border border-[#E8491D]/20">
                  Admin Privileges Active
                </span>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => {
                    setType('open');
                    setHasChallenge(false);
                  }}
                  className={`flex items-start gap-3 p-3.5 rounded-xl border text-left transition-all ${
                    type === 'open'
                      ? 'border-[#E8491D] bg-[#FDE4D8]/40 ring-1 ring-[#E8491D]'
                      : 'border-[#E5E2DA] bg-white hover:bg-[#F2EFE6]'
                  }`}
                >
                  <Users className={`h-5 w-5 mt-0.5 ${type === 'open' ? 'text-[#E8491D]' : 'text-[#8A8578]'}`} />
                  <div>
                    <div className="text-sm font-bold text-[#1A1A1A]">Open Community</div>
                    <div className="text-xs text-[#8A8578] mt-0.5 leading-relaxed">
                      User-created group for hobbies, learning, local cities, or networking.
                    </div>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setType('kobuild_official');
                    setHasChallenge(true);
                    setCategory('challenge');
                  }}
                  className={`flex items-start gap-3 p-3.5 rounded-xl border text-left transition-all ${
                    type === 'kobuild_official'
                      ? 'border-[#E8491D] bg-[#FDE4D8]/40 ring-1 ring-[#E8491D]'
                      : 'border-[#E5E2DA] bg-white hover:bg-[#F2EFE6]'
                  }`}
                >
                  <Flame className={`h-5 w-5 mt-0.5 ${type === 'kobuild_official' ? 'text-[#E8491D]' : 'text-[#8A8578]'}`} />
                  <div>
                    <div className="text-sm font-bold text-[#1A1A1A]">KOBUILD Challenge</div>
                    <div className="text-xs text-[#8A8578] mt-0.5 leading-relaxed">
                      Flagship challenge/competition with daily submissions, scoring, and prizes.
                    </div>
                  </div>
                </button>
              </div>
            </div>
          ) : (
            <div className="p-3.5 rounded-xl bg-[#F2EFE6] border border-[#E5E2DA] flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-white text-[#E8491D] shadow-2xs">
                  <Users className="h-4 w-4" />
                </div>
                <div>
                  <div className="text-xs font-bold text-[#1A1A1A]">Creating an Open Community</div>
                  <div className="text-[11px] text-[#8A8578]">
                    Anyone in the KOBUILD ecosystem can discover, join, and collaborate in your community.
                  </div>
                </div>
              </div>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
                Community Builder
              </span>
            </div>
          )}

          {/* Community Name */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold uppercase tracking-wider text-[#55524A]">
              Community Name <span className="text-[#E8491D]">*</span>
            </label>
            <input
              type="text"
              required
              placeholder={type === 'kobuild_official' ? 'e.g. 90 DAY WINTER ARC, 30 DAY FULL-STACK SPRINT' : 'e.g. Hyderabad Tech Founders, React Beginners, AI Learners'}
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-[#E5E2DA] bg-white text-sm text-[#1A1A1A] placeholder-[#8A8578] focus:border-[#E8491D] focus:ring-1 focus:ring-[#E8491D] outline-none transition-all"
            />
          </div>

          {/* Description */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold uppercase tracking-wider text-[#55524A]">
              Description & Mission <span className="text-[#E8491D]">*</span>
            </label>
            <textarea
              required
              rows={3}
              placeholder="What is the purpose of this community? What will members learn, build, or achieve together?"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-[#E5E2DA] bg-white text-sm text-[#1A1A1A] placeholder-[#8A8578] focus:border-[#E8491D] focus:ring-1 focus:ring-[#E8491D] outline-none transition-all resize-none"
            />
          </div>

          {/* Category */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold uppercase tracking-wider text-[#55524A]">Category</label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {CATEGORIES.map((cat) => (
                <button
                  type="button"
                  key={cat.id}
                  onClick={() => setCategory(cat.id)}
                  className={`flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-medium border text-left transition-all ${
                    category === cat.id
                      ? 'border-[#E8491D] bg-[#FDE4D8] text-[#E8491D] font-bold shadow-sm'
                      : 'border-[#E5E2DA] bg-white text-[#55524A] hover:bg-[#F2EFE6]'
                  }`}
                >
                  <span>{cat.icon}</span>
                  <span className="truncate">{cat.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Cover Photo */}
          <div className="space-y-2">
            <label className="text-xs font-bold uppercase tracking-wider text-[#55524A]">Cover Image</label>
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
              {PRESET_COVERS.map((cover, idx) => (
                <button
                  type="button"
                  key={idx}
                  onClick={() => {
                    setCoverImage(cover);
                    setCustomCoverInput('');
                  }}
                  className={`relative aspect-video rounded-lg overflow-hidden border-2 transition-all ${
                    coverImage === cover && !customCoverInput ? 'border-[#E8491D] ring-2 ring-[#E8491D]/30' : 'border-transparent opacity-70 hover:opacity-100'
                  }`}
                >
                  <img src={cover} alt="Preset cover" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
            <input
              type="url"
              placeholder="Or enter custom image URL (https://...)"
              value={customCoverInput}
              onChange={(e) => setCustomCoverInput(e.target.value)}
              className="w-full px-3.5 py-2 rounded-xl border border-[#E5E2DA] bg-white text-xs text-[#1A1A1A] placeholder-[#8A8578] focus:border-[#E8491D] focus:ring-1 focus:ring-[#E8491D] outline-none"
            />
          </div>

          {/* Location & Access Settings */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs font-bold uppercase tracking-wider text-[#55524A]">Location (Optional)</label>
              <input
                type="text"
                placeholder="e.g. Hyderabad, Bengaluru, Virtual / Global"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-[#E5E2DA] bg-white text-sm text-[#1A1A1A] placeholder-[#8A8578] focus:border-[#E8491D] focus:ring-1 focus:ring-[#E8491D] outline-none"
              />
            </div>

            {/* Approval Required Setting */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold uppercase tracking-wider text-[#55524A]">Join Permissions</label>
              <div className="flex items-center justify-between p-2.5 rounded-xl border border-[#E5E2DA] bg-white">
                <div className="flex items-center gap-2">
                  <Shield className="h-4 w-4 text-[#8A8578]" />
                  <div>
                    <div className="text-xs font-bold text-[#1A1A1A]">Require Approval to Join</div>
                    <div className="text-[10px] text-[#8A8578]">Creator manually accepts requests</div>
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={requireApproval}
                  onChange={(e) => setRequireApproval(e.target.checked)}
                  className="h-4 w-4 rounded accent-[#E8491D] cursor-pointer"
                />
              </div>
            </div>
          </div>

          {/* Challenge Configuration Section */}
          {(type === 'kobuild_official' || hasChallenge) && (
            <div className="p-4 rounded-xl border border-[#E8491D]/30 bg-[#FDE4D8]/20 space-y-4">
              <div className="flex items-center gap-2 text-sm font-bold text-[#E8491D]">
                <Flame className="h-4 w-4" />
                <span>Challenge & Verification Rules</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-[#55524A]">Duration (Days)</label>
                  <input
                    type="number"
                    min={7}
                    max={365}
                    value={durationDays}
                    onChange={(e) => setDurationDays(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border border-[#E5E2DA] bg-white text-sm text-[#1A1A1A]"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-[#55524A]">Daily Checkpoint Count</label>
                  <div className="px-3 py-2 rounded-xl border border-[#E5E2DA] bg-white text-sm text-[#55524A] font-semibold">
                    {dailyRequirements.length} Daily Checkpoints
                  </div>
                </div>
              </div>

              {/* Checkpoint list */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-[#55524A]">Daily Verification Requirements:</label>
                <div className="space-y-2">
                  {dailyRequirements.map((req, idx) => (
                    <div key={req.id} className="flex items-center justify-between p-2.5 rounded-xl border border-[#E5E2DA] bg-white text-xs">
                      <div>
                        <span className="font-bold text-[#1A1A1A]">
                          {idx + 1}. {req.title}
                        </span>
                        <span className="text-[#8A8578] ml-2">({req.points} pts) — {req.description}</span>
                      </div>
                      <span className="px-2 py-0.5 rounded-md bg-[#F2EFE6] text-[10px] font-bold text-[#55524A] uppercase">
                        {req.type}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Tags */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold uppercase tracking-wider text-[#55524A]">Tags & Keywords</label>
            <div className="flex flex-wrap gap-1.5 mb-2">
              {tags.map((tag) => (
                <span
                  key={tag}
                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#F2EFE6] text-xs font-medium text-[#1A1A1A] border border-[#E5E2DA]"
                >
                  #{tag}
                  <button type="button" onClick={() => handleRemoveTag(tag)} className="text-[#8A8578] hover:text-red-600">
                    <X className="h-3 w-3" />
                  </button>
                </span>
              ))}
            </div>
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="Add tag (e.g. Nextjs, Fitness, 90Days)"
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                onKeyDown={handleAddTag}
                className="flex-1 px-3 py-2 rounded-xl border border-[#E5E2DA] bg-white text-xs text-[#1A1A1A] placeholder-[#8A8578] focus:border-[#E8491D] outline-none"
              />
              <button
                type="button"
                onClick={handleAddTag}
                className="px-3.5 py-2 rounded-xl bg-[#F2EFE6] hover:bg-[#E5E2DA] text-xs font-bold text-[#1A1A1A] transition-colors"
              >
                Add
              </button>
            </div>
          </div>

          {/* Rules */}
          <div className="space-y-2">
            <label className="text-xs font-bold uppercase tracking-wider text-[#55524A]">Community Rules</label>
            <div className="space-y-2">
              {rules.map((rule, idx) => (
                <div key={idx} className="flex items-center justify-between p-2.5 rounded-xl border border-[#E5E2DA] bg-white text-xs">
                  <span className="text-[#1A1A1A]">
                    {idx + 1}. {rule}
                  </span>
                  <button
                    type="button"
                    onClick={() => handleRemoveRule(idx)}
                    className="text-[#8A8578] hover:text-red-600 transition-colors p-1"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              ))}
            </div>
            <div className="flex gap-2 mt-2">
              <input
                type="text"
                placeholder="Add a community guideline..."
                value={newRuleInput}
                onChange={(e) => setNewRuleInput(e.target.value)}
                className="flex-1 px-3 py-2 rounded-xl border border-[#E5E2DA] bg-white text-xs text-[#1A1A1A] placeholder-[#8A8578] focus:border-[#E8491D] outline-none"
              />
              <button
                type="button"
                onClick={handleAddRule}
                className="px-3.5 py-2 rounded-xl bg-[#F2EFE6] hover:bg-[#E5E2DA] text-xs font-bold text-[#1A1A1A] transition-colors"
              >
                Add Rule
              </button>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-[#E5E2DA]">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl border border-[#E5E2DA] bg-white text-xs font-bold text-[#55524A] hover:bg-[#F2EFE6] transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-[#E8491D] hover:bg-[#D03E15] text-xs font-bold text-white shadow-sm transition-all disabled:opacity-50"
            >
              {loading ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  <span>Creating Community...</span>
                </>
              ) : (
                <>
                  <Sparkles className="h-4 w-4" />
                  <span>Launch Community</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
