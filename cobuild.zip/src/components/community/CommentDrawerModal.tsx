import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { CommunityPost, Comment, UserSection } from '../../types';
import {
  subscribePostComments,
  addPostComment,
  updatePostComment,
  deletePostComment,
} from '../../services/userService';
import {
  X,
  Send,
  MessageSquare,
  CornerDownRight,
  Edit2,
  Trash2,
  Check,
  Loader2,
  Lock,
  Sparkles,
} from 'lucide-react';

interface CommentDrawerModalProps {
  post: CommunityPost;
  onClose: () => void;
  onOpenAuth: (section?: UserSection | null) => void;
}

export const CommentDrawerModal: React.FC<CommentDrawerModalProps> = ({
  post,
  onClose,
  onOpenAuth,
}) => {
  const { user, userProfile } = useAuth();
  const [comments, setComments] = useState<Comment[]>([]);
  const [loading, setLoading] = useState(true);
  const [newCommentText, setNewCommentText] = useState('');
  const [submitting, setSubmitting] = useState(false);

  // Replying state
  const [replyingTo, setReplyingTo] = useState<Comment | null>(null);
  const [replyText, setReplyText] = useState('');

  // Editing state
  const [editingCommentId, setEditingCommentId] = useState<string | null>(null);
  const [editText, setEditText] = useState('');

  useEffect(() => {
    const unsub = subscribePostComments(post.id, (fetchedComments) => {
      setComments(fetchedComments);
      setLoading(false);
    });

    return () => unsub();
  }, [post.id]);

  const handleAddComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !userProfile) {
      onOpenAuth(null);
      return;
    }
    if (!newCommentText.trim()) return;

    setSubmitting(true);
    try {
      await addPostComment(
        {
          postId: post.id,
          userId: user.uid,
          userName: userProfile.name,
          userPhotoURL: userProfile.photoURL || null,
          userSection: userProfile.section,
          parentCommentId: null,
          content: newCommentText.trim(),
        },
        post.title,
        post.creatorId
      );
      setNewCommentText('');
    } catch (err) {
      console.error('Failed to add comment:', err);
    } finally {
      setSubmitting(false);
    }
  };

  const handleAddReply = async (parentComment: Comment) => {
    if (!user || !userProfile) {
      onOpenAuth(null);
      return;
    }
    if (!replyText.trim()) return;

    setSubmitting(true);
    try {
      await addPostComment(
        {
          postId: post.id,
          userId: user.uid,
          userName: userProfile.name,
          userPhotoURL: userProfile.photoURL || null,
          userSection: userProfile.section,
          parentCommentId: parentComment.id,
          content: replyText.trim(),
        },
        post.title,
        post.creatorId,
        parentComment.userId
      );
      setReplyText('');
      setReplyingTo(null);
    } catch (err) {
      console.error('Failed to add reply:', err);
    } finally {
      setSubmitting(false);
    }
  };

  const handleSaveEdit = async (commentId: string) => {
    if (!editText.trim()) return;
    try {
      await updatePostComment(commentId, editText.trim());
      setEditingCommentId(null);
      setEditText('');
    } catch (err) {
      console.error('Failed to update comment:', err);
    }
  };

  const handleDelete = async (commentId: string) => {
    if (!window.confirm('Delete this comment?')) return;
    try {
      await deletePostComment(commentId, post.id);
    } catch (err) {
      console.error('Failed to delete comment:', err);
    }
  };

  const getSectionBadgeClass = (sec?: UserSection) => {
    switch (sec) {
      case 'student':
        return 'bg-[#FDE4D8] text-[#E8491D] border-[#E8491D]/40';
      case 'homemaker':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case 'entrepreneur':
        return 'bg-purple-50 text-purple-700 border-purple-200';
      default:
        return 'bg-[#FAF8F3] text-[#55524A] border-[#E5E2DA]';
    }
  };

  const formatRelativeTime = (isoString?: string) => {
    if (!isoString) return 'just now';
    const date = new Date(isoString);
    const diffSec = Math.floor((Date.now() - date.getTime()) / 1000);
    if (diffSec < 60) return 'just now';
    if (diffSec < 3600) return `${Math.floor(diffSec / 60)}m ago`;
    if (diffSec < 86400) return `${Math.floor(diffSec / 3600)}h ago`;
    return `${Math.floor(diffSec / 86400)}d ago`;
  };

  // Group comments: top-level comments and replies
  const topLevelComments = comments.filter((c) => !c.parentCommentId);
  const repliesMap = comments.reduce<Record<string, Comment[]>>((acc, c) => {
    if (c.parentCommentId) {
      if (!acc[c.parentCommentId]) acc[c.parentCommentId] = [];
      acc[c.parentCommentId].push(c);
    }
    return acc;
  }, {});

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-[#1A1A1A]/40 p-3 sm:p-4 backdrop-blur-xs animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="w-full max-w-2xl max-h-[90vh] flex flex-col rounded-3xl border border-[#E5E2DA] bg-[#FFFFFF] shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-[#E5E2DA] px-6 py-4.5 bg-[#FAF8F3]">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#FDE4D8] text-[#E8491D] border border-[#E8491D]/30">
              <MessageSquare className="h-4.5 w-4.5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-[#1A1A1A]">Discussion &amp; Feedback</h3>
                <span className="rounded-full bg-[#FFFFFF] border border-[#E5E2DA] px-2 py-0.5 text-[10px] font-bold text-[#55524A] font-mono">
                  {comments.length}
                </span>
              </div>
              <p className="text-[11px] text-[#55524A] line-clamp-1 max-w-md">
                {post.title}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="rounded-xl p-2 text-[#8A8578] hover:bg-[#F2EFE6] hover:text-[#1A1A1A] transition"
            aria-label="Close"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Original Post Context Banner */}
        <div className="px-6 py-3.5 bg-[#FDE4D8]/40 border-b border-[#E8491D]/20 flex items-start gap-3">
          <div className="flex-1">
            <div className="flex items-center gap-2 text-[11px] text-[#55524A] mb-1">
              <span className="font-semibold text-[#1A1A1A]">{post.creatorName}</span>
              <span
                className={`rounded border px-1.5 py-0.2 text-[9px] font-bold uppercase tracking-wider ${getSectionBadgeClass(
                  post.creatorSection
                )}`}
              >
                {post.creatorSection}
              </span>
              <span>•</span>
              <span className="font-mono text-[10px] text-[#8A8578]">{formatRelativeTime(post.createdAt)}</span>
            </div>
            <p className="text-xs text-[#55524A] line-clamp-2 leading-relaxed">
              {post.description}
            </p>
          </div>
        </div>

        {/* Comments Scrollable List */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {loading ? (
            <div className="flex flex-col items-center justify-center py-12 text-[#55524A] gap-2">
              <Loader2 className="h-6 w-6 animate-spin text-[#E8491D]" />
              <span className="text-xs font-medium">Loading discussion...</span>
            </div>
          ) : topLevelComments.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-[#E5E2DA] bg-[#FAF8F3] p-8 text-center space-y-2">
              <div className="mx-auto flex h-10 w-10 items-center justify-center rounded-xl bg-[#FFFFFF] text-[#8A8578]">
                <Sparkles className="h-5 w-5" />
              </div>
              <h4 className="text-xs font-bold text-[#1A1A1A]">Be the first to share feedback</h4>
              <p className="text-[11px] text-[#55524A] max-w-xs mx-auto">
                Ask questions, suggest tweaks, or share ideas to help validate this concept.
              </p>
            </div>
          ) : (
            topLevelComments.map((comment) => {
              const isOwner = user?.uid === comment.userId;
              const isCreator = comment.userId === post.creatorId;
              const replies = repliesMap[comment.id] || [];

              return (
                <div key={comment.id} className="space-y-3">
                  {/* Top-Level Comment Card */}
                  <div className="rounded-2xl border border-[#E5E2DA] bg-[#FAF8F3] p-4 shadow-2xs space-y-2.5 transition hover:border-[#D4D0C5]">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2.5">
                        <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-[#FFFFFF] border border-[#E5E2DA] text-[#1A1A1A] text-[10px] font-bold">
                          {comment.userName.charAt(0)}
                        </div>
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="text-xs font-bold text-[#1A1A1A]">
                            {comment.userName}
                          </span>
                          {isCreator && (
                            <span className="rounded bg-amber-50 text-amber-700 border border-amber-200 px-1.5 py-0.2 text-[9px] font-bold uppercase">
                              Idea Creator
                            </span>
                          )}
                          <span
                            className={`rounded border px-1.5 py-0.2 text-[9px] font-bold uppercase ${getSectionBadgeClass(
                              comment.userSection
                            )}`}
                          >
                            {comment.userSection || 'member'}
                          </span>
                          <span className="text-[10px] text-[#8A8578] font-mono">
                            {formatRelativeTime(comment.createdAt)}
                          </span>
                        </div>
                      </div>

                      {/* Comment Actions (Edit / Delete) */}
                      {isOwner && (
                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => {
                              setEditingCommentId(comment.id);
                              setEditText(comment.content);
                            }}
                            className="p-1 text-[#8A8578] hover:text-[#E8491D] rounded"
                            title="Edit comment"
                          >
                            <Edit2 className="h-3.5 w-3.5" />
                          </button>
                          <button
                            onClick={() => handleDelete(comment.id)}
                            className="p-1 text-[#8A8578] hover:text-rose-600 rounded"
                            title="Delete comment"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      )}
                    </div>

                    {/* Content or Edit Box */}
                    {editingCommentId === comment.id ? (
                      <div className="space-y-2 pt-1">
                        <textarea
                          rows={2}
                          value={editText}
                          onChange={(e) => setEditText(e.target.value)}
                          className="w-full rounded-xl border border-[#E5E2DA] bg-[#FFFFFF] p-2 text-xs text-[#1A1A1A] focus:border-[#E8491D] focus:outline-none"
                        />
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={() => setEditingCommentId(null)}
                            className="px-2.5 py-1 text-[11px] font-semibold text-[#55524A] hover:bg-[#F2EFE6] rounded-lg"
                          >
                            Cancel
                          </button>
                          <button
                            onClick={() => handleSaveEdit(comment.id)}
                            className="px-3 py-1 text-[11px] font-semibold bg-[#E8491D] hover:bg-[#FF5722] text-white rounded-lg"
                          >
                            Save Changes
                          </button>
                        </div>
                      </div>
                    ) : (
                      <p className="text-xs text-[#55524A] leading-relaxed pl-9">
                        {comment.content}
                      </p>
                    )}

                    {/* Reply Trigger */}
                    <div className="pl-9 flex items-center gap-3 pt-1">
                      <button
                        onClick={() => {
                          if (!user) {
                            onOpenAuth(null);
                            return;
                          }
                          setReplyingTo(replyingTo?.id === comment.id ? null : comment);
                          setReplyText('');
                        }}
                        className="text-[11px] font-semibold text-[#E8491D] hover:text-[#FF5722] flex items-center gap-1"
                      >
                        <CornerDownRight className="h-3 w-3" />
                        <span>Reply</span>
                      </button>
                    </div>
                  </div>

                  {/* Inline Reply Box if Active */}
                  {replyingTo?.id === comment.id && (
                    <div className="ml-8 rounded-2xl border border-[#E8491D]/30 bg-[#FDE4D8]/30 p-3 space-y-2 animate-in fade-in duration-150">
                      <div className="flex items-center justify-between text-[11px] text-[#E8491D] font-medium">
                        <span>Replying to @{comment.userName}</span>
                        <button
                          onClick={() => setReplyingTo(null)}
                          className="text-[#8A8578] hover:text-[#1A1A1A]"
                        >
                          <X className="h-3.5 w-3.5" />
                        </button>
                      </div>
                      <textarea
                        rows={2}
                        value={replyText}
                        onChange={(e) => setReplyText(e.target.value)}
                        placeholder={`Write your reply to ${comment.userName}...`}
                        className="w-full rounded-xl border border-[#E5E2DA] bg-[#FFFFFF] p-2.5 text-xs text-[#1A1A1A] placeholder:text-[#8A8578] focus:border-[#E8491D] focus:outline-none"
                      />
                      <div className="flex justify-end gap-2">
                        <button
                          type="button"
                          onClick={() => setReplyingTo(null)}
                          className="px-2.5 py-1 text-[11px] font-semibold text-[#55524A] hover:bg-[#F2EFE6] rounded-lg"
                        >
                          Cancel
                        </button>
                        <button
                          type="button"
                          disabled={submitting || !replyText.trim()}
                          onClick={() => handleAddReply(comment)}
                          className="flex items-center gap-1 rounded-lg bg-[#E8491D] px-3 py-1 text-[11px] font-semibold text-white hover:bg-[#FF5722] disabled:opacity-50"
                        >
                          {submitting ? (
                            <Loader2 className="h-3 w-3 animate-spin" />
                          ) : (
                            <Send className="h-3 w-3" />
                          )}
                          <span>Post Reply</span>
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Nested Replies Stream */}
                  {replies.length > 0 && (
                    <div className="ml-8 space-y-2.5 border-l-2 border-[#E5E2DA] pl-3">
                      {replies.map((reply) => {
                        const isReplyOwner = user?.uid === reply.userId;
                        const isReplyCreator = reply.userId === post.creatorId;

                        return (
                          <div
                            key={reply.id}
                            className="rounded-2xl border border-[#E5E2DA] bg-[#FFFFFF] p-3.5 space-y-2"
                          >
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <div className="flex h-6 w-6 items-center justify-center rounded-md bg-[#FAF8F3] text-[#1A1A1A] text-[9px] font-bold">
                                  {reply.userName.charAt(0)}
                                </div>
                                <span className="text-xs font-bold text-[#1A1A1A]">
                                  {reply.userName}
                                </span>
                                {isReplyCreator && (
                                  <span className="rounded bg-amber-50 text-amber-700 border border-amber-200 px-1 py-0.2 text-[8px] font-bold uppercase">
                                    Creator
                                  </span>
                                )}
                                <span
                                  className={`rounded border px-1.5 py-0.2 text-[8px] font-bold uppercase ${getSectionBadgeClass(
                                    reply.userSection
                                  )}`}
                                >
                                  {reply.userSection || 'member'}
                                </span>
                                <span className="text-[9px] text-[#8A8578] font-mono">
                                  {formatRelativeTime(reply.createdAt)}
                                </span>
                              </div>

                              {isReplyOwner && (
                                <div className="flex items-center gap-1">
                                  <button
                                    onClick={() => {
                                      setEditingCommentId(reply.id);
                                      setEditText(reply.content);
                                    }}
                                    className="p-1 text-[#8A8578] hover:text-[#E8491D] rounded"
                                    title="Edit reply"
                                  >
                                    <Edit2 className="h-3.5 w-3.5" />
                                  </button>
                                  <button
                                    onClick={() => handleDelete(reply.id)}
                                    className="p-1 text-[#8A8578] hover:text-rose-600 rounded"
                                    title="Delete reply"
                                  >
                                    <Trash2 className="h-3.5 w-3.5" />
                                  </button>
                                </div>
                              )}
                            </div>

                            {editingCommentId === reply.id ? (
                              <div className="space-y-2">
                                <textarea
                                  rows={2}
                                  value={editText}
                                  onChange={(e) => setEditText(e.target.value)}
                                  className="w-full rounded-xl border border-[#E5E2DA] bg-[#FAF8F3] p-2 text-xs text-[#1A1A1A] focus:border-[#E8491D] focus:outline-none"
                                />
                                <div className="flex items-center justify-end gap-2">
                                  <button
                                    onClick={() => setEditingCommentId(null)}
                                    className="px-2.5 py-1 text-[11px] font-semibold text-[#55524A] hover:bg-[#F2EFE6] rounded-lg"
                                  >
                                    Cancel
                                  </button>
                                  <button
                                    onClick={() => handleSaveEdit(reply.id)}
                                    className="px-3 py-1 text-[11px] font-semibold bg-[#E8491D] hover:bg-[#FF5722] text-white rounded-lg"
                                  >
                                    Save Changes
                                  </button>
                                </div>
                              </div>
                            ) : (
                              <p className="text-xs text-[#55524A] leading-relaxed pl-8">
                                {reply.content}
                              </p>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>

        {/* Bottom Comment Input Bar */}
        <div className="border-t border-[#E5E2DA] p-4 bg-[#FAF8F3]">
          {user ? (
            <form onSubmit={handleAddComment} className="flex items-center gap-2">
              <input
                type="text"
                value={newCommentText}
                onChange={(e) => setNewCommentText(e.target.value)}
                placeholder="Add your thoughts, feedback, or questions..."
                className="flex-1 rounded-xl border border-[#E5E2DA] bg-[#FFFFFF] px-3.5 py-2.5 text-xs text-[#1A1A1A] placeholder:text-[#8A8578] focus:border-[#E8491D] focus:outline-none shadow-2xs"
              />
              <button
                type="submit"
                disabled={submitting || !newCommentText.trim()}
                className="flex items-center gap-1.5 rounded-xl bg-[#E8491D] hover:bg-[#FF5722] px-4 py-2.5 text-xs font-semibold text-white disabled:opacity-50 transition shadow-2xs"
              >
                {submitting ? (
                  <Loader2 className="h-3.5 w-3.5 animate-spin" />
                ) : (
                  <Send className="h-3.5 w-3.5" />
                )}
                <span>Comment</span>
              </button>
            </form>
          ) : (
            <div className="flex items-center justify-between rounded-xl bg-[#FFFFFF] border border-[#E5E2DA] p-3">
              <div className="flex items-center gap-2 text-xs text-[#55524A]">
                <Lock className="h-4 w-4 text-[#8A8578]" />
                <span>Sign in to join the conversation and leave comments.</span>
              </div>
              <button
                onClick={() => onOpenAuth(null)}
                className="rounded-lg bg-[#E8491D] hover:bg-[#FF5722] px-3 py-1.5 text-xs font-semibold text-white"
              >
                Sign In
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
