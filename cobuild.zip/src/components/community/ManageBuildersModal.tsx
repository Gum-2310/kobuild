import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import {
  CommunityPost,
  BuildRequest,
  TeamRequirement,
  UserSection,
  AppView,
  UserProfile,
} from '../../types';
import {
  subscribeBuildRequestsForPost,
  updateBuildRequestStatus,
  updateCommunityPost,
  launchBuildSpaceFromIdea,
} from '../../services/userService';
import {
  X,
  Users,
  CheckCircle2,
  XCircle,
  Clock,
  Sparkles,
  Rocket,
  Plus,
  Trash2,
  Check,
  AlertCircle,
  Loader2,
  FolderGit2,
  ChevronRight,
  ShieldCheck,
  UserCheck,
  UserX,
} from 'lucide-react';

interface ManageBuildersModalProps {
  post: CommunityPost;
  onClose: () => void;
  onNavigate: (view: AppView, section?: UserSection) => void;
}

export const ManageBuildersModal: React.FC<ManageBuildersModalProps> = ({
  post,
  onClose,
  onNavigate,
}) => {
  const { user, userProfile } = useAuth();
  const [requests, setRequests] = useState<BuildRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'all' | 'interested' | 'shortlisted' | 'rejected'>('all');

  // Team Requirements state
  const [teamRequirements, setTeamRequirements] = useState<TeamRequirement[]>(
    post.teamRequirements || [
      { role: 'Developer', count: 2 },
      { role: 'UI/UX Designer', count: 1 },
    ]
  );
  const [newRoleName, setNewRoleName] = useState('');
  const [newRoleCount, setNewRoleCount] = useState(1);
  const [showAddRole, setShowAddRole] = useState(false);

  const [launching, setLaunching] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Subscribe to live requests
  useEffect(() => {
    const unsub = subscribeBuildRequestsForPost(post.id, (fetchedRequests) => {
      setRequests(fetchedRequests);
      setLoading(false);
    });

    return () => unsub();
  }, [post.id]);

  const shortlistedBuilders = requests.filter((r) => r.status === 'shortlisted');
  const interestedBuilders = requests.filter((r) => r.status === 'interested');
  const rejectedBuilders = requests.filter((r) => r.status === 'rejected');

  const totalTargetBuilders = teamRequirements.reduce((acc, curr) => acc + (curr.count || 1), 0);
  const isTeamFull = shortlistedBuilders.length >= totalTargetBuilders && totalTargetBuilders > 0;

  const handleStatusChange = async (
    request: BuildRequest,
    newStatus: 'interested' | 'shortlisted' | 'rejected' | 'accepted'
  ) => {
    try {
      await updateBuildRequestStatus(request.id, post.id, newStatus, request.status);
    } catch (err: any) {
      console.error('Failed to update status:', err);
      setError('Failed to update applicant status.');
    }
  };

  const handleAddRole = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRoleName.trim()) return;

    const updated = [
      ...teamRequirements,
      { role: newRoleName.trim(), count: Number(newRoleCount) || 1 },
    ];
    setTeamRequirements(updated);
    setNewRoleName('');
    setNewRoleCount(1);
    setShowAddRole(false);

    try {
      await updateCommunityPost(post.id, {
        teamRequirements: updated,
        targetTeamSize: updated.reduce((acc, curr) => acc + curr.count, 0),
      });
    } catch (err) {
      console.error('Failed to persist team requirements:', err);
    }
  };

  const handleRemoveRole = async (index: number) => {
    const updated = teamRequirements.filter((_, i) => i !== index);
    setTeamRequirements(updated);
    try {
      await updateCommunityPost(post.id, {
        teamRequirements: updated,
        targetTeamSize: updated.reduce((acc, curr) => acc + curr.count, 0),
      });
    } catch (err) {
      console.error('Failed to update requirements:', err);
    }
  };

  const handleLaunchBuildSpace = async () => {
    if (!user) {
      setError('You must be logged in to launch a Build Space.');
      return;
    }

    if (post.creatorId && post.creatorId !== user.uid) {
      setError('Only the creator / project lead of this idea can launch the Build Space.');
      return;
    }

    if (shortlistedBuilders.length === 0) {
      if (
        !window.confirm(
          'You have not shortlisted any builders yet. Launch Build Space as a solo project for now?'
        )
      ) {
        return;
      }
    }

    setLaunching(true);
    setError(null);
    try {
      const activeProfile: UserProfile = userProfile || {
        uid: user.uid,
        name: user.displayName || user.email?.split('@')[0] || 'Project Lead',
        email: user.email || '',
        photoURL: user.photoURL || null,
        section: post.creatorSection || 'student',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      await launchBuildSpaceFromIdea({
        postId: post.id,
        postTitle: post.title,
        postDescription: post.description,
        postCategory: post.category,
        leadProfile: activeProfile,
        shortlistedBuilders: shortlistedBuilders,
      });

      onClose();
      onNavigate('buildspace');
    } catch (err: any) {
      console.error('Failed to launch build space:', err);
      setError(err?.message || 'Failed to launch Build Space. Please try again.');
    } finally {
      setLaunching(false);
    }
  };

  const getSectionBadgeClass = (sec?: UserSection) => {
    switch (sec) {
      case 'student':
        return 'bg-[#FDE4D8] text-[#E8491D] border-[#E8491D]/40';
      case 'homemaker':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case 'entrepreneur':
        return 'bg-purple-50 text-purple-700 border-purple-200';
      default:
        return 'bg-[#FAF8F3] text-[#55524A] border-[#E5E2DA]';
    }
  };

  const filteredRequests = requests.filter((r) => {
    if (activeTab === 'all') return true;
    return r.status === activeTab;
  });

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-[#1A1A1A]/40 p-3 sm:p-4 backdrop-blur-xs animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="w-full max-w-3xl max-h-[92vh] flex flex-col rounded-3xl border border-[#E5E2DA] bg-[#FFFFFF] shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#E5E2DA] px-6 py-4 bg-[#FAF8F3]">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#E8491D] text-white shadow-xs">
              <Users className="h-5 w-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-[#1A1A1A]">Manage Squad &amp; Builders</h3>
                <span className="rounded-md bg-[#FDE4D8] text-[#E8491D] border border-[#E8491D]/40 px-2 py-0.5 text-[10px] font-bold uppercase font-mono">
                  Project Lead View
                </span>
              </div>
              <p className="text-[11px] text-[#55524A] line-clamp-1 max-w-md">
                {post.title}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="rounded-xl p-2 text-[#8A8578] hover:bg-[#F2EFE6] hover:text-[#1A1A1A] transition"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {error && (
            <div className="flex items-center gap-2 rounded-xl bg-rose-50 border border-rose-200 p-3 text-xs text-rose-700">
              <AlertCircle className="h-4 w-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Section 1: Team Requirements & Shortlist Progress Meter */}
          <div className="rounded-2xl border border-[#E5E2DA] bg-[#FAF8F3] p-5 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-[#8A8578]">
                  1. Squad Requirements &amp; Target
                </h4>
                <p className="text-xs text-[#55524A] mt-0.5">
                  Define the roles you need. Shortlist applicants to fill each spot.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-[#1A1A1A]">
                  {shortlistedBuilders.length} of {totalTargetBuilders} Shortlisted
                </span>
                <button
                  onClick={() => setShowAddRole(!showAddRole)}
                  className="flex items-center gap-1 rounded-lg border border-[#E5E2DA] bg-[#FFFFFF] px-2.5 py-1 text-[11px] font-semibold text-[#1A1A1A] hover:bg-[#F5F1E8]"
                >
                  <Plus className="h-3 w-3" />
                  <span>Add Role Needed</span>
                </button>
              </div>
            </div>

            {/* Progress Bar */}
            <div className="w-full bg-[#E5E2DA] rounded-full h-2 overflow-hidden border border-[#D4D0C5]">
              <div
                className="bg-[#E8491D] h-2 rounded-full transition-all duration-300"
                style={{
                  width: `${Math.min(
                    100,
                    totalTargetBuilders > 0
                      ? (shortlistedBuilders.length / totalTargetBuilders) * 100
                      : 0
                  )}%`,
                }}
              />
            </div>

            {/* Role Pills */}
            <div className="flex flex-wrap gap-2 pt-1">
              {teamRequirements.map((req, idx) => (
                <div
                  key={idx}
                  className="flex items-center gap-2 rounded-xl bg-[#FFFFFF] border border-[#E5E2DA] px-3 py-1.5 text-xs text-[#1A1A1A] shadow-2xs"
                >
                  <span className="font-semibold">{req.count}x {req.role}</span>
                  <button
                    onClick={() => handleRemoveRole(idx)}
                    className="text-[#8A8578] hover:text-rose-600 p-0.5"
                    title="Remove requirement"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </div>
              ))}
            </div>

            {/* Add Role Inline Form */}
            {showAddRole && (
              <form onSubmit={handleAddRole} className="flex items-center gap-2 pt-2 animate-in fade-in">
                <input
                  type="text"
                  required
                  placeholder="Role name (e.g. Firmware Engineer)"
                  value={newRoleName}
                  onChange={(e) => setNewRoleName(e.target.value)}
                  className="flex-1 rounded-lg border border-[#E5E2DA] bg-[#FFFFFF] px-3 py-1.5 text-xs text-[#1A1A1A] placeholder:text-[#8A8578] focus:border-[#E8491D] focus:outline-none"
                />
                <input
                  type="number"
                  min={1}
                  max={10}
                  value={newRoleCount}
                  onChange={(e) => setNewRoleCount(parseInt(e.target.value) || 1)}
                  className="w-16 rounded-lg border border-[#E5E2DA] bg-[#FFFFFF] px-2 py-1.5 text-xs text-[#1A1A1A] focus:border-[#E8491D] focus:outline-none text-center"
                />
                <button
                  type="submit"
                  className="rounded-lg bg-[#E8491D] hover:bg-[#FF5722] px-3 py-1.5 text-xs font-semibold text-white"
                >
                  Save
                </button>
              </form>
            )}
          </div>

          {/* Section 2: Shortlisted Builders Squad List */}
          <div className="rounded-2xl border border-[#E8491D]/30 bg-[#FDE4D8]/30 p-5 space-y-3.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ShieldCheck className="h-4 w-4 text-[#E8491D]" />
                <h4 className="text-xs font-bold uppercase tracking-wider text-[#E8491D]">
                  2. Current Shortlisted Squad ({shortlistedBuilders.length})
                </h4>
              </div>
              <span className="text-[11px] text-[#E8491D]/80 font-medium">
                Will be invited directly to Build Space
              </span>
            </div>

            {shortlistedBuilders.length === 0 ? (
              <div className="rounded-xl border border-dashed border-[#E8491D]/30 p-4 text-center text-xs text-[#E8491D]/70">
                No builders shortlisted yet. Browse applicant requests below and click [Shortlist] to add them to your squad.
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {shortlistedBuilders.map((b) => (
                  <div
                    key={b.id}
                    className="flex items-center justify-between gap-2 rounded-xl bg-[#FFFFFF] border border-[#E8491D]/30 p-3 shadow-2xs"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-[#E8491D] text-white text-[10px] font-bold shrink-0">
                        {b.applicantName.charAt(0)}
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5">
                          <span className="text-xs font-bold text-[#1A1A1A] truncate">
                            {b.applicantName}
                          </span>
                          <span
                            className={`rounded px-1 py-0.2 text-[8px] font-bold uppercase ${getSectionBadgeClass(
                              b.applicantSection
                            )}`}
                          >
                            {b.applicantSection}
                          </span>
                        </div>
                        <div className="text-[10px] text-[#8A8578] truncate">
                          {b.skills?.slice(0, 3).join(', ')}
                        </div>
                      </div>
                    </div>

                    <button
                      onClick={() => handleStatusChange(b, 'interested')}
                      className="text-[10px] font-semibold text-rose-600 hover:text-rose-700 p-1 shrink-0"
                      title="Remove from shortlist"
                    >
                      Remove
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Section 3: Launch Guidance & Action Card */}
          <div className="rounded-2xl border border-[#E5E2DA] bg-[#FAF8F3] p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <Rocket className="h-4 w-4 text-amber-600" />
                <h4 className="text-xs font-bold text-[#1A1A1A]">
                  {isTeamFull
                    ? 'Squad Complete & Ready to Build!'
                    : shortlistedBuilders.length > 0
                    ? `Squad Forming (${shortlistedBuilders.length}/${totalTargetBuilders})`
                    : 'Awaiting Builder Shortlist'}
                </h4>
              </div>
              <p className="text-xs text-[#55524A] leading-relaxed max-w-md">
                {isTeamFull
                  ? 'All core team roles are filled. Launch your private Build Space now to coordinate tasks, files, and team meetings.'
                  : shortlistedBuilders.length > 0
                  ? 'You have candidates shortlisted. You can keep reviewing applicants or launch the Build Space workspace anytime.'
                  : 'Review the incoming requests from peers below and shortlist your favorites.'}
              </p>
            </div>

            <button
              onClick={handleLaunchBuildSpace}
              disabled={launching}
              className="flex items-center justify-center gap-2 rounded-xl bg-[#E8491D] hover:bg-[#FF5722] px-5 py-3 text-xs font-bold text-white active:scale-[0.99] transition shadow-xs shrink-0 disabled:opacity-50"
            >
              {launching ? (
                <Loader2 className="h-4 w-4 animate-spin text-white" />
              ) : (
                <Rocket className="h-4 w-4 text-white" />
              )}
              <span>
                {shortlistedBuilders.length > 0
                  ? `Launch Build Space (${shortlistedBuilders.length + 1} Builders)`
                  : 'Launch Build Space'}
              </span>
            </button>
          </div>

          {/* Section 4: All Want to Build Requests Stream */}
          <div className="space-y-3 pt-2">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#E5E2DA] pb-2">
              <h4 className="text-xs font-bold uppercase tracking-wider text-[#8A8578]">
                Incoming Builder Requests ({requests.length})
              </h4>

              {/* Tabs */}
              <div className="flex items-center gap-1">
                {(['all', 'interested', 'shortlisted', 'rejected'] as const).map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setActiveTab(tab)}
                    className={`rounded-lg px-2.5 py-1 text-[11px] font-semibold capitalize transition ${
                      activeTab === tab
                        ? 'bg-[#E8491D] text-white'
                        : 'text-[#55524A] hover:bg-[#FAF8F3] hover:text-[#1A1A1A]'
                    }`}
                  >
                    {tab} (
                    {tab === 'all'
                      ? requests.length
                      : tab === 'interested'
                      ? interestedBuilders.length
                      : tab === 'shortlisted'
                      ? shortlistedBuilders.length
                      : rejectedBuilders.length}
                    )
                  </button>
                ))}
              </div>
            </div>

            {loading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-5 w-5 animate-spin text-[#E8491D]" />
              </div>
            ) : filteredRequests.length === 0 ? (
              <div className="rounded-xl border border-dashed border-[#E5E2DA] p-6 text-center text-xs text-[#8A8578]">
                No requests in &ldquo;{activeTab}&rdquo; filter.
              </div>
            ) : (
              <div className="space-y-3">
                {filteredRequests.map((req) => (
                  <div
                    key={req.id}
                    className="rounded-2xl border border-[#E5E2DA] bg-[#FAF8F3] p-4.5 shadow-2xs space-y-3 transition hover:border-[#D4D0C5]"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <div className="flex items-center gap-3">
                        <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#FFFFFF] border border-[#E5E2DA] text-[#1A1A1A] text-xs font-bold">
                          {req.applicantName.charAt(0)}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-bold text-[#1A1A1A]">
                              {req.applicantName}
                            </span>
                            <span
                              className={`rounded border px-1.5 py-0.2 text-[9px] font-bold uppercase ${getSectionBadgeClass(
                                req.applicantSection
                              )}`}
                            >
                              {req.applicantSection}
                            </span>
                            {req.applicantLocation && (
                              <span className="text-[10px] text-[#8A8578]">
                                • {req.applicantLocation}
                              </span>
                            )}
                          </div>
                          <span className="text-[10px] text-[#8A8578] font-mono">
                            Applied on {new Date(req.createdAt).toLocaleDateString()}
                          </span>
                        </div>
                      </div>

                      {/* Status pill */}
                      <span
                        className={`rounded-full px-2.5 py-0.5 text-[9px] font-bold uppercase tracking-wider self-start sm:self-auto ${
                          req.status === 'shortlisted'
                            ? 'bg-amber-50 text-amber-800 border border-amber-300'
                            : req.status === 'accepted'
                            ? 'bg-emerald-50 text-emerald-800 border border-emerald-300'
                            : req.status === 'rejected'
                            ? 'bg-[#FFFFFF] text-[#8A8578] border border-[#E5E2DA]'
                            : 'bg-[#FDE4D8] text-[#E8491D] border border-[#E8491D]/40'
                        }`}
                      >
                        {req.status}
                      </span>
                    </div>

                    {/* Pitch Message */}
                    <div className="rounded-xl bg-[#FFFFFF] border border-[#E5E2DA] p-3 text-xs text-[#55524A] leading-relaxed">
                      &ldquo;{req.message}&rdquo;
                    </div>

                    {/* Skills pills */}
                    {req.skills && req.skills.length > 0 && (
                      <div className="flex flex-wrap gap-1.5 items-center">
                        <span className="text-[10px] font-semibold text-[#8A8578] uppercase tracking-wider">
                          Skills:
                        </span>
                        {req.skills.map((s, idx) => (
                          <span
                            key={idx}
                            className="rounded-md bg-[#FFFFFF] border border-[#E5E2DA] px-2 py-0.5 text-[10px] font-medium text-[#55524A]"
                          >
                            {s}
                          </span>
                        ))}
                      </div>
                    )}

                    {/* Action Bar */}
                    <div className="flex items-center justify-end gap-2 pt-2 border-t border-[#E5E2DA]">
                      {req.status === 'interested' && (
                        <>
                          <button
                            onClick={() => handleStatusChange(req, 'rejected')}
                            className="flex items-center gap-1 rounded-lg border border-[#E5E2DA] bg-[#FFFFFF] px-3 py-1.5 text-xs font-semibold text-[#55524A] hover:bg-[#FAF8F3] hover:text-[#1A1A1A]"
                          >
                            <X className="h-3.5 w-3.5" />
                            <span>Decline</span>
                          </button>

                          <button
                            onClick={() => handleStatusChange(req, 'shortlisted')}
                            className="flex items-center gap-1.5 rounded-lg bg-[#E8491D] hover:bg-[#FF5722] px-3.5 py-1.5 text-xs font-semibold text-white shadow-2xs"
                          >
                            <UserCheck className="h-3.5 w-3.5" />
                            <span>Shortlist Builder</span>
                          </button>
                        </>
                      )}

                      {req.status === 'shortlisted' && (
                        <button
                          onClick={() => handleStatusChange(req, 'interested')}
                          className="flex items-center gap-1 rounded-lg border border-rose-200 bg-rose-50 px-3 py-1.5 text-xs font-semibold text-rose-700 hover:bg-rose-100"
                        >
                          <UserX className="h-3.5 w-3.5" />
                          <span>Remove from Shortlist</span>
                        </button>
                      )}

                      {req.status === 'rejected' && (
                        <button
                          onClick={() => handleStatusChange(req, 'interested')}
                          className="text-xs font-semibold text-[#E8491D] hover:underline"
                        >
                          Reconsider Application
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
