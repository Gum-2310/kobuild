import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { CommunityPost, BuildRequest, UserSection } from '../../types';
import {
  createBuildRequest,
  withdrawBuildRequest,
} from '../../services/userService';
import {
  X,
  Rocket,
  UserPlus,
  Loader2,
  CheckCircle2,
  Trash2,
  Sparkles,
  Award,
  AlertCircle,
} from 'lucide-react';

interface WantToBuildModalProps {
  post: CommunityPost;
  existingRequest?: BuildRequest | null;
  onClose: () => void;
  onOpenAuth: (section?: UserSection | null) => void;
}

export const WantToBuildModal: React.FC<WantToBuildModalProps> = ({
  post,
  existingRequest,
  onClose,
  onOpenAuth,
}) => {
  const { user, userProfile } = useAuth();
  const [skills, setSkills] = useState(userProfile?.skills?.join(', ') || '');
  const [message, setMessage] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [withdrawing, setWithdrawing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !userProfile) {
      onOpenAuth(null);
      return;
    }
    if (!message.trim()) {
      setError('Please share a brief note on how you would like to help build this.');
      return;
    }

    setSubmitting(true);
    setError(null);
    try {
      const skillsArray = skills
        .split(',')
        .map((s) => s.trim())
        .filter(Boolean);

      await createBuildRequest(
        {
          postId: post.id,
          postTitle: post.title,
          applicantId: user.uid,
          applicantName: userProfile.name,
          applicantPhotoURL: userProfile.photoURL || null,
          applicantSection: userProfile.section,
          applicantLocation: userProfile.location || '',
          applicantBio: userProfile.bio || '',
          message: message.trim(),
          skills: skillsArray,
        },
        post.creatorId
      );

      onClose();
    } catch (err: any) {
      console.error('Failed to submit build request:', err);
      setError(err?.message || 'Failed to submit build request. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleWithdraw = async () => {
    if (!existingRequest) return;
    if (!window.confirm('Are you sure you want to withdraw your Want to Build request?')) return;

    setWithdrawing(true);
    try {
      await withdrawBuildRequest(existingRequest.id, post.id);
      onClose();
    } catch (err: any) {
      console.error('Failed to withdraw request:', err);
      setError('Failed to withdraw request.');
    } finally {
      setWithdrawing(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-[#1A1A1A]/40 p-3 sm:p-4 backdrop-blur-xs animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="w-full max-w-lg rounded-3xl border border-[#E5E2DA] bg-[#FFFFFF] shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#E5E2DA] px-6 py-4.5 bg-[#FAF8F3]">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#FDE4D8] text-[#E8491D] border border-[#E8491D]/30">
              <Rocket className="h-4.5 w-4.5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-[#1A1A1A]">Want to Build</h3>
              <p className="text-[11px] text-[#55524A] line-clamp-1 max-w-xs sm:max-w-sm">
                {post.title}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="rounded-xl p-2 text-[#8A8578] hover:bg-[#F2EFE6] hover:text-[#1A1A1A] transition"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Existing Application Status View */}
        {existingRequest ? (
          <div className="p-6 space-y-5">
            <div className="rounded-2xl border border-[#E8491D]/30 bg-[#FDE4D8]/30 p-5 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-[#E8491D]">
                  Application Status
                </span>
                <span
                  className={`rounded-full px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wider ${
                    existingRequest.status === 'shortlisted'
                      ? 'bg-amber-50 text-amber-800 border border-amber-300 animate-pulse'
                      : existingRequest.status === 'accepted'
                      ? 'bg-emerald-50 text-emerald-800 border border-emerald-300'
                      : existingRequest.status === 'rejected'
                      ? 'bg-[#FAF8F3] text-[#8A8578] border border-[#E5E2DA]'
                      : 'bg-[#FDE4D8] text-[#E8491D] border border-[#E8491D]/40'
                  }`}
                >
                  {existingRequest.status === 'shortlisted'
                    ? '🎉 Shortlisted by Lead'
                    : existingRequest.status === 'accepted'
                    ? '✅ Team Member'
                    : existingRequest.status === 'rejected'
                    ? 'Declined'
                    : 'Interested (Under Review)'}
                </span>
              </div>

              <p className="text-xs text-[#55524A] leading-relaxed">
                {existingRequest.status === 'shortlisted'
                  ? 'Great news! The idea creator has shortlisted you for their core squad. When they launch the Build Space, you will automatically be invited as a builder.'
                  : existingRequest.status === 'accepted'
                  ? 'You are an active squad member of this project Build Space!'
                  : 'You have submitted a request expressing intent to build this project. The creator will review your skills and can shortlist you for the squad.'}
              </p>

              <div className="pt-2 border-t border-[#E8491D]/20 text-xs text-[#55524A] space-y-1">
                <div>
                  <span className="font-semibold text-[#1A1A1A]">Your Message: </span>
                  <span className="text-[#55524A]">{existingRequest.message}</span>
                </div>
                {existingRequest.skills && existingRequest.skills.length > 0 && (
                  <div className="flex flex-wrap gap-1 pt-1">
                    {existingRequest.skills.map((s, idx) => (
                      <span
                        key={idx}
                        className="rounded-md bg-[#FFFFFF] border border-[#E8491D]/30 px-2 py-0.5 text-[10px] font-medium text-[#E8491D]"
                      >
                        {s}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            </div>

            <div className="flex items-center justify-between pt-2">
              <button
                type="button"
                onClick={onClose}
                className="rounded-xl border border-[#E5E2DA] px-4 py-2.5 text-xs font-semibold text-[#55524A] hover:bg-[#FAF8F3] hover:text-[#1A1A1A]"
              >
                Close
              </button>

              {existingRequest.status !== 'accepted' && (
                <button
                  type="button"
                  disabled={withdrawing}
                  onClick={handleWithdraw}
                  className="flex items-center gap-1.5 rounded-xl border border-rose-200 bg-rose-50 px-4 py-2.5 text-xs font-semibold text-rose-700 hover:bg-rose-100 transition"
                >
                  {withdrawing ? (
                    <Loader2 className="h-3.5 w-3.5 animate-spin" />
                  ) : (
                    <Trash2 className="h-3.5 w-3.5" />
                  )}
                  <span>Withdraw Request</span>
                </button>
              )}
            </div>
          </div>
        ) : (
          /* New Build Request Form */
          <form onSubmit={handleSubmit} className="p-6 space-y-4">
            {/* Context snippet */}
            <div className="rounded-2xl border border-[#E5E2DA] bg-[#FAF8F3] p-4 space-y-2">
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-[#8A8578]">
                  Target Project
                </span>
                <span className="text-xs font-bold text-[#1A1A1A]">{post.title}</span>
              </div>

              {post.teamRequirements && post.teamRequirements.length > 0 && (
                <div className="pt-2 border-t border-[#E5E2DA]">
                  <span className="text-[10px] font-bold text-[#8A8578] uppercase tracking-wider block mb-1.5">
                    Creator is looking for:
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {post.teamRequirements.map((r, i) => (
                      <span
                        key={i}
                        className="rounded-lg bg-[#FFFFFF] border border-[#E5E2DA] px-2 py-0.5 text-[11px] font-medium text-[#55524A]"
                      >
                        {r.count}x {r.role}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {error && (
              <div className="flex items-center gap-2 rounded-xl bg-rose-50 border border-rose-200 p-3 text-xs text-rose-700">
                <AlertCircle className="h-4 w-4 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <div>
              <label className="block text-xs font-bold text-[#1A1A1A] mb-1.5">
                Your Skills &amp; Stack <span className="text-[#E8491D]">*</span>
              </label>
              <input
                type="text"
                required
                value={skills}
                onChange={(e) => setSkills(e.target.value)}
                placeholder="e.g. React, Node.js, Hardware PCB, UI/UX, Growth Marketing"
                className="w-full rounded-xl border border-[#E5E2DA] bg-[#FAF8F3] px-3.5 py-2.5 text-xs text-[#1A1A1A] placeholder:text-[#8A8578] focus:border-[#E8491D] focus:outline-none shadow-2xs"
              />
              <p className="mt-1 text-[11px] text-[#8A8578]">
                Separate skills with commas so the creator can match roles.
              </p>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#1A1A1A] mb-1.5">
                How do you want to contribute? <span className="text-[#E8491D]">*</span>
              </label>
              <textarea
                rows={3}
                required
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Tell the lead why you're interested, what you've built before, or what part of the product you'd love to take ownership of..."
                className="w-full rounded-xl border border-[#E5E2DA] bg-[#FAF8F3] p-3 text-xs text-[#1A1A1A] placeholder:text-[#8A8578] focus:border-[#E8491D] focus:outline-none shadow-2xs"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-[#E5E2DA]">
              <button
                type="button"
                onClick={onClose}
                className="rounded-xl border border-[#E5E2DA] px-4 py-2.5 text-xs font-semibold text-[#55524A] hover:bg-[#FAF8F3] hover:text-[#1A1A1A]"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={submitting || !message.trim()}
                className="flex items-center gap-1.5 rounded-xl bg-[#E8491D] hover:bg-[#FF5722] px-5 py-2.5 text-xs font-semibold text-white disabled:opacity-50 transition shadow-2xs"
              >
                {submitting ? (
                  <Loader2 className="h-3.5 w-3.5 animate-spin" />
                ) : (
                  <UserPlus className="h-3.5 w-3.5" />
                )}
                <span>Send Request</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
