import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import * as SkeletonUtils from 'three/examples/jsm/utils/SkeletonUtils.js';
import {
  Maximize2,
  Minimize2,
  RotateCcw,
  ZoomIn,
  ZoomOut,
  Flame,
  Award,
  Calendar,
  User,
  ExternalLink,
  X,
  Sparkles,
  AlertCircle,
  CheckCircle2,
} from 'lucide-react';
import { ArenaParticipant, getArenaPositionForRank } from '../../types/arena';
import { UserProfile } from '../../types';
import { getAvatarById, loadAvatarGlb, AvatarDefinition } from '../../services/avatarRegistry';

interface WinterArc3DArenaProps {
  currentUser?: UserProfile | null;
  selectedAvatarId?: string;
  onOpenProfile?: () => void;
  className?: string;
}

export const WinterArc3DArena: React.FC<WinterArc3DArenaProps> = ({
  currentUser,
  selectedAvatarId,
  onOpenProfile,
  className = '',
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // Loading & Scene State
  const [isLoading, setIsLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [loadBytesLoaded, setLoadBytesLoaded] = useState<number>(0);
  const [loadPercent, setLoadPercent] = useState<number>(0);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showAvatarCard, setShowAvatarCard] = useState(false);
  const [activeAssetSource, setActiveAssetSource] = useState<string>('Avatar 1 (M01)');

  // Single participant data: Strictly 1 participant at Rank #1
  const [participant, setParticipant] = useState<ArenaParticipant>({
    participantId: currentUser?.uid || 'winter-arc-leader',
    userId: currentUser?.uid || 'user-1',
    avatarId: selectedAvatarId || 'M01',
    userName: currentUser?.name || 'YOU',
    userPhotoURL: currentUser?.photoURL || null,
    score: 1920,
    rank: 1,
    streak: 18,
    progress: 24, // Day 24 of 90
    position: getArenaPositionForRank(1), // [0, 0, 0] Center of arena
    isCurrentUser: true,
    tierBadge: 'Champion Tier',
  });

  const activeAvatarDef: AvatarDefinition = getAvatarById(selectedAvatarId || participant.avatarId);

  // Keep participant synced with currentUser and selected avatar
  useEffect(() => {
    if (currentUser || selectedAvatarId) {
      setParticipant((prev) => ({
        ...prev,
        userId: currentUser?.uid || prev.userId,
        userName: currentUser?.name || prev.userName,
        userPhotoURL: currentUser?.photoURL || prev.userPhotoURL,
        avatarId: selectedAvatarId || prev.avatarId,
      }));
    }
  }, [currentUser, selectedAvatarId]);

  // Three.js References
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const mixerRef = useRef<THREE.AnimationMixer | null>(null);
  const avatarGroupRef = useRef<THREE.Group | null>(null);
  const glowingRingRef = useRef<THREE.Mesh | null>(null);
  const pointerDownPos = useRef<{ x: number; y: number }>({ x: 0, y: 0 });

  // Camera framing: Centered on the athletic avatar's chest/torso at height ~1.05m
  const INITIAL_CAM_POS: [number, number, number] = [0, 2.25, 4.8];
  const INITIAL_CAM_TARGET: [number, number, number] = [0, 1.05, 0];

  // Helper to cleanly dispose of 3D objects and release GPU memory
  const cleanUpAvatarGroup = () => {
    if (avatarGroupRef.current && sceneRef.current) {
      sceneRef.current.remove(avatarGroupRef.current);
      avatarGroupRef.current.traverse((child: any) => {
        if (child.geometry) child.geometry.dispose();
        if (child.material) {
          if (Array.isArray(child.material)) {
            child.material.forEach((mat: any) => {
              if (mat.map) mat.map.dispose();
              if (mat.normalMap) mat.normalMap.dispose();
              if (mat.roughnessMap) mat.roughnessMap.dispose();
              if (mat.metalnessMap) mat.metalnessMap.dispose();
              mat.dispose();
            });
          } else {
            if (child.material.map) child.material.map.dispose();
            if (child.material.normalMap) child.material.normalMap.dispose();
            if (child.material.roughnessMap) child.material.roughnessMap.dispose();
            if (child.material.metalnessMap) child.material.metalnessMap.dispose();
            child.material.dispose();
          }
        }
      });
      avatarGroupRef.current = null;
    }
    if (mixerRef.current) {
      mixerRef.current.stopAllAction();
      mixerRef.current = null;
    }
  };

  // Load the authentic GLB model dynamically from the avatar registry
  const loadAvatarModel = useCallback((targetAvatarId?: string) => {
    if (!sceneRef.current) return;
    const avatarToLoad = targetAvatarId || selectedAvatarId || participant.avatarId || 'M01';
    const avatarDef = getAvatarById(avatarToLoad);

    setIsLoading(true);
    setLoadError(null);
    setLoadPercent(5);
    setLoadBytesLoaded(0);

    loadAvatarGlb(avatarDef.id, (percent, loaded) => {
      setLoadBytesLoaded(loaded);
      setLoadPercent(percent);
    })
      .then(({ gltf, definition }) => {
        if (!sceneRef.current) return;

        cleanUpAvatarGroup();

        const rawModel = gltf.scene;
        const model = SkeletonUtils.clone(rawModel);

        // Ensure shadow casting without overriding or modifying textures/materials
        model.traverse((child: any) => {
          if (child.isMesh) {
            child.castShadow = true;
            child.receiveShadow = true;
            // Retain original PBR textures & materials as defined by the GLB asset
            if (child.material) {
              child.material.needsUpdate = true;
            }
          }
        });

        // Calculate model bounding box
        const box = new THREE.Box3().setFromObject(model);
        const size = new THREE.Vector3();
        box.getSize(size);

        // Model height normalization: Target 1.88m athletic adult height.
        const naturalHeight = size.y || 1.88;
        const targetHeight = 1.88;
        const scale = targetHeight / naturalHeight;
        model.scale.set(scale, scale, scale);

        // Re-calculate after scaling so feet sit flush at Y = 0 on top of the dais
        const scaledBox = new THREE.Box3().setFromObject(model);
        const bottomY = scaledBox.min.y;
        const centerX = (scaledBox.max.x + scaledBox.min.x) / 2;
        const centerZ = (scaledBox.max.z + scaledBox.min.z) / 2;

        // Position model centered on the dais
        model.position.set(-centerX, -bottomY, -centerZ);

        // Wrap in participant group
        const avatarGroup = new THREE.Group();
        avatarGroup.name = `AvatarParticipant_${definition.id}`;
        avatarGroup.add(model);

        // Place at exact Rank #1 center position [0, 0, 0]
        const [posX, posY, posZ] = getArenaPositionForRank(1);
        avatarGroup.position.set(posX, posY, posZ);

        // Vertices naturally face +Z toward the camera
        avatarGroup.rotation.y = 0;

        sceneRef.current.add(avatarGroup);
        avatarGroupRef.current = avatarGroup;

        // Check for animations if any
        if (gltf.animations && gltf.animations.length > 0) {
          const mixer = new THREE.AnimationMixer(model);
          const action = mixer.clipAction(gltf.animations[0]);
          action.play();
          mixerRef.current = mixer;
        }

        setIsLoading(false);
        setLoadPercent(100);
        setActiveAssetSource(`${definition.name} (${definition.id})`);
      })
      .catch((err) => {
        console.error(`Failed to load avatar ${avatarDef.name}:`, err);
        setLoadError(
          `Failed to load 3D GLB model for ${avatarDef.name}. Reason: ${
            (err as any)?.message || 'Network/CORS error'
          }`
        );
        setIsLoading(false);
      });
  }, [selectedAvatarId, participant.avatarId]);

  // Main Three.js Scene Setup & Loop
  useEffect(() => {
    if (!mountRef.current) return;

    const container = mountRef.current;
    const width = container.clientWidth || 800;
    const height = container.clientHeight || 560;

    // 1. Scene
    const scene = new THREE.Scene();
    sceneRef.current = scene;
    scene.background = new THREE.Color(0xf6f3ec); // Warm architectural light stone background
    scene.fog = new THREE.FogExp2(0xf0ece4, 0.014); // Soft depth haze

    // 2. Camera
    const camera = new THREE.PerspectiveCamera(42, width / height, 0.1, 150);
    camera.position.set(...INITIAL_CAM_POS);
    cameraRef.current = camera;

    // 3. Renderer with SRGB color space and ACES tone mapping for authentic PBR colors
    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      powerPreference: 'high-performance',
      alpha: false,
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.06;
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    container.innerHTML = '';
    container.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // 4. OrbitControls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.minDistance = 1.1; // Allows close-up inspection of the avatar's face, hair, and clothing
    controls.maxDistance = 28.0;
    controls.maxPolarAngle = Math.PI / 2 - 0.03; // Never dip below the arena floor
    controls.minPolarAngle = 0.05;
    controls.target.set(...INITIAL_CAM_TARGET);
    controlsRef.current = controls;

    // 5. Existing Winter Arc Amphitheater Architecture (Preserved)
    // Materials
    const floorMat = new THREE.MeshStandardMaterial({
      color: 0xded9cf,
      roughness: 0.65,
      metalness: 0.08,
    });

    const daisMat = new THREE.MeshStandardMaterial({
      color: 0xf5efe6,
      roughness: 0.45,
      metalness: 0.12,
    });

    const tierStoneMat = new THREE.MeshStandardMaterial({
      color: 0xe5e0d5,
      roughness: 0.72,
      metalness: 0.05,
    });

    const ledGlowMat = new THREE.MeshBasicMaterial({
      color: 0xff9944,
    });

    const accentRingMat = new THREE.MeshBasicMaterial({
      color: 0xe8491d,
      side: THREE.DoubleSide,
    });

    // Central Arena Floor
    const floorGeo = new THREE.CircleGeometry(42, 64);
    const floorMesh = new THREE.Mesh(floorGeo, floorMat);
    floorMesh.rotation.x = -Math.PI / 2;
    floorMesh.position.y = -0.01;
    floorMesh.receiveShadow = true;
    scene.add(floorMesh);

    // Central Raised Dais (Podium where Rank #1 stands)
    const daisGeo = new THREE.CylinderGeometry(2.6, 2.9, 0.28, 64);
    const daisMesh = new THREE.Mesh(daisGeo, daisMat);
    daisMesh.position.y = -0.14; // Top surface sits exactly at Y = 0
    daisMesh.receiveShadow = true;
    daisMesh.castShadow = true;
    scene.add(daisMesh);

    // Glowing Neon Accent Ring directly beneath avatar's feet
    const glowingRingGeo = new THREE.RingGeometry(1.25, 1.34, 64);
    const glowingRing = new THREE.Mesh(glowingRingGeo, accentRingMat);
    glowingRing.rotation.x = -Math.PI / 2;
    glowingRing.position.y = 0.005;
    scene.add(glowingRing);
    glowingRingRef.current = glowingRing;

    // Outer concentric ring on the dais
    const daisOuterRingGeo = new THREE.RingGeometry(2.2, 2.25, 64);
    const daisOuterRingMat = new THREE.MeshBasicMaterial({ color: 0xd6cfc2, side: THREE.DoubleSide });
    const daisOuterRing = new THREE.Mesh(daisOuterRingGeo, daisOuterRingMat);
    daisOuterRing.rotation.x = -Math.PI / 2;
    daisOuterRing.position.y = 0.005;
    scene.add(daisOuterRing);

    // Concentric Stepped Seating / Amphitheater Terraces
    const tiersGroup = new THREE.Group();
    const tierCount = 7;
    const baseRadius = 5.2;
    const tierWidth = 2.4;
    const stepHeight = 0.42;

    for (let i = 0; i < tierCount; i++) {
      const innerR = baseRadius + i * tierWidth;
      const outerR = innerR + tierWidth;
      const currentY = (i + 1) * stepHeight;

      // Platform shelf
      const ringGeo = new THREE.RingGeometry(innerR, outerR, 64);
      const ringMesh = new THREE.Mesh(ringGeo, tierStoneMat);
      ringMesh.rotation.x = -Math.PI / 2;
      ringMesh.position.y = currentY;
      ringMesh.receiveShadow = true;
      tiersGroup.add(ringMesh);

      // Riser face
      const riserGeo = new THREE.CylinderGeometry(innerR, innerR, stepHeight, 64, 1, true);
      const riserMesh = new THREE.Mesh(riserGeo, tierStoneMat);
      riserMesh.position.y = currentY - stepHeight / 2;
      riserMesh.receiveShadow = true;
      tiersGroup.add(riserMesh);

      // Warm architectural LED strip under the lip of each step
      const ledGeo = new THREE.TorusGeometry(innerR + 0.04, 0.025, 8, 64);
      const ledMesh = new THREE.Mesh(ledGeo, ledGlowMat);
      ledMesh.rotation.x = Math.PI / 2;
      ledMesh.position.y = currentY - 0.02;
      tiersGroup.add(ledMesh);
    }
    scene.add(tiersGroup);

    // Outer Monumental Architectural Columns / Colonnade surrounding the amphitheater
    const colonnadeGroup = new THREE.Group();
    const columnCount = 28;
    const colonnadeRadius = baseRadius + tierCount * tierWidth + 2.0;
    const columnHeight = 11;

    for (let c = 0; c < columnCount; c++) {
      const angle = (c / columnCount) * Math.PI * 2;
      const colX = Math.cos(angle) * colonnadeRadius;
      const colZ = Math.sin(angle) * colonnadeRadius;

      const colGeo = new THREE.BoxGeometry(0.7, columnHeight, 1.4);
      const colMesh = new THREE.Mesh(colGeo, tierStoneMat);
      colMesh.position.set(colX, columnHeight / 2 + 2.5, colZ);
      colMesh.lookAt(0, columnHeight / 2 + 2.5, 0);
      colMesh.castShadow = true;
      colMesh.receiveShadow = true;
      colonnadeGroup.add(colMesh);

      const finLedGeo = new THREE.BoxGeometry(0.08, columnHeight * 0.8, 0.04);
      const finLed = new THREE.Mesh(finLedGeo, ledGlowMat);
      finLed.position.set(0, 0, 0.72);
      colMesh.add(finLed);
    }
    scene.add(colonnadeGroup);

    // 6. Lighting: Balanced to accurately showcase athletic skin tones, tank top, and shorts
    const ambientLight = new THREE.AmbientLight(0xffffff, 1.15);
    scene.add(ambientLight);

    // Main Key Light (Warm sunlight angled toward avatar)
    const keyLight = new THREE.DirectionalLight(0xfff8ee, 2.2);
    keyLight.position.set(5.5, 9.0, 7.0);
    keyLight.castShadow = true;
    keyLight.shadow.mapSize.width = 2048;
    keyLight.shadow.mapSize.height = 2048;
    keyLight.shadow.camera.near = 0.5;
    keyLight.shadow.camera.far = 40;
    keyLight.shadow.camera.left = -6;
    keyLight.shadow.camera.right = 6;
    keyLight.shadow.camera.top = 6;
    keyLight.shadow.camera.bottom = -6;
    keyLight.shadow.bias = -0.0003;
    scene.add(keyLight);

    // Fill Light (Soft cool bounce from rear)
    const fillLight = new THREE.DirectionalLight(0xdce7f5, 0.9);
    fillLight.position.set(-6, 6, -5);
    scene.add(fillLight);

    // Center Stage Hero Spotlight focused directly on the avatar
    const heroSpot = new THREE.SpotLight(0xffedd9, 2.0);
    heroSpot.position.set(0, 8.5, 2.0);
    heroSpot.target.position.set(0, 1.05, 0);
    heroSpot.angle = Math.PI / 4.5;
    heroSpot.penumbra = 0.65;
    heroSpot.castShadow = true;
    heroSpot.shadow.mapSize.width = 1024;
    heroSpot.shadow.mapSize.height = 1024;
    scene.add(heroSpot);
    scene.add(heroSpot.target);

    // Warm base point light for arena stage ambiance
    const footLight = new THREE.PointLight(0xe8491d, 1.2, 3.5);
    footLight.position.set(0, 0.25, 0);
    scene.add(footLight);

    // 7. Trigger the GLB load
    // Initial model load
    loadAvatarModel();

    // 8. Animation & Render Loop
    let animationFrameId: number;
    const clock = new THREE.Clock();

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      const delta = clock.getDelta();
      const time = clock.getElapsedTime();

      if (mixerRef.current) {
        mixerRef.current.update(delta);
      }

      // Gentle pulsating glow for the circular dais accent ring
      if (glowingRingRef.current) {
        const pulse = 0.82 + Math.sin(time * 2.2) * 0.18;
        (glowingRingRef.current.material as THREE.MeshBasicMaterial).opacity = pulse;
      }

      controls.update();
      renderer.render(scene, camera);
    };

    animate();

    // 9. Resize Handling
    const handleResize = () => {
      if (!mountRef.current || !rendererRef.current || !cameraRef.current) return;
      const newWidth = mountRef.current.clientWidth;
      const newHeight = mountRef.current.clientHeight;
      cameraRef.current.aspect = newWidth / newHeight;
      cameraRef.current.updateProjectionMatrix();
      rendererRef.current.setSize(newWidth, newHeight);
    };

    window.addEventListener('resize', handleResize);

    // Cleanup on unmount
    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationFrameId);

      cleanUpAvatarGroup();

      controls.dispose();
      renderer.dispose();
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, []); // Run once on mount

  // Smoothly swap and reload avatar model when selectedAvatarId or participant.avatarId changes
  useEffect(() => {
    if (sceneRef.current) {
      const targetId = selectedAvatarId || participant.avatarId;
      if (targetId) {
        loadAvatarModel(targetId);
      }
    }
  }, [selectedAvatarId, participant.avatarId, loadAvatarModel]);

  // Raycasting Avatar Click Handler
  const handlePointerDown = (e: React.PointerEvent) => {
    pointerDownPos.current = { x: e.clientX, y: e.clientY };
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    const dx = Math.abs(e.clientX - pointerDownPos.current.x);
    const dy = Math.abs(e.clientY - pointerDownPos.current.y);
    if (dx > 7 || dy > 7) return; // Distinguish orbit drag from click

    if (!mountRef.current || !cameraRef.current || !sceneRef.current) return;

    const rect = mountRef.current.getBoundingClientRect();
    const mouse = new THREE.Vector2(
      ((e.clientX - rect.left) / rect.width) * 2 - 1,
      -((e.clientY - rect.top) / rect.height) * 2 + 1
    );

    const raycaster = new THREE.Raycaster();
    raycaster.setFromCamera(mouse, cameraRef.current);

    if (avatarGroupRef.current) {
      const intersects = raycaster.intersectObjects(avatarGroupRef.current.children, true);
      if (intersects.length > 0) {
        setShowAvatarCard((prev) => !prev);
      }
    }
  };

  // Camera Controls
  const handleResetCamera = () => {
    if (!cameraRef.current || !controlsRef.current) return;
    cameraRef.current.position.set(...INITIAL_CAM_POS);
    controlsRef.current.target.set(...INITIAL_CAM_TARGET);
    controlsRef.current.update();
  };

  const handleZoomIn = () => {
    if (!cameraRef.current || !controlsRef.current) return;
    const cam = cameraRef.current;
    const target = controlsRef.current.target;
    const dir = new THREE.Vector3().subVectors(target, cam.position).normalize();
    cam.position.addScaledVector(dir, 1.2);
    controlsRef.current.update();
  };

  const handleZoomOut = () => {
    if (!cameraRef.current || !controlsRef.current) return;
    const cam = cameraRef.current;
    const target = controlsRef.current.target;
    const dir = new THREE.Vector3().subVectors(cam.position, target).normalize();
    cam.position.addScaledVector(dir, 1.2);
    controlsRef.current.update();
  };

  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen().catch((err) => {
        console.warn('Fullscreen error:', err);
      });
      setIsFullscreen(true);
    } else {
      document.exitFullscreen().catch((err) => {
        console.warn('Exit fullscreen error:', err);
      });
      setIsFullscreen(false);
    }
  };

  useEffect(() => {
    const handleFsChange = () => {
      setIsFullscreen(Boolean(document.fullscreenElement));
    };
    document.addEventListener('fullscreenchange', handleFsChange);
    return () => document.removeEventListener('fullscreenchange', handleFsChange);
  }, []);

  return (
    <div
      ref={containerRef}
      className={`relative w-full overflow-hidden rounded-3xl border border-[#E5E2DA] bg-[#F6F3EC] shadow-md select-none ${
        isFullscreen ? 'fixed inset-0 z-50 rounded-none h-screen' : 'h-[620px] sm:h-[680px]'
      } ${className}`}
    >
      {/* 3D Canvas Mounting Container */}
      <div
        ref={mountRef}
        className="w-full h-full cursor-grab active:cursor-grabbing touch-none"
        onPointerDown={handlePointerDown}
        onPointerUp={handlePointerUp}
      />

      {/* TOP ARENA OVERLAY (KOBUILD Brand & Challenge Milestone Status) */}
      <div className="absolute top-4 left-4 right-4 pointer-events-none flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 z-10">
        {/* Challenge Brand Pill */}
        <div className="pointer-events-auto bg-[#FFFFFF]/92 backdrop-blur-md border border-[#E5E2DA] rounded-2xl p-3.5 shadow-sm space-y-0.5 max-w-sm">
          <div className="flex items-center gap-2">
            <span className="flex h-6 w-6 items-center justify-center rounded-lg bg-[#E8491D] text-white">
              <Flame className="h-3.5 w-3.5 fill-current" />
            </span>
            <h2 className="text-sm font-black text-[#1A1A1A] tracking-tight uppercase">
              90 DAY WINTER ARC
            </h2>
            <span className="px-2 py-0.5 rounded-full bg-[#FDE4D8] text-[#E8491D] text-[10px] font-black tracking-wide uppercase">
              Virtual Arena
            </span>
          </div>
          <p className="text-[11px] font-medium text-[#55524A] pl-8">
            Discipline • Health • Better You
          </p>
        </div>

        {/* Milestone & Participant Status Badges */}
        <div className="pointer-events-auto flex items-center gap-2">
          {/* Day Progress Pill */}
          <div className="flex items-center gap-2 bg-[#FFFFFF]/92 backdrop-blur-md border border-[#E5E2DA] rounded-2xl px-3.5 py-2 shadow-sm">
            <Calendar className="h-4 w-4 text-[#E8491D]" />
            <div className="text-left">
              <p className="text-[10px] font-semibold text-[#8A8578] uppercase tracking-wider">Timeline</p>
              <p className="text-xs font-black text-[#1A1A1A]">Day 24 / 90</p>
            </div>
          </div>

          {/* EXACTLY 1 PARTICIPANT BADGE */}
          <div className="flex items-center gap-2 bg-[#FFFFFF]/92 backdrop-blur-md border border-[#E5E2DA] rounded-2xl px-3.5 py-2 shadow-sm">
            <div className="flex h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
            <div className="text-left">
              <p className="text-[10px] font-semibold text-[#8A8578] uppercase tracking-wider">Live In Arena</p>
              <p className="text-xs font-black text-[#1A1A1A]">1 Participant (Rank #1)</p>
            </div>
          </div>
        </div>
      </div>

      {/* QUICK INTERACTION HINT & ASSET VERIFICATION (Subtle footer pill) */}
      <div className="absolute bottom-4 left-4 pointer-events-none z-10 hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-xl bg-[#FFFFFF]/85 backdrop-blur-sm border border-[#E5E2DA] text-[11px] text-[#55524A] shadow-xs">
        <Sparkles className="h-3.5 w-3.5 text-[#E8491D]" />
        <span>Drag to orbit • Scroll to zoom • Click avatar for details</span>
        {!isLoading && !loadError && (
          <span className="inline-flex items-center gap-1 text-[10px] text-emerald-700 font-semibold bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
            <CheckCircle2 className="h-3 w-3 text-emerald-600" />
            <span>3D GLB Loaded ({activeAssetSource})</span>
          </span>
        )}
      </div>

      {/* FLOATING CONTROLS TOOLBAR */}
      <div className="absolute bottom-4 right-4 z-10 flex items-center gap-1.5 bg-[#FFFFFF]/92 backdrop-blur-md border border-[#E5E2DA] p-1.5 rounded-2xl shadow-md">
        {/* Zoom In */}
        <button
          id="btn-arena-zoom-in"
          onClick={handleZoomIn}
          title="Zoom in to inspect avatar"
          className="p-2 rounded-xl text-[#55524A] hover:text-[#1A1A1A] hover:bg-[#F2EFE6] transition"
        >
          <ZoomIn className="h-4 w-4" />
        </button>

        {/* Zoom Out */}
        <button
          id="btn-arena-zoom-out"
          onClick={handleZoomOut}
          title="Zoom out"
          className="p-2 rounded-xl text-[#55524A] hover:text-[#1A1A1A] hover:bg-[#F2EFE6] transition"
        >
          <ZoomOut className="h-4 w-4" />
        </button>

        {/* Reset View */}
        <button
          id="btn-arena-reset-view"
          onClick={handleResetCamera}
          title="Reset camera to default angle"
          className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold text-[#1A1A1A] hover:bg-[#F2EFE6] transition"
        >
          <RotateCcw className="h-3.5 w-3.5 text-[#E8491D]" />
          <span className="hidden sm:inline">Reset View</span>
        </button>

        <div className="h-4 w-px bg-[#E5E2DA] mx-0.5" />

        {/* Fullscreen Toggle */}
        <button
          id="btn-arena-fullscreen"
          onClick={toggleFullscreen}
          title={isFullscreen ? 'Exit fullscreen' : 'Enter fullscreen'}
          className="p-2 rounded-xl text-[#55524A] hover:text-[#1A1A1A] hover:bg-[#F2EFE6] transition"
        >
          {isFullscreen ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
        </button>
      </div>

      {/* AVATAR CLICK INFORMATION CARD OVERLAY */}
      {showAvatarCard && (
        <div className="absolute top-20 right-4 sm:top-24 sm:right-6 z-20 w-72 rounded-3xl border border-[#E5E2DA] bg-[#FFFFFF]/95 backdrop-blur-md p-5 shadow-2xl animate-in fade-in zoom-in-95 duration-200">
          <div className="flex items-start justify-between border-b border-[#E5E2DA] pb-3 mb-3">
            <div className="flex items-center gap-2.5">
              <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-[#FDE4D8] text-[#E8491D] font-bold text-sm overflow-hidden border border-[#E8491D]/30">
                {participant.userPhotoURL ? (
                  <img
                    src={participant.userPhotoURL}
                    alt={participant.userName}
                    className="h-full w-full object-cover"
                  />
                ) : (
                  <User className="h-5 w-5" />
                )}
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="text-xs font-black text-[#1A1A1A] uppercase tracking-wide">
                    {participant.userName}
                  </span>
                  {participant.isCurrentUser && (
                    <span className="px-1.5 py-0.2 rounded bg-[#E8491D] text-white text-[9px] font-black uppercase">
                      YOU
                    </span>
                  )}
                </div>
                <p className="text-[11px] font-semibold text-[#E8491D] flex items-center gap-1">
                  <Award className="h-3 w-3" />
                  <span>Rank #{participant.rank} (Arena Center)</span>
                </p>
              </div>
            </div>

            <button
              onClick={() => setShowAvatarCard(false)}
              className="p-1 rounded-lg text-[#8A8578] hover:text-[#1A1A1A] hover:bg-[#F2EFE6] transition"
            >
              <X className="h-4 w-4" />
            </button>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-2 gap-2 mb-4">
            <div className="rounded-2xl bg-[#FAF8F3] border border-[#E5E2DA] p-2.5 text-center">
              <p className="text-[10px] font-semibold uppercase text-[#8A8578]">Score</p>
              <p className="text-base font-black text-[#1A1A1A]">
                {participant.score.toLocaleString()}
              </p>
            </div>

            <div className="rounded-2xl bg-[#FAF8F3] border border-[#E5E2DA] p-2.5 text-center">
              <p className="text-[10px] font-semibold uppercase text-[#8A8578]">Current Streak</p>
              <p className="text-base font-black text-[#E8491D] flex items-center justify-center gap-1">
                <span>{participant.streak} days</span>
                <Flame className="h-3.5 w-3.5 fill-current" />
              </p>
            </div>
          </div>

          {/* Active 3D Avatar Asset Pill */}
          <div className="rounded-2xl bg-[#FAF8F3] border border-[#E5E2DA] p-2.5 mb-3 flex items-center justify-between text-xs">
            <span className="text-[#8A8578] font-bold">Arena Avatar</span>
            <span className="font-black text-[#1A1A1A]">
              {activeAvatarDef.name} ({activeAvatarDef.id})
            </span>
          </div>

          {/* Progress Timeline in Challenge */}
          <div className="rounded-2xl bg-[#F2EFE6]/60 border border-[#E5E2DA] p-3 mb-4 space-y-1.5">
            <div className="flex items-center justify-between text-xs font-bold text-[#1A1A1A]">
              <span>Challenge Checkpoint</span>
              <span className="text-[#E8491D]">Day {participant.progress} of 90</span>
            </div>
            <div className="w-full h-2 rounded-full bg-[#E5E2DA] overflow-hidden">
              <div
                className="h-full rounded-full bg-[#E8491D] transition-all duration-500"
                style={{ width: `${(participant.progress / 90) * 100}%` }}
              />
            </div>
          </div>

          {/* View Profile Action */}
          <button
            id="btn-arena-view-profile"
            onClick={() => {
              setShowAvatarCard(false);
              if (onOpenProfile) onOpenProfile();
            }}
            className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-[#1A1A1A] hover:bg-[#000000] text-white text-xs font-bold transition shadow-sm"
          >
            <span>View Profile</span>
            <ExternalLink className="h-3.5 w-3.5" />
          </button>
        </div>
      )}

      {/* LOADING STATE OVERLAY */}
      {isLoading && (
        <div className="absolute inset-0 bg-[#F6F3EC]/90 backdrop-blur-sm z-30 flex flex-col items-center justify-center p-6 text-center">
          <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-white border border-[#E5E2DA] shadow-sm mb-4">
            <Flame className="h-7 w-7 text-[#E8491D] animate-bounce" />
          </div>
          <h3 className="text-sm font-bold text-[#1A1A1A] mb-1">
            Loading Winter Arc 3D Arena
          </h3>
          <p className="text-xs text-[#8A8578] max-w-sm mb-3">
            Loading 3D GLB model for {activeAvatarDef.name}... (
            {loadBytesLoaded > 0
              ? `${(loadBytesLoaded / (1024 * 1024)).toFixed(1)} MB`
              : 'Connecting to asset server...'}
            )
          </p>
          <div className="w-56 h-2 rounded-full bg-[#E5E2DA] overflow-hidden">
            <div
              className="h-full bg-[#E8491D] transition-all duration-200 rounded-full"
              style={{ width: `${Math.max(loadPercent, 8)}%` }}
            />
          </div>
          <span className="text-[11px] font-semibold text-[#55524A] mt-2 font-mono">
            {loadPercent}%
          </span>
        </div>
      )}

      {/* CLEAR ERROR NOTIFICATION IF FILE FAILS TO LOAD */}
      {loadError && (
        <div className="absolute inset-0 bg-[#F6F3EC]/95 backdrop-blur-md z-30 flex flex-col items-center justify-center p-6 text-center space-y-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-rose-100 text-rose-800 border border-rose-200">
            <AlertCircle className="h-6 w-6" />
          </div>
          <div className="max-w-md space-y-2">
            <h4 className="text-sm font-bold text-[#1A1A1A]">Avatar Loading Error</h4>
            <p className="text-xs text-[#E8491D] font-mono break-all bg-white p-3 rounded-xl border border-[#E5E2DA] text-left">
              {loadError}
            </p>
            <p className="text-xs text-[#8A8578]">
              Target URL: <code>{activeAvatarDef.glbUrl}</code>
            </p>
          </div>
          <button
            onClick={() => loadAvatarModel()}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#E8491D] text-white text-xs font-bold shadow hover:bg-[#D03E15] transition"
          >
            <RotateCcw className="h-4 w-4" />
            <span>Retry Loading GLB</span>
          </button>
        </div>
      )}
    </div>
  );
};
