import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import {
  Community,
  CommunityMember,
  CommunityJoinRequest,
  ChallengeSubmission,
  AppView,
  UserSection,
} from '../../types';
import {
  subscribeCommunityMembers,
  subscribeCommunityJoinRequests,
  subscribeUserMembershipStatus,
  subscribeUserJoinRequestStatus,
  requestToJoinCommunity,
  joinPublicCommunity,
  leaveCommunity,
  handleJoinRequest,
  removeCommunityMember,
  subscribeCommunitySubmissions,
  submitChallengeDailyEntry,
  calculateLeaderboard,
  updateCommunityMemberAvatar,
} from '../../services/communityService';
import {
  ArrowLeft,
  Users,
  Flame,
  Sparkles,
  Award,
  Shield,
  Clock,
  MapPin,
  Calendar,
  CheckCircle2,
  XCircle,
  Plus,
  Lock,
  Share2,
  Trophy,
  Check,
  AlertCircle,
  Loader2,
  ChevronRight,
  UserX,
  UserCheck,
  Camera,
  X,
} from 'lucide-react';
import { UserProfilePopover } from '../UserProfilePopover';
import { WinterArc3DArena } from './WinterArc3DArena';
import { PublicCommunityJoinView } from './PublicCommunityJoinView';
import { AvatarOnboardingView } from './AvatarOnboardingView';

interface CommunitySpaceViewProps {
  community: Community;
  onBack: () => void;
  onOpenAuth: (section?: UserSection | null) => void;
  onNavigate: (view: AppView, section?: UserSection) => void;
}

export const CommunitySpaceView: React.FC<CommunitySpaceViewProps> = ({
  community,
  onBack,
  onOpenAuth,
  onNavigate,
}) => {
  const { user, userProfile, isAdmin } = useAuth();

  const isWinterArc =
    community.id === 'kobuild-winter-arc-90' ||
    community.title.toUpperCase().includes('WINTER ARC');

  // Active sub-navigation tab (simplified to active core spaces)
  const [activeTab, setActiveTab] = useState<
    'arena' | 'challenge' | 'progress' | 'leaderboard' | 'members'
  >(isWinterArc ? 'arena' : community.hasChallenge ? 'challenge' : 'members');

  // Real-time Subscriptions State
  const [members, setMembers] = useState<CommunityMember[]>([]);
  const [joinRequests, setJoinRequests] = useState<CommunityJoinRequest[]>([]);
  const [myMembership, setMyMembership] = useState<CommunityMember | null>(null);
  const [myJoinRequest, setMyJoinRequest] = useState<CommunityJoinRequest | null>(null);
  const [submissions, setSubmissions] = useState<ChallengeSubmission[]>([]);

  // Member management sub-tab (for creator/admin)
  const [memberManagementTab, setMemberManagementTab] = useState<'members' | 'pending' | 'rejected'>('members');

  // Actions & Form Inputs State
  const [joinMessageInput, setJoinMessageInput] = useState('');
  const [showJoinModal, setShowJoinModal] = useState(false);
  const [actionLoading, setActionLoading] = useState(false);

  // Challenge Daily Submission State
  const [submissionDay, setSubmissionDay] = useState<number>(1);
  const [submissionDate, setSubmissionDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [submissionItemValues, setSubmissionItemValues] = useState<Record<string, string>>({});
  const [submittingChallenge, setSubmittingChallenge] = useState(false);
  const [submissionSuccessMsg, setSubmissionSuccessMsg] = useState<string | null>(null);

  // Target user profile popover state
  const [popoverUser, setPopoverUser] = useState<{
    uid: string;
    name: string;
    photoURL?: string | null;
    bio?: string;
    skills?: string[];
  } | null>(null);

  // Share notification state
  const [copiedLink, setCopiedLink] = useState(false);

  const [isCheckingMembership, setIsCheckingMembership] = useState<boolean>(Boolean(user));

  const isCreator = user ? community.creatorId === user.uid : false;
  const canManage = Boolean(isAdmin) || (community.type === 'open' && isCreator);
  const isMember = Boolean(myMembership);
  const isPending = myJoinRequest?.status === 'pending';
  const isRejected = myJoinRequest?.status === 'rejected';
  const hasAccess = isMember || isCreator || Boolean(isAdmin);

  // Avatar onboarding check: required for Winter Arc community when user has confirmed access but no avatar selected
  const needsAvatarSetup = Boolean(
    hasAccess &&
    isWinterArc &&
    user &&
    (!myMembership || !myMembership.avatarId)
  );

  // Subscriptions setup - strictly only active when user has confirmed community access
  useEffect(() => {
    if (!hasAccess) {
      setMembers([]);
      setJoinRequests([]);
      setSubmissions([]);
      return;
    }

    const unsubMembers = subscribeCommunityMembers(community.id, setMembers);
    const unsubRequests = canManage ? subscribeCommunityJoinRequests(community.id, setJoinRequests) : () => {};
    const unsubSubs = subscribeCommunitySubmissions(community.id, setSubmissions);

    return () => {
      unsubMembers();
      unsubRequests();
      unsubSubs();
    };
  }, [community.id, hasAccess, canManage]);

  // User membership & join request status subscription
  useEffect(() => {
    if (!user) {
      setMyMembership(null);
      setMyJoinRequest(null);
      setIsCheckingMembership(false);
      return;
    }

    setIsCheckingMembership(true);
    const unsubMemStatus = subscribeUserMembershipStatus(community.id, user.uid, (member) => {
      setMyMembership(member);
      setIsCheckingMembership(false);
    });
    const unsubReqStatus = subscribeUserJoinRequestStatus(community.id, user.uid, (req) => {
      setMyJoinRequest(req);
    });

    return () => {
      unsubMemStatus();
      unsubReqStatus();
    };
  }, [community.id, user]);

  // Sync initial challenge submission day based on submissions count
  useEffect(() => {
    if (submissions.length > 0 && user) {
      const mySubCount = submissions.filter((s) => s.userId === user.uid).length;
      setSubmissionDay(Math.min(mySubCount + 1, community.challengeConfig?.totalDays || 90));
    }
  }, [submissions, user, community.challengeConfig]);

  // Leaderboard Calculation for Challenges
  const leaderboard = React.useMemo(() => {
    return calculateLeaderboard(submissions, members);
  }, [submissions, members]);

  const myProgress = React.useMemo(() => {
    if (!user) return null;
    return leaderboard.find((p) => p.userId === user.uid) || null;
  }, [leaderboard, user]);

  // Join Community Action
  const handleJoinClick = async () => {
    if (!user || !userProfile) {
      onOpenAuth();
      return;
    }

    if (community.requireApproval) {
      setShowJoinModal(true);
    } else {
      setActionLoading(true);
      try {
        await joinPublicCommunity(community.id, userProfile);
      } catch (err) {
        console.error('Error joining community:', err);
      } finally {
        setActionLoading(false);
      }
    }
  };

  const handleConfirmJoinRequest = async () => {
    if (!user || !userProfile) return;
    setActionLoading(true);
    try {
      await requestToJoinCommunity(community.id, community.title, userProfile, joinMessageInput);
      setShowJoinModal(false);
    } catch (err) {
      console.error('Error requesting to join:', err);
    } finally {
      setActionLoading(false);
    }
  };

  const handleLeaveCommunity = async () => {
    if (!user) return;
    if (window.confirm('Are you sure you want to leave this community?')) {
      setActionLoading(true);
      try {
        await leaveCommunity(community.id, user.uid);
      } catch (err) {
        console.error('Error leaving community:', err);
      } finally {
        setActionLoading(false);
      }
    }
  };

  const handleConfirmAvatar = async (avatarId: string) => {
    if (!user) return;
    setActionLoading(true);
    try {
      await updateCommunityMemberAvatar(community.id, user.uid, avatarId);
      setMyMembership((prev) =>
        prev
          ? { ...prev, avatarId }
          : {
              id: user.uid,
              communityId: community.id,
              userId: user.uid,
              userName: userProfile?.name || user?.displayName || 'YOU',
              userPhotoURL: userProfile?.photoURL || user?.photoURL || null,
              role: isCreator ? 'creator' : 'member',
              joinedAt: new Date().toISOString(),
              avatarId,
            }
      );
    } catch (err) {
      console.error('Error updating arena avatar:', err);
    } finally {
      setActionLoading(false);
    }
  };

  // Submit Challenge Daily Checkpoint
  const handleSubmitChallengeDay = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !userProfile || !community.challengeConfig) return;

    setSubmittingChallenge(true);
    setSubmissionSuccessMsg(null);

    try {
      const items = community.challengeConfig.dailyRequirements.map((req) => ({
        requirementId: req.id,
        title: req.title,
        type: req.type,
        content: submissionItemValues[req.id]?.trim() || `Verified entry for ${req.title}`,
        previewUrl: req.type === 'photo' && submissionItemValues[req.id]?.startsWith('http')
          ? submissionItemValues[req.id]
          : undefined,
      }));

      await submitChallengeDailyEntry(
        community.id,
        userProfile,
        submissionDay,
        submissionDate,
        items,
        25
      );

      setSubmissionSuccessMsg(`Day ${submissionDay} submitted successfully! You earned points and extended your streak!`);
      // Advance to next day for convenience
      setSubmissionDay((prev) => prev + 1);
    } catch (err) {
      console.error('Error submitting challenge entry:', err);
    } finally {
      setSubmittingChallenge(false);
    }
  };

  const handleShareCommunity = () => {
    const url = window.location.href;
    navigator.clipboard.writeText(url);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  // 1. Initial Access Verification Spinner
  if (user && isCheckingMembership) {
    return (
      <div className="flex min-h-[380px] flex-col items-center justify-center space-y-3">
        <Loader2 className="h-8 w-8 text-[#E8491D] animate-spin" />
        <p className="text-xs font-semibold uppercase tracking-wider text-[#8A8578]">
          Verifying community access...
        </p>
      </div>
    );
  }

  // 2. STATE 1: Non-Member Public View (Strictly gated: No Arena, No Leaderboard, No Participants)
  if (!hasAccess) {
    return (
      <>
        <PublicCommunityJoinView
          community={community}
          isPending={isPending}
          isRejected={isRejected}
          actionLoading={actionLoading}
          isAuthenticated={Boolean(user)}
          onJoinClick={handleJoinClick}
          onBack={onBack}
          onShare={handleShareCommunity}
        />

        {/* Modal: Request to Join Community (For approval-required communities) */}
        {showJoinModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
            <div className="relative w-full max-w-md rounded-3xl border border-[#E5E2DA] bg-white p-6 shadow-2xl space-y-5 animate-in fade-in zoom-in-95">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-sm font-black text-[#1A1A1A]">
                  <Lock className="h-4 w-4 text-[#E8491D]" />
                  <span>Request to Join {community.title}</span>
                </div>
                <button
                  onClick={() => setShowJoinModal(false)}
                  className="rounded-lg p-1 text-[#8A8578] hover:bg-[#F2EFE6]"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-[#1A1A1A]">
                  Introduce yourself to community admins
                </label>
                <textarea
                  value={joinMessageInput}
                  onChange={(e) => setJoinMessageInput(e.target.value)}
                  placeholder="Share why you'd like to participate, your background, or relevant goals..."
                  rows={4}
                  className="w-full rounded-xl border border-[#E5E2DA] bg-[#FAF8F3] p-3 text-xs text-[#1A1A1A] focus:bg-white focus:outline-none focus:ring-1 focus:ring-[#E8491D]"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  onClick={() => setShowJoinModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-[#8A8578] hover:bg-[#F2EFE6]"
                >
                  Cancel
                </button>
                <button
                  onClick={handleConfirmJoinRequest}
                  disabled={actionLoading}
                  className="inline-flex items-center gap-2 px-5 py-2 rounded-xl bg-[#E8491D] hover:bg-[#D03E15] text-xs font-bold text-white shadow-sm disabled:opacity-50"
                >
                  {actionLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Send Join Request'}
                </button>
              </div>
            </div>
          </div>
        )}
      </>
    );
  }

  // 3. POST-JOIN AVATAR ONBOARDING (For 3D Arena communities like Winter Arc)
  if (needsAvatarSetup) {
    return (
      <div className="space-y-6 pb-16">
        <div className="flex items-center justify-between">
          <button
            onClick={onBack}
            className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-xl border border-[#E5E2DA] bg-white text-xs font-bold text-[#55524A] hover:bg-[#F2EFE6] hover:text-[#1A1A1A] transition-all shadow-sm"
          >
            <ArrowLeft className="h-4 w-4" />
            <span>Back to Communities</span>
          </button>
        </div>

        <AvatarOnboardingView
          communityTitle={community.title}
          communityId={community.id}
          userId={user?.uid || ''}
          userName={userProfile?.name || user?.displayName || 'Builder'}
          userPhotoURL={userProfile?.photoURL || user?.photoURL || null}
          onAvatarConfirmed={handleConfirmAvatar}
        />
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-16">
      {/* Top Back Nav & Quick Info */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-xl border border-[#E5E2DA] bg-white text-xs font-bold text-[#55524A] hover:bg-[#F2EFE6] hover:text-[#1A1A1A] transition-all shadow-sm"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Back to Communities</span>
        </button>

        <div className="flex items-center gap-2">
          <button
            onClick={handleShareCommunity}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-[#E5E2DA] bg-white text-xs font-semibold text-[#55524A] hover:bg-[#F2EFE6] transition-colors"
          >
            {copiedLink ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Share2 className="h-3.5 w-3.5" />}
            <span>{copiedLink ? 'Link Copied' : 'Share'}</span>
          </button>
        </div>
      </div>

      {/* Community Hero Card */}
      <div className="relative rounded-3xl border border-[#E5E2DA] bg-white overflow-hidden shadow-sm">
        {/* Cover Photo */}
        <div className="relative h-48 sm:h-64 w-full bg-[#1A1A1A]">
          <img
            src={community.coverImage || 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=1200&auto=format&fit=crop&q=80'}
            alt={community.title}
            className="w-full h-full object-cover opacity-75"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent" />

          {/* Badges Overlay */}
          <div className="absolute top-4 left-4 flex flex-wrap items-center gap-2">
            {community.type === 'kobuild_official' ? (
              <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-[#E8491D] text-white text-xs font-black uppercase tracking-wider shadow-lg">
                <Flame className="h-3.5 w-3.5 fill-current" />
                KOBUILD Official Challenge
              </span>
            ) : (
              <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-white/95 backdrop-blur-md text-[#1A1A1A] text-xs font-bold uppercase tracking-wider shadow-lg">
                <Users className="h-3.5 w-3.5 text-[#E8491D]" />
                Open Community
              </span>
            )}

            <span className="px-2.5 py-0.5 rounded-full bg-black/50 backdrop-blur-md text-white text-xs font-medium capitalize">
              {community.category}
            </span>

            {community.requireApproval && (
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-amber-500/80 backdrop-blur-md text-white text-xs font-medium">
                <Lock className="h-3 w-3" />
                Approval Required
              </span>
            )}
          </div>

          {/* Title & Creator on Cover */}
          <div className="absolute bottom-4 left-4 right-4 text-white">
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight">{community.title}</h1>
            <p className="text-xs sm:text-sm text-white/80 line-clamp-1 mt-1">{community.description}</p>
          </div>
        </div>

        {/* Quick Stats & Membership Bar */}
        <div className="flex flex-wrap items-center justify-between gap-4 p-4 sm:p-6 bg-[#FAF8F3] border-t border-[#E5E2DA]">
          <div className="flex flex-wrap items-center gap-4 sm:gap-6 text-xs text-[#55524A]">
            <div className="flex items-center gap-1.5">
              <Users className="h-4 w-4 text-[#E8491D]" />
              <span className="font-bold text-[#1A1A1A]">{members.length || community.memberCount}</span>
              <span>Members</span>
            </div>

            {community.hasChallenge && community.challengeConfig && (
              <div className="flex items-center gap-1.5">
                <Calendar className="h-4 w-4 text-[#E8491D]" />
                <span className="font-bold text-[#1A1A1A]">{community.challengeConfig.durationDays} Days</span>
                <span>Challenge Duration</span>
              </div>
            )}

            {community.location && (
              <div className="flex items-center gap-1.5">
                <MapPin className="h-4 w-4 text-[#8A8578]" />
                <span>{community.location}</span>
              </div>
            )}

            <div className="flex items-center gap-2">
              <span className="text-[#8A8578]">Created by</span>
              <button
                onClick={() =>
                  setPopoverUser({
                    uid: community.creatorId,
                    name: community.creatorName,
                    photoURL: community.creatorPhotoURL,
                    bio: community.creatorBio,
                  })
                }
                className="font-bold text-[#1A1A1A] hover:text-[#E8491D] hover:underline"
              >
                {community.creatorName}
              </button>
            </div>
          </div>

          {/* Join / Status CTA */}
          <div className="flex items-center gap-3">
            {isCreator ? (
              <div className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-[#FDE4D8] border border-[#E8491D]/30 text-xs font-bold text-[#E8491D]">
                <Shield className="h-3.5 w-3.5" />
                <span>You are Creator / Admin</span>
              </div>
            ) : isMember ? (
              <div className="flex items-center gap-2">
                <div className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-emerald-50 border border-emerald-200 text-xs font-bold text-emerald-700">
                  <CheckCircle2 className="h-3.5 w-3.5" />
                  <span>Joined Member</span>
                </div>
                <button
                  onClick={handleLeaveCommunity}
                  disabled={actionLoading}
                  className="px-2.5 py-1.5 rounded-xl border border-[#E5E2DA] bg-white text-xs font-semibold text-[#8A8578] hover:text-red-600 hover:border-red-200 transition-colors"
                >
                  Leave
                </button>
              </div>
            ) : isPending ? (
              <div className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-amber-50 border border-amber-200 text-xs font-bold text-amber-700">
                <Clock className="h-3.5 w-3.5" />
                <span>Join Request Pending Approval</span>
              </div>
            ) : isRejected ? (
              <div className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-red-50 border border-red-200 text-xs font-bold text-red-700">
                <XCircle className="h-3.5 w-3.5" />
                <span>Request Declined</span>
              </div>
            ) : (
              <button
                onClick={handleJoinClick}
                disabled={actionLoading}
                className="inline-flex items-center gap-2 px-5 py-2 rounded-xl bg-[#E8491D] hover:bg-[#D03E15] text-xs font-bold text-white shadow-sm transition-all"
              >
                {actionLoading ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : community.hasChallenge ? (
                  <>
                    <Flame className="h-4 w-4" />
                    <span>Join Challenge</span>
                  </>
                ) : community.requireApproval ? (
                  <>
                    <Lock className="h-4 w-4" />
                    <span>Request to Join</span>
                  </>
                ) : (
                  <>
                    <Plus className="h-4 w-4" />
                    <span>Join Community</span>
                  </>
                )}
              </button>
            )}
          </div>
        </div>

        {/* Tab Navigation Navigation Bar */}
        <div className="flex items-center gap-1 px-4 sm:px-6 overflow-x-auto border-t border-[#E5E2DA] bg-white no-scrollbar">
          {isWinterArc && (
            <button
              id="tab-winter-arc-arena"
              onClick={() => setActiveTab('arena')}
              className={`flex items-center gap-2 px-4 py-3 text-xs font-bold border-b-2 whitespace-nowrap transition-all ${
                activeTab === 'arena'
                  ? 'border-[#E8491D] text-[#E8491D] bg-[#FDE4D8]/30'
                  : 'border-transparent text-[#8A8578] hover:text-[#1A1A1A]'
              }`}
            >
              <Sparkles className="h-4 w-4 text-[#E8491D]" />
              <span>3D Virtual Arena</span>
              <span className="px-1.5 py-0.2 rounded-full bg-[#E8491D] text-white text-[9px] font-black uppercase">
                LIVE
              </span>
            </button>
          )}

          {community.hasChallenge && (
            <>
              <button
                onClick={() => setActiveTab('challenge')}
                className={`flex items-center gap-2 px-4 py-3 text-xs font-bold border-b-2 whitespace-nowrap transition-all ${
                  activeTab === 'challenge'
                    ? 'border-[#E8491D] text-[#E8491D]'
                    : 'border-transparent text-[#8A8578] hover:text-[#1A1A1A]'
                }`}
              >
                <Flame className="h-4 w-4" />
                <span>Challenge & Submissions</span>
              </button>

              <button
                onClick={() => setActiveTab('progress')}
                className={`flex items-center gap-2 px-4 py-3 text-xs font-bold border-b-2 whitespace-nowrap transition-all ${
                  activeTab === 'progress'
                    ? 'border-[#E8491D] text-[#E8491D]'
                    : 'border-transparent text-[#8A8578] hover:text-[#1A1A1A]'
                }`}
              >
                <Trophy className="h-4 w-4" />
                <span>My Progress</span>
              </button>

              <button
                onClick={() => setActiveTab('leaderboard')}
                className={`flex items-center gap-2 px-4 py-3 text-xs font-bold border-b-2 whitespace-nowrap transition-all ${
                  activeTab === 'leaderboard'
                    ? 'border-[#E8491D] text-[#E8491D]'
                    : 'border-transparent text-[#8A8578] hover:text-[#1A1A1A]'
                }`}
              >
                <Award className="h-4 w-4" />
                <span>Leaderboard ({leaderboard.length})</span>
              </button>
            </>
          )}

          <button
            onClick={() => setActiveTab('members')}
            className={`flex items-center gap-2 px-4 py-3 text-xs font-bold border-b-2 whitespace-nowrap transition-all ${
              activeTab === 'members'
                ? 'border-[#E8491D] text-[#E8491D]'
                : 'border-transparent text-[#8A8578] hover:text-[#1A1A1A]'
            }`}
          >
            <Users className="h-4 w-4" />
            <span>Members ({members.length})</span>
            {isCreator && joinRequests.filter((r) => r.status === 'pending').length > 0 && (
              <span className="px-1.5 py-0.2 rounded-full bg-[#E8491D] text-[10px] font-bold text-white">
                {joinRequests.filter((r) => r.status === 'pending').length}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* TAB 0: 3D VIRTUAL ARENA (Specially featured for 90 Day Winter Arc) */}
      {isWinterArc && activeTab === 'arena' && (
        <div className="space-y-6">
          <WinterArc3DArena
            currentUser={userProfile}
            selectedAvatarId={myMembership?.avatarId}
            onOpenProfile={() => onNavigate('profile')}
          />

          {/* Arena Feature & Challenge Milestones Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="rounded-3xl border border-[#E5E2DA] bg-white p-5 shadow-xs space-y-2">
              <div className="flex items-center gap-2 text-xs font-bold text-[#E8491D]">
                <Flame className="h-4 w-4 fill-current" />
                <span>Virtual Coliseum V1</span>
              </div>
              <h3 className="text-sm font-bold text-[#1A1A1A]">Interactive 3D Arena</h3>
              <p className="text-xs text-[#55524A] leading-relaxed">
                Step onto the central platform in the 3D Winter Arc amphitheater. Orbit around the arena, zoom in to inspect your avatar, and track your rank live.
              </p>
            </div>

            <div className="rounded-3xl border border-[#E5E2DA] bg-white p-5 shadow-xs space-y-2">
              <div className="flex items-center gap-2 text-xs font-bold text-[#1A1A1A]">
                <Award className="h-4 w-4 text-[#E8491D]" />
                <span>Daily Discipline Checkpoints</span>
              </div>
              <h3 className="text-sm font-bold text-[#1A1A1A]">Daily Verifications</h3>
              <p className="text-xs text-[#55524A] leading-relaxed">
                Log your daily workouts, nutrition checkpoints, and reflections under <strong>Challenge & Submissions</strong> to maintain your streak.
              </p>
              <button
                onClick={() => setActiveTab('challenge')}
                className="inline-flex items-center gap-1.5 text-xs font-bold text-[#E8491D] hover:underline pt-1"
              >
                <span>Go to Daily Submissions</span>
                <ChevronRight className="h-3.5 w-3.5" />
              </button>
            </div>

            <div className="rounded-3xl border border-[#E5E2DA] bg-white p-5 shadow-xs space-y-2">
              <div className="flex items-center gap-2 text-xs font-bold text-[#1A1A1A]">
                <Users className="h-4 w-4 text-[#E8491D]" />
                <span>Future Scalability</span>
              </div>
              <h3 className="text-sm font-bold text-[#1A1A1A]">Multi-Avatar Ready</h3>
              <p className="text-xs text-[#55524A] leading-relaxed">
                Modular participant architecture designed to seamlessly scale from this single-avatar prototype to 20–30 and 100–150 competitors across concentric amphitheater tiers.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* TAB 1: CHALLENGE & DAILY SUBMISSIONS (For Challenge Communities) */}
      {community.hasChallenge && activeTab === 'challenge' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Submission Portal Form */}
          <div className="lg:col-span-2 space-y-6">
            <div className="rounded-2xl border border-[#E5E2DA] bg-white p-6 shadow-sm space-y-5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#FDE4D8] text-[#E8491D]">
                    <Camera className="h-4 w-4" />
                  </div>
                  <div>
                    <h2 className="text-base font-bold text-[#1A1A1A]">Daily Checkpoint Submission</h2>
                    <p className="text-xs text-[#8A8578]">Submit your daily requirements to verify progress and gain points</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-[#55524A]">Day #</span>
                  <input
                    type="number"
                    min={1}
                    max={community.challengeConfig?.durationDays || 90}
                    value={submissionDay}
                    onChange={(e) => setSubmissionDay(Number(e.target.value))}
                    className="w-16 px-2.5 py-1 rounded-lg border border-[#E5E2DA] bg-[#FAF8F3] text-xs font-bold text-center"
                  />
                </div>
              </div>

              {submissionSuccessMsg && (
                <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-800 font-medium flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-emerald-600 shrink-0" />
                  <span>{submissionSuccessMsg}</span>
                </div>
              )}

              {/* Requirement Upload Inputs */}
              <form onSubmit={handleSubmitChallengeDay} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {community.challengeConfig?.dailyRequirements.map((req, idx) => (
                    <div
                      key={req.id}
                      className="p-4 rounded-xl border border-[#E5E2DA] bg-[#FAF8F3] hover:border-[#E8491D]/40 transition-all space-y-2"
                    >
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-bold text-[#1A1A1A]">
                          {idx + 1}. {req.title}
                        </span>
                        <span className="px-2 py-0.5 rounded bg-[#FDE4D8] text-[10px] font-bold text-[#E8491D]">
                          +{req.points} pts
                        </span>
                      </div>
                      <p className="text-[11px] text-[#8A8578]">{req.description}</p>

                      {/* Photo / Link / Text input */}
                      {req.type === 'photo' ? (
                        <div className="space-y-2 pt-1">
                          <input
                            type="url"
                            placeholder="Enter image URL (https://...) or description"
                            value={submissionItemValues[req.id] || ''}
                            onChange={(e) =>
                              setSubmissionItemValues({ ...submissionItemValues, [req.id]: e.target.value })
                            }
                            className="w-full px-3 py-2 rounded-lg border border-[#E5E2DA] bg-white text-xs text-[#1A1A1A] placeholder-[#8A8578] focus:border-[#E8491D] outline-none"
                          />
                          {/* Quick preset preview test buttons */}
                          <div className="flex items-center gap-1.5 text-[10px] text-[#8A8578]">
                            <span>Preset:</span>
                            <button
                              type="button"
                              onClick={() =>
                                setSubmissionItemValues({
                                  ...submissionItemValues,
                                  [req.id]:
                                    'https://images.unsplash.com/photo-1494859802809-d069c3b71a8a?w=400&auto=format&fit=crop&q=80',
                                })
                              }
                              className="px-2 py-0.5 rounded bg-white border border-[#E5E2DA] hover:border-[#E8491D]"
                            >
                              Healthy Meal
                            </button>
                            <button
                              type="button"
                              onClick={() =>
                                setSubmissionItemValues({
                                  ...submissionItemValues,
                                  [req.id]:
                                    'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=400&auto=format&fit=crop&q=80',
                                })
                              }
                              className="px-2 py-0.5 rounded bg-white border border-[#E5E2DA] hover:border-[#E8491D]"
                            >
                              Workout
                            </button>
                          </div>
                        </div>
                      ) : (
                        <input
                          type="text"
                          placeholder={req.type === 'link' ? 'https://github.com/...' : 'Enter verification note...'}
                          value={submissionItemValues[req.id] || ''}
                          onChange={(e) =>
                            setSubmissionItemValues({ ...submissionItemValues, [req.id]: e.target.value })
                          }
                          className="w-full px-3 py-2 rounded-lg border border-[#E5E2DA] bg-white text-xs text-[#1A1A1A] placeholder-[#8A8578] focus:border-[#E8491D] outline-none"
                        />
                      )}
                    </div>
                  ))}
                </div>

                <div className="flex items-center justify-between pt-2">
                  <div className="text-xs text-[#8A8578]">
                    <span>Points for this submission: </span>
                    <span className="font-bold text-[#E8491D]">
                      {community.challengeConfig?.dailyRequirements.reduce((acc, r) => acc + r.points, 0)} pts
                    </span>
                  </div>

                  <button
                    type="submit"
                    disabled={submittingChallenge || !isMember}
                    className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-[#E8491D] hover:bg-[#D03E15] text-xs font-bold text-white shadow-sm transition-all disabled:opacity-50"
                  >
                    {submittingChallenge ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <>
                        <Check className="h-4 w-4" />
                        <span>Submit Day {submissionDay} Verification</span>
                      </>
                    )}
                  </button>
                </div>
              </form>
            </div>

            {/* Recent Submissions Feed */}
            <div className="rounded-2xl border border-[#E5E2DA] bg-white p-6 shadow-sm space-y-4">
              <h3 className="text-sm font-bold text-[#1A1A1A]">Recent Community Submissions ({submissions.length})</h3>
              {submissions.length === 0 ? (
                <div className="p-8 text-center text-xs text-[#8A8578]">
                  No daily submissions yet. Be the first to submit for Day 1!
                </div>
              ) : (
                <div className="space-y-3">
                  {submissions.slice(0, 8).map((sub) => (
                    <div
                      key={sub.id}
                      className="p-3.5 rounded-xl border border-[#E5E2DA] bg-[#FAF8F3] flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                    >
                      <div className="flex items-center gap-3">
                        <div className="h-8 w-8 rounded-full bg-[#F2EFE6] border border-[#D4D0C5] overflow-hidden flex items-center justify-center font-bold text-[#55524A]">
                          {sub.userPhotoURL ? (
                            <img src={sub.userPhotoURL} alt={sub.userName} className="w-full h-full object-cover" />
                          ) : (
                            sub.userName.charAt(0)
                          )}
                        </div>
                        <div>
                          <div className="font-bold text-[#1A1A1A]">{sub.userName}</div>
                          <div className="text-[11px] text-[#8A8578]">
                            Day {sub.dayNumber} Checkpoint • {sub.items.length} items verified
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <span className="px-2 py-1 rounded-lg bg-emerald-50 border border-emerald-200 text-[11px] font-bold text-emerald-700">
                          +{sub.pointsEarned} pts
                        </span>
                        <span className="text-[10px] text-[#8A8578]">
                          {new Date(sub.submittedAt).toLocaleDateString()}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Right Sidebar: Rules & Rewards Showcase */}
          <div className="space-y-6">
            {/* Rewards Card */}
            <div className="rounded-2xl border border-[#E5E2DA] bg-gradient-to-br from-[#FDE4D8]/50 to-[#FAF8F3] p-5 space-y-4">
              <div className="flex items-center gap-2 text-sm font-bold text-[#E8491D]">
                <Award className="h-4 w-4" />
                <span>Challenge Rewards & Prizes</span>
              </div>
              <div className="space-y-3">
                {community.challengeConfig?.rewards.map((reward, i) => (
                  <div key={i} className="p-3 rounded-xl bg-white border border-[#E5E2DA] space-y-1">
                    <div className="text-xs font-bold text-[#1A1A1A] flex items-center gap-1.5">
                      <Trophy className="h-3.5 w-3.5 text-[#E8491D]" />
                      <span>{reward.title}</span>
                    </div>
                    <p className="text-[11px] text-[#8A8578]">{reward.description}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Rules Breakdown */}
            <div className="rounded-2xl border border-[#E5E2DA] bg-white p-5 space-y-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-[#55524A]">Official Challenge Rules</h3>
              <ul className="space-y-2 text-xs text-[#55524A]">
                {community.challengeConfig?.rules.map((rule, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <span className="h-1.5 w-1.5 rounded-full bg-[#E8491D] mt-1.5 shrink-0" />
                    <span>{rule}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: MY PROGRESS DASHBOARD (For Challenge Communities) */}
      {community.hasChallenge && activeTab === 'progress' && (
        <div className="space-y-6">
          {/* Progress KPI Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="rounded-2xl border border-[#E5E2DA] bg-white p-4 space-y-1">
              <div className="flex items-center justify-between text-xs text-[#8A8578]">
                <span>Current Streak</span>
                <Flame className="h-4 w-4 text-[#E8491D]" />
              </div>
              <div className="text-2xl font-black text-[#1A1A1A]">{myProgress?.currentStreak || 0} Days</div>
              <div className="text-[11px] text-emerald-600 font-semibold">Active Momentum</div>
            </div>

            <div className="rounded-2xl border border-[#E5E2DA] bg-white p-4 space-y-1">
              <div className="flex items-center justify-between text-xs text-[#8A8578]">
                <span>Days Completed</span>
                <Calendar className="h-4 w-4 text-[#E8491D]" />
              </div>
              <div className="text-2xl font-black text-[#1A1A1A]">
                {myProgress?.completedDays || 0} / {community.challengeConfig?.durationDays || 90}
              </div>
              <div className="text-[11px] text-[#8A8578]">
                {Math.round(((myProgress?.completedDays || 0) / (community.challengeConfig?.durationDays || 90)) * 100)}% Complete
              </div>
            </div>

            <div className="rounded-2xl border border-[#E5E2DA] bg-white p-4 space-y-1">
              <div className="flex items-center justify-between text-xs text-[#8A8578]">
                <span>Total Score</span>
                <Trophy className="h-4 w-4 text-[#E8491D]" />
              </div>
              <div className="text-2xl font-black text-[#1A1A1A]">{myProgress?.totalScore || 0} pts</div>
              <div className="text-[11px] text-[#8A8578]">Leaderboard Points</div>
            </div>

            <div className="rounded-2xl border border-[#E5E2DA] bg-white p-4 space-y-1">
              <div className="flex items-center justify-between text-xs text-[#8A8578]">
                <span>Leaderboard Rank</span>
                <Award className="h-4 w-4 text-[#E8491D]" />
              </div>
              <div className="text-2xl font-black text-[#1A1A1A]">
                {myProgress?.rank ? `#${myProgress.rank}` : 'Unranked'}
              </div>
              <div className="text-[11px] text-[#8A8578]">Among {leaderboard.length} participants</div>
            </div>
          </div>

          {/* Badges Showcase */}
          <div className="rounded-2xl border border-[#E5E2DA] bg-white p-6 shadow-sm space-y-4">
            <h3 className="text-sm font-bold text-[#1A1A1A]">Earned Badges & Milestones</h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {[
                { title: 'First Checkpoint', desc: 'Submitted Day 1', earned: (myProgress?.completedDays || 0) >= 1 },
                { title: '3-Day Momentum', desc: 'Maintained 3-day streak', earned: (myProgress?.currentStreak || 0) >= 3 },
                { title: '7-Day Unstoppable', desc: 'Full week consistency', earned: (myProgress?.currentStreak || 0) >= 7 },
                { title: 'Winter Arc Master', desc: 'Finished challenge', earned: (myProgress?.completedDays || 0) >= (community.challengeConfig?.durationDays || 90) },
              ].map((badge, idx) => (
                <div
                  key={idx}
                  className={`p-4 rounded-xl border text-center space-y-2 transition-all ${
                    badge.earned
                      ? 'border-[#E8491D]/30 bg-[#FDE4D8]/30'
                      : 'border-[#E5E2DA] bg-[#FAF8F3] opacity-60'
                  }`}
                >
                  <div
                    className={`mx-auto flex h-10 w-10 items-center justify-center rounded-full ${
                      badge.earned ? 'bg-[#E8491D] text-white shadow-md' : 'bg-[#E5E2DA] text-[#8A8578]'
                    }`}
                  >
                    <Trophy className="h-5 w-5" />
                  </div>
                  <div className="text-xs font-bold text-[#1A1A1A]">{badge.title}</div>
                  <div className="text-[10px] text-[#8A8578]">{badge.desc}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: LEADERBOARD (For Challenge Communities) */}
      {community.hasChallenge && activeTab === 'leaderboard' && (
        <div className="rounded-2xl border border-[#E5E2DA] bg-white overflow-hidden shadow-sm">
          <div className="px-6 py-4 border-b border-[#E5E2DA] bg-[#FAF8F3] flex items-center justify-between">
            <div className="flex items-center gap-2 font-bold text-sm text-[#1A1A1A]">
              <Trophy className="h-4 w-4 text-[#E8491D]" />
              <span>Official Challenge Leaderboard</span>
            </div>
            <span className="text-xs text-[#8A8578]">{leaderboard.length} active participants</span>
          </div>

          <div className="divide-y divide-[#E5E2DA]">
            {leaderboard.length === 0 ? (
              <div className="p-8 text-center text-xs text-[#8A8578]">No participants have submitted yet!</div>
            ) : (
              leaderboard.map((item, idx) => (
                <div
                  key={item.userId}
                  className={`flex items-center justify-between p-4 px-6 text-xs transition-colors ${
                    user && item.userId === user.uid ? 'bg-[#FDE4D8]/30 font-semibold' : 'hover:bg-[#FAF8F3]'
                  }`}
                >
                  <div className="flex items-center gap-4">
                    {/* Rank Badge */}
                    <div
                      className={`flex h-7 w-7 items-center justify-center rounded-full font-black text-xs ${
                        idx === 0
                          ? 'bg-amber-400 text-amber-950 shadow-sm'
                          : idx === 1
                          ? 'bg-slate-300 text-slate-800'
                          : idx === 2
                          ? 'bg-amber-700/40 text-amber-950'
                          : 'bg-[#F2EFE6] text-[#55524A]'
                      }`}
                    >
                      #{idx + 1}
                    </div>

                    {/* Participant Avatar & Name */}
                    <div className="flex items-center gap-3">
                      <div className="h-9 w-9 rounded-full bg-[#F2EFE6] border border-[#D4D0C5] overflow-hidden flex items-center justify-center font-bold text-[#55524A]">
                        {item.userPhotoURL ? (
                          <img src={item.userPhotoURL} alt={item.userName} className="w-full h-full object-cover" />
                        ) : (
                          item.userName.charAt(0)
                        )}
                      </div>
                      <div>
                        <div className="font-bold text-[#1A1A1A] flex items-center gap-1.5">
                          <span>{item.userName}</span>
                          {user && item.userId === user.uid && (
                            <span className="px-1.5 py-0.2 rounded bg-[#E8491D] text-white text-[9px] font-bold">
                              YOU
                            </span>
                          )}
                        </div>
                        <div className="text-[11px] text-[#8A8578]">
                          {item.completedDays} days completed • Streak: 🔥 {item.currentStreak}d
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Points & Badges */}
                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <div className="text-sm font-black text-[#E8491D]">{item.totalScore} pts</div>
                      <div className="text-[10px] text-[#8A8578]">{item.badges.length} badges</div>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* TAB 7: MEMBERS & SQUAD MANAGEMENT */}
      {activeTab === 'members' && (
        <div className="rounded-2xl border border-[#E5E2DA] bg-white shadow-sm overflow-hidden space-y-4">
          {/* If Creator/Admin: show management tabs for Join Requests */}
          {canManage && (
            <div className="flex items-center gap-2 px-6 pt-4 border-b border-[#E5E2DA] bg-[#FAF8F3]">
              <button
                onClick={() => setMemberManagementTab('members')}
                className={`px-3 py-2 text-xs font-bold border-b-2 transition-colors ${
                  memberManagementTab === 'members'
                    ? 'border-[#E8491D] text-[#E8491D]'
                    : 'border-transparent text-[#8A8578] hover:text-[#1A1A1A]'
                }`}
              >
                Active Members ({members.length})
              </button>

              <button
                onClick={() => setMemberManagementTab('pending')}
                className={`flex items-center gap-1.5 px-3 py-2 text-xs font-bold border-b-2 transition-colors ${
                  memberManagementTab === 'pending'
                    ? 'border-[#E8491D] text-[#E8491D]'
                    : 'border-transparent text-[#8A8578] hover:text-[#1A1A1A]'
                }`}
              >
                <span>Pending Requests</span>
                <span className="px-1.5 py-0.2 rounded-full bg-[#E8491D] text-[10px] text-white font-black">
                  {joinRequests.filter((r) => r.status === 'pending').length}
                </span>
              </button>

              <button
                onClick={() => setMemberManagementTab('rejected')}
                className={`px-3 py-2 text-xs font-bold border-b-2 transition-colors ${
                  memberManagementTab === 'rejected'
                    ? 'border-[#E8491D] text-[#E8491D]'
                    : 'border-transparent text-[#8A8578] hover:text-[#1A1A1A]'
                }`}
              >
                Rejected Requests ({joinRequests.filter((r) => r.status === 'rejected').length})
              </button>
            </div>
          )}

          {/* Sub-view: Active Members List */}
          {(!canManage || memberManagementTab === 'members') && (
            <div className="divide-y divide-[#E5E2DA]">
              {members.map((member) => (
                <div key={member.id} className="flex items-center justify-between p-4 px-6 text-xs hover:bg-[#FAF8F3]">
                  <div className="flex items-center gap-3">
                    <div className="h-9 w-9 rounded-full bg-[#F2EFE6] border border-[#D4D0C5] overflow-hidden flex items-center justify-center font-bold text-[#55524A]">
                      {member.userPhotoURL ? (
                        <img src={member.userPhotoURL} alt={member.userName} className="w-full h-full object-cover" />
                      ) : (
                        member.userName.charAt(0)
                      )}
                    </div>
                    <div>
                      <div className="font-bold text-[#1A1A1A] flex items-center gap-1.5">
                        <span>{member.userName}</span>
                        {member.role === 'creator' && (
                          <span className="px-1.5 py-0.2 rounded bg-[#FDE4D8] text-[#E8491D] text-[9px] font-bold">
                            CREATOR
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-[#8A8578]">
                        Joined {new Date(member.joinedAt).toLocaleDateString()}
                      </div>
                    </div>
                  </div>

                  {/* Admin/Creator Action: Remove member */}
                  {canManage && member.userId !== community.creatorId && (
                    <button
                      onClick={() => removeCommunityMember(community.id, member.userId)}
                      className="px-2.5 py-1 rounded-lg border border-red-200 text-red-600 hover:bg-red-50 text-xs font-semibold transition-colors"
                    >
                      Remove
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}

          {/* Sub-view: Pending Join Requests (Creator/Admin Only) */}
          {canManage && memberManagementTab === 'pending' && (
            <div className="divide-y divide-[#E5E2DA] p-2">
              {joinRequests.filter((r) => r.status === 'pending').length === 0 ? (
                <div className="p-8 text-center text-xs text-[#8A8578]">No pending join requests at this time.</div>
              ) : (
                joinRequests
                  .filter((r) => r.status === 'pending')
                  .map((req) => (
                    <div key={req.id} className="p-4 rounded-xl border border-[#E5E2DA] bg-[#FAF8F3] mb-2 space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="h-8 w-8 rounded-full bg-white border border-[#D4D0C5] overflow-hidden flex items-center justify-center font-bold text-[#55524A] text-xs">
                            {req.userPhotoURL ? (
                              <img src={req.userPhotoURL} alt={req.userName} className="w-full h-full object-cover" />
                            ) : (
                              req.userName.charAt(0)
                            )}
                          </div>
                          <div>
                            <div className="font-bold text-xs text-[#1A1A1A]">{req.userName}</div>
                            <div className="text-[10px] text-[#8A8578]">{req.userBio || 'Member candidate'}</div>
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => handleJoinRequest(community.id, req, 'accept')}
                            className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-sm"
                          >
                            <UserCheck className="h-3.5 w-3.5" />
                            <span>Accept</span>
                          </button>
                          <button
                            onClick={() => handleJoinRequest(community.id, req, 'reject')}
                            className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg border border-red-200 text-red-600 hover:bg-red-50 text-xs font-semibold"
                          >
                            <UserX className="h-3.5 w-3.5" />
                            <span>Decline</span>
                          </button>
                        </div>
                      </div>
                      <p className="text-xs text-[#55524A] italic bg-white p-2.5 rounded-lg border border-[#E5E2DA]">
                        &ldquo;{req.message}&rdquo;
                      </p>
                    </div>
                  ))
              )}
            </div>
          )}

          {/* Sub-view: Rejected Requests */}
          {canManage && memberManagementTab === 'rejected' && (
            <div className="divide-y divide-[#E5E2DA] p-2">
              {joinRequests.filter((r) => r.status === 'rejected').length === 0 ? (
                <div className="p-8 text-center text-xs text-[#8A8578]">No rejected requests.</div>
              ) : (
                joinRequests
                  .filter((r) => r.status === 'rejected')
                  .map((req) => (
                    <div key={req.id} className="p-3 text-xs flex items-center justify-between">
                      <span className="font-bold text-[#1A1A1A]">{req.userName}</span>
                      <button
                        onClick={() => handleJoinRequest(community.id, req, 'accept')}
                        className="text-xs font-semibold text-[#E8491D] hover:underline"
                      >
                        Re-admit Member
                      </button>
                    </div>
                  ))
              )}
            </div>
          )}
        </div>
      )}

      {/* Join Request Modal */}
      {showJoinModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="w-full max-w-md bg-[#FAF8F3] border border-[#E5E2DA] rounded-2xl p-6 shadow-2xl space-y-4">
            <h3 className="text-base font-bold text-[#1A1A1A]">Request to Join {community.title}</h3>
            <p className="text-xs text-[#55524A] leading-relaxed">
              This community requires creator approval. Send a short note about why you want to join.
            </p>
            <textarea
              rows={3}
              placeholder="Hi! I'd love to collaborate on..."
              value={joinMessageInput}
              onChange={(e) => setJoinMessageInput(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-[#E5E2DA] bg-white text-xs text-[#1A1A1A] outline-none focus:border-[#E8491D] resize-none"
            />
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setShowJoinModal(false)}
                className="px-3.5 py-2 rounded-xl border border-[#E5E2DA] bg-white text-xs font-bold text-[#55524A]"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmJoinRequest}
                disabled={actionLoading}
                className="px-4 py-2 rounded-xl bg-[#E8491D] text-xs font-bold text-white hover:bg-[#D03E15]"
              >
                {actionLoading ? 'Sending...' : 'Send Request'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* User Profile Popover */}
      {popoverUser && (
        <UserProfilePopover
          targetUser={popoverUser}
          isOpen={Boolean(popoverUser)}
          onClose={() => setPopoverUser(null)}
          onNavigateToChat={() => onNavigate('chats')}
        />
      )}
    </div>
  );
};
