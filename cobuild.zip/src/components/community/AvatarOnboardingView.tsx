import React, { useState } from 'react';
import {
  CheckCircle2,
  Shield,
  Loader2,
  ArrowRight,
  Sparkles,
} from 'lucide-react';
import { getAllAvailableAvatars, AvatarDefinition } from '../../services/avatarRegistry';
import { AvatarCard3DPreview } from './AvatarCard3DPreview';

interface AvatarOnboardingViewProps {
  communityTitle: string;
  communityId: string;
  userId: string;
  userName: string;
  userPhotoURL?: string | null;
  onAvatarConfirmed: (avatarId: string) => Promise<void>;
}

export const AvatarOnboardingView: React.FC<AvatarOnboardingViewProps> = ({
  communityTitle,
  userName,
  userPhotoURL,
  onAvatarConfirmed,
}) => {
  const avatars = getAllAvailableAvatars(); // M01 (Avatar 1), M02 (Avatar 2)
  const [selectedAvatarId, setSelectedAvatarId] = useState<string>(avatars[0]?.id || 'M01');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const selectedOption: AvatarDefinition =
    avatars.find((a) => a.id === selectedAvatarId) || avatars[0];

  const handleConfirm = async () => {
    if (!selectedAvatarId) return;
    setIsSubmitting(true);
    try {
      await onAvatarConfirmed(selectedAvatarId);
    } catch (err) {
      console.error('Error saving arena avatar selection:', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto py-8 px-4 sm:px-6 space-y-8 animate-fade-in">
      {/* Onboarding Header */}
      <div className="text-center space-y-3 max-w-2xl mx-auto">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#FDE4D8] border border-[#E8491D]/30 text-[#E8491D] text-xs font-black uppercase tracking-wider">
          <Sparkles className="h-4 w-4" />
          <span>Membership Active • Required Onboarding</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-black tracking-tight text-[#1A1A1A]">
          Choose Your Arena Avatar
        </h1>
        <p className="text-sm text-[#55524A] leading-relaxed">
          This avatar will represent you inside the community arena.
        </p>
      </div>

      {/* Avatar Selection Cards Grid (Two Real 3D GLB Avatars) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-3xl mx-auto">
        {avatars.map((option) => {
          const isSelected = option.id === selectedAvatarId;

          return (
            <div
              key={option.id}
              id={`avatar-card-${option.id}`}
              onClick={() => setSelectedAvatarId(option.id)}
              className={`relative group rounded-3xl border p-6 flex flex-col justify-between transition-all cursor-pointer shadow-xs ${
                isSelected
                  ? 'border-[#E8491D] bg-white ring-2 ring-[#E8491D]/25 shadow-md transform -translate-y-1'
                  : 'border-[#E5E2DA] bg-[#FAF8F3] hover:bg-white hover:border-[#D4D0C5]'
              }`}
            >
              <div className="space-y-4">
                {/* Top Row: Avatar Badge & Radio Check */}
                <div className="flex items-center justify-between">
                  <span
                    className="px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider text-white shadow-xs"
                    style={{ backgroundColor: option.previewColor }}
                  >
                    {option.name} • {option.id}
                  </span>

                  <div
                    className={`flex h-6 w-6 items-center justify-center rounded-full border-2 transition-all ${
                      isSelected
                        ? 'border-[#E8491D] bg-[#E8491D] text-white shadow-xs'
                        : 'border-[#D4D0C5] bg-white group-hover:border-[#8A8578]'
                    }`}
                  >
                    {isSelected && <CheckCircle2 className="h-4 w-4 stroke-[3]" />}
                  </div>
                </div>

                {/* Real 3D GLB Turntable Preview */}
                <AvatarCard3DPreview avatar={option} isSelected={isSelected} />

                {/* Option Title & Description */}
                <div className="space-y-1 pt-1">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-black text-[#1A1A1A]">{option.name}</h3>
                    <span className="text-xs font-bold text-[#8A8578]">{option.physique}</span>
                  </div>
                  <p className="text-xs text-[#55524A] leading-relaxed line-clamp-2">
                    {option.description}
                  </p>
                </div>

                {/* Feature Tags */}
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {option.features.map((feat, idx) => (
                    <span
                      key={idx}
                      className="px-2.5 py-0.5 rounded-lg bg-[#F2EFE6] text-[#55524A] text-[10px] font-semibold"
                    >
                      {feat}
                    </span>
                  ))}
                </div>
              </div>

              {/* Selection Status Indicator */}
              <div className="mt-5 pt-4 border-t border-[#E5E2DA]">
                <div
                  className={`text-xs font-bold text-center py-1 rounded-xl transition-all ${
                    isSelected
                      ? 'bg-[#FDE4D8] text-[#E8491D]'
                      : 'bg-transparent text-[#8A8578] group-hover:text-[#1A1A1A]'
                  }`}
                >
                  {isSelected ? '✓ Selected Avatar' : 'Click to select this avatar'}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Profile Photo vs 3D Avatar Clarification Banner */}
      <div className="rounded-2xl border border-[#E5E2DA] bg-[#F2EFE6] p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 max-w-3xl mx-auto">
        <div className="flex items-start sm:items-center gap-3">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-white border border-[#E5E2DA] text-[#8A8578] overflow-hidden">
            {userPhotoURL ? (
              <img src={userPhotoURL} alt={userName} className="h-full w-full object-cover" />
            ) : (
              <Shield className="h-5 w-5 text-[#E8491D]" />
            )}
          </div>
          <div className="space-y-0.5 text-xs text-[#55524A]">
            <p className="font-bold text-[#1A1A1A]">Profile Photo Remains Separate</p>
            <p>
              Your personal 2D profile photo stays untouched. The selected 3D GLB model will be used exclusively for your presence on the coliseum podium.
            </p>
          </div>
        </div>

        <div className="shrink-0 text-xs font-semibold text-[#8A8578] px-3 py-1.5 rounded-xl bg-white border border-[#E5E2DA]">
          Member: <strong className="text-[#1A1A1A]">{userName}</strong>
        </div>
      </div>

      {/* Confirmation CTA Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-[#E5E2DA] max-w-3xl mx-auto">
        <div className="text-xs text-[#8A8578]">
          Selected: <strong className="text-[#1A1A1A]">{selectedOption.name} ({selectedOption.id})</strong> • Saved to community membership
        </div>

        <button
          id="btn-confirm-avatar"
          onClick={handleConfirm}
          disabled={!selectedAvatarId || isSubmitting}
          className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-3.5 rounded-xl bg-[#E8491D] hover:bg-[#D03E15] text-white text-xs font-black uppercase tracking-wider shadow-md hover:shadow-lg transition-all disabled:opacity-50 cursor-pointer"
        >
          {isSubmitting ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin" />
              <span>Saving Avatar Selection...</span>
            </>
          ) : (
            <>
              <span>Confirm Avatar</span>
              <ArrowRight className="h-4 w-4" />
            </>
          )}
        </button>
      </div>
    </div>
  );
};
