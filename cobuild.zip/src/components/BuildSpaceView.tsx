import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { UserSection, AppView, BuildSpace, BuildSpaceMember, BuildSpaceTask, Ticket } from '../types';
import {
  subscribeUserBuildSpaces,
  subscribeBuildSpaceMembers,
  subscribeBuildSpaceTasks,
  addBuildSpaceTask,
  updateBuildSpaceTask,
  deleteBuildSpaceTask,
  updateBuildSpace,
  getOrCreateDirectConversation,
} from '../services/userService';
import { RaiseTicketModal } from './collab/RaiseTicketModal';
import {
  FolderGit2,
  Video,
  CheckSquare,
  FileText,
  Users,
  Sparkles,
  ExternalLink,
  MessageSquare,
  Plus,
  Play,
  Github,
  Globe,
  Layers,
  ArrowRight,
  ShieldCheck,
  GraduationCap,
  Home as HomeIcon,
  Briefcase,
  Loader2,
  Check,
  Clock,
  Trash2,
  Edit2,
  X,
  AlertCircle,
  Code,
  Share2,
  ChevronDown,
} from 'lucide-react';

interface BuildSpaceViewProps {
  onOpenAuth: (section?: UserSection | null) => void;
  onNavigate: (view: AppView, section?: UserSection) => void;
}

export const BuildSpaceView: React.FC<BuildSpaceViewProps> = ({ onOpenAuth, onNavigate }) => {
  const { user, userProfile } = useAuth();
  const [spaces, setSpaces] = useState<BuildSpace[]>([]);
  const [loadingSpaces, setLoadingSpaces] = useState(true);
  const [selectedSpaceId, setSelectedSpaceId] = useState<string | null>(null);

  // Modal for raising ticket directly from Build Spaces
  const [isRaiseModalOpen, setIsRaiseModalOpen] = useState(false);
  const [raiseSection, setRaiseSection] = useState<UserSection>(userProfile?.section || 'student');

  // Active space state
  const [members, setMembers] = useState<BuildSpaceMember[]>([]);
  const [loadingMembers, setLoadingMembers] = useState(false);
  const [tasks, setTasks] = useState<BuildSpaceTask[]>([]);
  const [loadingTasks, setLoadingTasks] = useState(false);

  // Tabs & Meetings
  const [activeTab, setActiveTab] = useState<'overview' | 'tasks' | 'files' | 'meetings'>('overview');
  const [meetingActive, setMeetingActive] = useState(false);
  const [meetingElapsedSeconds, setMeetingElapsedSeconds] = useState(0);

  // Tasks Form
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [newTaskStatus, setNewTaskStatus] = useState<'todo' | 'in_progress' | 'done'>('todo');
  const [addingTask, setAddingTask] = useState(false);

  // Edit Space Links Modal / State
  const [editingLinks, setEditingLinks] = useState(false);
  const [repoUrlInput, setRepoUrlInput] = useState('');
  const [deployUrlInput, setDeployUrlInput] = useState('');
  const [savingLinks, setSavingLinks] = useState(false);

  // Direct Message Loading state
  const [openingChatWithUid, setOpeningChatWithUid] = useState<string | null>(null);

  // Keep raise section updated with user profile
  useEffect(() => {
    if (userProfile?.section) {
      setRaiseSection(userProfile.section);
    }
  }, [userProfile?.section]);

  // Meeting timer effect
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (meetingActive) {
      interval = setInterval(() => {
        setMeetingElapsedSeconds((prev) => prev + 1);
      }, 1000);
    } else {
      setMeetingElapsedSeconds(0);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [meetingActive]);

  // Subscribe to all Build Spaces strictly owned/accessible by the user
  useEffect(() => {
    if (!user) {
      setSpaces([]);
      setLoadingSpaces(false);
      return;
    }

    setLoadingSpaces(true);
    const unsub = subscribeUserBuildSpaces(user.uid, (fetchedSpaces) => {
      setSpaces(fetchedSpaces);
      setLoadingSpaces(false);

      setSelectedSpaceId((current) => {
        if (current && fetchedSpaces.some((s) => s.id === current)) {
          return current;
        }
        return fetchedSpaces.length > 0 ? fetchedSpaces[0].id : null;
      });
    });

    return () => unsub();
  }, [user]);

  // Active space
  const activeSpace = spaces.find((s) => s.id === selectedSpaceId) || null;

  // Sync inputs when active space changes
  useEffect(() => {
    if (activeSpace) {
      setRepoUrlInput(activeSpace.repositoryUrl || '');
      setDeployUrlInput(activeSpace.deploymentUrl || '');
    }
  }, [activeSpace?.id]);

  // Subscribe to members for active space
  useEffect(() => {
    if (!activeSpace) {
      setMembers([]);
      setLoadingMembers(false);
      return;
    }

    setLoadingMembers(true);
    const unsub = subscribeBuildSpaceMembers(activeSpace.id, (fetchedMembers) => {
      setMembers(fetchedMembers);
      setLoadingMembers(false);
    });

    return () => unsub();
  }, [activeSpace?.id]);

  // Subscribe to tasks for active space
  useEffect(() => {
    if (!activeSpace) {
      setTasks([]);
      setLoadingTasks(false);
      return;
    }

    setLoadingTasks(true);
    const unsub = subscribeBuildSpaceTasks(activeSpace.id, (fetchedTasks) => {
      setTasks(fetchedTasks);
      setLoadingTasks(false);
    });

    return () => unsub();
  }, [activeSpace?.id]);

  // Format meeting seconds into MM:SS
  const formatSeconds = (sec: number) => {
    const m = Math.floor(sec / 60)
      .toString()
      .padStart(2, '0');
    const s = (sec % 60).toString().padStart(2, '0');
    return `${m}:${s}`;
  };

  const handleAddTask = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeSpace || !newTaskTitle.trim()) return;

    setAddingTask(true);
    try {
      await addBuildSpaceTask(activeSpace.id, {
        buildSpaceId: activeSpace.id,
        title: newTaskTitle.trim(),
        status: newTaskStatus,
      });
      setNewTaskTitle('');
      setNewTaskStatus('todo');
    } catch (err) {
      console.error('Failed to add task:', err);
    } finally {
      setAddingTask(false);
    }
  };

  const handleUpdateTaskStatus = async (taskId: string, status: 'todo' | 'in_progress' | 'done') => {
    if (!activeSpace) return;
    try {
      await updateBuildSpaceTask(activeSpace.id, taskId, { status });
    } catch (err) {
      console.error('Failed to update task status:', err);
    }
  };

  const handleDeleteTask = async (taskId: string) => {
    if (!activeSpace) return;
    try {
      await deleteBuildSpaceTask(activeSpace.id, taskId);
    } catch (err) {
      console.error('Failed to delete task:', err);
    }
  };

  const handleSaveLinks = async () => {
    if (!activeSpace) return;
    setSavingLinks(true);
    try {
      await updateBuildSpace(activeSpace.id, {
        repositoryUrl: repoUrlInput.trim(),
        deploymentUrl: deployUrlInput.trim(),
      });
      setEditingLinks(false);
    } catch (err) {
      console.error('Failed to update build space links:', err);
    } finally {
      setSavingLinks(false);
    }
  };

  const handleDirectMessageBuilder = async (member: BuildSpaceMember) => {
    if (!user) {
      onOpenAuth(null);
      return;
    }
    if (member.userId === user.uid) return;

    setOpeningChatWithUid(member.userId);
    try {
      await getOrCreateDirectConversation(
        userProfile || {
          uid: user.uid,
          name: user.displayName || 'Builder',
          photoURL: user.photoURL,
        },
        member.userId,
        {
          type: 'build_space',
          id: activeSpace?.id,
          title: activeSpace?.title || 'Build Space Squad',
        },
        `Hey ${member.userName}! Checking in from our Build Space squad workspace.`
      );
      onNavigate('chats');
    } catch (err) {
      console.error('Failed to initiate direct message:', err);
    } finally {
      setOpeningChatWithUid(null);
    }
  };

  const handleTicketCreated = (ticket: Ticket) => {
    setIsRaiseModalOpen(false);
    if (ticket.id) {
      setSelectedSpaceId(ticket.id);
    }
  };

  // If user is not authenticated
  if (!user) {
    return (
      <div id="build-spaces-auth-gate" className="space-y-6 pb-20 max-w-3xl mx-auto text-center py-16">
        <div className="flex h-16 w-16 mx-auto items-center justify-center rounded-3xl bg-[#FDE4D8] border border-[#E8491D]/30 text-[#E8491D]">
          <FolderGit2 className="h-8 w-8" />
        </div>
        <div className="space-y-2">
          <h1 className="text-2xl font-extrabold text-[#1A1A1A] tracking-tight">
            Build Spaces
          </h1>
          <p className="text-sm font-medium text-[#8A8578]">
            Your active collaboration projects and spaces.
          </p>
          <p className="text-xs text-[#55524A] max-w-md mx-auto leading-relaxed pt-2">
            Build Spaces are private project environments tied strictly to collaboration tickets you raise.
          </p>
        </div>
        <div>
          <button
            id="build-spaces-login-btn"
            onClick={() => onOpenAuth(null)}
            className="rounded-2xl bg-[#E8491D] hover:bg-[#FF5722] px-6 py-3 text-xs font-bold text-white shadow-md transition"
          >
            Sign in to Access Your Build Spaces
          </button>
        </div>
      </div>
    );
  }

  // If loading spaces
  if (loadingSpaces) {
    return (
      <div id="build-spaces-loading" className="py-24 text-center space-y-3">
        <Loader2 className="h-8 w-8 animate-spin mx-auto text-[#E8491D]" />
        <p className="text-xs font-semibold text-[#8A8578]">Loading your Build Spaces...</p>
      </div>
    );
  }

  // If user has no build spaces / tickets raised
  if (spaces.length === 0) {
    return (
      <div id="build-spaces-empty-view" className="space-y-8 pb-20 max-w-3xl mx-auto py-10">
        {/* Header with Subtitle */}
        <div className="text-center space-y-1.5">
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-[#1A1A1A]">
            Build Spaces
          </h1>
          <p className="text-xs sm:text-sm font-medium text-[#8A8578]">
            Your active collaboration projects and spaces.
          </p>
        </div>

        <div className="rounded-3xl border border-[#E5E2DA] bg-[#FFFFFF] p-8 sm:p-12 text-center space-y-6 shadow-xs">
          <div className="flex h-16 w-16 mx-auto items-center justify-center rounded-3xl bg-[#FAF8F3] border border-[#E5E2DA] text-[#E8491D]">
            <FolderGit2 className="h-8 w-8" />
          </div>

          <div className="space-y-2 max-w-md mx-auto">
            <h2 className="text-xl sm:text-2xl font-extrabold text-[#1A1A1A]">
              You haven't raised any collaboration tickets yet.
            </h2>
            <p className="text-xs sm:text-sm text-[#55524A] leading-relaxed">
              Raise a ticket in Collab to start building your own project space.
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
            <button
              id="empty-raise-ticket-btn"
              onClick={() => setIsRaiseModalOpen(true)}
              className="flex items-center gap-2 rounded-xl bg-[#E8491D] hover:bg-[#FF5722] px-5 py-2.5 text-xs font-bold text-white shadow-xs transition"
            >
              <Plus className="h-4 w-4" />
              <span>Raise a Collaboration Ticket</span>
            </button>
          </div>
        </div>

        {/* Raise Ticket Modal */}
        {isRaiseModalOpen && (
          <RaiseTicketModal
            section={raiseSection}
            isOpen={isRaiseModalOpen}
            onClose={() => setIsRaiseModalOpen(false)}
            onTicketCreated={handleTicketCreated}
          />
        )}
      </div>
    );
  }

  return (
    <div id="build-spaces-active-view" className="space-y-8 pb-20">
      {/* Top Header with Title, Subtitle, and Action Button */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#E5E2DA] pb-5">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-[#1A1A1A]">
            Build Spaces
          </h1>
          <p className="text-xs sm:text-sm font-medium text-[#8A8578] mt-1">
            Your active collaboration projects and spaces.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            id="top-raise-collab-ticket-btn"
            onClick={() => setIsRaiseModalOpen(true)}
            className="flex items-center gap-2 rounded-xl bg-[#E8491D] hover:bg-[#FF5722] px-4 py-2.5 text-xs font-bold text-white shadow-xs transition"
          >
            <Plus className="h-4 w-4" />
            <span>Raise Collaboration Ticket</span>
          </button>
        </div>
      </div>

      {/* 1. Build Space Selector Bar if user has multiple spaces */}
      {spaces.length > 1 && (
        <div className="flex items-center gap-2 overflow-x-auto pb-1">
          <span className="text-xs font-bold uppercase tracking-wider text-[#8A8578] shrink-0 mr-1">
            Your Spaces:
          </span>
          {spaces.map((s) => (
            <button
              key={s.id}
              id={`select-space-${s.id}`}
              onClick={() => setSelectedSpaceId(s.id)}
              className={`flex items-center gap-2 rounded-xl px-3.5 py-1.5 text-xs font-semibold whitespace-nowrap transition border ${
                s.id === selectedSpaceId
                  ? 'bg-[#1A1A1A] text-white border-[#1A1A1A] shadow-xs'
                  : 'bg-[#FFFFFF] text-[#55524A] border-[#E5E2DA] hover:bg-[#FAF8F3]'
              }`}
            >
              <FolderGit2 className="h-3.5 w-3.5 text-[#E8491D]" />
              <span>{s.title}</span>
              {s.section && (
                <span className="text-[10px] opacity-70 capitalize font-mono">
                  ({s.section})
                </span>
              )}
            </button>
          ))}
        </div>
      )}

      {activeSpace && (
        <>
          {/* 2. Header with Project Overview & Quick Actions */}
          <div className="rounded-3xl border border-[#E5E2DA] bg-[#FFFFFF] p-6 sm:p-10 shadow-xs">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
              <div className="space-y-3 max-w-2xl">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="rounded-md bg-emerald-50 text-emerald-700 border border-emerald-200 px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wider font-mono">
                    Build Space Active • {activeSpace.status || 'building'}
                  </span>
                  {activeSpace.section && (
                    <span className="rounded-md bg-[#FAF8F3] text-[#55524A] border border-[#E5E2DA] px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider capitalize font-mono">
                      {activeSpace.section} Ticket Space
                    </span>
                  )}
                  <span className="text-xs text-[#8A8578] font-medium font-mono">
                    Category: {activeSpace.category || 'Collaboration'}
                  </span>
                  <span className="text-xs text-[#8A8578] font-medium font-mono">
                    Lead: {activeSpace.leadName || 'You (Ticket Owner)'}
                  </span>
                </div>

                <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-[#1A1A1A]">
                  {activeSpace.title}
                </h2>

                <p className="text-xs sm:text-sm text-[#55524A] leading-relaxed">
                  {activeSpace.description || 'Private workspace for your collaboration ticket project.'}
                </p>
              </div>

              {/* Quick Actions */}
              <div className="flex flex-wrap items-center gap-2 shrink-0">
                <button
                  id="toggle-live-sync-btn"
                  onClick={() => setMeetingActive(!meetingActive)}
                  className={`flex items-center gap-2 rounded-xl px-4 py-2.5 text-xs font-semibold shadow-xs transition ${
                    meetingActive
                      ? 'bg-rose-600 text-white hover:bg-rose-500'
                      : 'bg-[#E8491D] text-white hover:bg-[#FF5722]'
                  }`}
                >
                  <Video className="h-4 w-4" />
                  <span>{meetingActive ? 'End Live Sync' : 'Start Team Sync'}</span>
                </button>

                <button
                  id="open-team-chat-btn"
                  onClick={() => onNavigate('chats')}
                  className="flex items-center gap-2 rounded-xl border border-[#E5E2DA] bg-[#FAF8F3] px-4 py-2.5 text-xs font-semibold text-[#1A1A1A] hover:bg-[#F5F1E8]"
                >
                  <MessageSquare className="h-4 w-4 text-[#E8491D]" />
                  <span>Team Chat</span>
                </button>
              </div>
            </div>

            {/* Live Meeting Banner */}
            {meetingActive && (
              <div className="mt-6 rounded-2xl border border-[#E8491D]/40 bg-[#FDE4D8] p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 animate-in fade-in duration-200">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#E8491D] text-white">
                    <Video className="h-5 w-5 animate-pulse" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-[#1A1A1A]">Live Squad Sync in Progress</h4>
                    <p className="text-[11px] text-[#55524A]">
                      {members.length} builder{members.length !== 1 ? 's' : ''} in room • Audio &amp; Screen share active
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="rounded-full bg-emerald-500 h-2.5 w-2.5 animate-ping" />
                  <span className="text-xs font-bold text-emerald-800 font-mono">
                    {formatSeconds(meetingElapsedSeconds)}
                  </span>
                </div>
              </div>
            )}

            {/* External Links & Manage Bar */}
            <div className="mt-6 pt-6 border-t border-[#E5E2DA] flex flex-wrap items-center justify-between gap-4 text-xs font-medium text-[#55524A]">
              <div className="flex flex-wrap items-center gap-4">
                {activeSpace.repositoryUrl ? (
                  <a
                    href={activeSpace.repositoryUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center gap-1.5 text-[#1A1A1A] hover:text-[#E8491D] font-semibold"
                  >
                    <Github className="h-4 w-4" />
                    <span>Code Repository</span>
                    <ExternalLink className="h-3 w-3 text-[#8A8578]" />
                  </a>
                ) : (
                  <span className="text-[#8A8578] flex items-center gap-1">
                    <Github className="h-4 w-4 text-[#8A8578]/60" />
                    <span>No Git repo linked</span>
                  </span>
                )}

                {activeSpace.deploymentUrl ? (
                  <a
                    href={activeSpace.deploymentUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center gap-1.5 text-emerald-700 hover:text-emerald-800 font-semibold"
                  >
                    <Globe className="h-4 w-4 text-emerald-600" />
                    <span>Live Staging Demo</span>
                    <ExternalLink className="h-3 w-3 text-emerald-600" />
                  </a>
                ) : (
                  <span className="text-[#8A8578] flex items-center gap-1">
                    <Globe className="h-4 w-4 text-[#8A8578]/60" />
                    <span>No demo URL linked</span>
                  </span>
                )}
              </div>

              {/* Edit links if lead */}
              {(user.uid === activeSpace.leadId || user.uid === activeSpace.ticketCreatorId) && (
                <button
                  onClick={() => setEditingLinks(true)}
                  className="flex items-center gap-1 text-[11px] font-semibold text-[#8A8578] hover:text-[#1A1A1A]"
                >
                  <Edit2 className="h-3 w-3" />
                  <span>Configure Repo &amp; Demo URLs</span>
                </button>
              )}
            </div>
          </div>

          {/* 3. Workspace Navigation Tabs */}
          <div className="flex items-center gap-2 border-b border-[#E5E2DA] pb-2">
            <button
              onClick={() => setActiveTab('overview')}
              className={`rounded-xl px-4 py-2 text-xs font-semibold transition ${
                activeTab === 'overview'
                  ? 'bg-[#E8491D] text-white shadow-xs'
                  : 'text-[#55524A] hover:bg-[#FAF8F3] hover:text-[#1A1A1A]'
              }`}
            >
              Overview &amp; Squad ({members.length})
            </button>

            <button
              onClick={() => setActiveTab('tasks')}
              className={`rounded-xl px-4 py-2 text-xs font-semibold transition ${
                activeTab === 'tasks'
                  ? 'bg-[#E8491D] text-white shadow-xs'
                  : 'text-[#55524A] hover:bg-[#FAF8F3] hover:text-[#1A1A1A]'
              }`}
            >
              Tasks Board ({tasks.length})
            </button>

            <button
              onClick={() => setActiveTab('files')}
              className={`rounded-xl px-4 py-2 text-xs font-semibold transition ${
                activeTab === 'files'
                  ? 'bg-[#E8491D] text-white shadow-xs'
                  : 'text-[#55524A] hover:bg-[#FAF8F3] hover:text-[#1A1A1A]'
              }`}
            >
              Files &amp; Artifacts
            </button>
          </div>

          {/* 4. Tab Contents */}
          {activeTab === 'overview' && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Members List */}
              <div className="lg:col-span-2 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-bold uppercase tracking-widest text-[#8A8578]">
                    Assigned Builders &amp; Roles ({members.length})
                  </h3>
                  <span className="text-[11px] text-[#8A8578]">
                    {members.filter((m) => m.role === 'lead').length} Lead •{' '}
                    {members.filter((m) => m.role === 'member').length} Squad Members
                  </span>
                </div>

                {loadingMembers ? (
                  <div className="py-8 text-center text-xs text-[#8A8578] flex items-center justify-center gap-2">
                    <Loader2 className="h-4 w-4 animate-spin text-[#E8491D]" />
                    <span>Loading members...</span>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {members.map((m) => (
                      <div
                        key={m.id}
                        className="rounded-2xl border border-[#E5E2DA] bg-[#FFFFFF] p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                      >
                        <div className="flex items-center gap-3.5">
                          {m.userPhotoURL ? (
                            <img
                              src={m.userPhotoURL}
                              alt={m.userName}
                              className="h-10 w-10 rounded-full object-cover border border-[#E5E2DA]"
                              referrerPolicy="no-referrer"
                            />
                          ) : (
                            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#FAF8F3] border border-[#E5E2DA] text-[#E8491D] text-xs font-bold">
                              {(m.userName || 'B').slice(0, 2).toUpperCase()}
                            </div>
                          )}

                          <div>
                            <div className="flex items-center gap-2">
                              <h4 className="text-xs font-bold text-[#1A1A1A]">{m.userName}</h4>
                              {m.role === 'lead' ? (
                                <span className="rounded bg-[#FDE4D8] text-[#E8491D] border border-[#E8491D]/40 px-2 py-0.5 text-[9px] font-bold uppercase">
                                  Project Lead
                                </span>
                              ) : (
                                <span className="rounded bg-[#FAF8F3] text-[#55524A] border border-[#E5E2DA] px-2 py-0.5 text-[9px] font-bold uppercase">
                                  Builder Member
                                </span>
                              )}
                              <span className="rounded bg-[#FAF8F3] border border-[#E5E2DA] px-1.5 py-0.5 text-[9px] font-semibold text-[#8A8578] capitalize">
                                {m.userSection || 'student'}
                              </span>
                            </div>

                            {m.skills && m.skills.length > 0 && (
                              <div className="mt-1 flex flex-wrap gap-1">
                                {m.skills.map((s, idx) => (
                                  <span
                                    key={idx}
                                    className="rounded bg-[#FAF8F3] border border-[#E5E2DA] px-1.5 py-0.5 text-[10px] text-[#55524A]"
                                  >
                                    {s}
                                  </span>
                                ))}
                              </div>
                            )}
                          </div>
                        </div>

                        {m.userId !== user.uid && (
                          <button
                            onClick={() => handleDirectMessageBuilder(m)}
                            disabled={openingChatWithUid === m.userId}
                            className="flex items-center gap-1 text-xs font-semibold text-[#E8491D] hover:text-[#FF5722] self-end sm:self-auto"
                          >
                            {openingChatWithUid === m.userId ? (
                              <Loader2 className="h-3 w-3 animate-spin" />
                            ) : (
                              <MessageSquare className="h-3.5 w-3.5" />
                            )}
                            <span>Direct Message</span>
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Architecture & Workspace Structure Guide */}
              <div className="space-y-4">
                <h3 className="text-xs font-bold uppercase tracking-widest text-[#8A8578]">
                  Workspace Security &amp; Access
                </h3>

                <div className="rounded-2xl border border-[#E5E2DA] bg-[#FAF8F3] p-5 shadow-xs space-y-3">
                  <div className="flex items-center gap-2 text-xs font-bold text-[#1A1A1A]">
                    <ShieldCheck className="h-4 w-4 text-[#E8491D]" />
                    <span>Private Project Workspace</span>
                  </div>
                  <p className="text-xs leading-relaxed text-[#55524A]">
                    This Build Space is scoped strictly to your collaboration ticket. Only you and accepted squad members have access.
                  </p>
                </div>

                <div className="rounded-2xl border border-[#E5E2DA] bg-[#FFFFFF] p-5 shadow-xs space-y-2">
                  <h4 className="text-xs font-bold text-[#1A1A1A]">Connected Workspace Tools</h4>
                  <div className="space-y-1.5 text-xs text-[#55524A]">
                    <div className="flex items-center justify-between py-1 border-b border-[#E5E2DA]/60">
                      <span>Live Sync Audio/Video</span>
                      <span className="text-emerald-600 font-semibold font-mono text-[10px]">Available</span>
                    </div>
                    <div className="flex items-center justify-between py-1 border-b border-[#E5E2DA]/60">
                      <span>Tasks Board</span>
                      <span className="font-mono text-[10px] text-[#1A1A1A]">{tasks.length} items</span>
                    </div>
                    <div className="flex items-center justify-between py-1">
                      <span>Access Restriction</span>
                      <span className="font-mono text-[10px] text-emerald-700 font-semibold">Strict Owner Scoped</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'tasks' && (
            <div className="space-y-6">
              {/* Add Task Form */}
              <form
                onSubmit={handleAddTask}
                className="flex flex-col sm:flex-row items-center gap-3 rounded-2xl border border-[#E5E2DA] bg-[#FAF8F3] p-4"
              >
                <input
                  type="text"
                  required
                  placeholder="Add a new task or milestone (e.g. Implement WebSocket connector)..."
                  value={newTaskTitle}
                  onChange={(e) => setNewTaskTitle(e.target.value)}
                  className="flex-1 w-full rounded-xl border border-[#E5E2DA] bg-[#FFFFFF] px-3.5 py-2 text-xs text-[#1A1A1A] placeholder:text-[#8A8578] focus:border-[#E8491D] focus:outline-none"
                />

                <select
                  value={newTaskStatus}
                  onChange={(e) => setNewTaskStatus(e.target.value as any)}
                  className="rounded-xl border border-[#E5E2DA] bg-[#FFFFFF] px-3 py-2 text-xs text-[#1A1A1A] focus:border-[#E8491D] focus:outline-none"
                >
                  <option value="todo">To Do</option>
                  <option value="in_progress">In Progress</option>
                  <option value="done">Done</option>
                </select>

                <button
                  type="submit"
                  disabled={addingTask || !newTaskTitle.trim()}
                  className="flex items-center justify-center gap-1.5 rounded-xl bg-[#E8491D] hover:bg-[#FF5722] px-4 py-2 text-xs font-bold text-white shrink-0 disabled:opacity-50"
                >
                  {addingTask ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Plus className="h-3.5 w-3.5" />}
                  <span>Add Task</span>
                </button>
              </form>

              {/* Tasks Columns */}
              {loadingTasks ? (
                <div className="py-12 text-center text-xs text-[#8A8578]">
                  <Loader2 className="h-5 w-5 animate-spin mx-auto text-[#E8491D]" />
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {/* To Do Column */}
                  <div className="rounded-2xl border border-[#E5E2DA] bg-[#FFFFFF] p-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <h4 className="text-xs font-bold uppercase tracking-wider text-[#8A8578]">
                        To Do ({tasks.filter((t) => t.status === 'todo').length})
                      </h4>
                    </div>

                    <div className="space-y-2">
                      {tasks
                        .filter((t) => t.status === 'todo')
                        .map((task) => (
                          <div
                            key={task.id}
                            className="rounded-xl border border-[#E5E2DA] bg-[#FAF8F3] p-3 text-xs text-[#1A1A1A] space-y-2 group"
                          >
                            <p className="font-medium leading-relaxed">{task.title}</p>
                            <div className="flex items-center justify-between pt-1 border-t border-[#E5E2DA]/60">
                              <button
                                onClick={() => handleUpdateTaskStatus(task.id, 'in_progress')}
                                className="text-[10px] font-semibold text-amber-700 hover:underline"
                              >
                                Move to In Progress →
                              </button>
                              <button
                                onClick={() => handleDeleteTask(task.id)}
                                className="opacity-0 group-hover:opacity-100 text-[#8A8578] hover:text-rose-600 transition"
                                title="Delete task"
                              >
                                <Trash2 className="h-3 w-3" />
                              </button>
                            </div>
                          </div>
                        ))}
                      {tasks.filter((t) => t.status === 'todo').length === 0 && (
                        <p className="text-center text-[11px] text-[#8A8578] py-4">No tasks in To Do</p>
                      )}
                    </div>
                  </div>

                  {/* In Progress Column */}
                  <div className="rounded-2xl border border-amber-200 bg-[#FFFFFF] p-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <h4 className="text-xs font-bold uppercase tracking-wider text-amber-700">
                        In Progress ({tasks.filter((t) => t.status === 'in_progress').length})
                      </h4>
                    </div>

                    <div className="space-y-2">
                      {tasks
                        .filter((t) => t.status === 'in_progress')
                        .map((task) => (
                          <div
                            key={task.id}
                            className="rounded-xl border border-amber-200 bg-amber-50/60 p-3 text-xs text-amber-950 space-y-2 group"
                          >
                            <p className="font-medium leading-relaxed">{task.title}</p>
                            <div className="flex items-center justify-between pt-1 border-t border-amber-200">
                              <button
                                onClick={() => handleUpdateTaskStatus(task.id, 'done')}
                                className="text-[10px] font-semibold text-emerald-700 hover:underline"
                              >
                                Mark Done ✓
                              </button>
                              <button
                                onClick={() => handleDeleteTask(task.id)}
                                className="opacity-0 group-hover:opacity-100 text-[#8A8578] hover:text-rose-600 transition"
                                title="Delete task"
                              >
                                <Trash2 className="h-3 w-3" />
                              </button>
                            </div>
                          </div>
                        ))}
                      {tasks.filter((t) => t.status === 'in_progress').length === 0 && (
                        <p className="text-center text-[11px] text-amber-700/60 py-4">
                          No tasks in progress
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Done Column */}
                  <div className="rounded-2xl border border-emerald-200 bg-[#FFFFFF] p-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <h4 className="text-xs font-bold uppercase tracking-wider text-emerald-700">
                        Done ({tasks.filter((t) => t.status === 'done').length})
                      </h4>
                    </div>

                    <div className="space-y-2">
                      {tasks
                        .filter((t) => t.status === 'done')
                        .map((task) => (
                          <div
                            key={task.id}
                            className="rounded-xl border border-emerald-200 bg-emerald-50/50 p-3 text-xs text-emerald-950 space-y-2 group"
                          >
                            <div className="flex items-start gap-1.5">
                              <Check className="h-3.5 w-3.5 text-emerald-600 shrink-0 mt-0.5" />
                              <p className="font-medium line-through text-emerald-800 leading-relaxed">
                                {task.title}
                              </p>
                            </div>
                            <div className="flex items-center justify-end pt-1 border-t border-emerald-200">
                              <button
                                onClick={() => handleDeleteTask(task.id)}
                                className="opacity-0 group-hover:opacity-100 text-[#8A8578] hover:text-rose-600 transition"
                                title="Delete task"
                              >
                                <Trash2 className="h-3 w-3" />
                              </button>
                            </div>
                          </div>
                        ))}
                      {tasks.filter((t) => t.status === 'done').length === 0 && (
                        <p className="text-center text-[11px] text-emerald-700/60 py-4">No completed tasks yet</p>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {activeTab === 'files' && (
            <div className="space-y-6">
              <div className="rounded-2xl border border-[#E5E2DA] bg-[#FFFFFF] p-6 shadow-xs space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <FileText className="h-5 w-5 text-[#E8491D]" />
                    <h4 className="text-sm font-bold text-[#1A1A1A]">Project Files &amp; Resources</h4>
                  </div>
                  {(user.uid === activeSpace.leadId || user.uid === activeSpace.ticketCreatorId) && (
                    <button
                      onClick={() => setEditingLinks(true)}
                      className="text-xs font-semibold text-[#E8491D] hover:underline"
                    >
                      Update Git / Demo Links
                    </button>
                  )}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="rounded-xl border border-[#E5E2DA] bg-[#FAF8F3] p-4 space-y-1">
                    <div className="flex items-center gap-2 text-xs font-bold text-[#1A1A1A]">
                      <Github className="h-4 w-4" />
                      <span>Git Repository</span>
                    </div>
                    {activeSpace.repositoryUrl ? (
                      <a
                        href={activeSpace.repositoryUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="text-xs text-[#E8491D] hover:underline break-all"
                      >
                        {activeSpace.repositoryUrl}
                      </a>
                    ) : (
                      <p className="text-xs text-[#8A8578]">No repository linked yet.</p>
                    )}
                  </div>

                  <div className="rounded-xl border border-[#E5E2DA] bg-[#FAF8F3] p-4 space-y-1">
                    <div className="flex items-center gap-2 text-xs font-bold text-[#1A1A1A]">
                      <Globe className="h-4 w-4 text-emerald-600" />
                      <span>Staging Demo URL</span>
                    </div>
                    {activeSpace.deploymentUrl ? (
                      <a
                        href={activeSpace.deploymentUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="text-xs text-emerald-700 hover:underline break-all"
                      >
                        {activeSpace.deploymentUrl}
                      </a>
                    ) : (
                      <p className="text-xs text-[#8A8578]">No live demo URL linked yet.</p>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Edit Space Links Modal */}
          {editingLinks && (
            <div
              className="fixed inset-0 z-60 flex items-center justify-center bg-[#1A1A1A]/40 p-4 backdrop-blur-xs animate-in fade-in"
              onClick={() => setEditingLinks(false)}
            >
              <div
                className="w-full max-w-md rounded-2xl border border-[#E5E2DA] bg-[#FFFFFF] p-6 shadow-2xl space-y-4"
                onClick={(e) => e.stopPropagation()}
              >
                <div className="flex items-center justify-between border-b border-[#E5E2DA] pb-3">
                  <h3 className="text-sm font-bold text-[#1A1A1A]">Workspace Repositories &amp; Links</h3>
                  <button onClick={() => setEditingLinks(false)} className="text-[#8A8578] hover:text-[#1A1A1A]">
                    <X className="h-4 w-4" />
                  </button>
                </div>

                <div className="space-y-3">
                  <div>
                    <label className="text-[11px] font-bold uppercase tracking-wider text-[#8A8578]">
                      GitHub / Git Repository URL
                    </label>
                    <input
                      type="url"
                      placeholder="https://github.com/org/project"
                      value={repoUrlInput}
                      onChange={(e) => setRepoUrlInput(e.target.value)}
                      className="w-full mt-1 rounded-xl border border-[#E5E2DA] bg-[#FAF8F3] px-3.5 py-2 text-xs text-[#1A1A1A] focus:border-[#E8491D] focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] font-bold uppercase tracking-wider text-[#8A8578]">
                      Live Staging / Deployment URL
                    </label>
                    <input
                      type="url"
                      placeholder="https://my-project.dev"
                      value={deployUrlInput}
                      onChange={(e) => setDeployUrlInput(e.target.value)}
                      className="w-full mt-1 rounded-xl border border-[#E5E2DA] bg-[#FAF8F3] px-3.5 py-2 text-xs text-[#1A1A1A] focus:border-[#E8491D] focus:outline-none"
                    />
                  </div>
                </div>

                <div className="flex items-center justify-end gap-2 pt-2 border-t border-[#E5E2DA]">
                  <button
                    onClick={() => setEditingLinks(false)}
                    className="rounded-xl border border-[#E5E2DA] bg-[#FFFFFF] px-4 py-2 text-xs font-semibold text-[#55524A] hover:bg-[#FAF8F3]"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleSaveLinks}
                    disabled={savingLinks}
                    className="flex items-center gap-1.5 rounded-xl bg-[#E8491D] hover:bg-[#FF5722] px-4 py-2 text-xs font-bold text-white shadow-xs disabled:opacity-50"
                  >
                    {savingLinks ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Check className="h-3.5 w-3.5" />}
                    <span>Save Changes</span>
                  </button>
                </div>
              </div>
            </div>
          )}
        </>
      )}

      {/* Raise Ticket Modal when triggered from header or empty state */}
      {isRaiseModalOpen && (
        <RaiseTicketModal
          section={raiseSection}
          isOpen={isRaiseModalOpen}
          onClose={() => setIsRaiseModalOpen(false)}
          onTicketCreated={handleTicketCreated}
        />
      )}
    </div>
  );
};
