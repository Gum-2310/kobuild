import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import {
  User,
  signInWithPopup,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  updateProfile as updateAuthProfile,
} from 'firebase/auth';
import { auth, googleProvider } from '../lib/firebase';
import { getUserProfile, createUserProfile, updateUserProfile, isUserPlatformAdmin } from '../services/userService';
import { UserProfile, UserSection } from '../types';
import { formatAuthError } from '../utils/authErrors';

interface AuthContextType {
  user: User | null;
  userProfile: UserProfile | null;
  isAdmin: boolean;
  loading: boolean;
  profileIncomplete: boolean;
  error: string | null;
  activeSection: UserSection;
  setActiveSection: (section: UserSection) => void;
  signInWithGoogle: () => Promise<void>;
  signUpWithEmail: (email: string, pass: string, name: string) => Promise<void>;
  signInWithEmail: (email: string, pass: string) => Promise<void>;
  logout: () => Promise<void>;
  completeProfile: (
    data: {
      name: string;
      section?: UserSection;
      location?: string;
      skills?: string[];
      interests?: string[];
      bio?: string;
    }
  ) => Promise<void>;
  updateProfileData: (updates: Partial<Omit<UserProfile, 'uid' | 'createdAt'>>) => Promise<void>;
  clearError: () => void;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [profileIncomplete, setProfileIncomplete] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [activeSection, setActiveSection] = useState<UserSection>('student');

  const clearError = () => setError(null);

  const fetchProfile = async (firebaseUser: User): Promise<UserProfile | null> => {
    try {
      const profile = await getUserProfile(firebaseUser.uid);
      if (profile) {
        setUserProfile(profile);
        setProfileIncomplete(false);
        if (profile.section) {
          setActiveSection(profile.section);
        }
        return profile;
      } else {
        // If no profile exists in Firestore, create the minimal profile
        const timestamp = new Date().toISOString();
        const fallbackName =
          firebaseUser.displayName?.trim() ||
          (firebaseUser.email ? firebaseUser.email.split('@')[0] : 'User');
        const fallbackEmail = firebaseUser.email || '';

        const newProfile: UserProfile = {
          uid: firebaseUser.uid,
          name: fallbackName,
          email: fallbackEmail,
          photoURL: firebaseUser.photoURL || null,
          createdAt: timestamp,
          updatedAt: timestamp,
        };

        await createUserProfile(newProfile);
        setUserProfile(newProfile);
        setProfileIncomplete(false);
        return newProfile;
      }
    } catch (err: unknown) {
      console.error('Failed to fetch/sync user profile from Firestore:', err);
      return null;
    }
  };

  const refreshProfile = async () => {
    if (user) {
      await fetchProfile(user);
    }
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        await fetchProfile(currentUser);
      } else {
        setUserProfile(null);
        setProfileIncomplete(false);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const signInWithGoogle = async () => {
    setError(null);
    try {
      const result = await signInWithPopup(auth, googleProvider);
      const loggedUser = result.user;
      setUser(loggedUser);
      await fetchProfile(loggedUser);
    } catch (err: unknown) {
      console.error('Google Sign-In Error:', err);
      const friendlyMsg = formatAuthError(err);
      if (!friendlyMsg.includes('cancelled before completion')) {
        setError(friendlyMsg);
      }
      throw new Error(friendlyMsg);
    }
  };

  const signUpWithEmail = async (
    email: string,
    pass: string,
    name: string
  ) => {
    setError(null);
    const normalizedEmail = email.trim().toLowerCase();
    const cleanName = name.trim() || 'User';

    try {
      // 1. Create Firebase Auth user
      const userCredential = await createUserWithEmailAndPassword(auth, normalizedEmail, pass);
      const createdUser = userCredential.user;

      // 2. Set Firebase Auth display name
      try {
        await updateAuthProfile(createdUser, { displayName: cleanName });
      } catch (profileErr) {
        console.warn('Failed to update auth display name:', profileErr);
      }

      // 3. Create Firestore User Profile Document with verified UID
      const timestamp = new Date().toISOString();
      const newProfile: UserProfile = {
        uid: createdUser.uid,
        name: cleanName,
        email: createdUser.email || normalizedEmail,
        photoURL: createdUser.photoURL || null,
        createdAt: timestamp,
        updatedAt: timestamp,
      };

      await createUserProfile(newProfile);

      // 4. Update state synchronously
      setUser(createdUser);
      setUserProfile(newProfile);
      setProfileIncomplete(false);
    } catch (err: unknown) {
      console.error('Email Sign-Up Error:', err);
      const friendlyMsg = formatAuthError(err);
      setError(friendlyMsg);
      throw new Error(friendlyMsg);
    }
  };

  const signInWithEmail = async (email: string, pass: string) => {
    setError(null);
    const normalizedEmail = email.trim().toLowerCase();

    try {
      const userCredential = await signInWithEmailAndPassword(auth, normalizedEmail, pass);
      const loggedUser = userCredential.user;
      setUser(loggedUser);
      await fetchProfile(loggedUser);
    } catch (err: unknown) {
      console.error('Email Sign-In Error:', err);
      const friendlyMsg = formatAuthError(err);
      setError(friendlyMsg);
      throw new Error(friendlyMsg);
    }
  };

  const logout = async () => {
    setError(null);
    try {
      await signOut(auth);
      setUser(null);
      setUserProfile(null);
      setProfileIncomplete(false);
    } catch (err: unknown) {
      console.error('Sign-Out Error:', err);
      const friendlyMsg = formatAuthError(err);
      setError(friendlyMsg);
      throw new Error(friendlyMsg);
    }
  };

  const completeProfile = async (data: {
    name: string;
    section?: UserSection;
    location?: string;
    skills?: string[];
    interests?: string[];
    bio?: string;
  }) => {
    if (!user) {
      throw new Error('User must be authenticated to complete profile');
    }
    setError(null);
    try {
      const timestamp = new Date().toISOString();
      const newProfile: UserProfile = {
        uid: user.uid,
        name: data.name.trim() || user.displayName || 'User',
        email: user.email || '',
        photoURL: user.photoURL || null,
        createdAt: timestamp,
        updatedAt: timestamp,
      };

      if (data.section) newProfile.section = data.section;
      if (data.location) newProfile.location = data.location.trim();
      if (data.skills && data.skills.length > 0) newProfile.skills = data.skills;
      if (data.interests && data.interests.length > 0) newProfile.interests = data.interests;
      if (data.bio) newProfile.bio = data.bio.trim();

      await createUserProfile(newProfile);
      setUserProfile(newProfile);
      setProfileIncomplete(false);
      if (data.section) {
        setActiveSection(data.section);
      }
    } catch (err: unknown) {
      console.error('Complete Profile Error:', err);
      const friendlyMsg = formatAuthError(err);
      setError(friendlyMsg);
      throw new Error(friendlyMsg);
    }
  };

  const updateProfileData = async (updates: Partial<Omit<UserProfile, 'uid' | 'createdAt'>>) => {
    if (!user || !userProfile) {
      throw new Error('No authenticated user profile found');
    }
    setError(null);
    try {
      await updateUserProfile(user.uid, updates);
      setUserProfile((prev) => (prev ? { ...prev, ...updates, updatedAt: new Date().toISOString() } : null));
      if (updates.section) {
        setActiveSection(updates.section);
      }
    } catch (err: unknown) {
      console.error('Update Profile Error:', err);
      const friendlyMsg = formatAuthError(err);
      setError(friendlyMsg);
      throw new Error(friendlyMsg);
    }
  };

  const isAdmin = isUserPlatformAdmin(user, userProfile);

  return (
    <AuthContext.Provider
      value={{
        user,
        userProfile,
        isAdmin,
        loading,
        profileIncomplete,
        error,
        activeSection,
        setActiveSection,
        signInWithGoogle,
        signUpWithEmail,
        signInWithEmail,
        logout,
        completeProfile,
        updateProfileData,
        clearError,
        refreshProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
