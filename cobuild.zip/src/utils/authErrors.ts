/**
 * Standardized Firebase Authentication Error Formatter
 * Translates Firebase auth error codes, network failures, and edge cases
 * into clear, user-friendly messages for normal end users.
 */

export function formatAuthError(error: unknown): string {
  if (!error) {
    return 'An unexpected error occurred during authentication. Please try again.';
  }

  let code = '';
  let message = '';

  if (typeof error === 'string') {
    message = error;
  } else if (typeof error === 'object' && error !== null) {
    if ('code' in error && typeof (error as any).code === 'string') {
      code = (error as any).code;
    }
    if ('message' in error && typeof (error as any).message === 'string') {
      message = (error as any).message;
    }
  }

  const combined = (code + ' ' + message).toLowerCase();

  // Invalid credentials / incorrect password
  if (
    combined.includes('auth/invalid-credential') ||
    combined.includes('invalid-credential') ||
    combined.includes('auth/wrong-password') ||
    combined.includes('wrong-password')
  ) {
    return 'Incorrect email address or password. Please verify your credentials and try again.';
  }

  // Account does not exist
  if (
    combined.includes('auth/user-not-found') ||
    combined.includes('user-not-found')
  ) {
    return 'No account exists with this email address. Please create an account.';
  }

  // Email already registered
  if (
    combined.includes('auth/email-already-in-use') ||
    combined.includes('email-already-in-use')
  ) {
    return 'This email address is already registered. Please sign in instead.';
  }

  // Weak password
  if (
    combined.includes('auth/weak-password') ||
    combined.includes('weak-password')
  ) {
    return 'Password is too weak. Please choose a password with at least 6 characters.';
  }

  // Invalid email syntax
  if (
    combined.includes('auth/invalid-email') ||
    combined.includes('invalid-email')
  ) {
    return 'Invalid email address. Please enter a valid email format (e.g., name@example.com).';
  }

  // Missing email or password
  if (combined.includes('auth/missing-email') || combined.includes('missing-email')) {
    return 'Please enter your email address.';
  }
  if (combined.includes('auth/missing-password') || combined.includes('missing-password')) {
    return 'Please enter your password.';
  }

  // Rate limiting / too many failed attempts
  if (
    combined.includes('auth/too-many-requests') ||
    combined.includes('too-many-requests')
  ) {
    return 'Access to this account has been temporarily disabled due to many failed login attempts. Please try again in a few minutes or reset your password.';
  }

  // Network connection issue
  if (
    combined.includes('auth/network-request-failed') ||
    combined.includes('network-request-failed')
  ) {
    return 'Network connection error. Please check your internet connection and try again.';
  }

  // Disabled account
  if (
    combined.includes('auth/user-disabled') ||
    combined.includes('user-disabled')
  ) {
    return 'This user account has been disabled. Please contact support for assistance.';
  }

  // Email/Password provider not enabled in Firebase Console
  if (
    combined.includes('auth/operation-not-allowed') ||
    combined.includes('operation-not-allowed')
  ) {
    return 'Email/Password sign-in is not enabled in the Firebase Console. Please sign in with Google, or enable Email/Password under Authentication > Sign-in method in Firebase.';
  }

  // Popup closed by user
  if (
    combined.includes('auth/popup-closed-by-user') ||
    combined.includes('popup-closed-by-user')
  ) {
    return 'Sign-in was cancelled before completion.';
  }

  // Popup blocked
  if (
    combined.includes('auth/popup-blocked') ||
    combined.includes('popup-blocked')
  ) {
    return 'Sign-in popup was blocked by your browser. Please allow popups for this site and try again.';
  }

  // Account exists with different credential
  if (
    combined.includes('auth/account-exists-with-different-credential') ||
    combined.includes('account-exists-with-different-credential')
  ) {
    return 'An account already exists with this email using a different sign-in method (such as Google). Please sign in with Google.';
  }

  // Internal error / service unavailable
  if (
    combined.includes('auth/internal-error') ||
    combined.includes('internal-error')
  ) {
    return 'Authentication service is temporarily unavailable. Please try again in a moment.';
  }

  // Clean raw Firebase error messages
  let cleanMsg = message
    .replace(/^Firebase:\s*/i, '')
    .replace(/\(auth\/[a-z0-9-]+\)\.?/gi, '')
    .trim();

  if (cleanMsg.startsWith('Error ')) {
    cleanMsg = cleanMsg.substring(6).trim();
  }

  return cleanMsg || 'Authentication failed. Please verify your details and try again.';
}
