/**
 * Reusable Avatar Registry & Asset Configuration
 *
 * Provides a clean abstraction mapping participant.avatarId -> avatar definition -> GLB URL.
 * Extensible for M01, M02, M03 ... M20 ... M30.
 *
 * Never requires hardcoded user logic ("if user X show model Y").
 * Instead:
 * participant.avatarId -> avatar registry -> GLB URL -> GLB loader -> rendered avatar
 */

import * as THREE from 'three';
import { GLTF, GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';

export interface AvatarDefinition {
  id: string; // 'M01', 'M02', ...
  name: string; // 'Avatar 1', 'Avatar 2', ...
  glbUrl: string; // Primary remote asset URL
  fallbackGlbUrl?: string; // High-res local replica fallback
  description: string;
  badge: string;
  previewColor: string;
  physique: string;
  features: string[];
  expectedBytes: number;
}

export const AVATAR_REGISTRY: Record<string, AvatarDefinition> = {
  M01: {
    id: 'M01',
    name: 'Avatar 1',
    glbUrl:
      'https://raw.githubusercontent.com/Gum-2310/kobuild/main/Meshy_AI_Athletic_Young_Man_0908082025_texture.glb',
    fallbackGlbUrl: '/Meshy_AI_Athletic_Young_Man_0908082025_texture.glb',
    description:
      'Textured PBR athletic competitor in performance training apparel. Calibrated for coliseum center-podium positioning.',
    badge: 'Avatar 1 • Official GLB',
    previewColor: '#E8491D',
    physique: 'Sculpted Athletic • 1.88m',
    features: ['7.87 MB Textured GLB', 'Full PBR Shading', 'Center Podium Calibrated'],
    expectedBytes: 8256816,
  },
  M02: {
    id: 'M02',
    name: 'Avatar 2',
    glbUrl: 'https://raw.githubusercontent.com/Gum-2310/kobuild/main/2nd%20one.glb',
    fallbackGlbUrl: '/2nd_one.glb',
    description:
      'Textured PBR athletic competitor model with distinct styling, athletic stance, and full physical geometry.',
    badge: 'Avatar 2 • Official GLB',
    previewColor: '#3B82F6',
    physique: 'High-Performance Athlete • 1.88m',
    features: ['6.05 MB Textured GLB', 'Full PBR Shading', 'Arena Calibrated'],
    expectedBytes: 6341304,
  },
  // Future avatars can be easily registered here:
  // M03: { id: 'M03', name: 'Avatar 3', ... },
  // M04: { id: 'M04', name: 'Avatar 4', ... },
};

export const DEFAULT_AVATAR_ID = 'M01';

/**
 * Resolves an avatarId to its registry definition.
 * Supports legacy draft IDs seamlessly as fallbacks.
 */
export function getAvatarById(avatarId?: string | null): AvatarDefinition {
  if (!avatarId) {
    return AVATAR_REGISTRY[DEFAULT_AVATAR_ID];
  }

  // Exact ID match
  if (AVATAR_REGISTRY[avatarId]) {
    return AVATAR_REGISTRY[avatarId];
  }

  // Case-insensitive / normalized lookup
  const upper = avatarId.toUpperCase();
  if (AVATAR_REGISTRY[upper]) {
    return AVATAR_REGISTRY[upper];
  }

  // Backward compatibility with preliminary slugs
  if (avatarId === 'meshy-athletic-young-man' || avatarId === 'meshy-athletic-striker') {
    return AVATAR_REGISTRY['M01'];
  }
  if (avatarId === 'meshy-athletic-endurance') {
    return AVATAR_REGISTRY['M02'];
  }

  return AVATAR_REGISTRY[DEFAULT_AVATAR_ID];
}

/**
 * Returns list of all available avatars in the registry
 */
export function getAllAvailableAvatars(): AvatarDefinition[] {
  return Object.values(AVATAR_REGISTRY);
}

// In-memory cache for parsed GLTF assets to prevent repeated network fetching and parsing
const gltfCache = new Map<string, Promise<GLTF>>();

/**
 * Loads a GLTF asset using the avatar registry, caching the result.
 * Automatically tries the remote URL first with smooth fallback to local asset.
 */
export function loadAvatarGlb(
  avatarId: string,
  onProgress?: (percent: number, loaded: number, total: number) => void
): Promise<{ gltf: GLTF; source: string; definition: AvatarDefinition }> {
  const definition = getAvatarById(avatarId);
  const cacheKey = definition.id;

  const cachedPromise = gltfCache.get(cacheKey);
  if (cachedPromise) {
    return cachedPromise.then((gltf) => ({
      gltf,
      source: 'Cached Asset',
      definition,
    }));
  }

  const loadPromise = new Promise<GLTF>((resolve, reject) => {
    const loader = new GLTFLoader();

    const handleProgress = (xhr: ProgressEvent) => {
      if (onProgress) {
        let percent = 0;
        if (xhr.lengthComputable && xhr.total > 0) {
          percent = Math.round((xhr.loaded / xhr.total) * 100);
        } else {
          percent = Math.min(99, Math.round((xhr.loaded / definition.expectedBytes) * 100));
        }
        onProgress(percent, xhr.loaded, xhr.total || definition.expectedBytes);
      }
    };

    loader.load(
      definition.glbUrl,
      (gltf) => {
        resolve(gltf);
      },
      handleProgress,
      (remoteErr) => {
        console.warn(`Remote load failed for ${definition.name}, trying fallback replica:`, remoteErr);
        if (definition.fallbackGlbUrl) {
          loader.load(
            definition.fallbackGlbUrl,
            (fallbackGltf) => {
              resolve(fallbackGltf);
            },
            handleProgress,
            (fallbackErr) => {
              console.error(`All load attempts failed for avatar ${definition.id}:`, fallbackErr);
              reject(fallbackErr);
            }
          );
        } else {
          reject(remoteErr);
        }
      }
    );
  });

  gltfCache.set(cacheKey, loadPromise);

  return loadPromise.then((gltf) => ({
    gltf,
    source: 'Network / Fallback',
    definition,
  }));
}
