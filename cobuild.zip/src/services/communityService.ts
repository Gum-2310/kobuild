import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  orderBy,
  onSnapshot,
  increment,
  Unsubscribe,
  limit,
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import {
  Community,
  CommunityMember,
  CommunityJoinRequest,
  CommunityFeedPost,
  CommunityFeedComment,
  CommunityMessage,
  CommunityFile,
  CommunityLiveSession,
  LiveSessionParticipant,
  ChallengeSubmission,
  ChallengeParticipantProgress,
  UserProfile,
  JoinRequestStatus,
} from '../types';
import { isUserPlatformAdmin } from './userService';

const COMMUNITIES_COLLECTION = 'communities';

/**
 * Creates a new Community and automatically enrolls creator as 'creator' member.
 * Enforces role-based authorization: only platform owners/admins can create official KOBUILD challenges.
 */
export async function createCommunity(
  data: Omit<Community, 'id' | 'memberCount' | 'createdAt' | 'updatedAt' | 'creatorId' | 'creatorName' | 'creatorPhotoURL'>,
  creator: UserProfile
): Promise<Community> {
  // Enforce role-based access for KOBUILD official challenges
  if (data.type === 'kobuild_official') {
    const isAdmin = isUserPlatformAdmin({ email: creator.email, uid: creator.uid }, creator);
    if (!isAdmin) {
      throw new Error('Unauthorized: Only the platform owner or administrator is permitted to launch official KOBUILD Challenges.');
    }
  }

  const commsRef = collection(db, COMMUNITIES_COLLECTION);
  const newDoc = doc(commsRef);
  const now = new Date().toISOString();

  const newCommunity: Community = {
    ...data,
    id: newDoc.id,
    creatorId: creator.uid,
    creatorName: creator.name,
    creatorPhotoURL: creator.photoURL || null,
    creatorBio: creator.bio || '',
    memberCount: 1,
    activeCount: 1,
    createdAt: now,
    updatedAt: now,
  };

  await setDoc(newDoc, newCommunity);

  // Add creator as member
  const memberRef = doc(db, COMMUNITIES_COLLECTION, newDoc.id, 'members', creator.uid);
  const creatorMember: CommunityMember = {
    id: creator.uid,
    communityId: newDoc.id,
    userId: creator.uid,
    userName: creator.name,
    userPhotoURL: creator.photoURL || null,
    userBio: creator.bio || '',
    userSkills: creator.skills || [],
    role: 'creator',
    joinedAt: now,
  };
  await setDoc(memberRef, creatorMember);

  return newCommunity;
}

/**
 * Updates an existing Community document.
 * Enforces role checks: only platform owner/admin can update official challenges,
 * and creators (or admins) can update open communities.
 */
export async function updateCommunity(
  communityId: string,
  updates: Partial<Community>,
  currentUser?: UserProfile | null
): Promise<void> {
  const commRef = doc(db, COMMUNITIES_COLLECTION, communityId);
  const snap = await getDoc(commRef);
  if (!snap.exists()) {
    throw new Error('Community not found');
  }

  const existingData = snap.data() as Community;
  if (currentUser) {
    const isAdmin = isUserPlatformAdmin({ email: currentUser.email, uid: currentUser.uid }, currentUser);
    if (existingData.type === 'kobuild_official' && !isAdmin) {
      throw new Error('Unauthorized: Only platform owners and administrators can edit official KOBUILD challenges.');
    }
    if (existingData.type === 'open' && existingData.creatorId !== currentUser.uid && !isAdmin) {
      throw new Error('Unauthorized: You can only edit Open Communities that you created.');
    }
  }

  await updateDoc(commRef, {
    ...updates,
    updatedAt: new Date().toISOString(),
  });
}

/**
 * Deletes a Community document.
 * Enforces role checks: only platform owner/admin can delete official challenges.
 */
export async function deleteCommunity(
  communityId: string,
  currentUser?: UserProfile | null
): Promise<void> {
  const commRef = doc(db, COMMUNITIES_COLLECTION, communityId);
  const snap = await getDoc(commRef);
  if (!snap.exists()) {
    return;
  }

  const existingData = snap.data() as Community;
  if (currentUser) {
    const isAdmin = isUserPlatformAdmin({ email: currentUser.email, uid: currentUser.uid }, currentUser);
    if (existingData.type === 'kobuild_official' && !isAdmin) {
      throw new Error('Unauthorized: Only platform owners and administrators can delete official KOBUILD challenges.');
    }
    if (existingData.type === 'open' && existingData.creatorId !== currentUser.uid && !isAdmin) {
      throw new Error('Unauthorized: You can only delete Open Communities that you created.');
    }
  }

  await deleteDoc(commRef);
}

/**
 * Gets a Community by ID
 */
export async function getCommunityById(communityId: string): Promise<Community | null> {
  try {
    const commRef = doc(db, COMMUNITIES_COLLECTION, communityId);
    const snap = await getDoc(commRef);
    if (snap.exists()) {
      return snap.data() as Community;
    }
    const defaultComm = DEFAULT_PLATFORM_COMMUNITIES.find((c) => c.id === communityId);
    return defaultComm || null;
  } catch (err) {
    console.warn('Error fetching community by id, checking fallback list:', err);
    const defaultComm = DEFAULT_PLATFORM_COMMUNITIES.find((c) => c.id === communityId);
    return defaultComm || null;
  }
}

/**
 * Real-time listener for all communities
 */
export function subscribeAllCommunities(callback: (communities: Community[]) => void): Unsubscribe {
  const commsRef = collection(db, COMMUNITIES_COLLECTION);
  const q = query(commsRef, orderBy('createdAt', 'desc'));

  return onSnapshot(
    q,
    (snapshot) => {
      if (snapshot.empty) {
        // Yield default curated platform and open communities if Firestore is empty
        callback(DEFAULT_PLATFORM_COMMUNITIES);
        return;
      }
      const items: Community[] = [];
      snapshot.forEach((docSnap) => {
        items.push(docSnap.data() as Community);
      });
      callback(items);
    },
    (err) => {
      console.warn('Notice: Using default fallback communities for guest/offline view:', err.message);
      callback(DEFAULT_PLATFORM_COMMUNITIES);
    }
  );
}

/**
 * Subscribes to members of a community
 */
export function subscribeCommunityMembers(
  communityId: string,
  callback: (members: CommunityMember[]) => void
): Unsubscribe {
  const membersRef = collection(db, COMMUNITIES_COLLECTION, communityId, 'members');
  const q = query(membersRef, orderBy('joinedAt', 'asc'));

  return onSnapshot(
    q,
    (snapshot) => {
      const items: CommunityMember[] = [];
      snapshot.forEach((docSnap) => {
        items.push(docSnap.data() as CommunityMember);
      });
      callback(items);
    },
    (err) => {
      console.error('Error subscribing to community members:', err);
    }
  );
}

/**
 * Subscribes to join requests for a community (for creators/admins)
 */
export function subscribeCommunityJoinRequests(
  communityId: string,
  callback: (requests: CommunityJoinRequest[]) => void
): Unsubscribe {
  const requestsRef = collection(db, COMMUNITIES_COLLECTION, communityId, 'joinRequests');
  const q = query(requestsRef, orderBy('createdAt', 'desc'));

  return onSnapshot(
    q,
    (snapshot) => {
      const items: CommunityJoinRequest[] = [];
      snapshot.forEach((docSnap) => {
        items.push(docSnap.data() as CommunityJoinRequest);
      });
      callback(items);
    },
    (err) => {
      console.error('Error subscribing to join requests:', err);
    }
  );
}

/**
 * Subscribes to check if current user is a member of specific community
 */
export function subscribeUserMembershipStatus(
  communityId: string,
  userId: string | undefined,
  callback: (member: CommunityMember | null) => void
): Unsubscribe {
  if (!userId) {
    callback(null);
    return () => {};
  }

  const memberRef = doc(db, COMMUNITIES_COLLECTION, communityId, 'members', userId);
  return onSnapshot(
    memberRef,
    (snap) => {
      if (snap.exists()) {
        callback(snap.data() as CommunityMember);
      } else {
        callback(null);
      }
    },
    (err) => {
      console.error('Error subscribing to user membership status:', err);
      callback(null);
    }
  );
}

/**
 * Subscribes to user's pending/accepted/rejected join request for a community
 */
export function subscribeUserJoinRequestStatus(
  communityId: string,
  userId: string | undefined,
  callback: (request: CommunityJoinRequest | null) => void
): Unsubscribe {
  if (!userId) {
    callback(null);
    return () => {};
  }

  const requestRef = doc(db, COMMUNITIES_COLLECTION, communityId, 'joinRequests', userId);
  return onSnapshot(
    requestRef,
    (snap) => {
      if (snap.exists()) {
        callback(snap.data() as CommunityJoinRequest);
      } else {
        callback(null);
      }
    },
    (err) => {
      console.error('Error subscribing to user join request:', err);
      callback(null);
    }
  );
}

/**
 * Submits a Join Request for an approval-based community
 */
export async function requestToJoinCommunity(
  communityId: string,
  communityTitle: string,
  userProfile: UserProfile,
  message: string = ''
): Promise<void> {
  const now = new Date().toISOString();
  const requestRef = doc(db, COMMUNITIES_COLLECTION, communityId, 'joinRequests', userProfile.uid);

  const payload: CommunityJoinRequest = {
    id: userProfile.uid,
    communityId,
    communityTitle,
    userId: userProfile.uid,
    userName: userProfile.name,
    userPhotoURL: userProfile.photoURL || null,
    userBio: userProfile.bio || '',
    userSkills: userProfile.skills || [],
    message: message.trim() || `Hi! I'd like to join ${communityTitle}.`,
    status: 'pending',
    createdAt: now,
    updatedAt: now,
  };

  await setDoc(requestRef, payload);
}

/**
 * Directly joins a public community (no approval required).
 * Prevents duplicate memberships and duplicate count increments if clicked multiple times.
 */
export async function joinPublicCommunity(
  communityId: string,
  userProfile: UserProfile,
  avatarId?: string
): Promise<void> {
  const memberRef = doc(db, COMMUNITIES_COLLECTION, communityId, 'members', userProfile.uid);
  const existingSnap = await getDoc(memberRef);

  if (existingSnap.exists()) {
    // Already a member - if avatarId was provided and missing, update it safely
    if (avatarId && !existingSnap.data().avatarId) {
      await updateDoc(memberRef, {
        avatarId,
        updatedAt: new Date().toISOString(),
      });
    }
    return;
  }

  const now = new Date().toISOString();
  const payload: CommunityMember = {
    id: userProfile.uid,
    communityId,
    userId: userProfile.uid,
    userName: userProfile.name,
    userPhotoURL: userProfile.photoURL || null,
    userBio: userProfile.bio || '',
    userSkills: userProfile.skills || [],
    role: 'member',
    joinedAt: now,
    ...(avatarId ? { avatarId } : {}),
  };

  await setDoc(memberRef, payload);

  // Increment community member count only on initial join
  const commRef = doc(db, COMMUNITIES_COLLECTION, communityId);
  try {
    await updateDoc(commRef, {
      memberCount: increment(1),
      updatedAt: now,
    });
  } catch (err) {
    console.warn('Could not update memberCount on community doc:', err);
  }
}

/**
 * Persists selected 3D arena avatar ID for a user's membership in a specific community.
 */
export async function updateCommunityMemberAvatar(
  communityId: string,
  userId: string,
  avatarId: string
): Promise<void> {
  const memberRef = doc(db, COMMUNITIES_COLLECTION, communityId, 'members', userId);
  await setDoc(
    memberRef,
    {
      avatarId,
      updatedAt: new Date().toISOString(),
    },
    { merge: true }
  );
}

/**
 * Handles accepting or rejecting a Join Request
 */
export async function handleJoinRequest(
  communityId: string,
  request: CommunityJoinRequest,
  action: 'accept' | 'reject'
): Promise<void> {
  const now = new Date().toISOString();
  const requestRef = doc(db, COMMUNITIES_COLLECTION, communityId, 'joinRequests', request.userId);

  if (action === 'accept') {
    // 1. Add to members subcollection
    const memberRef = doc(db, COMMUNITIES_COLLECTION, communityId, 'members', request.userId);
    const memberPayload: CommunityMember = {
      id: request.userId,
      communityId,
      userId: request.userId,
      userName: request.userName,
      userPhotoURL: request.userPhotoURL || null,
      userBio: request.userBio || '',
      userSkills: request.userSkills || [],
      role: 'member',
      joinedAt: now,
    };
    await setDoc(memberRef, memberPayload);

    // 2. Mark request as accepted
    await updateDoc(requestRef, {
      status: 'accepted' as JoinRequestStatus,
      updatedAt: now,
    });

    // 3. Increment member count
    const commRef = doc(db, COMMUNITIES_COLLECTION, communityId);
    await updateDoc(commRef, {
      memberCount: increment(1),
      updatedAt: now,
    });
  } else {
    // Mark as rejected
    await updateDoc(requestRef, {
      status: 'rejected' as JoinRequestStatus,
      updatedAt: now,
    });
  }
}

/**
 * Creator or admin removes a member from the community
 */
export async function removeCommunityMember(
  communityId: string,
  userId: string
): Promise<void> {
  const memberRef = doc(db, COMMUNITIES_COLLECTION, communityId, 'members', userId);
  await deleteDoc(memberRef);

  // Also clean up any joinRequest record so they can re-apply if desired
  const requestRef = doc(db, COMMUNITIES_COLLECTION, communityId, 'joinRequests', userId);
  try {
    await deleteDoc(requestRef);
  } catch {
    // Ignore if didn't exist
  }

  // Decrement member count
  const commRef = doc(db, COMMUNITIES_COLLECTION, communityId);
  await updateDoc(commRef, {
    memberCount: increment(-1),
    updatedAt: new Date().toISOString(),
  });
}

/**
 * User leaves a community
 */
export async function leaveCommunity(
  communityId: string,
  userId: string
): Promise<void> {
  await removeCommunityMember(communityId, userId);
}

// ----------------------------------------------------
// COMMUNITY FEED & COMMENTS
// ----------------------------------------------------

export function subscribeCommunityFeedPosts(
  communityId: string,
  callback: (posts: CommunityFeedPost[]) => void
): Unsubscribe {
  const feedRef = collection(db, COMMUNITIES_COLLECTION, communityId, 'feedPosts');
  const q = query(feedRef, orderBy('createdAt', 'desc'));

  return onSnapshot(
    q,
    (snapshot) => {
      const items: CommunityFeedPost[] = [];
      snapshot.forEach((docSnap) => {
        items.push(docSnap.data() as CommunityFeedPost);
      });
      callback(items);
    },
    (err) => {
      console.error('Error subscribing to community feed:', err);
    }
  );
}

export async function createCommunityFeedPost(
  communityId: string,
  author: UserProfile,
  content: string,
  mediaUrls?: { url: string; type: 'image' | 'video' | 'file'; name?: string }[],
  title?: string
): Promise<CommunityFeedPost> {
  const feedRef = collection(db, COMMUNITIES_COLLECTION, communityId, 'feedPosts');
  const newDoc = doc(feedRef);
  const now = new Date().toISOString();

  const payload: CommunityFeedPost = {
    id: newDoc.id,
    communityId,
    authorId: author.uid,
    authorName: author.name,
    authorPhotoURL: author.photoURL || null,
    authorRole: author.bio || 'Member',
    title: title?.trim() || undefined,
    content: content.trim(),
    mediaUrls: mediaUrls || [],
    reactions: {},
    commentsCount: 0,
    createdAt: now,
    updatedAt: now,
  };

  await setDoc(newDoc, payload);
  return payload;
}

export async function toggleFeedPostReaction(
  communityId: string,
  postId: string,
  userId: string,
  reactionType: string = 'like'
): Promise<void> {
  const postRef = doc(db, COMMUNITIES_COLLECTION, communityId, 'feedPosts', postId);
  const snap = await getDoc(postRef);
  if (!snap.exists()) return;

  const data = snap.data() as CommunityFeedPost;
  const currentReactions = data.reactions || {};
  const currentUsers = currentReactions[reactionType] || [];

  let nextUsers: string[];
  if (currentUsers.includes(userId)) {
    nextUsers = currentUsers.filter((id) => id !== userId);
  } else {
    nextUsers = [...currentUsers, userId];
  }

  await updateDoc(postRef, {
    reactions: {
      ...currentReactions,
      [reactionType]: nextUsers,
    },
    updatedAt: new Date().toISOString(),
  });
}

export function subscribeFeedPostComments(
  communityId: string,
  postId: string,
  callback: (comments: CommunityFeedComment[]) => void
): Unsubscribe {
  const commentsRef = collection(
    db,
    COMMUNITIES_COLLECTION,
    communityId,
    'feedPosts',
    postId,
    'comments'
  );
  const q = query(commentsRef, orderBy('createdAt', 'asc'));

  return onSnapshot(
    q,
    (snapshot) => {
      const items: CommunityFeedComment[] = [];
      snapshot.forEach((docSnap) => {
        items.push(docSnap.data() as CommunityFeedComment);
      });
      callback(items);
    },
    (err) => {
      console.error('Error subscribing to post comments:', err);
    }
  );
}

export async function addFeedPostComment(
  communityId: string,
  postId: string,
  author: UserProfile,
  content: string
): Promise<CommunityFeedComment> {
  const commentsRef = collection(
    db,
    COMMUNITIES_COLLECTION,
    communityId,
    'feedPosts',
    postId,
    'comments'
  );
  const newDoc = doc(commentsRef);
  const now = new Date().toISOString();

  const payload: CommunityFeedComment = {
    id: newDoc.id,
    postId,
    communityId,
    authorId: author.uid,
    authorName: author.name,
    authorPhotoURL: author.photoURL || null,
    content: content.trim(),
    createdAt: now,
  };

  await setDoc(newDoc, payload);

  // Increment comment count on post
  const postRef = doc(db, COMMUNITIES_COLLECTION, communityId, 'feedPosts', postId);
  await updateDoc(postRef, {
    commentsCount: increment(1),
  });

  return payload;
}

// ----------------------------------------------------
// COMMUNITY REAL-TIME CHAT
// ----------------------------------------------------

export function subscribeCommunityMessages(
  communityId: string,
  callback: (messages: CommunityMessage[]) => void
): Unsubscribe {
  const msgsRef = collection(db, COMMUNITIES_COLLECTION, communityId, 'messages');
  const q = query(msgsRef, orderBy('createdAt', 'asc'), limit(150));

  return onSnapshot(
    q,
    (snapshot) => {
      const items: CommunityMessage[] = [];
      snapshot.forEach((docSnap) => {
        items.push(docSnap.data() as CommunityMessage);
      });
      callback(items);
    },
    (err) => {
      console.error('Error subscribing to community messages:', err);
    }
  );
}

export async function sendCommunityMessage(
  communityId: string,
  sender: UserProfile,
  text: string,
  mediaUrl?: string,
  mediaType?: 'image' | 'video' | 'file',
  fileName?: string,
  fileSize?: string,
  replyTo?: { id: string; senderName: string; text: string } | null
): Promise<CommunityMessage> {
  const msgsRef = collection(db, COMMUNITIES_COLLECTION, communityId, 'messages');
  const newDoc = doc(msgsRef);
  const now = new Date().toISOString();

  const payload: CommunityMessage = {
    id: newDoc.id,
    communityId,
    senderId: sender.uid,
    senderName: sender.name,
    senderPhotoURL: sender.photoURL || null,
    text: text.trim(),
    mediaUrl: mediaUrl || undefined,
    mediaType: mediaType || undefined,
    fileName: fileName || undefined,
    fileSize: fileSize || undefined,
    replyTo: replyTo || null,
    reactions: {},
    createdAt: now,
  };

  await setDoc(newDoc, payload);
  return payload;
}

export async function toggleMessageReaction(
  communityId: string,
  messageId: string,
  userId: string,
  emoji: string
): Promise<void> {
  const msgRef = doc(db, COMMUNITIES_COLLECTION, communityId, 'messages', messageId);
  const snap = await getDoc(msgRef);
  if (!snap.exists()) return;

  const data = snap.data() as CommunityMessage;
  const currentReactions = data.reactions || {};
  const currentUsers = currentReactions[emoji] || [];

  let nextUsers: string[];
  if (currentUsers.includes(userId)) {
    nextUsers = currentUsers.filter((id) => id !== userId);
  } else {
    nextUsers = [...currentUsers, userId];
  }

  await updateDoc(msgRef, {
    reactions: {
      ...currentReactions,
      [emoji]: nextUsers,
    },
  });
}

// ----------------------------------------------------
// COMMUNITY FILES
// ----------------------------------------------------

export function subscribeCommunityFiles(
  communityId: string,
  callback: (files: CommunityFile[]) => void
): Unsubscribe {
  const filesRef = collection(db, COMMUNITIES_COLLECTION, communityId, 'files');
  const q = query(filesRef, orderBy('createdAt', 'desc'));

  return onSnapshot(
    q,
    (snapshot) => {
      const items: CommunityFile[] = [];
      snapshot.forEach((docSnap) => {
        items.push(docSnap.data() as CommunityFile);
      });
      callback(items);
    },
    (err) => {
      console.error('Error subscribing to community files:', err);
    }
  );
}

export async function uploadCommunityFile(
  communityId: string,
  uploader: UserProfile,
  name: string,
  size: string,
  type: 'document' | 'image' | 'video' | 'archive' | 'code' | 'other',
  url: string
): Promise<CommunityFile> {
  const filesRef = collection(db, COMMUNITIES_COLLECTION, communityId, 'files');
  const newDoc = doc(filesRef);
  const now = new Date().toISOString();

  const payload: CommunityFile = {
    id: newDoc.id,
    communityId,
    uploadedBy: uploader.uid,
    uploaderName: uploader.name,
    uploaderPhotoURL: uploader.photoURL || null,
    name: name.trim(),
    size,
    type,
    url,
    createdAt: now,
  };

  await setDoc(newDoc, payload);
  return payload;
}

export async function deleteCommunityFile(
  communityId: string,
  fileId: string
): Promise<void> {
  const fileRef = doc(db, COMMUNITIES_COLLECTION, communityId, 'files', fileId);
  await deleteDoc(fileRef);
}

// ----------------------------------------------------
// COMMUNITY LIVE AUDIO / VIDEO SESSIONS
// ----------------------------------------------------

export function subscribeCommunityLiveSessions(
  communityId: string,
  callback: (sessions: CommunityLiveSession[]) => void
): Unsubscribe {
  const liveRef = collection(db, COMMUNITIES_COLLECTION, communityId, 'liveSessions');
  const q = query(liveRef, orderBy('startedAt', 'desc'));

  return onSnapshot(
    q,
    (snapshot) => {
      const items: CommunityLiveSession[] = [];
      snapshot.forEach((docSnap) => {
        items.push(docSnap.data() as CommunityLiveSession);
      });
      callback(items);
    },
    (err) => {
      console.error('Error subscribing to live sessions:', err);
    }
  );
}

export async function startCommunityLiveSession(
  communityId: string,
  host: UserProfile,
  title: string
): Promise<CommunityLiveSession> {
  const liveRef = collection(db, COMMUNITIES_COLLECTION, communityId, 'liveSessions');
  const newDoc = doc(liveRef);
  const now = new Date().toISOString();

  const initialHostParticipant: LiveSessionParticipant = {
    userId: host.uid,
    userName: host.name,
    photoURL: host.photoURL || null,
    isAudioOn: true,
    isVideoOn: true,
    isScreenSharing: false,
    joinedAt: now,
  };

  const payload: CommunityLiveSession = {
    id: newDoc.id,
    communityId,
    hostId: host.uid,
    hostName: host.name,
    hostPhotoURL: host.photoURL || null,
    title: title.trim() || 'Community Live Session',
    active: true,
    participants: [initialHostParticipant],
    startedAt: now,
  };

  await setDoc(newDoc, payload);
  return payload;
}

export async function joinCommunityLiveSession(
  communityId: string,
  sessionId: string,
  user: UserProfile
): Promise<void> {
  const sessRef = doc(db, COMMUNITIES_COLLECTION, communityId, 'liveSessions', sessionId);
  const snap = await getDoc(sessRef);
  if (!snap.exists()) return;

  const data = snap.data() as CommunityLiveSession;
  const exists = data.participants.some((p) => p.userId === user.uid);

  let nextParticipants = data.participants;
  if (!exists) {
    nextParticipants = [
      ...data.participants,
      {
        userId: user.uid,
        userName: user.name,
        photoURL: user.photoURL || null,
        isAudioOn: true,
        isVideoOn: false,
        isScreenSharing: false,
        joinedAt: new Date().toISOString(),
      },
    ];
  }

  await updateDoc(sessRef, {
    active: true,
    participants: nextParticipants,
  });
}

export async function updateLiveParticipantState(
  communityId: string,
  sessionId: string,
  userId: string,
  isAudioOn: boolean,
  isVideoOn: boolean,
  isScreenSharing: boolean = false
): Promise<void> {
  const sessRef = doc(db, COMMUNITIES_COLLECTION, communityId, 'liveSessions', sessionId);
  const snap = await getDoc(sessRef);
  if (!snap.exists()) return;

  const data = snap.data() as CommunityLiveSession;
  const updatedParticipants = data.participants.map((p) => {
    if (p.userId === userId) {
      return { ...p, isAudioOn, isVideoOn, isScreenSharing };
    }
    return p;
  });

  await updateDoc(sessRef, {
    participants: updatedParticipants,
  });
}

export async function leaveCommunityLiveSession(
  communityId: string,
  sessionId: string,
  userId: string
): Promise<void> {
  const sessRef = doc(db, COMMUNITIES_COLLECTION, communityId, 'liveSessions', sessionId);
  const snap = await getDoc(sessRef);
  if (!snap.exists()) return;

  const data = snap.data() as CommunityLiveSession;
  const updatedParticipants = data.participants.filter((p) => p.userId !== userId);

  // If host leaves and no one remains, mark session inactive
  const isInactive = updatedParticipants.length === 0 || (data.hostId === userId && updatedParticipants.length === 0);

  await updateDoc(sessRef, {
    participants: updatedParticipants,
    active: !isInactive,
    endedAt: isInactive ? new Date().toISOString() : undefined,
  });
}

export async function endCommunityLiveSession(
  communityId: string,
  sessionId: string
): Promise<void> {
  const sessRef = doc(db, COMMUNITIES_COLLECTION, communityId, 'liveSessions', sessionId);
  await updateDoc(sessRef, {
    active: false,
    participants: [],
    endedAt: new Date().toISOString(),
  });
}

// ----------------------------------------------------
// CHALLENGE SUBMISSIONS & LEADERBOARD
// ----------------------------------------------------

export function subscribeCommunitySubmissions(
  communityId: string,
  callback: (submissions: ChallengeSubmission[]) => void
): Unsubscribe {
  const subsRef = collection(db, COMMUNITIES_COLLECTION, communityId, 'submissions');
  const q = query(subsRef, orderBy('submittedAt', 'desc'));

  return onSnapshot(
    q,
    (snapshot) => {
      const items: ChallengeSubmission[] = [];
      snapshot.forEach((docSnap) => {
        items.push(docSnap.data() as ChallengeSubmission);
      });
      callback(items);
    },
    (err) => {
      console.error('Error subscribing to challenge submissions:', err);
    }
  );
}

export async function submitChallengeDailyEntry(
  communityId: string,
  user: UserProfile,
  dayNumber: number,
  dateString: string,
  items: ChallengeSubmission['items'],
  pointsPerEntry: number = 25
): Promise<ChallengeSubmission> {
  // Use unique key per day per user: `${user.uid}_day_${dayNumber}` or date
  const subDocId = `${user.uid}_day_${dayNumber}`;
  const subRef = doc(db, COMMUNITIES_COLLECTION, communityId, 'submissions', subDocId);
  const now = new Date().toISOString();

  const totalPoints = items.length * pointsPerEntry;

  const payload: ChallengeSubmission = {
    id: subDocId,
    communityId,
    userId: user.uid,
    userName: user.name,
    userPhotoURL: user.photoURL || null,
    dayNumber,
    dateString,
    items,
    status: 'submitted',
    pointsEarned: totalPoints,
    submittedAt: now,
  };

  await setDoc(subRef, payload);
  return payload;
}

/**
 * Calculates user streaks, total points, badges, and leaderboard rankings
 */
export function calculateLeaderboard(
  submissions: ChallengeSubmission[],
  members: CommunityMember[]
): ChallengeParticipantProgress[] {
  const userMap: Record<string, {
    userId: string;
    userName: string;
    userPhotoURL?: string | null;
    submissionsByDay: Record<number, ChallengeSubmission>;
    totalScore: number;
    lastDate?: string;
  }> = {};

  // Initialize members in map
  members.forEach((m) => {
    userMap[m.userId] = {
      userId: m.userId,
      userName: m.userName,
      userPhotoURL: m.userPhotoURL || null,
      submissionsByDay: {},
      totalScore: 0,
    };
  });

  // Populate submissions
  submissions.forEach((sub) => {
    if (!userMap[sub.userId]) {
      userMap[sub.userId] = {
        userId: sub.userId,
        userName: sub.userName,
        userPhotoURL: sub.userPhotoURL || null,
        submissionsByDay: {},
        totalScore: 0,
      };
    }
    userMap[sub.userId].submissionsByDay[sub.dayNumber] = sub;
    userMap[sub.userId].totalScore += sub.pointsEarned || 0;
    if (!userMap[sub.userId].lastDate || sub.dateString > (userMap[sub.userId].lastDate || '')) {
      userMap[sub.userId].lastDate = sub.dateString;
    }
  });

  const progressList: ChallengeParticipantProgress[] = Object.values(userMap).map((u) => {
    const completedDaysCount = Object.keys(u.submissionsByDay).length;

    // Calculate current streak
    const dayNumbers = Object.keys(u.submissionsByDay)
      .map(Number)
      .sort((a, b) => b - a);

    let streak = 0;
    if (dayNumbers.length > 0) {
      let expected = dayNumbers[0];
      for (const d of dayNumbers) {
        if (d === expected) {
          streak++;
          expected--;
        } else {
          break;
        }
      }
    }

    // Determine earned badges
    const badges: string[] = [];
    if (completedDaysCount >= 1) badges.push('First Submission');
    if (streak >= 3) badges.push('3-Day Momentum');
    if (streak >= 7) badges.push('7-Day Unstoppable');
    if (streak >= 14) badges.push('2-Week Titan');
    if (streak >= 30) badges.push('30-Day Elite');
    if (streak >= 60) badges.push('60-Day Master');
    if (streak >= 90) badges.push('Winter Arc Champion');
    if (u.totalScore >= 500) badges.push('Score 500+');
    if (u.totalScore >= 2000) badges.push('Score 2000+');

    return {
      userId: u.userId,
      userName: u.userName,
      userPhotoURL: u.userPhotoURL || null,
      currentStreak: streak,
      completedDays: completedDaysCount,
      totalScore: u.totalScore,
      lastSubmissionDate: u.lastDate,
      badges,
    };
  });

  // Sort by totalScore desc, then completedDays desc
  progressList.sort((a, b) => {
    if (b.totalScore !== a.totalScore) return b.totalScore - a.totalScore;
    return b.completedDays - a.completedDays;
  });

  // Assign ranks
  return progressList.map((p, idx) => ({
    ...p,
    rank: idx + 1,
  }));
}

// ----------------------------------------------------
// DEFAULT PLATFORM & OPEN COMMUNITIES (Fallback & Seeds)
// ----------------------------------------------------

const nowFallback = new Date();
const startDateFallback = new Date(nowFallback.getFullYear(), nowFallback.getMonth(), 1).toISOString();
const endDateFallback = new Date(nowFallback.getFullYear(), nowFallback.getMonth() + 3, 1).toISOString();

export const DEFAULT_PLATFORM_COMMUNITIES: Community[] = [
  {
    id: 'kobuild-winter-arc-90',
    type: 'kobuild_official',
    title: '90 DAY WINTER ARC',
    description:
      'The flagship KOBUILD discipline and body transformation challenge. Complete daily nutrition, training, and habit checkpoints to climb the official leaderboard and earn exclusive rewards.',
    category: 'challenge',
    coverImage: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=1200&auto=format&fit=crop&q=80',
    creatorId: 'kobuild-platform-official',
    creatorName: 'KOBUILD Official',
    creatorPhotoURL: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=200&auto=format&fit=crop&q=80',
    creatorBio: 'KOBUILD Platform Operations & Challenge Master',
    rules: [
      'Submit 4 daily photo verifications every single day: Breakfast, Lunch, Dinner, Daily Progress.',
      'Submissions must be posted before 11:59 PM in your local timezone.',
      'Missing a day breaks your streak, but you can keep competing for total points.',
      'Maintain genuine community support and respect all builders.',
    ],
    tags: ['Winter Arc', '90 Days', 'Fitness', 'Discipline', 'Daily Photos', 'Prizes'],
    location: 'Global / All Regions',
    isPrivate: false,
    requireApproval: false,
    memberCount: 24,
    activeCount: 18,
    featured: true,
    trending: true,
    hasChallenge: true,
    challengeConfig: {
      startDate: startDateFallback,
      endDate: endDateFallback,
      durationDays: 90,
      rules: [
        'Upload breakfast nutrition photo',
        'Upload lunch nutrition photo',
        'Upload dinner nutrition photo',
        'Upload daily progress workout/focus photo',
      ],
      dailyRequirements: [
        {
          id: 'req_breakfast',
          title: 'Breakfast Photo',
          description: 'Healthy breakfast nutrition meal verification',
          type: 'photo',
          points: 25,
        },
        {
          id: 'req_lunch',
          title: 'Lunch Photo',
          description: 'Nutritious lunch meal verification',
          type: 'photo',
          points: 25,
        },
        {
          id: 'req_dinner',
          title: 'Dinner Photo',
          description: 'Clean dinner meal verification',
          type: 'photo',
          points: 25,
        },
        {
          id: 'req_progress',
          title: 'Daily Progress Photo',
          description: 'Workout, training session or physical progress snapshot',
          type: 'photo',
          points: 25,
        },
      ],
      scoringSystem: '100 points per full day (25 pts x 4 checkpoints) + streak bonuses',
      rewards: [
        {
          title: 'KOBUILD Winter Arc T-Shirt & Goodies Kit',
          description: 'Custom embroidered championship apparel shipped to top 5 finishers',
          badgeIcon: 'Shirt',
        },
        {
          title: 'Champion Verified Badge',
          description: 'Permanent golden builder badge displayed across KOBUILD profile',
          badgeIcon: 'Trophy',
        },
        {
          title: 'Builder Grant / Hardware Credit',
          description: '$500 cloud/gear credit awarded to the top scoring participant',
          badgeIcon: 'Gift',
        },
      ],
    },
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 12).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'kobuild-ai-hackathon-30',
    type: 'kobuild_official',
    title: '30 DAY FULL-STACK AI HACKATHON',
    description:
      'Build, iterate, and deploy an AI-powered agent or SaaS application in 30 days. Daily code commits and architecture checkpoints with live peer reviews.',
    category: 'hackathon',
    coverImage: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=1200&auto=format&fit=crop&q=80',
    creatorId: 'kobuild-platform-official',
    creatorName: 'KOBUILD Official',
    creatorPhotoURL: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=200&auto=format&fit=crop&q=80',
    creatorBio: 'KOBUILD Platform Operations',
    rules: [
      'Build open-source or commercial AI tools.',
      'Provide daily git commit links and weekly demo screencasts.',
      'Collaborate with at least 1 other KOBUILD member.',
    ],
    tags: ['AI', 'Hackathon', 'Next.js', 'Gemini', '30 Days', 'Cash Prize'],
    location: 'Global / Virtual',
    isPrivate: false,
    requireApproval: false,
    memberCount: 42,
    activeCount: 31,
    featured: true,
    trending: true,
    hasChallenge: true,
    challengeConfig: {
      startDate: startDateFallback,
      endDate: new Date(nowFallback.getFullYear(), nowFallback.getMonth() + 1, 1).toISOString(),
      durationDays: 30,
      rules: ['Daily GitHub commit submission', 'Weekly working demo link'],
      dailyRequirements: [
        {
          id: 'req_code_commit',
          title: 'Daily Code Commit / Repo Update',
          description: 'GitHub commit hash or repository progress link',
          type: 'link',
          points: 50,
        },
        {
          id: 'req_summary',
          title: 'Daily Architecture Note',
          description: 'What technical milestone did you solve today?',
          type: 'text',
          points: 50,
        },
      ],
      scoringSystem: '100 points per daily code milestone',
      rewards: [
        {
          title: '$2,500 Prototype Grant',
          description: 'Direct project seed grant for top 3 innovative applications',
          badgeIcon: 'Award',
        },
      ],
    },
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 8).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'community-hyderabad-builders',
    type: 'open',
    title: 'Hyderabad Tech & AI Builders',
    description:
      'Local community of developers, designers, and startup founders in Hyderabad. Weekly meetups, co-working sprints at T-Hub/Hitec City, and collaborative hackathons.',
    category: 'local',
    coverImage: 'https://images.unsplash.com/photo-1570168007204-dfb528c6958f?w=1200&auto=format&fit=crop&q=80',
    creatorId: 'user-hyderabad-lead',
    creatorName: 'Arjun Reddy',
    creatorPhotoURL: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
    creatorBio: 'Full-stack builder & Hyderabad Community Host',
    rules: [
      'Be constructive and open to collaboration.',
      'No self-promotional spam; share genuine projects and learnings.',
      'Active participation in monthly build meetups encouraged.',
    ],
    tags: ['Hyderabad', 'AI', 'Meetups', 'Local Builders', 'Startups'],
    location: 'Hyderabad, India',
    isPrivate: false,
    requireApproval: true,
    memberCount: 38,
    activeCount: 15,
    featured: false,
    trending: true,
    hasChallenge: false,
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 6).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'community-react-architecture',
    type: 'open',
    title: 'React & Next.js Advanced Architecture',
    description:
      'Deep dive into modern React 19, Server Components, State Machines, WebSockets, and high-performance WebGL integrations. Code reviews and pairing sessions.',
    category: 'coding',
    coverImage: 'https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=1200&auto=format&fit=crop&q=80',
    creatorId: 'user-react-lead',
    creatorName: 'Priya Sharma',
    creatorPhotoURL: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=200&auto=format&fit=crop&q=80',
    creatorBio: 'Frontend Engineer & Design Systems Architect',
    rules: [
      'Share actual code snippets and reproducible sandboxes.',
      'Assist fellow learners in debugging and architectural decisions.',
    ],
    tags: ['React', 'TypeScript', 'Next.js', 'Frontend', 'Design Systems'],
    location: 'Global',
    isPrivate: false,
    requireApproval: false,
    memberCount: 56,
    activeCount: 22,
    featured: false,
    trending: false,
    hasChallenge: false,
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 4).toISOString(),
    updatedAt: new Date().toISOString(),
  },
];

export async function seedInitialPlatformCommunities(isAdmin?: boolean): Promise<void> {
  // Only attempt Firestore persistence if called by a verified administrator
  if (!isAdmin) {
    return;
  }

  try {
    const commsRef = collection(db, COMMUNITIES_COLLECTION);
    const existingSnap = await getDocs(commsRef);
    if (!existingSnap.empty) {
      return; // Already populated
    }

    for (const seed of DEFAULT_PLATFORM_COMMUNITIES) {
      const docRef = doc(db, COMMUNITIES_COLLECTION, seed.id);
      await setDoc(docRef, seed);
    }
  } catch (err) {
    console.warn('Notice: Communities seeding skipped or restricted:', err);
  }
}
