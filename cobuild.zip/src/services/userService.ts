import {
  doc,
  getDoc,
  setDoc,
  updateDoc,
  deleteDoc,
  collection,
  query,
  where,
  getDocs,
  addDoc,
  increment,
  arrayUnion,
  onSnapshot,
  orderBy,
  Unsubscribe,
} from 'firebase/firestore';
import { db, auth } from '../lib/firebase';
import {
  UserProfile,
  UserStats,
  UserContribution,
  CommunityPost,
  Comment,
  BuildSpace,
  BuildSpaceMember,
  BuildSpaceTask,
  BuildRequest,
  Conversation,
  ConversationContext,
  ConversationParticipantDetail,
  ChatMessage,
  AppNotification,
  Ticket,
  Application,
  UserSection,
  ActiveBuildItem,
  UserCobuildActivityData,
  UserCommunityTicketActivity,
} from '../types';

const USERS_COLLECTION = 'users';
const TICKETS_COLLECTION = 'tickets';
const APPLICATIONS_COLLECTION = 'applications';
const COMMUNITY_POSTS_COLLECTION = 'communityPosts';
const COMMENTS_COLLECTION = 'comments';
const BUILD_SPACES_COLLECTION = 'buildSpaces';
const BUILD_REQUESTS_COLLECTION = 'buildRequests';
const CONVERSATIONS_COLLECTION = 'conversations';
const NOTIFICATIONS_COLLECTION = 'notifications';

/**
 * Safely fetches user profile from Firestore by UID
 */
export async function getUserProfile(uid: string): Promise<UserProfile | null> {
  try {
    const docRef = doc(db, USERS_COLLECTION, uid);
    const docSnap = await getDoc(docRef);

    if (docSnap.exists()) {
      return docSnap.data() as UserProfile;
    }
    return null;
  } catch (error) {
    console.error('Error fetching user profile:', error);
    throw error;
  }
}

/**
 * Creates a new user profile document in Firestore using only defined fields
 */
export async function createUserProfile(profile: Partial<UserProfile> & { uid: string; name: string; email: string }): Promise<void> {
  try {
    const docRef = doc(db, USERS_COLLECTION, profile.uid);
    const timestamp = new Date().toISOString();
    
    const payload: Record<string, any> = {
      uid: profile.uid,
      name: profile.name,
      email: profile.email,
      createdAt: profile.createdAt || timestamp,
      updatedAt: timestamp,
    };

    if (profile.role !== undefined) {
      payload.role = profile.role;
    }
    if (profile.isPlatformAdmin !== undefined) {
      payload.isPlatformAdmin = profile.isPlatformAdmin;
    }
    if (profile.photoURL !== undefined && profile.photoURL !== null) {
      payload.photoURL = profile.photoURL;
    }
    if (profile.preferredTrack !== undefined) {
      payload.preferredTrack = profile.preferredTrack;
    }
    if (profile.section !== undefined) {
      payload.section = profile.section;
    }
    if (profile.location) {
      payload.location = profile.location;
    }
    if (profile.bio) {
      payload.bio = profile.bio;
    }
    if (Array.isArray(profile.skills) && profile.skills.length > 0) {
      payload.skills = profile.skills;
    }
    if (Array.isArray(profile.interests) && profile.interests.length > 0) {
      payload.interests = profile.interests;
    }

    await setDoc(docRef, payload, { merge: true });
  } catch (error) {
    console.error('Error creating user profile:', error);
    throw error;
  }
}

/**
 * Updates an existing user profile document in Firestore
 */
export async function updateUserProfile(
  uid: string,
  updates: Partial<Omit<UserProfile, 'uid' | 'createdAt'>>
): Promise<void> {
  try {
    const docRef = doc(db, USERS_COLLECTION, uid);
    const timestamp = new Date().toISOString();

    const payload: Record<string, any> = {
      updatedAt: timestamp,
    };

    for (const [key, value] of Object.entries(updates)) {
      if (value !== undefined) {
        payload[key] = value;
      }
    }

    await updateDoc(docRef, payload);
  } catch (error) {
    console.error('Error updating user profile:', error);
    throw error;
  }
}

/**
 * Checks whether a user has platform owner / administrator privileges
 */
export const PLATFORM_ADMIN_EMAILS = [
  'admin@kobuild.com',
  'owner@kobuild.com',
  'platform@kobuild.com',
  'admin@gmail.com',
];

export function isUserPlatformAdmin(
  user: { email?: string | null; uid?: string } | null,
  profile?: UserProfile | null
): boolean {
  if (!user) return false;
  if (profile?.role === 'admin' || profile?.isPlatformAdmin === true) return true;
  if (user.email) {
    const emailLower = user.email.trim().toLowerCase();
    if (PLATFORM_ADMIN_EMAILS.includes(emailLower) || emailLower.endsWith('@kobuild.com')) {
      return true;
    }
  }
  return false;
}

/**
 * Checks whether a user profile already exists in Firestore
 */
export async function checkUserProfileExists(uid: string): Promise<boolean> {
  try {
    const docRef = doc(db, USERS_COLLECTION, uid);
    const docSnap = await getDoc(docRef);
    return docSnap.exists();
  } catch (error) {
    console.error('Error checking profile existence:', error);
    return false;
  }
}

/**
 * Fetches real user statistics from Firestore
 */
export async function getUserStatistics(uid: string): Promise<UserStats> {
  try {
    // 1. Tickets / Projects created
    const ticketsQuery = query(
      collection(db, TICKETS_COLLECTION),
      where('creatorId', '==', uid)
    );
    const ticketsSnap = await getDocs(ticketsQuery);
    const projectsCreated = ticketsSnap.size;

    // 2. Community posts / Ideas created
    const postsQuery = query(
      collection(db, COMMUNITY_POSTS_COLLECTION),
      where('creatorId', '==', uid)
    );
    const postsSnap = await getDocs(postsQuery);
    const communityPosts = postsSnap.size;

    // 3. Collaborations / Accepted applications
    const appsQuery = query(
      collection(db, APPLICATIONS_COLLECTION),
      where('applicantId', '==', uid)
    );
    const appsSnap = await getDocs(appsQuery);
    let collaborations = 0;
    appsSnap.forEach((doc) => {
      const data = doc.data();
      if (data.status === 'accepted') {
        collaborations += 1;
      }
    });

    const ideasCreated = communityPosts;
    const peopleConnected = collaborations + (projectsCreated > 0 ? 1 : 0);

    return {
      ideasCreated,
      projectsCreated,
      collaborations,
      communityPosts,
      peopleConnected,
    };
  } catch (error) {
    console.error('Error fetching user statistics:', error);
    // Return pristine zeroes on error/empty
    return {
      ideasCreated: 0,
      projectsCreated: 0,
      collaborations: 0,
      communityPosts: 0,
      peopleConnected: 0,
    };
  }
}

/**
 * Fetches real user contributions from Firestore (ideas + tickets)
 */
export async function getUserContributions(uid: string): Promise<UserContribution[]> {
  try {
    const contributions: UserContribution[] = [];

    // Query community posts created by user
    const postsQuery = query(
      collection(db, COMMUNITY_POSTS_COLLECTION),
      where('creatorId', '==', uid)
    );
    const postsSnap = await getDocs(postsQuery);
    postsSnap.forEach((docSnap) => {
      const data = docSnap.data();
      contributions.push({
        id: docSnap.id,
        title: data.title || 'Untitled Community Idea',
        type: 'community_idea',
        typeLabel: 'Community Idea',
        status: data.status || 'idea',
        section: data.creatorSection,
        createdAt: data.createdAt || new Date().toISOString(),
        engagement: `${data.upvotesCount || 0} upvotes • ${data.commentsCount || 0} replies`,
      });
    });

    // Query tickets created by user
    const ticketsQuery = query(
      collection(db, TICKETS_COLLECTION),
      where('creatorId', '==', uid)
    );
    const ticketsSnap = await getDocs(ticketsQuery);
    ticketsSnap.forEach((docSnap) => {
      const data = docSnap.data();
      contributions.push({
        id: docSnap.id,
        title: data.title || 'Untitled Project Ticket',
        type: 'project_ticket',
        typeLabel: 'Project Opportunity',
        status: data.status || 'open',
        section: data.section,
        createdAt: data.createdAt || new Date().toISOString(),
        engagement: `${data.skillsRequired?.length || 0} skills needed`,
      });
    });

    // Sort by latest createdAt
    return contributions.sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  } catch (error) {
    console.error('Error fetching user contributions:', error);
    return [];
  }
}

/**
 * Fetches all community posts from Firestore (ordered by newest first)
 */
export async function getCommunityPosts(): Promise<CommunityPost[]> {
  try {
    const snap = await getDocs(collection(db, COMMUNITY_POSTS_COLLECTION));
    const posts = snap.docs.map((d) => ({ id: d.id, ...d.data() } as CommunityPost));
    return posts.sort(
      (a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
    );
  } catch (error) {
    console.error('Error fetching community posts:', error);
    return [];
  }
}

/**
 * Subscribes to real-time updates for Community Posts
 */
export function subscribeCommunityPosts(
  callback: (posts: CommunityPost[]) => void
): Unsubscribe {
  const postsQuery = query(collection(db, COMMUNITY_POSTS_COLLECTION));
  return onSnapshot(
    postsQuery,
    (snap) => {
      const posts = snap.docs.map((d) => ({ id: d.id, ...d.data() } as CommunityPost));
      const sorted = posts.sort(
        (a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
      );
      callback(sorted);
    },
    (error) => {
      console.error('Error in community posts subscription:', error);
    }
  );
}

/**
 * Creates a new community post in Firestore.
 * Strictly binds creatorId to the authenticated Firebase User UID.
 */
export async function createCommunityPost(
  post: Omit<CommunityPost, 'id' | 'createdAt' | 'updatedAt' | 'upvotesCount' | 'commentsCount'> & {
    upvotesCount?: number;
    commentsCount?: number;
  }
): Promise<string> {
  try {
    const currentUser = auth.currentUser;
    if (!currentUser) {
      throw new Error('Authentication required to create a community post.');
    }

    const timestamp = new Date().toISOString();
    const docRef = await addDoc(collection(db, COMMUNITY_POSTS_COLLECTION), {
      ...post,
      creatorId: currentUser.uid, // Strictly lock creatorId to authenticated UID
      upvotesCount: post.upvotesCount ?? 0,
      commentsCount: post.commentsCount ?? 0,
      interestedCount: post.interestedCount ?? 0,
      buildRequestsCount: post.buildRequestsCount ?? 0,
      shortlistedCount: post.shortlistedCount ?? 0,
      teamRequirements: post.teamRequirements || [],
      status: post.status || 'idea',
      createdAt: timestamp,
      updatedAt: timestamp,
    });
    return docRef.id;
  } catch (error) {
    console.error('Error creating community post:', error);
    throw error;
  }
}

/**
 * Updates a community post (e.g., team requirements, title, status).
 * Verifies that the authenticated user is the original creator.
 */
export async function updateCommunityPost(
  postId: string,
  updates: Partial<CommunityPost>,
  expectedCreatorId?: string
): Promise<void> {
  try {
    const currentUser = auth.currentUser;
    if (!currentUser) {
      throw new Error('Authentication required to update this post.');
    }

    if (expectedCreatorId && expectedCreatorId !== currentUser.uid) {
      throw new Error('Unauthorized: Only the creator can update this post.');
    }

    // Verify creator ownership in Firestore
    const postRef = doc(db, COMMUNITY_POSTS_COLLECTION, postId);
    const postSnap = await getDoc(postRef);
    if (!postSnap.exists()) {
      throw new Error('Post not found.');
    }

    const data = postSnap.data();
    if (data.creatorId !== currentUser.uid) {
      throw new Error('Unauthorized: Only the creator can update this post.');
    }

    // Strip protected fields to prevent ownership tampering
    const safeUpdates = { ...updates };
    delete (safeUpdates as any).creatorId;
    delete (safeUpdates as any).id;
    delete (safeUpdates as any).createdAt;

    await updateDoc(postRef, {
      ...safeUpdates,
      updatedAt: new Date().toISOString(),
    });
  } catch (error) {
    console.error('Error updating community post:', error);
    throw error;
  }
}

/**
 * Permanently deletes a Community Post from Firestore.
 * Strictly verifies that the authenticated user is the original creator.
 */
export async function deleteCommunityPost(
  postId: string,
  expectedCreatorId?: string
): Promise<void> {
  try {
    const currentUser = auth.currentUser;
    if (!currentUser) {
      throw new Error('Authentication required to delete this ticket.');
    }

    if (expectedCreatorId && expectedCreatorId !== currentUser.uid) {
      throw new Error('Unauthorized: You can only delete collaboration tickets you created.');
    }

    const postRef = doc(db, COMMUNITY_POSTS_COLLECTION, postId);
    const postSnap = await getDoc(postRef);

    if (!postSnap.exists()) {
      // Document already removed
      return;
    }

    const data = postSnap.data();
    if (data.creatorId !== currentUser.uid) {
      throw new Error('Unauthorized: You can only delete collaboration tickets you created.');
    }

    await deleteDoc(postRef);

    // If this community post is linked to a collaboration ticket, delete the ticket too
    if (data.ticketId) {
      try {
        const ticketRef = doc(db, TICKETS_COLLECTION, data.ticketId);
        const ticketSnap = await getDoc(ticketRef);
        if (ticketSnap.exists() && ticketSnap.data().creatorId === currentUser.uid) {
          await deleteDoc(ticketRef);
        }
      } catch (ticketDelErr) {
        console.warn('Could not delete linked ticket for post:', ticketDelErr);
      }
    }
  } catch (error) {
    console.error('Error deleting community post:', error);
    throw error;
  }
}

/**
 * Expresses interest / like in a community post.
 * Also notifies the post creator and links/starts a direct communication channel.
 */
export async function expressInterestInPost(
  postId: string,
  incrementVal: number = 1,
  userProfile?: UserProfile | null,
  post?: CommunityPost | null
): Promise<void> {
  try {
    const postRef = doc(db, COMMUNITY_POSTS_COLLECTION, postId);
    await updateDoc(postRef, {
      interestedCount: increment(incrementVal),
      upvotesCount: increment(incrementVal),
      updatedAt: new Date().toISOString(),
    });

    // If a user profile and post are provided and it's positive engagement, notify creator and initialize chat path
    const currentUser = auth.currentUser;
    if (currentUser && incrementVal > 0 && post && post.creatorId && post.creatorId !== currentUser.uid) {
      const senderName = userProfile?.name || currentUser.displayName || 'A builder';
      
      // 1. Create in-app notification for the creator
      await createAppNotification({
        userId: post.creatorId,
        type: 'interest',
        title: 'Project Interest',
        message: `${senderName} is interested in your project "${post.title}".`,
        senderName,
        senderPhotoURL: userProfile?.photoURL || currentUser.photoURL || null,
        senderSection: userProfile?.section || 'student',
        relatedPostId: postId,
        contextTitle: post.title,
      });

      // 2. Connect direct conversation context
      if (userProfile) {
        await getOrCreateDirectConversation(
          userProfile,
          post.creatorId,
          {
            type: 'post',
            id: post.id,
            title: post.title,
            section: post.creatorSection,
            note: 'Interested in project',
          }
        ).catch(() => {});
      }
    }
  } catch (error) {
    console.error('Error expressing interest:', error);
    throw error;
  }
}

/* ==========================================================================
   COMMENTS SERVICES (Threaded, editable, deletable)
   ========================================================================== */

/**
 * Subscribes to real-time comments for a specific community post
 */
export function subscribePostComments(
  postId: string,
  callback: (comments: Comment[]) => void
): Unsubscribe {
  const commentsQuery = query(
    collection(db, COMMENTS_COLLECTION),
    where('postId', '==', postId)
  );

  return onSnapshot(
    commentsQuery,
    (snap) => {
      const comments = snap.docs.map((d) => ({ id: d.id, ...d.data() } as Comment));
      const sorted = comments.sort(
        (a, b) => new Date(a.createdAt || 0).getTime() - new Date(b.createdAt || 0).getTime()
      );
      callback(sorted);
    },
    (error) => {
      console.error('Error in comments subscription:', error);
    }
  );
}

/**
 * Adds a new comment or reply to a community post.
 * Automatically notifies the post creator and/or parent commenter.
 */
export async function addPostComment(
  comment: Omit<Comment, 'id' | 'createdAt' | 'updatedAt'>,
  postTitle?: string,
  postCreatorId?: string,
  parentCommentUserId?: string
): Promise<string> {
  try {
    const timestamp = new Date().toISOString();
    const docRef = await addDoc(collection(db, COMMENTS_COLLECTION), {
      ...comment,
      parentCommentId: comment.parentCommentId || null,
      createdAt: timestamp,
      updatedAt: timestamp,
    });

    // Atomically increment comment count on the post
    const postRef = doc(db, COMMUNITY_POSTS_COLLECTION, comment.postId);
    await updateDoc(postRef, {
      commentsCount: increment(1),
      updatedAt: timestamp,
    }).catch(() => {});

    // Notification Logic
    const currentUser = auth.currentUser;
    if (currentUser) {
      // 1. If replying to a specific comment, notify parent commenter
      if (comment.parentCommentId && parentCommentUserId && parentCommentUserId !== currentUser.uid) {
        await createAppNotification({
          userId: parentCommentUserId,
          type: 'reply',
          title: 'New Reply',
          message: `${comment.userName} replied to your comment on "${postTitle || 'Community Post'}".`,
          senderName: comment.userName,
          senderPhotoURL: comment.userPhotoURL || null,
          senderSection: comment.userSection,
          relatedPostId: comment.postId,
          contextTitle: postTitle,
        }).catch(() => {});
      }

      // 2. Notify post creator if commenter is not the post creator
      if (postCreatorId && postCreatorId !== currentUser.uid && postCreatorId !== parentCommentUserId) {
        await createAppNotification({
          userId: postCreatorId,
          type: 'comment',
          title: 'New Comment',
          message: `${comment.userName} commented on your post "${postTitle || 'Community Post'}".`,
          senderName: comment.userName,
          senderPhotoURL: comment.userPhotoURL || null,
          senderSection: comment.userSection,
          relatedPostId: comment.postId,
          contextTitle: postTitle,
        }).catch(() => {});
      }
    }

    return docRef.id;
  } catch (error) {
    console.error('Error adding comment:', error);
    throw error;
  }
}

/**
 * Updates a comment's content
 */
export async function updatePostComment(
  commentId: string,
  newContent: string
): Promise<void> {
  try {
    const commentRef = doc(db, COMMENTS_COLLECTION, commentId);
    await updateDoc(commentRef, {
      content: newContent,
      updatedAt: new Date().toISOString(),
    });
  } catch (error) {
    console.error('Error updating comment:', error);
    throw error;
  }
}

/**
 * Deletes a comment and decrements comment count
 */
export async function deletePostComment(
  commentId: string,
  postId: string
): Promise<void> {
  try {
    const commentRef = doc(db, COMMENTS_COLLECTION, commentId);
    await deleteDoc(commentRef);

    // Decrement comment count on the post
    const postRef = doc(db, COMMUNITY_POSTS_COLLECTION, postId);
    await updateDoc(postRef, {
      commentsCount: increment(-1),
      updatedAt: new Date().toISOString(),
    }).catch(() => {});
  } catch (error) {
    console.error('Error deleting comment:', error);
    throw error;
  }
}

/* ==========================================================================
   BUILD REQUESTS SERVICES ("Want to Build" -> Shortlist -> Launch)
   ========================================================================== */

/**
 * Subscribes to real-time build requests for a specific post
 */
export function subscribeBuildRequestsForPost(
  postId: string,
  callback: (requests: BuildRequest[]) => void
): Unsubscribe {
  const reqQuery = query(
    collection(db, BUILD_REQUESTS_COLLECTION),
    where('postId', '==', postId)
  );

  return onSnapshot(
    reqQuery,
    (snap) => {
      const requests = snap.docs.map((d) => ({ id: d.id, ...d.data() } as BuildRequest));
      const sorted = requests.sort(
        (a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
      );
      callback(sorted);
    },
    (error) => {
      console.error('Error subscribing to build requests:', error);
    }
  );
}

/**
 * Submits a Build Request ("Want to Build") to join an idea's team.
 * Creates notification for post creator and establishes/updates a direct conversation.
 */
export async function createBuildRequest(
  request: Omit<BuildRequest, 'id' | 'createdAt' | 'updatedAt' | 'status'>,
  postCreatorId?: string
): Promise<string> {
  try {
    const currentUser = auth.currentUser;
    if (!currentUser) {
      throw new Error('Authentication required to submit a build request.');
    }

    const timestamp = new Date().toISOString();
    const cleaned: Record<string, any> = {};
    for (const [key, value] of Object.entries(request)) {
      if (value !== undefined) {
        cleaned[key] = value;
      }
    }

    const docRef = await addDoc(collection(db, BUILD_REQUESTS_COLLECTION), {
      ...cleaned,
      applicantId: currentUser.uid, // Strictly lock applicantId to authenticated UID
      status: 'interested',
      createdAt: timestamp,
      updatedAt: timestamp,
    });

    // Increment post requests count
    const postRef = doc(db, COMMUNITY_POSTS_COLLECTION, request.postId);
    await updateDoc(postRef, {
      buildRequestsCount: increment(1),
      updatedAt: timestamp,
    }).catch(() => {});

    // Resolve post creator if not directly provided
    let creatorId = postCreatorId;
    let postTitle = request.postTitle || 'Project';
    if (!creatorId) {
      const postSnap = await getDoc(postRef);
      if (postSnap.exists()) {
        const postData = postSnap.data();
        creatorId = postData.creatorId;
        postTitle = postData.title || postTitle;
      }
    }

    // Trigger Notification & Direct Chat Channel
    if (creatorId && creatorId !== currentUser.uid) {
      // 1. In-app Notification
      await createAppNotification({
        userId: creatorId,
        type: 'want_to_build',
        title: 'Want to Build Request',
        message: `${request.applicantName} wants to build "${postTitle}".`,
        senderName: request.applicantName,
        senderPhotoURL: request.applicantPhotoURL || null,
        senderSection: request.applicantSection,
        relatedPostId: request.postId,
        contextTitle: postTitle,
      }).catch(() => {});

      // 2. Direct Chat Context & Starter Message
      const applicantProfile: Partial<UserProfile> & { uid: string; name: string } = {
        uid: currentUser.uid,
        name: request.applicantName,
        photoURL: request.applicantPhotoURL || null,
        section: request.applicantSection,
        location: request.applicantLocation,
        bio: request.applicantBio,
        skills: request.skills,
      };

      await getOrCreateDirectConversation(
        applicantProfile,
        creatorId,
        {
          type: 'post',
          id: request.postId,
          title: postTitle,
          note: 'Want to Build request',
        },
        request.message
      ).catch(() => {});
    }

    return docRef.id;
  } catch (error) {
    console.error('Error creating build request:', error);
    throw error;
  }
}

/**
 * Withdraws a Want to Build request
 */
export async function withdrawBuildRequest(
  requestId: string,
  postId: string
): Promise<void> {
  try {
    const currentUser = auth.currentUser;
    if (!currentUser) {
      throw new Error('Authentication required to withdraw request.');
    }

    const reqRef = doc(db, BUILD_REQUESTS_COLLECTION, requestId);
    const reqSnap = await getDoc(reqRef);
    if (reqSnap.exists()) {
      const data = reqSnap.data();
      if (data.applicantId !== currentUser.uid) {
        throw new Error('Unauthorized: You can only withdraw your own request.');
      }
    }

    await deleteDoc(reqRef);

    const postRef = doc(db, COMMUNITY_POSTS_COLLECTION, postId);
    await updateDoc(postRef, {
      buildRequestsCount: increment(-1),
      updatedAt: new Date().toISOString(),
    }).catch(() => {});
  } catch (error) {
    console.error('Error withdrawing build request:', error);
    throw error;
  }
}

/**
 * Updates a Build Request's status (interested | shortlisted | rejected | accepted)
 * Verifies that the authenticated user owns the parent idea post.
 */
export async function updateBuildRequestStatus(
  requestId: string,
  postId: string,
  status: 'interested' | 'shortlisted' | 'rejected' | 'accepted',
  previousStatus?: string
): Promise<void> {
  try {
    const currentUser = auth.currentUser;
    if (!currentUser) {
      throw new Error('Authentication required to update request status.');
    }

    // Verify creator of the post
    const postRef = doc(db, COMMUNITY_POSTS_COLLECTION, postId);
    const postSnap = await getDoc(postRef);
    if (!postSnap.exists()) {
      throw new Error('Associated community post not found.');
    }
    const postData = postSnap.data();
    if (postData.creatorId !== currentUser.uid) {
      throw new Error('Unauthorized: Only the idea creator can manage build requests.');
    }

    const reqRef = doc(db, BUILD_REQUESTS_COLLECTION, requestId);
    await updateDoc(reqRef, {
      status,
      updatedAt: new Date().toISOString(),
    });

    // If changing shortlisted state, adjust shortlisted count on post
    if (status === 'shortlisted' && previousStatus !== 'shortlisted') {
      await updateDoc(postRef, {
        shortlistedCount: increment(1),
        updatedAt: new Date().toISOString(),
      }).catch(() => {});
    } else if (previousStatus === 'shortlisted' && status !== 'shortlisted') {
      await updateDoc(postRef, {
        shortlistedCount: increment(-1),
        updatedAt: new Date().toISOString(),
      }).catch(() => {});
    }
  } catch (error) {
    console.error('Error updating build request status:', error);
    throw error;
  }
}

/**
 * Launches a Build Space from a validated idea and accepted shortlisted builders.
 * Implements strict idempotency (checks for existing build space before creating a new one),
 * sanitizes all fields to prevent Firestore undefined errors, updates member subcollections,
 * marks build requests as accepted, and establishes the squad conversation.
 */
export async function launchBuildSpaceFromIdea(params: {
  postId: string;
  postTitle: string;
  postDescription?: string;
  postCategory?: string;
  leadProfile?: Partial<UserProfile>;
  shortlistedBuilders?: BuildRequest[];
}): Promise<string> {
  try {
    const currentUser = auth.currentUser;
    if (!currentUser) {
      throw new Error('Authentication required to launch a Build Space.');
    }

    const {
      postId,
      postTitle,
      postDescription = '',
      postCategory = 'General',
      leadProfile = {},
      shortlistedBuilders = [],
    } = params;

    const leadUid = leadProfile.uid || currentUser.uid;
    const leadName =
      leadProfile.name || currentUser.displayName || currentUser.email?.split('@')[0] || 'Project Lead';
    const leadPhotoURL = leadProfile.photoURL || currentUser.photoURL || null;
    const leadSection: UserSection = leadProfile.section || 'student';

    // Verify creator authorization on the community post
    const postRef = doc(db, COMMUNITY_POSTS_COLLECTION, postId);
    const postSnap = await getDoc(postRef);
    if (postSnap.exists()) {
      const postData = postSnap.data();
      if (postData.creatorId && postData.creatorId !== currentUser.uid) {
        throw new Error('Unauthorized: Only the idea creator / project lead can launch this Build Space.');
      }
    }

    const timestamp = new Date().toISOString();

    // 1. Idempotency check: Check if a Build Space already exists for this post
    let existingSpaceId: string | null = null;

    if (postSnap.exists() && postSnap.data()?.buildSpaceId) {
      const candidateId = postSnap.data().buildSpaceId;
      const candidateSnap = await getDoc(doc(db, BUILD_SPACES_COLLECTION, candidateId));
      if (candidateSnap.exists()) {
        existingSpaceId = candidateId;
      }
    }

    if (!existingSpaceId) {
      // Query build spaces by originIdeaId or sourcePostId
      const qExisting = query(
        collection(db, BUILD_SPACES_COLLECTION),
        where('originIdeaId', '==', postId)
      );
      const snapExisting = await getDocs(qExisting);
      if (!snapExisting.empty) {
        existingSpaceId = snapExisting.docs[0].id;
      }
    }

    let targetSpaceId: string;

    if (existingSpaceId) {
      targetSpaceId = existingSpaceId;
      // Update existing build space document
      const spaceDocRef = doc(db, BUILD_SPACES_COLLECTION, targetSpaceId);
      await updateDoc(spaceDocRef, {
        title: postTitle || 'Build Space Project',
        description: postDescription || '',
        category: postCategory || 'General',
        status: 'building',
        memberCount: 1 + shortlistedBuilders.length,
        updatedAt: timestamp,
      }).catch((err) => {
        console.warn('Warning updating existing build space doc:', err);
      });
    } else {
      // Create new Build Space document
      const newSpaceData: Record<string, any> = {
        originIdeaId: postId,
        sourcePostId: postId,
        leadId: currentUser.uid,
        leadName,
        title: postTitle || 'Build Space Project',
        description: postDescription || '',
        category: postCategory || 'General',
        status: 'building',
        memberCount: 1 + shortlistedBuilders.length,
        repositoryUrl: '',
        deploymentUrl: '',
        createdAt: timestamp,
        updatedAt: timestamp,
      };

      const spaceRef = await addDoc(collection(db, BUILD_SPACES_COLLECTION), newSpaceData);
      targetSpaceId = spaceRef.id;
    }

    // 2. Add / Ensure Lead is in members subcollection
    const leadMemberRef = doc(
      db,
      `${BUILD_SPACES_COLLECTION}/${targetSpaceId}/members`,
      currentUser.uid
    );
    const leadMember: BuildSpaceMember = {
      id: currentUser.uid,
      buildSpaceId: targetSpaceId,
      userId: currentUser.uid,
      userName: leadName,
      userPhotoURL: leadPhotoURL,
      userSection: leadSection,
      role: 'lead',
      skills: leadProfile.skills || [],
      joinedAt: timestamp,
    };
    await setDoc(leadMemberRef, leadMember);

    // 3. Add each shortlisted builder to members subcollection & accept their request
    for (const b of shortlistedBuilders) {
      if (!b.applicantId) continue;

      const memberRef = doc(
        db,
        `${BUILD_SPACES_COLLECTION}/${targetSpaceId}/members`,
        b.applicantId
      );
      const memberData: BuildSpaceMember = {
        id: b.applicantId,
        buildSpaceId: targetSpaceId,
        userId: b.applicantId,
        userName: b.applicantName || 'Builder Member',
        userPhotoURL: b.applicantPhotoURL || null,
        userSection: b.applicantSection || 'student',
        role: 'member',
        skills: b.skills || [],
        joinedAt: timestamp,
      };
      await setDoc(memberRef, memberData);

      // Update the build request status to accepted
      if (b.id) {
        const reqRef = doc(db, BUILD_REQUESTS_COLLECTION, b.id);
        await updateDoc(reqRef, {
          status: 'accepted',
          updatedAt: timestamp,
        }).catch((err) => {
          console.warn('Warning updating build request status:', err);
        });
      }

      // Notify the builder that their space is live
      await createAppNotification({
        userId: b.applicantId,
        type: 'build_space',
        title: 'Build Space Launched!',
        message: `You were added to the Build Space for "${postTitle}". The workspace is ready!`,
        senderName: leadName,
        senderPhotoURL: leadPhotoURL,
        senderSection: leadSection,
        relatedPostId: postId,
        relatedBuildSpaceId: targetSpaceId,
        contextTitle: postTitle,
      }).catch(() => {});
    }

    // 4. Update original Community Post status to 'building'
    await updateDoc(postRef, {
      status: 'building',
      buildSpaceId: targetSpaceId,
      shortlistedCount: shortlistedBuilders.length,
      updatedAt: timestamp,
    }).catch((err) => {
      console.warn('Warning updating community post status:', err);
    });

    // 5. Create / update team conversation channel
    const memberUids = [currentUser.uid, ...shortlistedBuilders.map((b) => b.applicantId).filter(Boolean)];
    const participantNames: Record<string, string> = {
      [currentUser.uid]: leadName,
    };
    shortlistedBuilders.forEach((b) => {
      if (b.applicantId) {
        participantNames[b.applicantId] = b.applicantName || 'Builder';
      }
    });

    // Check if conversation already exists for this build space
    const convQuery = query(
      collection(db, CONVERSATIONS_COLLECTION),
      where('buildSpaceId', '==', targetSpaceId)
    );
    const existingConvs = await getDocs(convQuery);

    if (existingConvs.empty) {
      await addDoc(collection(db, CONVERSATIONS_COLLECTION), {
        type: 'build_space',
        buildSpaceId: targetSpaceId,
        title: `${postTitle} (Team Chat)`,
        participants: memberUids,
        participantNames,
        lastMessage: 'Build Space launched! Welcome to the squad workspace.',
        lastMessageAt: timestamp,
        createdAt: timestamp,
        updatedAt: timestamp,
      }).catch((err) => {
        console.warn('Warning creating build space conversation:', err);
      });
    } else {
      // Update existing conversation participants
      const existingConvDoc = existingConvs.docs[0];
      await updateDoc(existingConvDoc.ref, {
        participants: memberUids,
        participantNames,
        updatedAt: timestamp,
      }).catch(() => {});
    }

    return targetSpaceId;
  } catch (error) {
    console.error('Error launching build space from idea:', error);
    throw error;
  }
}

/**
 * Subscribes to real-time Build Spaces for a user.
 * STRICT ACCESS CONTROL:
 * - A user can ONLY access Build Spaces belonging to Collaboration Tickets THEY personally raised
 *   (or where they are an explicitly accepted collaborator).
 * - Never returns all build spaces or other users' private build spaces.
 */
export function subscribeUserBuildSpaces(
  uid: string,
  callback: (spaces: BuildSpace[]) => void
): Unsubscribe {
  if (!uid) {
    callback([]);
    return () => {};
  }

  let spacesByLead: BuildSpace[] = [];
  let spacesByTicket: BuildSpace[] = [];

  // 1. Query build spaces where user is the lead/owner
  const leadSpacesQuery = query(
    collection(db, BUILD_SPACES_COLLECTION),
    where('leadId', '==', uid)
  );

  // 2. Query tickets raised by this user to guarantee 1-to-1 sync with Build Spaces
  const userTicketsQuery = query(
    collection(db, TICKETS_COLLECTION),
    where('creatorId', '==', uid)
  );

  const notify = () => {
    const spaceMap = new Map<string, BuildSpace>();

    // Add explicit build spaces
    spacesByLead.forEach((s) => spaceMap.set(s.id, s));

    // For any ticket raised by the user that doesn't have an explicit build space yet,
    // ensure it is seamlessly represented and synchronized
    spacesByTicket.forEach((s) => {
      if (!spaceMap.has(s.id)) {
        spaceMap.set(s.id, s);
      }
    });

    const merged = Array.from(spaceMap.values());
    merged.sort(
      (a, b) =>
        new Date(b.updatedAt || b.createdAt || 0).getTime() -
        new Date(a.updatedAt || a.createdAt || 0).getTime()
    );

    callback(merged);
  };

  const unsubLead = onSnapshot(
    leadSpacesQuery,
    (snap) => {
      spacesByLead = snap.docs.map((d) => ({ id: d.id, ...d.data() } as BuildSpace));
      notify();
    },
    (err) => {
      console.warn('Error subscribing to lead build spaces:', err);
      spacesByLead = [];
      notify();
    }
  );

  const unsubTickets = onSnapshot(
    userTicketsQuery,
    (snap) => {
      spacesByTicket = snap.docs.map((d) => {
        const t = d.data() as Ticket;
        return {
          id: d.id,
          ticketId: d.id,
          ticketCreatorId: t.creatorId,
          leadId: t.creatorId,
          leadName: t.creatorName || 'Ticket Owner',
          title: t.title,
          description: t.description,
          category: t.category || t.section || 'Collaboration',
          section: t.section,
          status: (t.status === 'closed' ? 'deployed' : t.status === 'in_progress' ? 'building' : 'forming') as any,
          memberCount: 1,
          memberIds: [t.creatorId],
          createdAt: t.createdAt || new Date().toISOString(),
          updatedAt: t.updatedAt || t.createdAt || new Date().toISOString(),
        } as BuildSpace;
      });
      notify();
    },
    (err) => {
      console.warn('Error subscribing to user tickets for build spaces:', err);
      spacesByTicket = [];
      notify();
    }
  );

  return () => {
    unsubLead();
    unsubTickets();
  };
}

/**
 * Fetches a single Build Space by ID with strict ownership/access validation.
 * If currentUid is supplied and user does NOT own or belong to the Build Space, rejects with null.
 */
export async function getBuildSpaceById(
  spaceId: string,
  currentUid?: string
): Promise<BuildSpace | null> {
  if (!spaceId) return null;
  try {
    const spaceRef = doc(db, BUILD_SPACES_COLLECTION, spaceId);
    const snap = await getDoc(spaceRef);
    
    if (snap.exists()) {
      const data = { id: snap.id, ...snap.data() } as BuildSpace;
      
      // Enforce security in the service layer:
      if (currentUid) {
        const isOwner = data.leadId === currentUid || data.ticketCreatorId === currentUid;
        const isMember = data.memberIds && Array.isArray(data.memberIds) && data.memberIds.includes(currentUid);
        if (!isOwner && !isMember) {
          console.warn(`[SECURITY] Access denied to Build Space ${spaceId} for user ${currentUid}`);
          return null;
        }
      }
      return data;
    }

    // Fallback: Check if spaceId corresponds to a Ticket created by currentUid
    const ticketRef = doc(db, TICKETS_COLLECTION, spaceId);
    const ticketSnap = await getDoc(ticketRef);
    if (ticketSnap.exists()) {
      const ticketData = ticketSnap.data() as Ticket;
      if (currentUid && ticketData.creatorId !== currentUid) {
        console.warn(`[SECURITY] Access denied to Ticket/Build Space ${spaceId} for user ${currentUid}`);
        return null;
      }

      // Initialize the Build Space in Firestore for consistency
      const timestamp = new Date().toISOString();
      const generatedSpace: BuildSpace = {
        id: spaceId,
        ticketId: spaceId,
        ticketCreatorId: ticketData.creatorId,
        leadId: ticketData.creatorId,
        leadName: ticketData.creatorName || 'Lead Builder',
        title: ticketData.title,
        description: ticketData.description,
        category: ticketData.category || ticketData.section,
        section: ticketData.section,
        status: ticketData.status === 'in_progress' ? 'building' : 'forming',
        memberCount: 1,
        memberIds: [ticketData.creatorId],
        createdAt: ticketData.createdAt || timestamp,
        updatedAt: ticketData.updatedAt || timestamp,
      };

      try {
        await setDoc(spaceRef, generatedSpace);
        const memberRef = doc(db, `${BUILD_SPACES_COLLECTION}/${spaceId}/members`, ticketData.creatorId);
        await setDoc(memberRef, {
          id: ticketData.creatorId,
          buildSpaceId: spaceId,
          userId: ticketData.creatorId,
          userName: ticketData.creatorName || 'Lead Builder',
          userPhotoURL: ticketData.creatorPhotoURL || null,
          userSection: ticketData.section,
          role: 'lead',
          skills: ticketData.skillsRequired || [],
          joinedAt: timestamp,
        });
      } catch (initErr) {
        console.warn('Could not persist auto-initialized build space to Firestore:', initErr);
      }

      return generatedSpace;
    }

    return null;
  } catch (error) {
    console.error('Error fetching build space by ID:', error);
    return null;
  }
}

/**
 * Subscribes to members for a specific Build Space
 */
export function subscribeBuildSpaceMembers(
  buildSpaceId: string,
  callback: (members: BuildSpaceMember[]) => void
): Unsubscribe {
  const membersQuery = collection(db, `${BUILD_SPACES_COLLECTION}/${buildSpaceId}/members`);

  return onSnapshot(
    membersQuery,
    (snap) => {
      const members = snap.docs.map((d) => ({ id: d.id, ...d.data() } as BuildSpaceMember));
      // Put lead first, then members sorted by join time
      members.sort((a, b) => {
        if (a.role === 'lead') return -1;
        if (b.role === 'lead') return 1;
        return new Date(a.joinedAt || 0).getTime() - new Date(b.joinedAt || 0).getTime();
      });
      callback(members);
    },
    (error) => {
      console.error('Error subscribing to build space members:', error);
      callback([]);
    }
  );
}

/**
 * Subscribes to tasks for a specific Build Space
 */
export function subscribeBuildSpaceTasks(
  buildSpaceId: string,
  callback: (tasks: BuildSpaceTask[]) => void
): Unsubscribe {
  const tasksQuery = collection(db, `${BUILD_SPACES_COLLECTION}/${buildSpaceId}/tasks`);

  return onSnapshot(
    tasksQuery,
    (snap) => {
      const tasks = snap.docs.map((d) => ({ id: d.id, ...d.data() } as BuildSpaceTask));
      tasks.sort(
        (a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
      );
      callback(tasks);
    },
    (error) => {
      console.error('Error subscribing to build space tasks:', error);
      callback([]);
    }
  );
}

/**
 * Adds a new task to a Build Space
 */
export async function addBuildSpaceTask(
  buildSpaceId: string,
  task: Omit<BuildSpaceTask, 'id' | 'createdAt' | 'updatedAt'>
): Promise<string> {
  try {
    const timestamp = new Date().toISOString();
    const docRef = await addDoc(
      collection(db, `${BUILD_SPACES_COLLECTION}/${buildSpaceId}/tasks`),
      {
        ...task,
        createdAt: timestamp,
        updatedAt: timestamp,
      }
    );
    return docRef.id;
  } catch (error) {
    console.error('Error adding build space task:', error);
    throw error;
  }
}

/**
 * Updates a task status or details in a Build Space
 */
export async function updateBuildSpaceTask(
  buildSpaceId: string,
  taskId: string,
  updates: Partial<BuildSpaceTask>
): Promise<void> {
  try {
    const taskRef = doc(db, `${BUILD_SPACES_COLLECTION}/${buildSpaceId}/tasks`, taskId);
    await updateDoc(taskRef, {
      ...updates,
      updatedAt: new Date().toISOString(),
    });
  } catch (error) {
    console.error('Error updating build space task:', error);
    throw error;
  }
}

/**
 * Deletes a task from a Build Space
 */
export async function deleteBuildSpaceTask(
  buildSpaceId: string,
  taskId: string
): Promise<void> {
  try {
    const taskRef = doc(db, `${BUILD_SPACES_COLLECTION}/${buildSpaceId}/tasks`, taskId);
    await deleteDoc(taskRef);
  } catch (error) {
    console.error('Error deleting build space task:', error);
    throw error;
  }
}

/**
 * Updates metadata for a Build Space (links, status, description)
 */
export async function updateBuildSpace(
  buildSpaceId: string,
  updates: Partial<BuildSpace>
): Promise<void> {
  try {
    const spaceRef = doc(db, BUILD_SPACES_COLLECTION, buildSpaceId);
    await updateDoc(spaceRef, {
      ...updates,
      updatedAt: new Date().toISOString(),
    });
  } catch (error) {
    console.error('Error updating build space:', error);
    throw error;
  }
}

/**
 * Creates a new Build Space directly
 */
export async function createBuildSpace(
  space: Omit<BuildSpace, 'id' | 'createdAt' | 'updatedAt' | 'memberCount'>,
  leadProfile: UserProfile
): Promise<string> {
  try {
    const timestamp = new Date().toISOString();
    const spaceRef = await addDoc(collection(db, BUILD_SPACES_COLLECTION), {
      ...space,
      leadId: leadProfile.uid,
      ticketCreatorId: leadProfile.uid,
      memberIds: [leadProfile.uid],
      memberCount: 1,
      createdAt: timestamp,
      updatedAt: timestamp,
    });

    // Add Lead to members subcollection
    const memberRef = doc(db, `${BUILD_SPACES_COLLECTION}/${spaceRef.id}/members`, leadProfile.uid);
    const leadMember: BuildSpaceMember = {
      id: leadProfile.uid,
      buildSpaceId: spaceRef.id,
      userId: leadProfile.uid,
      userName: leadProfile.name,
      userPhotoURL: leadProfile.photoURL,
      userSection: leadProfile.section,
      role: 'lead',
      skills: leadProfile.skills || [],
      joinedAt: timestamp,
    };
    await setDoc(memberRef, leadMember);

    if (space.originIdeaId) {
      const postRef = doc(db, COMMUNITY_POSTS_COLLECTION, space.originIdeaId);
      await updateDoc(postRef, {
        status: 'build_space_active',
        buildSpaceId: spaceRef.id,
        updatedAt: timestamp,
      }).catch(() => {});
    }

    return spaceRef.id;
  } catch (error) {
    console.error('Error creating build space:', error);
    throw error;
  }
}

/**
 * Fetches Build Spaces belonging strictly to the specified or current user
 */
export async function getBuildSpaces(uid?: string): Promise<BuildSpace[]> {
  try {
    const currentUid = uid || auth.currentUser?.uid;
    if (!currentUid) return [];
    const q = query(
      collection(db, BUILD_SPACES_COLLECTION),
      where('leadId', '==', currentUid)
    );
    const snap = await getDocs(q);
    return snap.docs.map((d) => ({ id: d.id, ...d.data() } as BuildSpace));
  } catch (error) {
    console.error('Error fetching build spaces:', error);
    return [];
  }
}

/* ==========================================================================
   CONVERSATION & REAL-TIME CHAT MESSAGING SERVICES
   ========================================================================== */

/**
 * Subscribes to real-time conversations for an authenticated user
 */
export function subscribeUserConversations(
  uid: string,
  callback: (conversations: Conversation[]) => void
): Unsubscribe {
  const convQuery = query(
    collection(db, CONVERSATIONS_COLLECTION),
    where('participants', 'array-contains', uid)
  );

  return onSnapshot(
    convQuery,
    (snap) => {
      const convs = snap.docs.map((d) => ({ id: d.id, ...d.data() } as Conversation));
      convs.sort((a, b) => {
        const timeA = new Date(a.lastMessageAt || a.updatedAt || a.createdAt || 0).getTime();
        const timeB = new Date(b.lastMessageAt || b.updatedAt || b.createdAt || 0).getTime();
        return timeB - timeA;
      });
      callback(convs);
    },
    (error) => {
      console.error('Error subscribing to conversations:', error);
      callback([]);
    }
  );
}

/**
 * Subscribes to real-time messages within a specific conversation
 */
export function subscribeConversationMessages(
  conversationId: string,
  callback: (messages: ChatMessage[]) => void
): Unsubscribe {
  const messagesQuery = query(
    collection(db, `${CONVERSATIONS_COLLECTION}/${conversationId}/messages`),
    orderBy('createdAt', 'asc')
  );

  return onSnapshot(
    messagesQuery,
    (snap) => {
      const msgs = snap.docs.map((d) => ({ id: d.id, ...d.data() } as ChatMessage));
      callback(msgs);
    },
    (error) => {
      console.error('Error subscribing to conversation messages:', error);
      callback([]);
    }
  );
}

/**
 * Gets or creates a direct conversation between two users with deduplication.
 * Attaches rich contextual metadata (e.g. ticket, idea post) and sends optional initial message.
 */
export async function getOrCreateDirectConversation(
  currentUser: Partial<UserProfile> & { uid: string; name: string },
  otherUserId: string,
  context?: ConversationContext,
  initialMessageText?: string
): Promise<string> {
  try {
    if (!currentUser.uid || !otherUserId || currentUser.uid === otherUserId) {
      throw new Error('Invalid conversation participants.');
    }

    const timestamp = new Date().toISOString();

    // 1. Check if direct conversation already exists between currentUser and otherUserId
    const convQuery = query(
      collection(db, CONVERSATIONS_COLLECTION),
      where('participants', 'array-contains', currentUser.uid)
    );
    const snap = await getDocs(convQuery);

    let existingConvDoc = snap.docs.find((d) => {
      const data = d.data();
      return (
        data.type === 'direct' &&
        Array.isArray(data.participants) &&
        data.participants.includes(otherUserId)
      );
    });

    if (existingConvDoc) {
      const convId = existingConvDoc.id;
      const existingData = existingConvDoc.data();

      const updates: Record<string, any> = {
        updatedAt: timestamp,
      };

      if (context) {
        updates.context = context;
      }

      // Update current user details in the participant map
      const details = existingData.participantDetails || {};
      details[currentUser.uid] = {
        name: currentUser.name || 'Builder',
        photoURL: currentUser.photoURL || null,
        section: currentUser.section || 'student',
        location: currentUser.location || '',
        bio: currentUser.bio || '',
        skills: currentUser.skills || [],
      };
      updates.participantDetails = details;

      await updateDoc(doc(db, CONVERSATIONS_COLLECTION, convId), updates);

      // If initialMessageText provided, send chat message
      if (initialMessageText?.trim()) {
        await sendChatMessage(convId, initialMessageText.trim(), currentUser, context?.title);
      }

      return convId;
    }

    // 2. Fetch other user's profile to populate initial metadata
    let otherUserProfile: UserProfile | null = null;
    try {
      otherUserProfile = await getUserProfile(otherUserId);
    } catch {
      // Non-blocking fallback
    }

    const otherName = otherUserProfile?.name || 'Builder';
    const participantNames: Record<string, string> = {
      [currentUser.uid]: currentUser.name,
      [otherUserId]: otherName,
    };

    const participantDetails: Record<string, ConversationParticipantDetail> = {
      [currentUser.uid]: {
        name: currentUser.name,
        photoURL: currentUser.photoURL || null,
        section: currentUser.section || 'student',
        location: currentUser.location || '',
        bio: currentUser.bio || '',
        skills: currentUser.skills || [],
      },
      [otherUserId]: {
        name: otherName,
        photoURL: otherUserProfile?.photoURL || null,
        section: otherUserProfile?.section || 'student',
        location: otherUserProfile?.location || '',
        bio: otherUserProfile?.bio || '',
        skills: otherUserProfile?.skills || [],
      },
    };

    const newConvData: Record<string, any> = {
      type: 'direct',
      participants: [currentUser.uid, otherUserId],
      participantNames,
      participantDetails,
      unreadCounts: {
        [currentUser.uid]: 0,
        [otherUserId]: initialMessageText ? 1 : 0,
      },
      lastMessage: initialMessageText || (context ? `Context: ${context.title}` : 'Started conversation'),
      lastMessageSenderId: currentUser.uid,
      lastMessageAt: timestamp,
      createdAt: timestamp,
      updatedAt: timestamp,
    };

    if (context) {
      newConvData.context = context;
    }

    const docRef = await addDoc(collection(db, CONVERSATIONS_COLLECTION), newConvData);
    const convId = docRef.id;

    // Send initial message if provided
    if (initialMessageText?.trim()) {
      await addDoc(collection(db, `${CONVERSATIONS_COLLECTION}/${convId}/messages`), {
        conversationId: convId,
        senderId: currentUser.uid,
        senderName: currentUser.name,
        senderPhotoURL: currentUser.photoURL || null,
        senderSection: currentUser.section || 'student',
        text: initialMessageText.trim(),
        contextNote: context?.title || null,
        readBy: [currentUser.uid],
        createdAt: timestamp,
      });

      // Notification for recipient
      await createAppNotification({
        userId: otherUserId,
        type: 'message',
        title: currentUser.name,
        message: initialMessageText.trim().length > 60 ? initialMessageText.trim().substring(0, 57) + '...' : initialMessageText.trim(),
        senderName: currentUser.name,
        senderPhotoURL: currentUser.photoURL || null,
        senderSection: currentUser.section,
        relatedConversationId: convId,
        contextTitle: context?.title,
      });
    }

    return convId;
  } catch (error) {
    console.error('Error getting or creating direct conversation:', error);
    throw error;
  }
}

/**
 * Sends a chat message into a conversation.
 * Updates the conversation's unread counts, last message, and sends in-app notifications.
 */
export async function sendChatMessage(
  conversationId: string,
  text: string,
  senderProfile: Partial<UserProfile> & { uid: string; name: string },
  contextNote?: string
): Promise<string> {
  try {
    const currentUser = auth.currentUser;
    if (!currentUser || currentUser.uid !== senderProfile.uid) {
      throw new Error('Authentication required to send message.');
    }

    const timestamp = new Date().toISOString();

    // 1. Add message to messages subcollection
    const msgRef = await addDoc(collection(db, `${CONVERSATIONS_COLLECTION}/${conversationId}/messages`), {
      conversationId,
      senderId: currentUser.uid,
      senderName: senderProfile.name || 'Builder',
      senderPhotoURL: senderProfile.photoURL || null,
      senderSection: senderProfile.section || 'student',
      text: text.trim(),
      contextNote: contextNote || null,
      readBy: [currentUser.uid],
      createdAt: timestamp,
    });

    // 2. Fetch conversation to get other participants
    const convRef = doc(db, CONVERSATIONS_COLLECTION, conversationId);
    const convSnap = await getDoc(convRef);
    if (convSnap.exists()) {
      const convData = convSnap.data() as Conversation;
      const otherParticipants = (convData.participants || []).filter((p) => p !== currentUser.uid);

      const unreadUpdates: Record<string, any> = {
        lastMessage: text.trim(),
        lastMessageSenderId: currentUser.uid,
        lastMessageAt: timestamp,
        updatedAt: timestamp,
      };

      otherParticipants.forEach((pId) => {
        unreadUpdates[`unreadCounts.${pId}`] = increment(1);
      });

      await updateDoc(convRef, unreadUpdates).catch((e) => console.error('Error updating conv unread:', e));

      // 3. Create notifications for other participants
      for (const recipientId of otherParticipants) {
        await createAppNotification({
          userId: recipientId,
          type: 'message',
          title: senderProfile.name || 'New Message',
          message: text.trim().length > 60 ? text.trim().substring(0, 57) + '...' : text.trim(),
          senderName: senderProfile.name,
          senderPhotoURL: senderProfile.photoURL || null,
          senderSection: senderProfile.section,
          relatedConversationId: conversationId,
          contextTitle: convData.context?.title || convData.title,
        }).catch(() => {});
      }
    }

    return msgRef.id;
  } catch (error) {
    console.error('Error sending chat message:', error);
    throw error;
  }
}

/**
 * Marks a conversation as read for a given user
 */
export async function markConversationAsRead(
  conversationId: string,
  uid: string
): Promise<void> {
  try {
    const convRef = doc(db, CONVERSATIONS_COLLECTION, conversationId);
    await updateDoc(convRef, {
      [`unreadCounts.${uid}`]: 0,
    }).catch(() => {});

    // Also mark any notifications tied to this conversation as read
    const notifQuery = query(
      collection(db, NOTIFICATIONS_COLLECTION),
      where('userId', '==', uid),
      where('relatedConversationId', '==', conversationId),
      where('read', '==', false)
    );
    const snap = await getDocs(notifQuery);
    const promises = snap.docs.map((d) => updateDoc(d.ref, { read: true }));
    await Promise.all(promises).catch(() => {});
  } catch (error) {
    console.error('Error marking conversation as read:', error);
  }
}

/**
 * Fetches conversations for a user
 */
export async function getUserConversations(uid: string): Promise<Conversation[]> {
  try {
    const convQuery = query(
      collection(db, CONVERSATIONS_COLLECTION),
      where('participants', 'array-contains', uid)
    );
    const snap = await getDocs(convQuery);
    return snap.docs.map((d) => ({ id: d.id, ...d.data() } as Conversation));
  } catch (error) {
    console.error('Error fetching conversations:', error);
    return [];
  }
}

/**
 * Seeds initial community posts if the collection is empty
 */
export async function seedInitialCommunityPostsIfEmpty(): Promise<void> {
  try {
    const snap = await getDocs(collection(db, COMMUNITY_POSTS_COLLECTION));
    if (!snap.empty) return;

    const seedPosts = [
      {
        creatorId: 'seed-creator-student',
        creatorName: 'Aarav Patel',
        creatorSection: 'student' as const,
        creatorLocation: 'Bangalore, India',
        title: 'Acoustic soil-sensor network that plays frequencies when plants need water',
        description:
          'Looking for a mechanical/electrical peer to prototype the moisture resonance probe. We already have the audio synthesis firmware running.',
        category: 'Hardware / IoT',
        tags: ['hardware', 'iot', 'student', 'audio'],
        status: 'idea' as const,
        upvotesCount: 14,
        commentsCount: 2,
        interestedCount: 4,
        buildRequestsCount: 2,
        teamRequirements: [
          { role: 'Hardware / PCB Engineer', count: 1 },
          { role: 'Embedded C++ Developer', count: 1 },
          { role: 'UI / Mobile Designer', count: 1 },
        ],
        targetTeamSize: 3,
        createdAt: new Date(Date.now() - 3600000 * 24).toISOString(),
        updatedAt: new Date(Date.now() - 3600000 * 24).toISOString(),
      },
      {
        creatorId: 'seed-creator-homemaker',
        creatorName: 'Sunita Sharma',
        creatorSection: 'homemaker' as const,
        creatorLocation: 'Pune, India',
        title: 'Neighborhood micro-bakery subscription delivering fresh sourdough at 7 AM on weekends',
        description:
          'I can bake 20 artisanal loaves every Saturday. Looking for a collaborator who can build a simple WhatsApp order manager and customer subscription tracker.',
        category: 'Culinary / Local Business',
        tags: ['culinary', 'local business', 'homemaker'],
        status: 'idea' as const,
        upvotesCount: 22,
        commentsCount: 3,
        interestedCount: 6,
        buildRequestsCount: 1,
        teamRequirements: [
          { role: 'Web / WhatsApp Bot Developer', count: 1 },
          { role: 'Local Marketing / Operations', count: 1 },
        ],
        targetTeamSize: 2,
        createdAt: new Date(Date.now() - 3600000 * 12).toISOString(),
        updatedAt: new Date(Date.now() - 3600000 * 12).toISOString(),
      },
    ];

    for (const post of seedPosts) {
      await addDoc(collection(db, COMMUNITY_POSTS_COLLECTION), post);
    }
  } catch (error) {
    console.error('Error seeding initial community posts:', error);
  }
}

/* ==========================================================================
   COLLAB TICKETS SERVICES (Students, Homemakers, Entrepreneurs)
   ========================================================================== */

/**
 * Safely resolves and normalizes a ticket's internal section identity.
 * Valid values: 'student' | 'homemaker' | 'entrepreneur'
 * Returns null if the section cannot be reliably identified so it will not pollute any section.
 * STRICT SINGLE SOURCE OF TRUTH: Never infers section from user profiles, creator accounts, or keyword guessing.
 */
export function resolveTicketSection(ticketData: any): UserSection | null {
  if (!ticketData) return null;

  // 1. Direct valid section field (Single source of truth)
  if (
    ticketData.section === 'student' ||
    ticketData.section === 'homemaker' ||
    ticketData.section === 'entrepreneur'
  ) {
    return ticketData.section;
  }

  // 2. Legacy fallback only if explicit targetSection was stored
  if (
    ticketData.targetSection === 'student' ||
    ticketData.targetSection === 'homemaker' ||
    ticketData.targetSection === 'entrepreneur'
  ) {
    return ticketData.targetSection;
  }

  // If section is missing or invalid, do NOT guess or infer from user profile or keywords.
  // Return null so the ticket will not pollute any section page.
  return null;
}

/**
 * Real-time subscription to all tickets in Firestore, returned as a map of ticket ID -> Ticket.
 * Single source of truth for ticket status and details across Collab and Community feeds.
 */
export function subscribeAllTickets(
  callback: (ticketsMap: Record<string, Ticket>) => void
): Unsubscribe {
  const ticketsQuery = query(collection(db, TICKETS_COLLECTION));

  return onSnapshot(
    ticketsQuery,
    (snap) => {
      const map: Record<string, Ticket> = {};
      snap.docs.forEach((d) => {
        const data = d.data();
        const resolved = resolveTicketSection(data);
        if (resolved) {
          map[d.id] = {
            id: d.id,
            ...data,
            section: resolved,
          } as Ticket;
        }
      });
      callback(map);
    },
    (error) => {
      console.error('Error subscribing to all tickets:', error);
      callback({});
    }
  );
}

/**
 * Subscribes in real-time to tickets for a specific section (student | homemaker | entrepreneur).
 * Strictly guarantees that tickets returned belong exclusively to the requested section.
 */
export function subscribeSectionTickets(
  section: UserSection,
  callback: (tickets: Ticket[]) => void
): Unsubscribe {
  const ticketsQuery = query(
    collection(db, TICKETS_COLLECTION),
    where('section', '==', section)
  );

  return onSnapshot(
    ticketsQuery,
    (snap) => {
      const tickets: Ticket[] = [];
      snap.docs.forEach((d) => {
        const data = d.data();
        const resolved = resolveTicketSection(data);
        if (resolved === section) {
          tickets.push({
            id: d.id,
            ...data,
            section: resolved,
          } as Ticket);
        }
      });

      const sorted = tickets.sort(
        (a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
      );
      callback(sorted);
    },
    (error) => {
      console.error(`Error subscribing to ${section} tickets:`, error);
      callback([]);
    }
  );
}

/**
 * Real-time subscription to the PUBLIC collaboration activity statistics for a specific section:
 * 1. Active Count: Only tickets belonging to this section where status !== 'closed'.
 * 2. Open Requests Count: Only tickets belonging to this section where status === 'open'.
 * Strict isolation by section (student, homemaker, entrepreneur).
 * Completely public and independent of the authenticated user.
 */
export function subscribeSectionActiveStats(
  section: UserSection,
  callback: (stats: { activeCount: number; openRequestsCount: number; loading: boolean }) => void
): Unsubscribe {
  const ticketsQuery = query(
    collection(db, TICKETS_COLLECTION),
    where('section', '==', section)
  );

  return onSnapshot(
    ticketsQuery,
    (snap) => {
      let activeCount = 0;
      let openRequestsCount = 0;

      snap.docs.forEach((d) => {
        const data = d.data();
        const resolved = resolveTicketSection(data);
        if (resolved === section) {
          if (data.status !== 'closed') {
            activeCount += 1;
            if (data.status === 'open') {
              openRequestsCount += 1;
            }
          }
        }
      });

      callback({
        activeCount,
        openRequestsCount,
        loading: false,
      });
    },
    (err) => {
      console.error(`Error subscribing to ${section} active stats:`, err);
      callback({
        activeCount: 0,
        openRequestsCount: 0,
        loading: false,
      });
    }
  );
}

/**
 * Creates a new Collab Ticket in Firestore with explicit section validation.
 * Strictly binds creatorId to the authenticated Firebase User UID.
 * Automatically synchronizes an associated Community Post entry for unified discovery.
 */
export async function createSectionTicket(
  ticket: Omit<Ticket, 'id' | 'createdAt' | 'updatedAt' | 'interestedCount' | 'applicationsCount'> & {
    interestedCount?: number;
    applicationsCount?: number;
  }
): Promise<string> {
  try {
    const currentUser = auth.currentUser;
    if (!currentUser) {
      throw new Error('Authentication required to create a ticket.');
    }

    // Validate section strictly
    if (!ticket.section || !['student', 'homemaker', 'entrepreneur'].includes(ticket.section)) {
      throw new Error(`Invalid ticket section: "${ticket.section}". Must be "student", "homemaker", or "entrepreneur".`);
    }

    const timestamp = new Date().toISOString();
    const cleanedTicket: Record<string, any> = {};
    for (const [key, value] of Object.entries(ticket)) {
      if (value !== undefined) {
        cleanedTicket[key] = value;
      }
    }

    const docRef = await addDoc(collection(db, TICKETS_COLLECTION), {
      ...cleanedTicket,
      creatorId: currentUser.uid, // Strictly lock creatorId to authenticated UID
      section: ticket.section, // Strictly lock section identifier
      interestedCount: ticket.interestedCount ?? 0,
      applicationsCount: ticket.applicationsCount ?? 0,
      status: ticket.status || 'open',
      skillsRequired: Array.isArray(ticket.skillsRequired) ? ticket.skillsRequired : [],
      createdAt: timestamp,
      updatedAt: timestamp,
    });

    // Automatically create and link the private Build Space for this Collaboration Ticket
    try {
      const spaceRef = doc(db, BUILD_SPACES_COLLECTION, docRef.id);
      const spaceData: BuildSpace = {
        id: docRef.id,
        ticketId: docRef.id,
        ticketCreatorId: currentUser.uid,
        leadId: currentUser.uid,
        leadName: ticket.creatorName || currentUser.displayName || 'Lead Builder',
        title: ticket.title,
        description: ticket.description,
        category: ticket.category || ticket.section,
        section: ticket.section,
        status: 'forming',
        memberCount: 1,
        memberIds: [currentUser.uid],
        createdAt: timestamp,
        updatedAt: timestamp,
      };
      await setDoc(spaceRef, spaceData);

      const memberRef = doc(db, `${BUILD_SPACES_COLLECTION}/${docRef.id}/members`, currentUser.uid);
      await setDoc(memberRef, {
        id: currentUser.uid,
        buildSpaceId: docRef.id,
        userId: currentUser.uid,
        userName: ticket.creatorName || currentUser.displayName || 'Lead Builder',
        userPhotoURL: ticket.creatorPhotoURL || currentUser.photoURL || null,
        userSection: ticket.section,
        role: 'lead',
        skills: Array.isArray(ticket.skillsRequired) ? ticket.skillsRequired : [],
        joinedAt: timestamp,
      });

      await updateDoc(docRef, { buildSpaceId: docRef.id });
    } catch (spaceErr) {
      console.warn('Could not auto-create linked build space for ticket:', spaceErr);
    }

    // Auto-create associated Community Post representation for this Collaboration Ticket
    try {
      const skillsArray = Array.isArray(ticket.skillsRequired) ? ticket.skillsRequired : [];
      const teamRequirements = skillsArray.map((skill) => ({
        role: skill,
        count: 1,
      }));

      await addDoc(collection(db, COMMUNITY_POSTS_COLLECTION), {
        ticketId: docRef.id,
        ticketSection: ticket.section,
        creatorId: currentUser.uid,
        creatorName: ticket.creatorName || currentUser.displayName || 'Community Builder',
        creatorPhotoURL: ticket.creatorPhotoURL || currentUser.photoURL || null,
        creatorSection: ticket.section,
        creatorLocation: ticket.creatorLocation || ticket.location || '',
        title: ticket.title,
        description: ticket.description,
        category: ticket.category || 'Collaboration Opportunity',
        tags: [ticket.section, 'collaboration', ticket.category?.toLowerCase() || 'general'].filter(Boolean),
        status: 'idea',
        teamRequirements: teamRequirements.length > 0 ? teamRequirements : [{ role: 'Collaborator', count: ticket.peopleNeeded || 1 }],
        targetTeamSize: ticket.peopleNeeded || 2,
        upvotesCount: 0,
        commentsCount: 0,
        interestedCount: 0,
        buildRequestsCount: 0,
        createdAt: timestamp,
        updatedAt: timestamp,
      });
    } catch (communityErr) {
      console.warn('Could not auto-create linked community post for ticket:', communityErr);
    }

    return docRef.id;
  } catch (error) {
    console.error('Error creating ticket:', error);
    throw error;
  }
}

/**
 * Safely encodes a ticket ID for public sharing URLs without exposing raw internal database details.
 */
export function encodeTicketShareParam(ticketId: string): string {
  if (!ticketId) return '';
  try {
    return btoa(ticketId).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  } catch {
    return ticketId;
  }
}

/**
 * Decodes a ticket ID from a shared URL parameter.
 */
export function decodeTicketShareParam(param: string): string {
  if (!param) return '';
  try {
    let str = param.replace(/-/g, '+').replace(/_/g, '/');
    while (str.length % 4) str += '=';
    const decoded = atob(str);
    return decoded || param;
  } catch {
    return param;
  }
}

/**
 * Generates a clean, privacy-conscious public share URL for a collaboration ticket.
 */
export function generateTicketShareUrl(ticket: Ticket): string {
  const origin = typeof window !== 'undefined' ? window.location.origin : '';
  const pathname = typeof window !== 'undefined' ? window.location.pathname : '';
  const token = encodeTicketShareParam(ticket.id);
  const section = ticket.section || 'student';
  return `${origin}${pathname}?section=${encodeURIComponent(section)}&ticket=${encodeURIComponent(token)}`;
}

/**
 * Fetches a single collaboration ticket by ID from Firestore.
 */
export async function getSectionTicketById(ticketId: string): Promise<Ticket | null> {
  if (!ticketId) return null;
  try {
    const ticketRef = doc(db, TICKETS_COLLECTION, ticketId);
    const snap = await getDoc(ticketRef);
    if (!snap.exists()) {
      return null;
    }
    const data = snap.data();
    const resolved = resolveTicketSection(data);
    return {
      id: snap.id,
      ...data,
      section: resolved || (data.section as UserSection) || 'student',
    } as Ticket;
  } catch (error) {
    console.error('Error fetching ticket by ID:', error);
    return null;
  }
}

/**
 * Updates a Collab Ticket in Firestore.
 * Verifies that the authenticated user is the original creator.
 */
export async function updateSectionTicket(
  ticketId: string,
  updates: Partial<Ticket>,
  expectedCreatorId?: string
): Promise<void> {
  try {
    const currentUser = auth.currentUser;
    if (!currentUser) {
      throw new Error('Authentication required to update this ticket.');
    }

    if (expectedCreatorId && expectedCreatorId !== currentUser.uid) {
      throw new Error('Unauthorized: Only the creator can update this ticket.');
    }

    // Verify creator ownership in Firestore
    const ticketRef = doc(db, TICKETS_COLLECTION, ticketId);
    const ticketSnap = await getDoc(ticketRef);
    if (!ticketSnap.exists()) {
      throw new Error('Ticket not found.');
    }

    const data = ticketSnap.data();
    if (data.creatorId !== currentUser.uid) {
      throw new Error('Unauthorized: Only the creator can update this ticket.');
    }

    // Strip protected fields to prevent ownership or section tampering
    const safeUpdates = { ...updates };
    delete (safeUpdates as any).creatorId;
    delete (safeUpdates as any).id;
    delete (safeUpdates as any).createdAt;
    delete (safeUpdates as any).section;

    await updateDoc(ticketRef, {
      ...safeUpdates,
      updatedAt: new Date().toISOString(),
    });

    // If title, description, category, or skills changed, also update linked Community Post
    if (
      updates.title !== undefined ||
      updates.description !== undefined ||
      updates.category !== undefined ||
      updates.skillsRequired !== undefined ||
      updates.peopleNeeded !== undefined
    ) {
      try {
        const postsQuery = query(
          collection(db, COMMUNITY_POSTS_COLLECTION),
          where('ticketId', '==', ticketId)
        );
        const postSnaps = await getDocs(postsQuery);
        for (const pDoc of postSnaps.docs) {
          const postUpdates: any = {
            updatedAt: new Date().toISOString(),
          };
          if (updates.title !== undefined) postUpdates.title = updates.title;
          if (updates.description !== undefined) postUpdates.description = updates.description;
          if (updates.category !== undefined) postUpdates.category = updates.category;
          if (updates.skillsRequired !== undefined) {
            postUpdates.teamRequirements = updates.skillsRequired.map((s) => ({ role: s, count: 1 }));
          }
          if (updates.peopleNeeded !== undefined) postUpdates.targetTeamSize = updates.peopleNeeded;
          await updateDoc(doc(db, COMMUNITY_POSTS_COLLECTION, pDoc.id), postUpdates);
        }
      } catch (postSyncErr) {
        console.warn('Could not sync updates to linked community post:', postSyncErr);
      }
    }
  } catch (error) {
    console.error('Error updating ticket:', error);
    throw error;
  }
}

/**
 * Deletes a Collab Ticket in Firestore.
 * Strictly verifies that the authenticated user is the original creator.
 * Also cleans up any linked community posts to prevent orphaned or misleading active cards.
 */
export async function deleteSectionTicket(
  ticketId: string,
  expectedCreatorId?: string
): Promise<void> {
  try {
    const currentUser = auth.currentUser;
    if (!currentUser) {
      throw new Error('Authentication required to delete this ticket.');
    }

    if (expectedCreatorId && expectedCreatorId !== currentUser.uid) {
      throw new Error('Unauthorized: You can only delete collaboration tickets you created.');
    }

    const ticketRef = doc(db, TICKETS_COLLECTION, ticketId);
    const ticketSnap = await getDoc(ticketRef);

    if (!ticketSnap.exists()) {
      // Document already removed
      return;
    }

    const data = ticketSnap.data();
    if (data.creatorId !== currentUser.uid) {
      throw new Error('Unauthorized: You can only delete collaboration tickets you created.');
    }

    await deleteDoc(ticketRef);

    // Clean up associated build space if present
    try {
      await deleteDoc(doc(db, BUILD_SPACES_COLLECTION, ticketId));
      if (data.buildSpaceId && data.buildSpaceId !== ticketId) {
        await deleteDoc(doc(db, BUILD_SPACES_COLLECTION, data.buildSpaceId));
      }
    } catch (spaceCleanErr) {
      console.warn('Error cleaning up linked build space for ticket:', spaceCleanErr);
    }

    // Clean up associated community posts
    try {
      const postsQuery = query(
        collection(db, COMMUNITY_POSTS_COLLECTION),
        where('ticketId', '==', ticketId)
      );
      const postSnaps = await getDocs(postsQuery);
      for (const pDoc of postSnaps.docs) {
        await deleteDoc(doc(db, COMMUNITY_POSTS_COLLECTION, pDoc.id));
      }
    } catch (cleanErr) {
      console.warn('Error cleaning up linked community posts for ticket:', cleanErr);
    }
  } catch (error) {
    console.error('Error deleting ticket:', error);
    throw error;
  }
}

/**
 * Unified centralized deletion function for any collaboration ticket or community idea.
 * Validates authenticated user against document owner UID and removes the exact Firestore document.
 */
export async function deleteCollaborationTicket(
  documentId: string,
  collectionType: 'tickets' | 'communityPosts' = 'tickets',
  expectedCreatorId?: string
): Promise<void> {
  if (collectionType === 'communityPosts') {
    return deleteCommunityPost(documentId, expectedCreatorId);
  } else {
    return deleteSectionTicket(documentId, expectedCreatorId);
  }
}

/**
 * Expresses interest in a Collab Ticket.
 * Also notifies the ticket creator and links/starts a direct communication channel.
 */
export async function expressInterestInTicket(
  ticketId: string,
  incrementVal: number = 1,
  userProfile?: UserProfile | null,
  ticket?: Ticket | null
): Promise<void> {
  try {
    const ticketRef = doc(db, TICKETS_COLLECTION, ticketId);
    await updateDoc(ticketRef, {
      interestedCount: increment(incrementVal),
      updatedAt: new Date().toISOString(),
    });

    const currentUser = auth.currentUser;
    if (currentUser && incrementVal > 0 && ticket && ticket.creatorId && ticket.creatorId !== currentUser.uid) {
      const senderName = userProfile?.name || currentUser.displayName || 'A builder';

      // 1. In-app Notification for creator
      await createAppNotification({
        userId: ticket.creatorId,
        type: 'interest',
        title: 'Ticket Interest',
        message: `${senderName} expressed interest in your ticket "${ticket.title}".`,
        senderName,
        senderPhotoURL: userProfile?.photoURL || currentUser.photoURL || null,
        senderSection: userProfile?.section || 'student',
        relatedTicketId: ticketId,
        contextTitle: ticket.title,
      }).catch(() => {});

      // 2. Connect direct conversation context
      if (userProfile) {
        await getOrCreateDirectConversation(
          userProfile,
          ticket.creatorId,
          {
            type: 'ticket',
            id: ticket.id,
            title: ticket.title,
            section: ticket.section,
            note: 'Interested in collab ticket',
          }
        ).catch(() => {});
      }
    }
  } catch (error) {
    console.error('Error expressing interest in ticket:', error);
    throw error;
  }
}

/**
 * Submits an application / Want to Build request for a ticket.
 * Strictly binds applicantId to the authenticated Firebase User UID.
 * Notifies ticket creator and creates direct conversation channel.
 */
export async function createTicketApplication(
  application: Omit<Application, 'id' | 'createdAt' | 'updatedAt' | 'status'>,
  ticketCreatorId?: string
): Promise<string> {
  try {
    const currentUser = auth.currentUser;
    if (!currentUser) {
      throw new Error('Authentication required to submit an application.');
    }

    const timestamp = new Date().toISOString();
    const cleaned: Record<string, any> = {};
    for (const [key, value] of Object.entries(application)) {
      if (value !== undefined) {
        cleaned[key] = value;
      }
    }

    const docRef = await addDoc(collection(db, APPLICATIONS_COLLECTION), {
      ...cleaned,
      applicantId: currentUser.uid, // Strictly lock applicantId to authenticated UID
      status: 'pending',
      createdAt: timestamp,
      updatedAt: timestamp,
    });

    // Increment applications count on ticket
    const ticketRef = doc(db, TICKETS_COLLECTION, application.ticketId);
    await updateDoc(ticketRef, {
      applicationsCount: increment(1),
      updatedAt: timestamp,
    }).catch(() => {});

    // Resolve creator ID if not passed
    let creatorId = ticketCreatorId;
    let ticketTitle = application.ticketTitle || 'Collaboration Ticket';
    if (!creatorId) {
      const ticketSnap = await getDoc(ticketRef);
      if (ticketSnap.exists()) {
        const ticketData = ticketSnap.data();
        creatorId = ticketData.creatorId;
        ticketTitle = ticketData.title || ticketTitle;
      }
    }

    // Trigger notification and direct chat
    if (creatorId && creatorId !== currentUser.uid) {
      // 1. In-app Notification
      await createAppNotification({
        userId: creatorId,
        type: 'want_to_build',
        title: 'New Collaboration Application',
        message: `${application.applicantName} applied to your ticket "${ticketTitle}".`,
        senderName: application.applicantName,
        senderPhotoURL: application.applicantPhotoURL || null,
        senderSection: application.applicantSection,
        relatedTicketId: application.ticketId,
        contextTitle: ticketTitle,
      }).catch(() => {});

      // 2. Direct Chat Context & Starter Message
      const applicantProfile: Partial<UserProfile> & { uid: string; name: string } = {
        uid: currentUser.uid,
        name: application.applicantName,
        photoURL: application.applicantPhotoURL || null,
        section: application.applicantSection,
        location: application.applicantLocation,
        bio: application.applicantBio,
        skills: application.skills,
      };

      await getOrCreateDirectConversation(
        applicantProfile,
        creatorId,
        {
          type: 'ticket',
          id: application.ticketId,
          title: ticketTitle,
          section: application.ticketSection,
          note: 'Collab Application',
        },
        application.message
      ).catch(() => {});
    }

    return docRef.id;
  } catch (error) {
    console.error('Error creating ticket application:', error);
    throw error;
  }
}

/* ==========================================================================
   IN-APP NOTIFICATIONS SERVICES
   ========================================================================== */

/**
 * Creates an in-app notification in Firestore.
 * Prevents self-notifications and verifies sender authentication.
 */
export async function createAppNotification(
  notification: Omit<AppNotification, 'id' | 'createdAt' | 'read'>
): Promise<string> {
  try {
    const currentUser = auth.currentUser;
    if (!currentUser) return '';
    // Do not notify self
    if (notification.userId === currentUser.uid) return '';

    const timestamp = new Date().toISOString();
    const payload: Record<string, any> = {
      userId: notification.userId,
      type: notification.type,
      title: notification.title,
      message: notification.message,
      read: false,
      senderId: currentUser.uid,
      createdAt: timestamp,
    };

    if (notification.senderName) payload.senderName = notification.senderName;
    if (notification.senderPhotoURL !== undefined) payload.senderPhotoURL = notification.senderPhotoURL;
    if (notification.senderSection) payload.senderSection = notification.senderSection;
    if (notification.relatedTicketId) payload.relatedTicketId = notification.relatedTicketId;
    if (notification.relatedPostId) payload.relatedPostId = notification.relatedPostId;
    if (notification.relatedBuildSpaceId) payload.relatedBuildSpaceId = notification.relatedBuildSpaceId;
    if (notification.relatedConversationId) payload.relatedConversationId = notification.relatedConversationId;
    if (notification.contextTitle) payload.contextTitle = notification.contextTitle;

    const docRef = await addDoc(collection(db, NOTIFICATIONS_COLLECTION), payload);
    return docRef.id;
  } catch (error) {
    console.error('Error creating app notification:', error);
    return '';
  }
}

/**
 * Subscribes to real-time notifications for the current authenticated user
 */
export function subscribeUserNotifications(
  uid: string,
  callback: (notifications: AppNotification[]) => void
): Unsubscribe {
  const notifQuery = query(
    collection(db, NOTIFICATIONS_COLLECTION),
    where('userId', '==', uid)
  );

  return onSnapshot(
    notifQuery,
    (snap) => {
      const notifs = snap.docs.map((d) => ({ id: d.id, ...d.data() } as AppNotification));
      notifs.sort(
        (a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
      );
      callback(notifs);
    },
    (error) => {
      console.error('Error subscribing to notifications:', error);
      callback([]);
    }
  );
}

/**
 * Marks a specific notification as read
 */
export async function markNotificationAsRead(notificationId: string): Promise<void> {
  try {
    const notifRef = doc(db, NOTIFICATIONS_COLLECTION, notificationId);
    await updateDoc(notifRef, { read: true });
  } catch (error) {
    console.error('Error marking notification as read:', error);
  }
}

/**
 * Marks all notifications for a user as read
 */
export async function markAllNotificationsAsRead(uid: string): Promise<void> {
  try {
    const notifQuery = query(
      collection(db, NOTIFICATIONS_COLLECTION),
      where('userId', '==', uid),
      where('read', '==', false)
    );
    const snap = await getDocs(notifQuery);
    const promises = snap.docs.map((d) => updateDoc(d.ref, { read: true }));
    await Promise.all(promises);
  } catch (error) {
    console.error('Error marking all notifications as read:', error);
  }
}

/**
 * Deletes a notification
 */
export async function deleteNotification(notificationId: string): Promise<void> {
  try {
    const notifRef = doc(db, NOTIFICATIONS_COLLECTION, notificationId);
    await deleteDoc(notifRef);
  } catch (error) {
    console.error('Error deleting notification:', error);
  }
}

/**
 * Subscribes to applications for a specific ticket
 */
export function subscribeTicketApplications(
  ticketId: string,
  callback: (apps: Application[]) => void
): Unsubscribe {
  const appsQuery = query(
    collection(db, APPLICATIONS_COLLECTION),
    where('ticketId', '==', ticketId)
  );

  return onSnapshot(
    appsQuery,
    (snap) => {
      const apps = snap.docs.map((d) => ({ id: d.id, ...d.data() } as Application));
      const sorted = apps.sort(
        (a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
      );
      callback(sorted);
    },
    (error) => {
      console.error('Error subscribing to ticket applications:', error);
    }
  );
}

/**
 * Updates application status (pending | accepted | rejected).
 * Verifies that the authenticated user is the creator of the associated ticket.
 */
export async function updateTicketApplicationStatus(
  appId: string,
  status: 'pending' | 'accepted' | 'rejected'
): Promise<void> {
  try {
    const currentUser = auth.currentUser;
    if (!currentUser) {
      throw new Error('Authentication required to update application status.');
    }

    // Fetch the application and associated ticket to verify ownership
    const appRef = doc(db, APPLICATIONS_COLLECTION, appId);
    const appSnap = await getDoc(appRef);
    if (!appSnap.exists()) {
      throw new Error('Application not found.');
    }

    const appData = appSnap.data();
    const ticketRef = doc(db, TICKETS_COLLECTION, appData.ticketId);
    const ticketSnap = await getDoc(ticketRef);
    if (!ticketSnap.exists()) {
      throw new Error('Associated ticket not found.');
    }

    const ticketData = ticketSnap.data();
    if (ticketData.creatorId !== currentUser.uid) {
      throw new Error('Unauthorized: Only the ticket creator can review applications.');
    }

    await updateDoc(appRef, {
      status,
      updatedAt: new Date().toISOString(),
    });

    // If accepted, add applicant to the ticket's Build Space
    if (status === 'accepted') {
      try {
        const spaceId = ticketData.buildSpaceId || appData.ticketId;
        const spaceRef = doc(db, BUILD_SPACES_COLLECTION, spaceId);
        const spaceSnap = await getDoc(spaceRef);
        
        if (spaceSnap.exists()) {
          const memberRef = doc(db, `${BUILD_SPACES_COLLECTION}/${spaceId}/members`, appData.applicantId);
          await setDoc(memberRef, {
            id: appData.applicantId,
            buildSpaceId: spaceId,
            userId: appData.applicantId,
            userName: appData.applicantName || 'Collaborator',
            userPhotoURL: appData.applicantPhotoURL || null,
            userSection: appData.applicantSection || ticketData.section,
            role: 'member',
            skills: appData.skills || [],
            joinedAt: new Date().toISOString(),
          }, { merge: true });

          await updateDoc(spaceRef, {
            memberIds: arrayUnion(appData.applicantId),
            memberCount: increment(1),
            updatedAt: new Date().toISOString(),
          });
        }

        // Send notification to applicant
        await createAppNotification({
          userId: appData.applicantId,
          type: 'build_space',
          title: 'Collaboration Accepted!',
          message: `You were accepted into the Build Space for "${ticketData.title}".`,
          relatedTicketId: appData.ticketId,
          relatedBuildSpaceId: spaceId,
          contextTitle: ticketData.title,
        }).catch(() => {});
      } catch (collabErr) {
        console.warn('Could not sync accepted applicant to build space:', collabErr);
      }
    }
  } catch (error) {
    console.error('Error updating application status:', error);
    throw error;
  }
}

/**
 * Seeds initial tickets for all 3 Collab sections if empty
 */
export async function seedInitialTicketsIfEmpty(): Promise<void> {
  try {
    const snap = await getDocs(collection(db, TICKETS_COLLECTION));
    if (!snap.empty) return;

    const seedTickets: Omit<Ticket, 'id'>[] = [
      // 1. Student Tickets
      {
        creatorId: 'seed-student-1',
        creatorName: 'Rohan Deshmukh',
        creatorSection: 'student',
        creatorLocation: 'IIT Bombay / Mumbai',
        creatorBio: 'Final year Electronics student passionate about embedded robotics and autonomous drones.',
        section: 'student',
        title: 'Autonomous Solar Lawn Rover Capstone',
        description:
          'Building a GPS-guided, solar-rechargeable precision lawn rover for our final year capstone project. We already have the chassis fabricated and motor drivers tested. Looking for teammates to build the RTK-GPS path planning stack and a companion React Native mobile app.',
        category: 'Robotics & Embedded Systems',
        skillsRequired: ['ROS / C++', 'Computer Vision', 'React Native', 'CAD / 3D Printing'],
        peopleNeeded: 2,
        deadline: 'Nov 15, 2026',
        location: 'Mumbai / Hybrid',
        status: 'open',
        interestedCount: 5,
        applicationsCount: 2,
        createdAt: new Date(Date.now() - 3600000 * 20).toISOString(),
        updatedAt: new Date(Date.now() - 3600000 * 20).toISOString(),
      },
      {
        creatorId: 'seed-student-2',
        creatorName: 'Ananya Varma',
        creatorSection: 'student',
        creatorLocation: 'PES University / Bangalore',
        creatorBio: 'Computer Science junior specializing in Natural Language Processing and web systems.',
        section: 'student',
        title: 'AI Study Squad: Automated Flashcards from Lecture Slides',
        description:
          'Creating a web app that parses PDF lecture slides and automatically generates spaced-repetition Anki-compatible flashcards with key formula extraction. Looking for a frontend designer and an LLM pipeline builder.',
        category: 'EdTech & AI',
        skillsRequired: ['Next.js', 'FastAPI', 'Python NLP', 'Tailwind CSS'],
        peopleNeeded: 2,
        deadline: 'Dec 01, 2026',
        location: 'Remote',
        status: 'open',
        interestedCount: 8,
        applicationsCount: 3,
        createdAt: new Date(Date.now() - 3600000 * 10).toISOString(),
        updatedAt: new Date(Date.now() - 3600000 * 10).toISOString(),
      },

      // 2. Homemaker Tickets
      {
        creatorId: 'seed-homemaker-1',
        creatorName: 'Meera Kulkarni',
        creatorSection: 'homemaker',
        creatorLocation: 'Kothrud, Pune',
        creatorBio: 'Home baker with 6 years experience in natural sourdough, brioche, and sugar-free desserts.',
        section: 'homemaker',
        title: 'Weekend Artisanal Sourdough Delivery & WhatsApp Order Assistant',
        description:
          'I bake high-quality sourdough loaves and rustic pastries every weekend for over 35 local families. I need a collaborator to help organize automated weekly subscription reminders on WhatsApp, manage packaging logistics, and expand local neighborhood delivery routes.',
        category: 'Artisan Baking & Local Business',
        skillsRequired: ['Order Management', 'Local Delivery Logistics', 'Social Media Marketing', 'Packaging'],
        peopleNeeded: 1,
        deadline: 'Flexible / Ongoing',
        location: 'Pune / Local',
        status: 'open',
        interestedCount: 7,
        applicationsCount: 2,
        createdAt: new Date(Date.now() - 3600000 * 18).toISOString(),
        updatedAt: new Date(Date.now() - 3600000 * 18).toISOString(),
      },
      {
        creatorId: 'seed-homemaker-2',
        creatorName: 'Kavita Iyer',
        creatorSection: 'homemaker',
        creatorLocation: 'Indiranagar, Bangalore',
        creatorBio: 'Textile artisan specializing in handloom embroidery, macramé wall decor, and sustainable gift packaging.',
        section: 'homemaker',
        title: 'Handcrafted Festive Decor & Eco-Friendly Gift Hamper Studio',
        description:
          'Looking for a partner who loves photography, Instagram styling, or local pop-up coordination to collaborate on crafting handmade festive hampers and sustainable home accents for upcoming community flea markets and online orders.',
        category: 'Handmade Crafts & Styling',
        skillsRequired: ['Product Photography', 'Instagram Marketing', 'Craft Finishing', 'Pop-Up Stall Setup'],
        peopleNeeded: 2,
        deadline: 'Oct 30, 2026',
        location: 'Bangalore / On-site',
        status: 'open',
        interestedCount: 6,
        applicationsCount: 1,
        createdAt: new Date(Date.now() - 3600000 * 8).toISOString(),
        updatedAt: new Date(Date.now() - 3600000 * 8).toISOString(),
      },

      // 3. Entrepreneur Tickets
      {
        creatorId: 'seed-entrepreneur-1',
        creatorName: 'Vikram Sengupta',
        creatorSection: 'entrepreneur',
        creatorLocation: 'HSR Layout, Bangalore',
        creatorBio: 'Ex-Operations Lead at logistics startup; building IoT telematics for commercial fleet management.',
        section: 'entrepreneur',
        title: 'Commercial Fleet Predictive Maintenance SaaS MVP',
        description:
          'We have LOIs signed with two regional logistics operators (45 trucks total) to pilot predictive breakdown telematics. Looking for a Full-Stack Lead or Co-Founder with TypeScript, Node.js, and time-series data visualization experience to build out the real-time fleet dashboard.',
        category: 'B2B SaaS & Telematics',
        skillsRequired: ['Full-Stack TypeScript', 'PostgreSQL / Timescale', 'Tailwind CSS', 'IoT Protocols / MQTT'],
        peopleNeeded: 1,
        deadline: 'Nov 30, 2026',
        location: 'Bangalore / Remote',
        status: 'open',
        interestedCount: 11,
        applicationsCount: 4,
        createdAt: new Date(Date.now() - 3600000 * 15).toISOString(),
        updatedAt: new Date(Date.now() - 3600000 * 15).toISOString(),
      },
      {
        creatorId: 'seed-entrepreneur-2',
        creatorName: 'Shreya Nambiar',
        creatorSection: 'entrepreneur',
        creatorLocation: 'Cyber City, Gurugram',
        creatorBio: 'Founder at MedTech diagnostics venture focusing on automated slide stain analysis.',
        section: 'entrepreneur',
        title: 'AI Pathology Slide Triage Assistant - UI & Clinical Pipeline',
        description:
          'Developing a browser-based pathology viewport for triage scoring of hematology slides. Looking for a Senior Frontend Engineer proficient in WebGL/Canvas medical imaging and a Clinical Liaison to assist in validation with partner pathology labs.',
        category: 'HealthTech & AI',
        skillsRequired: ['WebGL / Canvas', 'React / TypeScript', 'Clinical Diagnostics', 'Product Design'],
        peopleNeeded: 2,
        deadline: 'Dec 15, 2026',
        location: 'Hybrid / Remote',
        status: 'open',
        interestedCount: 9,
        applicationsCount: 2,
        createdAt: new Date(Date.now() - 3600000 * 5).toISOString(),
        updatedAt: new Date(Date.now() - 3600000 * 5).toISOString(),
      },
    ];

    for (const ticket of seedTickets) {
      const docRef = await addDoc(collection(db, TICKETS_COLLECTION), ticket);
      try {
        const teamRequirements = (ticket.skillsRequired || []).map((s) => ({ role: s, count: 1 }));
        await addDoc(collection(db, COMMUNITY_POSTS_COLLECTION), {
          ticketId: docRef.id,
          ticketSection: ticket.section,
          creatorId: ticket.creatorId,
          creatorName: ticket.creatorName,
          creatorPhotoURL: null,
          creatorSection: ticket.section,
          creatorLocation: ticket.creatorLocation || ticket.location || '',
          title: ticket.title,
          description: ticket.description,
          category: ticket.category || 'Collaboration Opportunity',
          tags: [ticket.section, 'collaboration'],
          status: 'idea',
          teamRequirements: teamRequirements.length > 0 ? teamRequirements : [{ role: 'Collaborator', count: ticket.peopleNeeded || 1 }],
          targetTeamSize: ticket.peopleNeeded || 2,
          upvotesCount: ticket.interestedCount || 0,
          commentsCount: 0,
          interestedCount: ticket.interestedCount || 0,
          buildRequestsCount: ticket.applicationsCount || 0,
          createdAt: ticket.createdAt || new Date().toISOString(),
          updatedAt: ticket.updatedAt || new Date().toISOString(),
        });
      } catch (postSeedErr) {
        console.warn('Could not auto-seed linked community post for ticket:', postSeedErr);
      }
    }
  } catch (error) {
    console.error('Error seeding initial tickets:', error);
  }
}

/**
 * Subscribes in real-time to a user's CoBuild Activity data from real Firestore collections:
 * - Ideas Posted (community posts + tickets created by user)
 * - People Interested (sum of upvotes, build requests, interestedCount, applicationsCount across user's ideas/tickets)
 * - Projects Joined (accepted applications + accepted build requests)
 * - Projects Completed (completed tickets + deployed/showcased/completed build spaces)
 * - Active Build Spaces (active spaces where user is lead or member + in-progress tickets)
 * - Current Builds list (real projects/build spaces with title, status, member count)
 */
export function subscribeUserCobuildActivity(
  uid: string,
  callback: (data: UserCobuildActivityData) => void
): Unsubscribe {
  let userPosts: CommunityPost[] = [];
  let userTickets: Ticket[] = [];
  let userApplications: Application[] = [];
  let userBuildRequests: BuildRequest[] = [];
  let allBuildSpaces: BuildSpace[] = [];

  const recompute = () => {
    // 1. Ideas Posted (posts created + tickets created)
    const ideasPosted = userPosts.length + userTickets.length;

    // 2. People Interested (real total engagement from others across user's ideas & tickets)
    let peopleInterested = 0;
    userPosts.forEach((p) => {
      peopleInterested += (p.upvotesCount || 0) + (p.buildRequestsCount || 0) + (p.interestedCount || 0);
    });
    userTickets.forEach((t) => {
      peopleInterested += (t.interestedCount || 0) + (t.applicationsCount || 0);
    });

    // 3. Projects Joined (accepted applications to tickets + accepted build requests to posts)
    const acceptedApps = userApplications.filter((a) => a.status === 'accepted');
    const acceptedReqs = userBuildRequests.filter((r) => r.status === 'accepted');
    const projectsJoined = acceptedApps.length + acceptedReqs.length;

    // 4. Projects Completed (closed/completed tickets + deployed/showcase build spaces)
    const completedTickets = userTickets.filter((t) => t.status === 'closed').length;
    const completedSpaces = allBuildSpaces.filter(
      (s) => s.leadId === uid && (s.status === 'deployed' || s.status === 'showcase')
    ).length;
    const projectsCompleted = completedTickets + completedSpaces;

    // 5. Current Builds list (real active projects / build spaces / in-progress tickets)
    const currentBuilds: ActiveBuildItem[] = [];

    // Add active build spaces where user is lead
    const activeLeadSpaces = allBuildSpaces.filter(
      (s) => s.leadId === uid && (s.status === 'forming' || s.status === 'building')
    );
    activeLeadSpaces.forEach((s) => {
      currentBuilds.push({
        id: s.id,
        title: s.title,
        status: s.status === 'building' ? 'Active Build' : 'Team Forming',
        memberCount: s.memberCount || 1,
        role: 'Lead',
        category: s.category,
        source: 'build_space',
        updatedAt: s.updatedAt,
      });
    });

    // Add active in_progress tickets created by user
    userTickets
      .filter((t) => t.status === 'in_progress')
      .forEach((t) => {
        currentBuilds.push({
          id: t.id,
          title: t.title,
          status: 'In Progress',
          memberCount: (t.applicationsCount || 0) > 0 ? (t.applicationsCount || 0) + 1 : t.peopleNeeded || 1,
          role: 'Creator',
          category: t.category || t.section,
          source: 'ticket',
          updatedAt: t.updatedAt,
        });
      });

    // Add projects user joined via accepted applications
    acceptedApps.forEach((app) => {
      currentBuilds.push({
        id: app.ticketId,
        title: app.ticketTitle || 'Joined Project',
        status: 'Active Collab',
        memberCount: 2,
        role: 'Builder',
        category: app.ticketSection,
        source: 'application',
        updatedAt: app.updatedAt,
      });
    });

    // If no in_progress builds yet, but user has open tickets, include up to 2 open tickets as active projects
    if (currentBuilds.length === 0) {
      userTickets
        .filter((t) => t.status === 'open')
        .slice(0, 2)
        .forEach((t) => {
          currentBuilds.push({
            id: t.id,
            title: t.title,
            status: 'Team Forming',
            memberCount: (t.applicationsCount || 0) > 0 ? t.applicationsCount! : 1,
            role: 'Creator',
            category: t.category || t.section,
            source: 'ticket',
            updatedAt: t.updatedAt,
          });
        });
    }

    const activeBuildSpacesCount = currentBuilds.length;

    callback({
      ideasPosted,
      peopleInterested,
      projectsJoined,
      projectsCompleted,
      activeBuildSpacesCount,
      currentBuilds,
      loading: false,
    });
  };

  const unsubs: Unsubscribe[] = [];

  // Query 1: User's posts
  const postsQuery = query(
    collection(db, COMMUNITY_POSTS_COLLECTION),
    where('creatorId', '==', uid)
  );
  unsubs.push(
    onSnapshot(
      postsQuery,
      (snap) => {
        userPosts = snap.docs.map((d) => ({ id: d.id, ...d.data() } as CommunityPost));
        recompute();
      },
      (err) => console.error('Error in userPosts subscription:', err)
    )
  );

  // Query 2: User's tickets
  const ticketsQuery = query(
    collection(db, TICKETS_COLLECTION),
    where('creatorId', '==', uid)
  );
  unsubs.push(
    onSnapshot(
      ticketsQuery,
      (snap) => {
        userTickets = snap.docs.map((d) => ({ id: d.id, ...d.data() } as Ticket));
        recompute();
      },
      (err) => console.error('Error in userTickets subscription:', err)
    )
  );

  // Query 3: User's applications
  const appsQuery = query(
    collection(db, APPLICATIONS_COLLECTION),
    where('applicantId', '==', uid)
  );
  unsubs.push(
    onSnapshot(
      appsQuery,
      (snap) => {
        userApplications = snap.docs.map((d) => ({ id: d.id, ...d.data() } as Application));
        recompute();
      },
      (err) => console.error('Error in userApplications subscription:', err)
    )
  );

  // Query 4: User's build requests
  const reqsQuery = query(
    collection(db, BUILD_REQUESTS_COLLECTION),
    where('applicantId', '==', uid)
  );
  unsubs.push(
    onSnapshot(
      reqsQuery,
      (snap) => {
        userBuildRequests = snap.docs.map((d) => ({ id: d.id, ...d.data() } as BuildRequest));
        recompute();
      },
      (err) => console.error('Error in userBuildRequests subscription:', err)
    )
  );

  // Query 5: Build spaces
  const spacesQuery = query(
    collection(db, BUILD_SPACES_COLLECTION),
    where('leadId', '==', uid)
  );
  unsubs.push(
    onSnapshot(
      spacesQuery,
      (snap) => {
        allBuildSpaces = snap.docs.map((d) => ({ id: d.id, ...d.data() } as BuildSpace));
        recompute();
      },
      (err) => console.error('Error in buildSpaces subscription:', err)
    )
  );

  return () => {
    unsubs.forEach((u) => u());
  };
}

/**
 * Real-time subscription to a user's COMMUNITY TICKET activity for a specific section:
 * 1. ACTIVE TICKETS: Number of tickets in this section currently raised by the user that are still active/open (status !== 'closed')
 * 2. TOP LIKED: User's currently active ticket in this section with highest number of likes/interested count
 * 3. CURRENTLY WORKING: User's tickets in this section currently being worked on / have an active build team (status === 'in_progress')
 * 4. COMPLETED: Number of the user's tickets in this section completed (status === 'closed')
 */
export function subscribeUserTicketActivity(
  uid: string,
  section: UserSection,
  callback: (data: UserCommunityTicketActivity) => void
): Unsubscribe {
  const ticketsQuery = query(
    collection(db, TICKETS_COLLECTION),
    where('creatorId', '==', uid)
  );

  return onSnapshot(
    ticketsQuery,
    (snap) => {
      // 1. Resolve and filter strictly by the requested section
      const userSectionTickets: Ticket[] = [];
      snap.docs.forEach((d) => {
        const data = d.data();
        const resolved = resolveTicketSection(data);
        if (resolved === section) {
          userSectionTickets.push({
            id: d.id,
            ...data,
            section: resolved,
          } as Ticket);
        }
      });

      const activeTickets = userSectionTickets.filter((t) => t.status !== 'closed');
      const activeTicketsCount = activeTickets.length;
      const currentlyWorkingCount = userSectionTickets.filter((t) => t.status === 'in_progress').length;
      const completedCount = userSectionTickets.filter((t) => t.status === 'closed').length;

      let topLikedTicket: { id: string; title: string; likesCount: number } | null = null;
      if (activeTickets.length > 0) {
        const sorted = [...activeTickets].sort(
          (a, b) => (b.interestedCount || 0) - (a.interestedCount || 0)
        );
        topLikedTicket = {
          id: sorted[0].id,
          title: sorted[0].title,
          likesCount: sorted[0].interestedCount || 0,
        };
      }

      callback({
        activeTicketsCount,
        topLikedTicket,
        currentlyWorkingCount,
        completedCount,
        loading: false,
      });
    },
    (err) => {
      console.error(`Error in subscribeUserTicketActivity for ${section}:`, err);
      callback({
        activeTicketsCount: 0,
        topLikedTicket: null,
        currentlyWorkingCount: 0,
        completedCount: 0,
        loading: false,
      });
    }
  );
}

/**
 * Real-time subscription to all tickets created by a specific user (for dedicated My Tickets page)
 */
export function subscribeUserTickets(
  uid: string,
  callback: (tickets: Ticket[]) => void
): Unsubscribe {
  const ticketsQuery = query(
    collection(db, TICKETS_COLLECTION),
    where('creatorId', '==', uid)
  );

  return onSnapshot(
    ticketsQuery,
    (snap) => {
      const tickets = snap.docs.map((d) => {
        const data = d.data();
        const resolved = resolveTicketSection(data);
        return {
          id: d.id,
          ...data,
          section: resolved || data.section || 'student',
        } as Ticket;
      });
      // Sort newest first
      tickets.sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime());
      callback(tickets);
    },
    (err) => {
      console.error('Error in subscribeUserTickets:', err);
      callback([]);
    }
  );
}




