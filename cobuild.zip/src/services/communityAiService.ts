import { Community, ChallengeSubmission, CommunityMember, CommunityMessage, UserProfile } from '../types';
import { calculateLeaderboard } from './communityService';

/**
 * Generates an intelligent, contextual AI response tailored specifically to the active community
 */
export async function askCommunityAI(
  community: Community,
  user: UserProfile | null,
  submissions: ChallengeSubmission[],
  members: CommunityMember[],
  recentMessages: CommunityMessage[],
  userPrompt: string
): Promise<string> {
  const query = userPrompt.toLowerCase().trim();

  // If this is a challenge community (e.g. 90 DAY WINTER ARC)
  if (community.hasChallenge && community.challengeConfig) {
    const leaderboard = calculateLeaderboard(submissions, members);
    const userProgress = user ? leaderboard.find((p) => p.userId === user.uid) : null;
    const totalDays = community.challengeConfig.durationDays;
    const leader = leaderboard[0];

    // Question: How many days completed?
    if (query.includes('day') && (query.includes('completed') || query.includes('how many') || query.includes('progress'))) {
      if (!user) {
        return `You need to be logged in to track personal progress. In this ${totalDays}-day challenge, participants have submitted ${submissions.length} checkpoints in total so far!`;
      }
      const completed = userProgress?.completedDays || 0;
      const pct = Math.round((completed / totalDays) * 100);
      return `📊 **Your Challenge Progress Report:**\n\n• **Completed Days:** ${completed} of ${totalDays} days (${pct}% completion)\n• **Current Streak:** 🔥 ${userProgress?.currentStreak || 0} consecutive days\n• **Total Score:** ⭐ ${userProgress?.totalScore || 0} pts\n• **Current Leaderboard Rank:** #${userProgress?.rank || 'Unranked'}\n\nKeep pushing! Consistency is the only secret to finishing strong.`;
    }

    // Question: Current streak
    if (query.includes('streak')) {
      if (!user) return `Sign in to track your personal streak.`;
      return `🔥 **Your Active Streak:** ${userProgress?.currentStreak || 0} Days!\n\n${(userProgress?.currentStreak || 0) > 0 ? 'Amazing momentum! Submit your daily verifications before 11:59 PM to keep it alive.' : 'Submit today’s 4 verifications to start a fresh streak!'}`;
    }

    // Question: Who is leading / Leaderboard
    if (query.includes('leader') || query.includes('leading') || query.includes('rank') || query.includes('top')) {
      if (!leader) {
        return `No submissions yet! Be the very first participant to submit and claim the #1 spot on the leaderboard!`;
      }
      const top3 = leaderboard.slice(0, 3).map((p, idx) => `**#${idx + 1} ${p.userName}** — ${p.totalScore} pts (Streak: ${p.currentStreak}d, ${p.completedDays} days)`).join('\n');
      return `🏆 **Current Leaderboard Standings:**\n\n${top3}\n\n${userProgress ? `You are currently ranked **#${userProgress.rank}** with **${userProgress.totalScore} pts**.` : 'Join and start submitting to rank yourself!'}`;
    }

    // Question: Rules / Requirements
    if (query.includes('rule') || query.includes('requirement') || query.includes('how to submit')) {
      const reqList = community.challengeConfig.dailyRequirements.map((r, i) => `${i + 1}. **${r.title}** (${r.points} pts) — ${r.description}`).join('\n');
      return `📋 **${community.title} Rules & Daily Requirements:**\n\n${reqList}\n\n• **Scoring:** ${community.challengeConfig.scoringSystem}\n• **Rewards:** ${community.challengeConfig.rewards.map(r => r.title).join(', ')}`;
    }

    // Question: Summarize activity
    if (query.includes('summarize') || query.includes('activity') || query.includes('today')) {
      const today = new Date().toISOString().split('T')[0];
      const todaySubs = submissions.filter((s) => s.dateString === today);
      return `⚡ **Community Activity Summary:**\n\n• **Total Members:** ${members.length} participants\n• **Total Submissions to date:** ${submissions.length}\n• **Submissions Today:** ${todaySubs.length} entries submitted\n• **Top Performer:** ${leader ? `${leader.userName} (${leader.totalScore} pts)` : 'Open for grabs'}\n\nThe squad is moving with high energy! Check the Submissions tab to verify today’s checkpoints.`;
    }
  }

  // General or Open Community Context
  if (query.includes('summarize') || query.includes('discussion') || query.includes('what are people') || query.includes('struggling')) {
    if (recentMessages.length === 0) {
      return `Welcome to **${community.title}**! There haven't been any chat messages yet. Start the conversation by introducing yourself and sharing your current goals or projects.`;
    }

    const messageSenders = Array.from(new Set(recentMessages.map((m) => m.senderName)));
    const topics = community.tags.join(', ');
    return `📝 **Summary of Discussions in ${community.title}:**\n\n• **Active Contributors:** ${messageSenders.slice(0, 4).join(', ')}\n• **Key Community Focus:** ${topics || community.category}\n• **Recent Message Count:** ${recentMessages.length} real-time messages exchanged.\n\nMembers are actively sharing tips, resources, and collaborating. Drop a message in the Chat or Feed tab to get peer feedback!`;
  }

  if (query.includes('learning plan') || query.includes('roadmap') || query.includes('plan') || query.includes('guide')) {
    return `🎯 **Suggested 4-Week Action Plan for "${community.title}":**\n\n**Week 1: Fundamentals & Environment**\n• Complete profile setup and introduce yourself in the chat.\n• Review community guidelines and core tools (${community.tags.join(', ')}).\n\n**Week 2: Hands-on Practice & Sharing**\n• Share your first project draft or progress in the community feed.\n• Engage with at least 3 peer posts and offer constructive feedback.\n\n**Week 3: Collaborative Sprints**\n• Join a live session or propose a shared Build Space with another member.\n• Tackle intermediate problem sets and post file resources.\n\n**Week 4: Showcase & Milestone**\n• Present your completed work in the community showcase.\n• Celebrate learnings and earn community recognition badges!`;
  }

  // Default contextual helper response
  return `🤖 **KOBUILD Community AI for "${community.title}"**\n\nI am your real-time assistant for this space. Here is how I can assist you:\n\n• Ask *"How many days have I completed?"* or *"What is my streak?"* to check personal milestones.\n• Ask *"Who is leading the challenge?"* to view live rankings.\n• Ask *"Summarize recent discussions"* to catch up on squad messages.\n• Ask *"Create a learning plan"* for structured roadmaps.\n\nWhat would you like to explore?`;
}
