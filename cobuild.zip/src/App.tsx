/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { AppView, UserSection } from './types';
import { Navbar } from './components/Navbar';
import { HomePage } from './components/HomePage';
import { CommunitiesHub } from './components/community/CommunitiesHub';
import { ProfilePage } from './components/ProfilePage';
import { SectionOverview } from './components/SectionOverview';
import { MyTicketsView } from './components/MyTicketsView';
import { ChatsView } from './components/ChatsView';
import { BuildSpaceView } from './components/BuildSpaceView';
import { AuthModal } from './components/AuthModal';
import { ProfileModal } from './components/ProfileModal';
import { ProfileOnboarding } from './components/ProfileOnboarding';
import { decodeTicketShareParam, getSectionTicketById } from './services/userService';
import { Loader2 } from 'lucide-react';

const MainLayout: React.FC = () => {
  const { user, profileIncomplete, loading, setActiveSection } = useAuth();
  const [currentView, setCurrentView] = useState<AppView>('home');
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authTargetSection, setAuthTargetSection] = useState<UserSection | null>(null);
  const [profileModalOpen, setProfileModalOpen] = useState(false);
  const [initialCommunityId, setInitialCommunityId] = useState<string | null>(null);

  // Check URL query parameters for deep links on mount (e.g. ?community=... or ?ticket=...)
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const params = new URLSearchParams(window.location.search);
    const commParam = params.get('community') || params.get('c');
    const viewParam = params.get('view') as AppView | null;
    const sectionParam = params.get('section') as UserSection | null;
    const ticketParam = params.get('ticket') || params.get('ticketId') || params.get('t');

    if (commParam) {
      setInitialCommunityId(commParam);
      setCurrentView('communities');
    } else if (viewParam === 'collab') {
      const target = sectionParam && ['student', 'homemaker', 'entrepreneur'].includes(sectionParam) ? sectionParam : 'student';
      setActiveSection(target);
      setCurrentView(target);
    } else if (viewParam) {
      setCurrentView(viewParam);
    } else if (sectionParam && ['student', 'homemaker', 'entrepreneur'].includes(sectionParam)) {
      setActiveSection(sectionParam);
      setCurrentView(sectionParam);
    } else if (ticketParam) {
      const decodedId = decodeTicketShareParam(ticketParam);
      if (decodedId) {
        getSectionTicketById(decodedId).then((t) => {
          if (t && t.section) {
            setActiveSection(t.section);
            setCurrentView(t.section);
          }
        });
      }
    }
  }, []);

  const handleNavigate = (view: AppView, section?: UserSection) => {
    if (section) {
      setActiveSection(section);
      setCurrentView(section);
    } else if (view === 'student' || view === 'homemaker' || view === 'entrepreneur') {
      setActiveSection(view);
      setCurrentView(view);
    } else if (view === 'collab') {
      const target = 'student';
      setActiveSection(target);
      setCurrentView(target);
    } else {
      setCurrentView(view);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenAuth = (section: UserSection | null = null) => {
    setAuthTargetSection(section);
    setAuthModalOpen(true);
  };

  const handleOpenProfile = () => {
    setCurrentView('profile');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#FAF8F3]">
        <div className="flex flex-col items-center gap-3">
          <Loader2 className="h-7 w-7 animate-spin text-[#E8491D]" />
          <p className="text-xs font-semibold tracking-wider text-[#8A8578] uppercase">Connecting to KOBUILD...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#FAF8F3] text-[#55524A] flex flex-col antialiased selection:bg-[#FDE4D8] selection:text-[#E8491D]">
      <Navbar
        currentView={currentView}
        onNavigate={handleNavigate}
        onOpenAuth={handleOpenAuth}
        onOpenProfile={handleOpenProfile}
      />

      <main className="flex-1">
        {/* If user is logged in but hasn't completed their initial Firestore profile */}
        {user && profileIncomplete ? (
          <ProfileOnboarding lockedSection={authTargetSection} />
        ) : (
          <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
            {currentView === 'home' && (
              <HomePage
                onNavigate={handleNavigate}
                onOpenAuth={handleOpenAuth}
              />
            )}

            {(currentView === 'communities' || currentView === 'community') && (
              <CommunitiesHub
                initialCommunityId={initialCommunityId}
                onOpenAuth={handleOpenAuth}
                onNavigate={handleNavigate}
              />
            )}

            {currentView === 'chats' && (
              <ChatsView
                onOpenAuth={handleOpenAuth}
                onNavigate={handleNavigate}
              />
            )}

            {(currentView === 'build_spaces' || currentView === 'build_space' || currentView === 'buildspace') && (
              <BuildSpaceView
                onOpenAuth={handleOpenAuth}
                onNavigate={handleNavigate}
              />
            )}

            {currentView === 'profile' && (
              <ProfilePage
                onOpenEditProfile={() => setProfileModalOpen(true)}
                onNavigate={handleNavigate}
              />
            )}

            {currentView === 'my-tickets' && (
              <MyTicketsView
                onNavigate={handleNavigate}
                onOpenAuth={handleOpenAuth}
              />
            )}

            {(currentView === 'student' || currentView === 'homemaker' || currentView === 'entrepreneur' || currentView === 'collab') && (
              <SectionOverview
                onOpenAuth={handleOpenAuth}
                onOpenProfile={() => setProfileModalOpen(true)}
                onNavigate={handleNavigate}
              />
            )}
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-[#E5E2DA] bg-[#F2EFE6] py-6 mt-auto">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-3 px-4 text-xs text-[#8A8578] sm:flex-row sm:px-6 lg:px-8">
          <p className="tracking-tight font-medium">© {new Date().getFullYear()} KOBUILD. Open Collaboration &amp; Challenge Network.</p>
          <div className="flex items-center gap-4 font-medium tracking-wide">
            <button onClick={() => handleNavigate('home')} className="hover:text-[#1A1A1A] transition-colors">Home</button>
            <span className="text-[#D4D0C5]">•</span>
            <button onClick={() => handleNavigate('communities')} className="hover:text-[#1A1A1A] transition-colors">Communities</button>
            <span className="text-[#D4D0C5]">•</span>
            <button onClick={() => handleNavigate('student', 'student')} className="hover:text-[#1A1A1A] transition-colors">Collab</button>
            <span className="text-[#D4D0C5]">•</span>
            <button onClick={() => handleNavigate('chats')} className="hover:text-[#1A1A1A] transition-colors">Chats</button>
            <span className="text-[#D4D0C5]">•</span>
            <button onClick={() => handleNavigate('build_spaces')} className="hover:text-[#1A1A1A] transition-colors">Build Spaces</button>
          </div>
        </div>
      </footer>

      {/* Auth Modal with target section lock support */}
      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        targetSection={authTargetSection}
      />

      {/* Profile Edit Modal */}
      <ProfileModal
        isOpen={profileModalOpen}
        onClose={() => setProfileModalOpen(false)}
      />
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <MainLayout />
    </AuthProvider>
  );
}
