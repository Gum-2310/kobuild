import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import firebaseConfigData from '../../firebase-applet-config.json';

const firebaseConfig = {
  apiKey: firebaseConfigData.apiKey,
  authDomain: firebaseConfigData.authDomain,
  projectId: firebaseConfigData.projectId,
  storageBucket: firebaseConfigData.storageBucket,
  messagingSenderId: firebaseConfigData.messagingSenderId,
  appId: firebaseConfigData.appId,
  measurementId: firebaseConfigData.measurementId || undefined,
};

const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();

export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: 'select_account' });

// Explicitly initialize Firestore with the dedicated database ID: ai-studio-cobuild-a6189f79-6694-42b2-8e53-cb0d47c5eb68
const FIRESTORE_DATABASE_ID =
  firebaseConfigData.firestoreDatabaseId || 'ai-studio-cobuild-a6189f79-6694-42b2-8e53-cb0d47c5eb68';

export const db = getFirestore(app, FIRESTORE_DATABASE_ID);

export default app;
