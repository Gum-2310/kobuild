export type PreferredTrack = 'student' | 'homemaker' | 'entrepreneur' | 'community' | 'none';

export type UserSection = 'student' | 'homemaker' | 'entrepreneur';

export type AppView =
  | 'home'
  | 'communities'
  | 'community'
  | 'collab'
  | 'chats'
  | 'build_spaces'
  | 'build_space'
  | 'buildspace'
  | 'student'
  | 'homemaker'
  | 'entrepreneur'
  | 'profile'
  | 'my-tickets';

export interface UserProfile {
  uid: string;
  name: string;
  email: string;
  photoURL?: string | null;
  role?: 'admin' | 'user'; // User role: 'admin' for platform owners/admins, 'user' for standard members
  isPlatformAdmin?: boolean; // Convenience flag for platform administration
  section?: UserSection | null; // Optional for backward compatibility; not mandatory for user accounts
  preferredTrack?: PreferredTrack | null; // Optional preferred track
  location?: string;
  skills?: string[];
  interests?: string[];
  bio?: string;
  createdAt: string;
  updatedAt: string;
}

export type TicketStatus = 'open' | 'in_progress' | 'closed';

export interface Ticket {
  id: string;
  creatorId: string;
  creatorName: string;
  creatorPhotoURL?: string | null;
  creatorSection?: UserSection;
  creatorLocation?: string;
  creatorBio?: string;
  section: UserSection;
  title: string;
  description: string;
  category?: string;
  skillsRequired: string[];
  peopleNeeded: number;
  deadline?: string;
  location: string;
  status: TicketStatus;
  interestedCount?: number;
  applicationsCount?: number;
  buildSpaceId?: string;
  createdAt: string;
  updatedAt: string;
}

export interface TeamRequirement {
  role: string;
  count: number;
}

export interface CommunityPost {
  id: string;
  ticketId?: string;
  ticketSection?: UserSection;
  creatorId: string;
  creatorName: string;
  creatorPhotoURL?: string | null;
  creatorSection: UserSection;
  creatorLocation?: string;
  title: string;
  description: string;
  category: string;
  tags: string[];
  status: 'idea' | 'discussing' | 'validating' | 'building' | 'build_space_active';
  upvotesCount: number;
  commentsCount: number;
  interestedCount?: number;
  buildRequestsCount?: number;
  shortlistedCount?: number;
  buildSpaceId?: string;
  teamRequirements?: TeamRequirement[];
  targetTeamSize?: number;
  createdAt: string;
  updatedAt: string;
}

export interface Comment {
  id: string;
  postId: string;
  userId: string;
  userName: string;
  userPhotoURL?: string | null;
  userSection?: UserSection;
  parentCommentId: string | null;
  content: string;
  createdAt: string;
  updatedAt: string;
}

export interface BuildRequest {
  id: string;
  postId: string;
  postTitle: string;
  applicantId: string;
  applicantName: string;
  applicantPhotoURL?: string | null;
  applicantSection: UserSection;
  applicantLocation?: string;
  applicantBio?: string;
  message: string;
  skills: string[];
  status: 'interested' | 'shortlisted' | 'rejected' | 'accepted';
  createdAt: string;
  updatedAt: string;
}

export type BuildSpaceRole = 'lead' | 'member';

export interface BuildSpaceMember {
  id: string;
  buildSpaceId: string;
  userId: string;
  userName: string;
  userPhotoURL?: string | null;
  userSection: UserSection;
  role: BuildSpaceRole;
  skills: string[];
  joinedAt: string;
}

export type BuildSpaceStatus = 'forming' | 'building' | 'deployed' | 'showcase';

export interface BuildSpace {
  id: string;
  ticketId?: string;
  ticketCreatorId?: string;
  originIdeaId?: string;
  leadId: string;
  leadName: string;
  title: string;
  description: string;
  category: string;
  section?: UserSection;
  status: BuildSpaceStatus;
  memberCount: number;
  memberIds?: string[];
  repositoryUrl?: string;
  deploymentUrl?: string;
  createdAt: string;
  updatedAt: string;
}

export interface BuildSpaceTask {
  id: string;
  buildSpaceId: string;
  title: string;
  assigneeId?: string;
  assigneeName?: string;
  status: 'todo' | 'in_progress' | 'done';
  createdAt: string;
  updatedAt: string;
}

export interface ConversationParticipantDetail {
  name: string;
  photoURL?: string | null;
  section?: UserSection;
  location?: string;
  bio?: string;
  skills?: string[];
}

export interface ConversationContext {
  type: 'post' | 'ticket' | 'comment' | 'build_space' | 'direct';
  id?: string;
  title: string;
  note?: string;
  section?: UserSection;
}

export interface Conversation {
  id: string;
  type: 'direct' | 'build_space';
  buildSpaceId?: string;
  title?: string;
  participants: string[];
  participantNames?: Record<string, string>;
  participantDetails?: Record<string, ConversationParticipantDetail>;
  context?: ConversationContext;
  lastMessage?: string;
  lastMessageSenderId?: string;
  lastMessageAt?: string;
  unreadCounts?: Record<string, number>;
  createdAt: string;
  updatedAt: string;
}

export interface ChatMessage {
  id: string;
  conversationId: string;
  senderId: string;
  senderName: string;
  senderPhotoURL?: string | null;
  senderSection?: UserSection;
  text: string;
  contextNote?: string;
  readBy?: string[];
  createdAt: string;
}

export interface UserContribution {
  id: string;
  title: string;
  type: 'project_ticket' | 'community_idea' | 'community_poll' | 'collaboration' | 'build_space';
  typeLabel: string;
  status: string;
  section?: UserSection;
  createdAt: string;
  engagement?: string;
}

export interface UserStats {
  ideasCreated: number;
  projectsCreated: number;
  collaborations: number;
  communityPosts: number;
  peopleConnected: number;
  buildSpacesJoined?: number;
}

export type ApplicationStatus = 'pending' | 'accepted' | 'rejected';

export interface Application {
  id: string;
  ticketId: string;
  ticketTitle?: string;
  ticketSection?: UserSection;
  applicantId: string;
  applicantName: string;
  applicantPhotoURL?: string | null;
  applicantSection?: UserSection;
  applicantLocation?: string;
  applicantBio?: string;
  skills?: string[];
  message: string;
  status: ApplicationStatus;
  createdAt: string;
  updatedAt: string;
}

export interface AppNotification {
  id: string;
  userId: string; // Target recipient user UID
  type: 'interest' | 'want_to_build' | 'message' | 'comment' | 'reply' | 'application' | 'build_space' | 'system';
  title: string;
  message: string;
  read: boolean;
  senderId?: string;
  senderName?: string;
  senderPhotoURL?: string | null;
  senderSection?: UserSection;
  relatedTicketId?: string;
  relatedPostId?: string;
  relatedBuildSpaceId?: string;
  relatedConversationId?: string;
  contextTitle?: string;
  createdAt: string;
}

export interface ActiveBuildItem {
  id: string;
  title: string;
  status: string;
  memberCount: number;
  role?: string;
  category?: string;
  source: 'build_space' | 'ticket' | 'application';
  updatedAt?: string;
}

export interface UserCobuildActivityData {
  ideasPosted: number;
  peopleInterested: number;
  projectsJoined: number;
  projectsCompleted: number;
  activeBuildSpacesCount: number;
  currentBuilds: ActiveBuildItem[];
  loading: boolean;
}

export interface SectionPublicActivityStats {
  activeCount: number;
  openRequestsCount: number;
  loading: boolean;
}

export interface UserCommunityTicketActivity {
  activeTicketsCount: number;
  topLikedTicket: {
    id: string;
    title: string;
    likesCount: number;
  } | null;
  currentlyWorkingCount: number;
  completedCount: number;
  loading: boolean;
}

// ----------------------------------------------------
// KOBUILD & OPEN COMMUNITIES MODEL
// ----------------------------------------------------

export type CommunityType = 'kobuild_official' | 'open';

export type CommunityCategory =
  | 'challenge'
  | 'competition'
  | 'learning'
  | 'fitness'
  | 'coding'
  | 'ai'
  | 'hackathon'
  | 'interests'
  | 'hobbies'
  | 'skills'
  | 'local'
  | 'networking'
  | 'general';

export interface ChallengeRequirement {
  id: string;
  title: string;
  description: string;
  type: 'photo' | 'text' | 'file' | 'link' | 'metric';
  points: number;
  requiredCount?: number;
}

export interface ChallengeConfig {
  startDate: string; // ISO String
  endDate: string; // ISO String
  durationDays: number;
  rules: string[];
  dailyRequirements: ChallengeRequirement[]; // e.g. 4 photos: Breakfast, Lunch, Dinner, Daily progress
  scoringSystem: string;
  rewards: {
    title: string;
    description: string;
    badgeIcon?: string;
  }[];
}

export interface Community {
  id: string;
  type: CommunityType; // 'kobuild_official' | 'open'
  title: string;
  description: string;
  category: CommunityCategory;
  coverImage?: string;
  creatorId: string;
  creatorName: string;
  creatorPhotoURL?: string | null;
  creatorBio?: string;
  rules: string[];
  tags: string[];
  location?: string;
  isPrivate: boolean;
  requireApproval: boolean;
  memberCount: number;
  activeCount?: number;
  featured?: boolean;
  trending?: boolean;
  // Challenge features
  hasChallenge?: boolean;
  challengeConfig?: ChallengeConfig;
  createdAt: string;
  updatedAt: string;
}

export type CommunityRole = 'creator' | 'admin' | 'moderator' | 'member';

export interface CommunityMember {
  id: string;
  communityId: string;
  userId: string;
  userName: string;
  userPhotoURL?: string | null;
  userBio?: string;
  userSkills?: string[];
  role: CommunityRole;
  joinedAt: string;
  avatarId?: string; // Community-specific 3D arena avatar selection
  avatarModelUrl?: string;
  updatedAt?: string;
}

export interface ArenaAvatarOption {
  id: string;
  name: string;
  badge: string;
  description: string;
  glbUrl: string;
  previewColor: string;
  physique: string;
  features: string[];
}

export const AVAILABLE_ARENA_AVATARS: ArenaAvatarOption[] = [
  {
    id: 'M01',
    name: 'Avatar 1',
    badge: 'Avatar 1 • Official GLB',
    description: 'Textured PBR athletic model in performance tank and training shorts. Calibrated for coliseum center-podium positioning.',
    glbUrl: 'https://raw.githubusercontent.com/Gum-2310/kobuild/main/Meshy_AI_Athletic_Young_Man_0908082025_texture.glb',
    previewColor: '#E8491D',
    physique: 'Sculpted Athletic • 1.88m',
    features: ['7.87 MB Textured GLB', 'Full PBR Shading', 'Center Podium Ready'],
  },
  {
    id: 'M02',
    name: 'Avatar 2',
    badge: 'Avatar 2 • Official GLB',
    description: 'Textured PBR athletic competitor model with distinct styling, athletic stance, and full physical geometry.',
    glbUrl: 'https://raw.githubusercontent.com/Gum-2310/kobuild/main/2nd%20one.glb',
    previewColor: '#3B82F6',
    physique: 'Dynamic Competitor • 1.88m',
    features: ['6.05 MB Textured GLB', 'Full PBR Shading', 'Arena Calibrated'],
  },
];

export type JoinRequestStatus = 'pending' | 'accepted' | 'rejected';

export interface CommunityJoinRequest {
  id: string;
  communityId: string;
  communityTitle?: string;
  userId: string;
  userName: string;
  userPhotoURL?: string | null;
  userBio?: string;
  userSkills?: string[];
  message: string;
  status: JoinRequestStatus;
  createdAt: string;
  updatedAt: string;
}

export interface CommunityFeedPost {
  id: string;
  communityId: string;
  authorId: string;
  authorName: string;
  authorPhotoURL?: string | null;
  authorRole?: string;
  title?: string;
  content: string;
  mediaUrls?: {
    url: string;
    type: 'image' | 'video' | 'file';
    name?: string;
  }[];
  reactions?: Record<string, string[]>; // reactionType -> array of userIds
  commentsCount: number;
  createdAt: string;
  updatedAt: string;
}

export interface CommunityFeedComment {
  id: string;
  postId: string;
  communityId: string;
  authorId: string;
  authorName: string;
  authorPhotoURL?: string | null;
  content: string;
  createdAt: string;
}

export interface CommunityMessage {
  id: string;
  communityId: string;
  senderId: string;
  senderName: string;
  senderPhotoURL?: string | null;
  senderRole?: string;
  text: string;
  mediaUrl?: string;
  mediaType?: 'image' | 'video' | 'file';
  fileName?: string;
  fileSize?: string;
  replyTo?: {
    id: string;
    senderName: string;
    text: string;
  } | null;
  reactions?: Record<string, string[]>; // emoji/type -> array of UIDs
  createdAt: string;
}

export interface CommunityFile {
  id: string;
  communityId: string;
  uploadedBy: string;
  uploaderName: string;
  uploaderPhotoURL?: string | null;
  name: string;
  size: string;
  type: 'document' | 'image' | 'video' | 'archive' | 'code' | 'other';
  url: string;
  createdAt: string;
}

export interface LiveSessionParticipant {
  userId: string;
  userName: string;
  photoURL?: string | null;
  isAudioOn: boolean;
  isVideoOn: boolean;
  isScreenSharing?: boolean;
  joinedAt: string;
}

export interface CommunityLiveSession {
  id: string;
  communityId: string;
  hostId: string;
  hostName: string;
  hostPhotoURL?: string | null;
  title: string;
  active: boolean;
  participants: LiveSessionParticipant[];
  startedAt: string;
  endedAt?: string;
}

export interface ChallengeSubmissionItem {
  requirementId: string;
  title: string;
  type: 'photo' | 'text' | 'file' | 'link' | 'metric';
  content: string; // url, image base64, or text note
  previewUrl?: string;
}

export interface ChallengeSubmission {
  id: string;
  communityId: string;
  userId: string;
  userName: string;
  userPhotoURL?: string | null;
  dayNumber: number;
  dateString: string; // YYYY-MM-DD
  items: ChallengeSubmissionItem[];
  status: 'submitted' | 'verified';
  pointsEarned: number;
  submittedAt: string;
}

export interface ChallengeParticipantProgress {
  userId: string;
  userName: string;
  userPhotoURL?: string | null;
  currentStreak: number;
  completedDays: number;
  totalScore: number;
  rank?: number;
  lastSubmissionDate?: string;
  badges: string[];
}




