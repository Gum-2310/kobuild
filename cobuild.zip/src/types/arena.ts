/**
 * 3D Virtual Arena Types for 90 Day Winter Arc and future multi-avatar leaderboards.
 * Designed to cleanly scale from 1 participant (Rank #1 Center) to 20-30 and eventually 100-150 participants.
 */

export interface ArenaParticipant {
  participantId: string;
  userId: string;
  avatarId: string;
  userName: string;
  userPhotoURL?: string | null;
  score: number;
  rank: number;
  streak: number;
  progress: number; // e.g. current day completed (24)
  position?: [number, number, number]; // [x, y, z] in the 3D world
  rotationY?: number;
  isCurrentUser?: boolean;
  avatarModelUrl?: string;
  tierBadge?: string;
}

export interface ArenaState {
  participants: ArenaParticipant[];
  activeParticipantId: string | null;
  isLoading: boolean;
  loadProgress: number;
  error: string | null;
  isDragging: boolean;
  cameraResetTrigger: number;
  isFullscreen: boolean;
}

export interface ArenaCameraPreset {
  position: [number, number, number];
  target: [number, number, number];
  fov: number;
}

/**
 * Future Scalability Formation Calculator:
 * Maps rank to physical 3D amphitheater coordinates:
 * - Rank #1: Center podium [0, 0, 0]
 * - Rank #2 to #10: First concentric ring (radius = 4.2m)
 * - Rank #11 to #30: Second concentric ring (radius = 7.2m, step Y = 0.42m)
 * - Rank #31 to #150: Outer amphitheater seating tiers
 */
export function getArenaPositionForRank(rank: number): [number, number, number] {
  if (rank <= 1) {
    return [0, 0, 0]; // Exact center podium
  }
  if (rank <= 10) {
    const angle = ((rank - 2) / 9) * Math.PI * 2;
    const r = 4.2;
    return [Math.sin(angle) * r, 0, Math.cos(angle) * r];
  }
  if (rank <= 30) {
    const angle = ((rank - 11) / 20) * Math.PI * 2;
    const r = 7.2;
    return [Math.sin(angle) * r, 0.42, Math.cos(angle) * r];
  }
  const tierIndex = Math.floor((rank - 31) / 30);
  const indexInTier = (rank - 31) % 30;
  const r = 9.6 + tierIndex * 2.4;
  const y = (tierIndex + 2) * 0.42;
  const angle = (indexInTier / 30) * Math.PI * 2;
  return [Math.sin(angle) * r, y, Math.cos(angle) * r];
}
